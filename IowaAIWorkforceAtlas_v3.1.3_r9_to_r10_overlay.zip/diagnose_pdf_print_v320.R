# Iowa AI Workforce Atlas v3.1.3-clean-r10 browser-PDF diagnostic.
root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
version <- trimws(readLines(file.path(root, "VERSION"), warn = FALSE)[[1L]])
stopifnot(identical(version, "3.1.3-clean-r10"))
source(file.path(root, "R", "45_one_click_orchestrator_v312.R"), local = .GlobalEnv)
source(file.path(root, "R", "48_browser_pdf_completion_v319.R"), local = .GlobalEnv)
cat("Active PDF printer revision: ", attr(atlas_v312_print_html_pdf_with_fallback, "atlas_pdf_revision", exact = TRUE), "\n", sep = "")
cat("Browser candidates:\n")
print(atlas_v318_browser_candidates(NULL))
status_path <- file.path(root, "outputs", "pdf_print_status_v320.csv")
if (file.exists(status_path)) {
  cat("\nRecent PDF attempts:\n")
  status <- utils::read.csv(status_path, stringsAsFactors = FALSE)
  print(utils::tail(status, 12L), row.names = FALSE)
}
cat("\nLogs: outputs/pdf_logs_v320/\n")
