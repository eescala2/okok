# Iowa AI Workforce Atlas v3.1.3-clean-r10 validation report

## Observed Windows failure

Windows Chrome produced two PDF candidates of 469,397 and 465,580 bytes. The
full run had sourced the legacy R/43 printer after the revision-9 stable-file
printer. The legacy validator rejected each candidate only because it imposed a
fixed 500,000-byte minimum. Analytics, figures, and all four HTML reports had
already completed before this publication-stage rejection.

## Repair

- The current stable-file printer is sourced after R/43 during bootstrap and is
  reactivated again immediately before Stage 5.
- A revision attribute is verified before any browser process starts.
- PDF validity now depends on `%PDF-`, terminal `%%EOF`, `pdftools` parseability,
  page count, and content checks. File size is only a low corruption floor.
- Report publication uses a 65,536-byte floor; final compendium validation uses
  32,768 bytes. Neither can reject the observed 465-469 KB Windows PDFs merely
  because of platform-specific compression.
- Browser timeouts use `IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS` and are capped at
  240 seconds per attempt.
- The local OEWS reader searches nonstandard header rows, recognizes custom Iowa
  wage-workbook column names, and can identify a SOC column from its values.
- `IA_ATLAS_IGNORE_LOCAL_OEWS=true` bypasses an unrelated local workbook and uses
  the official BLS download/cached fallback.

## Static and archive validation

Revision 10 was checked for balanced R delimiters and strings, YAML parsing, CSV
row widths, source-order contracts, fixed-threshold removal, known-secret and
absolute-home-path leakage, internal manifest integrity, ZIP CRC/path safety,
overlay/full-tree equality, and byte-for-byte extraction. An independently
parsed ten-page PDF of 6,661 bytes demonstrates why a fixed 500 KB rule is not a
valid structural test.

## Runtime tests included

The R 4.4.0 smoke test simulates the exact source-order regression, restores the
current printer, validates a ten-page PDF below 500 KB, and parses a synthetic
workbook using `Standard Occupational Classification Code`, `Occupation`, and
`Estimated Employment`. The target Windows browser and the user's actual local
OEWS workbook remain target-environment tests; no claim is made that Windows R
was executed in the Linux packaging environment.
