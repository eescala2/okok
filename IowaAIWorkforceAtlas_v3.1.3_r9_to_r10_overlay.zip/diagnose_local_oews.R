# Diagnose local OEWS workbooks without running the Atlas.
root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
source(file.path(root, "R", "00_setup.R"))
activate_atlas_package_library()
source(file.path(root, "R", "01_lwda_crosswalk.R"))
source(file.path(root, "R", "02_data_download.R"))
files <- find_local_oews_workbooks(load_config())
if (!length(files)) {
  message("No candidate local OEWS workbook was found. The Atlas will use the official BLS download/fallback.")
} else {
  results <- lapply(files, function(path) {
    tryCatch({
      raw <- read_oews_workbook(path)
      code_shares <- sort(vapply(raw, atlas_oews_soc_share, numeric(1L)), decreasing = TRUE)
      data.frame(
        file = normalizePath(path, winslash = "/", mustWork = TRUE),
        parsed = TRUE,
        rows = nrow(raw),
        columns = ncol(raw),
        likely_soc_column = if (length(code_shares)) names(code_shares)[[1L]] else "",
        likely_soc_share = if (length(code_shares)) unname(code_shares[[1L]]) else 0,
        discovered_columns = paste(names(raw), collapse = " | "),
        error = "",
        stringsAsFactors = FALSE
      )
    }, error = function(e) data.frame(
      file = normalizePath(path, winslash = "/", mustWork = FALSE),
      parsed = FALSE,
      rows = NA_integer_,
      columns = NA_integer_,
      likely_soc_column = "",
      likely_soc_share = NA_real_,
      discovered_columns = "",
      error = conditionMessage(e),
      stringsAsFactors = FALSE
    ))
  })
  results <- do.call(rbind, results)
  dir.create(file.path(root, "outputs"), recursive = TRUE, showWarnings = FALSE)
  output <- file.path(root, "outputs", "local_oews_workbook_diagnostic_v320.csv")
  utils::write.csv(results, output, row.names = FALSE, na = "")
  print(results, row.names = FALSE)
  message("Wrote: ", output)
}
