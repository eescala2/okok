# 02_data_download.R ---------------------------------------------------------
# Public data download/read functions for BLS OEWS, BLS National Employment
# Matrix, Census ACS, Census LEHD QWI/LODES, O*NET, AIOE, and TIGER/Line.

source(file.path(project_root(), 'R', '00_setup.R'))
source(file.path(project_root(), 'R', '01_lwda_crosswalk.R'))

get_county_shapes <- function(cfg = load_config(), refresh = FALSE) {
  p <- paths()
  out <- file.path(p$processed, 'iowa_county_shapes.gpkg')
  if (file.exists(out) && !refresh) return(sf::st_read(out, quiet = TRUE))
  options(tigris_use_cache = TRUE)
  shp <- tigris::counties(state = cfg$state_fips, cb = TRUE, year = 2024, class = 'sf') |>
    janitor::clean_names() |>
    dplyr::mutate(
      county_fips = geoid,
      county_name = stringr::str_remove(name, ' County$'),
      county_name_key = stringr::str_to_lower(county_name)
    ) |>
    dplyr::select(county_fips, county_name, county_name_key, geometry)
  sf::st_write(shp, out, quiet = TRUE, append = FALSE)
  shp
}

get_acs_county_demographics <- function(cfg = load_config(), refresh = FALSE) {
  p <- paths()
  out <- file.path(p$processed, 'acs_county_demographics.csv')
  if (file.exists(out) && !refresh) return(readr::read_csv(out, show_col_types = FALSE))
  key <- Sys.getenv('CENSUS_API_KEY')
  if (nzchar(key)) tidycensus::census_api_key(key, install = FALSE, overwrite = TRUE)

  vars <- c(
    pop = 'B01003_001',
    med_hh_income = 'B19013_001',
    total_25plus = 'B15003_001',
    bach = 'B15003_022',
    masters = 'B15003_023',
    professional = 'B15003_024',
    doctorate = 'B15003_025'
  )
  x <- tryCatch({
    tidycensus::get_acs(
      geography = 'county', state = cfg$state_fips, variables = vars,
      year = cfg$acs_year, survey = 'acs5', output = 'wide', cache_table = TRUE
    ) |>
      janitor::clean_names() |>
      dplyr::transmute(
        county_fips = geoid,
        county_name = stringr::str_remove(name, ' County, Iowa'),
        population = pop_e,
        median_household_income = med_hh_income_e,
        share_bachelors_plus = (bach_e + masters_e + professional_e + doctorate_e) / total_25plus_e
      )
  }, error = function(e) {
    warning('ACS download failed: ', conditionMessage(e), call. = FALSE)
    tibble::tibble(county_fips = character(), county_name = character())
  })
  readr::write_csv(x, out)
  x
}


# ---- Local/manual BLS OEWS support ---------------------------------------
# BLS occasionally blocks scripted downloads of the May OEWS special-request
# ZIP files. If the official workbooks have been downloaded manually, place them
# in the project root, inputs/, data_raw/, data_raw/oews/, data_raw/oews_manual/,
# or ~/Downloads. The parser will use state_M2025_dl.xlsx first and then
# all_data_M_2025.xlsx as a fallback before attempting any network download.
find_local_oews_workbooks <- function(cfg = load_config()) {
  ignore_local <- tolower(trimws(Sys.getenv('IA_ATLAS_IGNORE_LOCAL_OEWS', unset = 'false'))) %in% c('1','true','yes','y','on')
  if (ignore_local) {
    message('Skipping local OEWS workbook discovery because IA_ATLAS_IGNORE_LOCAL_OEWS=true.')
    return(character())
  }
  p <- paths()
  dirs <- unique(c(
    p$root,
    p$inputs,
    p$raw,
    file.path(p$raw, 'oews'),
    file.path(p$raw, 'oews_manual'),
    file.path(p$raw, 'bls_oews'),
    path.expand('~/Downloads')
  ))
  dirs <- dirs[dir.exists(dirs)]
  if (!length(dirs)) return(character())

  files <- unique(unlist(lapply(dirs, function(d) {
    list.files(d, pattern = '\\.(xlsx|xlsm|xls)$', full.names = TRUE, ignore.case = TRUE)
  }), use.names = FALSE))
  if (!length(files)) return(character())

  yy <- stringr::str_sub(as.character(cfg$oews_year), -2)
  yr <- as.character(cfg$oews_year)
  base <- tolower(basename(files))
  keep <- stringr::str_detect(base, paste0(
    '(^state_m', yr, '_dl\\.xlsx$)|',
    '(^state_m', yy, '.*\\.xlsx$)|',
    '(^all_data_m_', yr, '\\.(xlsx|xlsm|xls)$)|',
    '(^all_data_m_', yy, '.*\\.xlsx$)|',
    '(^oesm', yy, '(st|all).*\\.(xlsx|xlsm|xls)$)|',
    '(oews.*', yr, '.*\\.(xlsx|xlsm|xls)$)'
  ))
  files <- files[keep]
  if (!length(files)) return(character())

  score <- rep(50, length(files))
  b <- tolower(basename(files))
  score[b == paste0('state_m', yr, '_dl.xlsx')] <- 1
  score[b == paste0('state_m', yy, '_dl.xlsx')] <- 2
  score[stringr::str_detect(b, paste0('^state_m', yr, '|^state_m', yy))] <- pmin(score[stringr::str_detect(b, paste0('^state_m', yr, '|^state_m', yy))], 3)
  score[b == paste0('all_data_m_', yr, '.xlsx')] <- 10
  score[stringr::str_detect(b, paste0('^all_data_m_', yr, '|^all_data_m_', yy))] <- pmin(score[stringr::str_detect(b, paste0('^all_data_m_', yr, '|^all_data_m_', yy))], 11)
  score[stringr::str_detect(b, paste0('^oesm', yy, 'st'))] <- pmin(score[stringr::str_detect(b, paste0('^oesm', yy, 'st'))], 20)
  score[stringr::str_detect(b, paste0('^oesm', yy, 'all'))] <- pmin(score[stringr::str_detect(b, paste0('^oesm', yy, 'all'))], 21)
  files[order(score, b)]
}

atlas_oews_soc_share <- function(x) {
  x <- stringr::str_squish(as.character(x))
  x <- stringr::str_replace(x, "[.]0+$", "")
  x <- stringr::str_replace_all(x, "[^0-9-]", "")
  ok <- stringr::str_detect(x, "^\\d{2}-?\\d{4}$")
  denom <- sum(!is.na(x) & nzchar(x))
  if (!denom) return(0)
  sum(ok, na.rm = TRUE) / denom
}

atlas_oews_header_score <- function(values) {
  values <- tolower(stringr::str_squish(as.character(values)))
  values <- values[!is.na(values) & nzchar(values)]
  if (!length(values)) return(0)
  text <- paste(values, collapse = " | ")
  6 * as.integer(grepl("soc|occupational classification|occupation code|occ code", text)) +
    5 * as.integer(grepl("occupation|occupational title|job title", text)) +
    5 * as.integer(grepl("employment|jobs", text)) +
    2 * as.integer(grepl("wage|hourly|annual|mean|median", text)) +
    sum(grepl("soc|occupation|employment|wage|hourly|annual", values))
}

atlas_oews_candidate_score <- function(x) {
  if (is.null(x) || !nrow(x) || !ncol(x)) return(-Inf)
  nms <- names(x)
  name_score <- sum(stringr::str_detect(
    nms,
    "soc|occ|occupation|occupational|employment|jobs|wage|hourly|annual|tot_emp|h_mean|a_mean|area|naics"
  ))
  shares <- vapply(x, atlas_oews_soc_share, numeric(1L))
  2 * name_score + 25 * max(shares, na.rm = TRUE) + log1p(nrow(x))
}

read_oews_workbook <- function(path, max_header_rows = 40L) {
  sheets <- tryCatch(readxl::excel_sheets(path), error = function(e) character())
  if (!length(sheets)) stop("Could not read Excel workbook sheets: ", path, call. = FALSE)

  tries <- list()
  k <- 1L
  for (sheet in sheets) {
    # Fast path for ordinary BLS workbooks.
    tries[[k]] <- list(sheet = sheet, skip = 0L)
    k <- k + 1L

    preview <- tryCatch(
      suppressMessages(readxl::read_excel(
        path,
        sheet = sheet,
        col_names = FALSE,
        n_max = max_header_rows,
        .name_repair = "minimal"
      )),
      error = function(e) NULL
    )
    if (is.null(preview) || !nrow(preview)) next

    scores <- vapply(
      seq_len(nrow(preview)),
      function(i) atlas_oews_header_score(unlist(preview[i, , drop = FALSE], use.names = FALSE)),
      numeric(1L)
    )
    candidate_rows <- order(scores, decreasing = TRUE)
    candidate_rows <- candidate_rows[scores[candidate_rows] >= 8]
    candidate_rows <- utils::head(candidate_rows, 4L)
    for (row in candidate_rows) {
      tries[[k]] <- list(sheet = sheet, skip = as.integer(row - 1L))
      k <- k + 1L
    }
  }

  keys <- vapply(tries, function(x) paste(x$sheet, x$skip, sep = "::"), character(1L))
  tries <- tries[!duplicated(keys)]
  best <- NULL
  best_score <- -Inf
  best_meta <- NULL

  for (attempt in tries) {
    x <- tryCatch(
      suppressMessages(readxl::read_excel(
        path,
        sheet = attempt$sheet,
        skip = attempt$skip,
        guess_max = 200000,
        .name_repair = "unique_quiet"
      )) |>
        janitor::clean_names(),
      error = function(e) NULL
    )
    if (is.null(x) || nrow(x) < 3L || ncol(x) < 3L) next
    score <- atlas_oews_candidate_score(x)
    if (is.finite(score) && score > best_score) {
      best <- x
      best_score <- score
      best_meta <- attempt
    }
    nms <- names(x)
    has_code_name <- any(stringr::str_detect(
      nms,
      "(^|_)(soc|occ|occupation|occupational).*(code|number|id)$|standard_occupational_classification"
    ))
    has_code_values <- max(vapply(x, atlas_oews_soc_share, numeric(1L)), na.rm = TRUE) >= 0.20
    has_title <- any(stringr::str_detect(nms, "occupation|occupational|occ.*title|job.*title"))
    has_emp <- any(stringr::str_detect(nms, "employment|tot_emp|estimated_jobs|^jobs?$"))
    if ((has_code_name || has_code_values) && has_title && has_emp) return(x)
  }

  if (is.null(best)) {
    stop("Could not identify an OEWS-like table in ", path, call. = FALSE)
  }
  attr(best, "atlas_oews_sheet") <- best_meta$sheet
  attr(best, "atlas_oews_skip") <- best_meta$skip
  best
}


parse_oews_iowa_table <- function(raw, cfg = load_config(), out = NULL, source_label = "OEWS workbook") {
  if (is.null(out)) out <- file.path(paths()$processed, "oews_iowa_occupations.csv")
  raw <- raw |> janitor::clean_names()
  nms <- names(raw)

  pick_first <- function(candidates, required = TRUE) {
    hit <- intersect(candidates, nms)
    if (length(hit)) return(hit[[1L]])
    if (required) {
      stop(
        "Could not find expected OEWS column among: ", paste(candidates, collapse = ", "),
        ". Available columns: ", paste(utils::head(nms, 40L), collapse = ", "),
        call. = FALSE
      )
    }
    NA_character_
  }
  pick_regex <- function(pattern, required = TRUE, exclude = character()) {
    hit <- setdiff(nms[stringr::str_detect(nms, pattern)], exclude)
    if (length(hit)) return(hit[[1L]])
    if (required) {
      stop(
        "Could not find OEWS column matching: ", pattern,
        ". Available columns: ", paste(utils::head(nms, 40L), collapse = ", "),
        call. = FALSE
      )
    }
    NA_character_
  }
  pick_soc_by_values <- function() {
    shares <- vapply(raw, atlas_oews_soc_share, numeric(1L))
    shares[!is.finite(shares)] <- 0
    if (!length(shares) || max(shares) < 0.10) return(NA_character_)
    names(shares)[which.max(shares)]
  }

  area_title_col <- pick_first(c("area_title", "area_name", "geography", "geography_name"), required = FALSE)
  area_col <- pick_first(c("area", "area_code", "state_fips"), required = FALSE)
  state_col <- pick_first(c("prim_state", "state", "state_abbreviation", "state_name"), required = FALSE)
  area_type_col <- pick_first(c("area_type", "area_type_code", "geography_type"), required = FALSE)
  naics_col <- pick_first(c("naics", "naics_code", "industry_code"), required = FALSE)
  group_col <- pick_first(c("o_group", "occ_group", "occupation_group", "occupational_group"), required = FALSE)

  occ_code_col <- pick_first(c(
    "occ_code", "occupation_code", "occupational_code", "soc_code", "soc",
    "soc_2018_code", "soc_2020_code", "standard_occupational_classification_code",
    "standard_occupation_classification_code", "occupation_soc_code", "oews_soc_code"
  ), required = FALSE)
  if (is.na(occ_code_col)) {
    occ_code_col <- pick_regex(
      "soc.*(code|number|id)$|standard_occupational_classification|(^|_)(occ|occupation|occupational).*(code|number|id)$",
      required = FALSE
    )
  }
  if (is.na(occ_code_col)) occ_code_col <- pick_soc_by_values()
  if (is.na(occ_code_col)) {
    stop(
      "Could not identify an OEWS SOC/occupation-code column by name or values. Available columns: ",
      paste(utils::head(nms, 40L), collapse = ", "),
      call. = FALSE
    )
  }

  occ_title_col <- pick_first(c(
    "occ_title", "occupation_title", "occupational_title", "occupation_name",
    "occupation", "job_title", "job_name"
  ), required = FALSE)
  if (is.na(occ_title_col)) {
    occ_title_col <- pick_regex(
      "(^|_)(occ|occupation|occupational|job).*(title|name)$|^occupation$",
      required = TRUE,
      exclude = c(occ_code_col, area_title_col)
    )
  }

  emp_col <- pick_first(c(
    "tot_emp", "total_employment", "estimated_employment", "employment_estimate",
    "employment", "employment_total", "estimated_jobs", "jobs", "emp"
  ), required = FALSE)
  if (is.na(emp_col)) {
    emp_col <- pick_regex(
      "(^|_)(total|estimated|estimate)?_?employment(_estimate|_total)?$|(^|_)tot_emp$|(^|_)estimated_jobs$|^jobs?$",
      required = TRUE
    )
  }

  h_mean_col <- pick_first(c(
    "h_mean", "hourly_mean", "mean_hourly_wage", "average_hourly_wage",
    "avg_hourly_wage", "hourly_wage_mean"
  ), required = FALSE)
  if (is.na(h_mean_col)) h_mean_col <- pick_regex("hourly.*(mean|average|avg).*wage|(mean|average|avg).*hourly.*wage", required = FALSE)
  a_mean_col <- pick_first(c(
    "a_mean", "annual_mean", "mean_annual_wage", "average_annual_wage",
    "avg_annual_wage", "annual_wage_mean"
  ), required = FALSE)
  if (is.na(a_mean_col)) a_mean_col <- pick_regex("annual.*(mean|average|avg).*wage|(mean|average|avg).*annual.*wage", required = FALSE)
  h_median_col <- pick_first(c(
    "h_median", "hourly_median", "median_hourly_wage", "hourly_wage_median"
  ), required = FALSE)
  if (is.na(h_median_col)) h_median_col <- pick_regex("hourly.*median.*wage|median.*hourly.*wage", required = FALSE)
  a_median_col <- pick_first(c(
    "a_median", "annual_median", "median_annual_wage", "annual_wage_median"
  ), required = FALSE)
  if (is.na(a_median_col)) a_median_col <- pick_regex("annual.*median.*wage|median.*annual.*wage", required = FALSE)

  dat <- raw
  if (!is.na(area_title_col) && area_title_col %in% names(dat)) {
    state_rows <- dat |>
      dplyr::filter(stringr::str_to_lower(stringr::str_squish(as.character(.data[[area_title_col]]))) == "iowa")
    if (nrow(state_rows)) dat <- state_rows
  }
  if (!nrow(dat) && !is.na(area_col) && area_col %in% names(raw)) {
    dat <- raw |> dplyr::filter(as.character(.data[[area_col]]) %in% c("19", "019", "19000"))
  }
  if (!nrow(dat) && !is.na(state_col) && state_col %in% names(raw)) {
    dat <- raw |> dplyr::filter(tolower(as.character(.data[[state_col]])) %in% c("ia", "19", "iowa"))
  }
  if (!is.na(area_type_col) && area_type_col %in% names(dat)) {
    st <- dat |> dplyr::filter(tolower(as.character(.data[[area_type_col]])) %in% c("2", "state", "statewide"))
    if (nrow(st) > 100L) dat <- st
  }
  if (!is.na(naics_col) && naics_col %in% names(dat)) {
    cross <- dat |> dplyr::filter(tolower(as.character(.data[[naics_col]])) %in% c("000000", "0000000", "0", "cross-industry", "cross industry", "all industries"))
    if (nrow(cross) > 100L) dat <- cross
  }
  if (!is.na(group_col) && group_col %in% names(dat)) {
    det <- dat |> dplyr::filter(tolower(stringr::str_squish(as.character(.data[[group_col]]))) %in% c("detailed", "detail"))
    if (nrow(det) > 100L) dat <- det
  }

  numeric_column <- function(name) {
    if (is.na(name) || !name %in% names(dat)) return(rep(NA_real_, nrow(dat)))
    suppressWarnings(readr::parse_number(as.character(dat[[name]])))
  }

  oews <- tibble::tibble(
    soc_code = clean_soc(dat[[occ_code_col]]),
    occupation_title = as.character(dat[[occ_title_col]]),
    occ_group = if (!is.na(group_col) && group_col %in% names(dat)) as.character(dat[[group_col]]) else NA_character_,
    state_emp = numeric_column(emp_col),
    hourly_mean = numeric_column(h_mean_col),
    annual_mean = numeric_column(a_mean_col),
    hourly_median = numeric_column(h_median_col),
    annual_median = numeric_column(a_median_col)
  ) |>
    dplyr::mutate(
      occupation_title = dplyr::na_if(stringr::str_squish(.data$occupation_title), ""),
      hourly_mean = dplyr::if_else(is.na(.data$hourly_mean) & !is.na(.data$annual_mean), .data$annual_mean / 2080, .data$hourly_mean),
      hourly_median = dplyr::if_else(is.na(.data$hourly_median) & !is.na(.data$annual_median), .data$annual_median / 2080, .data$hourly_median)
    ) |>
    dplyr::filter(
      stringr::str_detect(.data$soc_code, "^\\d{2}-\\d{4}$"),
      .data$soc_code != "00-0000",
      !is.na(.data$state_emp),
      .data$state_emp > 0
    ) |>
    dplyr::distinct(.data$soc_code, .keep_all = TRUE)

  if (!nrow(oews)) {
    stop("OEWS parser produced zero Iowa detailed occupation rows from ", source_label, call. = FALSE)
  }
  bad_title_share <- mean(
    is.na(oews$occupation_title) |
      stringr::str_to_lower(oews$occupation_title) %in% c("iowa", "united states"),
    na.rm = TRUE
  )
  if (nrow(oews) < 300L) {
    warning("OEWS parser produced fewer detailed occupations than expected from ", source_label, ": ", nrow(oews), call. = FALSE)
  }
  if (is.finite(bad_title_share) && bad_title_share > 0.10) {
    warning("OEWS occupation titles look misparsed in ", source_label, ". Check OEWS columns before using report labels.", call. = FALSE)
  }

  readr::write_csv(oews, out)
  message(
    "Wrote Iowa OEWS occupation file from ", source_label, ": ", out,
    " [code=", occ_code_col, "; title=", occ_title_col,
    "; employment=", emp_col, "]"
  )
  oews
}


parse_local_oews_workbook <- function(path, cfg = load_config(), out = NULL) {
  raw <- read_oews_workbook(path)
  parse_oews_iowa_table(raw, cfg = cfg, out = out, source_label = basename(path))
}


get_oews_iowa_from_timeseries <- function(cfg = load_config(), refresh = FALSE, out = NULL) {
  p <- paths()
  if (is.null(out)) out <- file.path(p$processed, 'oews_iowa_occupations.csv')
  base <- 'https://download.bls.gov/pub/time.series/oe'
  raw_dir <- file.path(p$raw, 'oews_timeseries')
  data_path <- download_if_needed(paste0(base, '/oe.data.0.Current'),
                                  file.path(raw_dir, 'oe.data.0.Current'), refresh = refresh, mode = 'wb')
  occ_path <- download_if_needed(paste0(base, '/oe.occupation'),
                                 file.path(raw_dir, 'oe.occupation'), refresh = refresh, mode = 'wb')

  message('Reading BLS OEWS public time-series fallback. This can take a minute because the current OEWS file is large.')
  dat <- data.table::fread(
    data_path,
    data.table = FALSE,
    showProgress = TRUE,
    colClasses = list(character = c('series_id', 'period', 'footnote_codes'))
  ) |>
    janitor::clean_names()

  required_cols <- c('series_id', 'year', 'period', 'value')
  if (!all(required_cols %in% names(dat))) {
    stop('BLS OEWS time-series data did not contain expected columns: ',
         paste(required_cols, collapse = ', '), call. = FALSE)
  }

  iowa_area <- paste0(cfg$state_fips, '00000')
  keep_datatypes <- c(
    employment = '01',
    hourly_mean = '03',
    annual_mean = '04',
    hourly_median = '08',
    annual_median = '13'
  )

  dat <- dat |>
    dplyr::mutate(
      series_id = stringr::str_trim(as.character(series_id)),
      year = suppressWarnings(as.integer(year)),
      areatype_code = stringr::str_sub(series_id, 4, 4),
      area_code = stringr::str_sub(series_id, 5, 11),
      industry_code = stringr::str_sub(series_id, 12, 17),
      occupation_code = stringr::str_sub(series_id, 18, 23),
      datatype_code = stringr::str_sub(series_id, 24, 25),
      value_num = readr::parse_number(as.character(value))
    ) |>
    dplyr::filter(
      areatype_code == 'S',
      area_code == iowa_area,
      industry_code == '000000',
      datatype_code %in% unname(keep_datatypes),
      !is.na(year), !is.na(value_num)
    )

  if (!nrow(dat)) {
    stop('BLS OEWS time-series fallback returned zero Iowa state cross-industry rows.', call. = FALSE)
  }

  latest_year <- max(dat$year, na.rm = TRUE)
  wide <- dat |>
    dplyr::filter(year == latest_year) |>
    dplyr::arrange(occupation_code, datatype_code, dplyr::desc(period)) |>
    dplyr::group_by(occupation_code, datatype_code) |>
    dplyr::slice(1) |>
    dplyr::ungroup() |>
    dplyr::select(occupation_code, datatype_code, value_num) |>
    tidyr::pivot_wider(names_from = datatype_code, values_from = value_num, names_prefix = 'dt_')

  occ <- data.table::fread(occ_path, data.table = FALSE, showProgress = FALSE, quote = '') |>
    janitor::clean_names()
  nms <- names(occ)
  occ_code_col <- nms[stringr::str_detect(nms, '^occupation_code$|occ.*code')][1]
  occ_name_col <- nms[stringr::str_detect(nms, '^occupation_name$|occ.*name|title')][1]
  display_col <- nms[stringr::str_detect(nms, '^display_level$')][1]
  if (is.na(occ_code_col) || is.na(occ_name_col)) {
    stop('Could not parse BLS OEWS occupation lookup.', call. = FALSE)
  }

  occ_lu <- occ |>
    dplyr::transmute(
      occupation_code = stringr::str_pad(as.character(.data[[occ_code_col]]), width = 6, pad = '0'),
      occupation_title = stringr::str_squish(as.character(.data[[occ_name_col]])),
      display_level = if (!is.na(display_col)) suppressWarnings(as.integer(.data[[display_col]])) else NA_integer_
    )

  joined <- wide |>
    dplyr::left_join(occ_lu, by = 'occupation_code')
  for (nm in c('dt_01', 'dt_03', 'dt_04', 'dt_08', 'dt_13')) {
    if (!nm %in% names(joined)) joined[[nm]] <- NA_real_
  }

  oews <- joined |>
    dplyr::transmute(
      soc_code = clean_soc(occupation_code),
      occupation_title = occupation_title,
      display_level = display_level,
      state_emp = dt_01,
      hourly_mean = dt_03,
      annual_mean = dt_04,
      hourly_median = dt_08,
      annual_median = dt_13
    ) |>
    dplyr::mutate(
      hourly_mean = dplyr::if_else(is.na(hourly_mean) & !is.na(annual_mean), annual_mean / 2080, hourly_mean),
      hourly_median = dplyr::if_else(is.na(hourly_median) & !is.na(annual_median), annual_median / 2080, hourly_median),
      is_detailed = dplyr::case_when(
        !is.na(display_level) ~ display_level == 3L,
        TRUE ~ !stringr::str_detect(soc_code, '-0000$|-[0-9]{2}00$|-[0-9]000$')
      ),
      occ_group = dplyr::if_else(is_detailed, 'detailed', 'aggregate')
    ) |>
    dplyr::filter(
      stringr::str_detect(soc_code, '^\\d{2}-\\d{4}$'),
      is_detailed,
      !is.na(state_emp), state_emp > 0
    ) |>
    dplyr::select(soc_code, occupation_title, occ_group, state_emp, hourly_mean, annual_mean, hourly_median, annual_median) |>
    dplyr::distinct(soc_code, .keep_all = TRUE)

  if (nrow(oews) < 300) {
    warning('OEWS time-series fallback produced fewer detailed occupations than expected: ', nrow(oews), call. = FALSE)
  }
  readr::write_csv(oews, out)
  oews
}

get_oews_iowa <- function(cfg = load_config(), refresh = FALSE) {
  p <- paths()
  out <- file.path(p$processed, 'oews_iowa_occupations.csv')
  if (file.exists(out) && !refresh) return(readr::read_csv(out, show_col_types = FALSE))

  local_files <- find_local_oews_workbooks(cfg)
  if (length(local_files)) {
    for (lf in local_files) {
      message('Trying local BLS OEWS workbook: ', lf)
      ans <- tryCatch(
        parse_local_oews_workbook(lf, cfg = cfg, out = out),
        error = function(e) {
          warning('Could not parse local OEWS workbook ', basename(lf), ': ', conditionMessage(e), call. = FALSE)
          NULL
        }
      )
      if (!is.null(ans) && nrow(ans)) return(ans)
    }
    warning('Found local OEWS workbook(s), but none parsed successfully; trying BLS download/fallback.', call. = FALSE)
  }

  yy <- stringr::str_sub(as.character(cfg$oews_year), -2)
  urls <- c(
    glue::glue('https://www.bls.gov/oes/special-requests/oesm{yy}st.zip'),
    glue::glue('https://www.bls.gov/oes/special-requests/oesm{yy}all.zip')
  )
  z <- tryCatch(
    try_download(urls, file.path(p$raw, 'oews'), refresh = refresh),
    error = function(e) {
      warning('BLS OEWS special-request ZIP download failed: ', conditionMessage(e),
              '\nFalling back to BLS public OEWS time-series text files at download.bls.gov.',
              call. = FALSE)
      NA_character_
    }
  )
  if (is.na(z)) return(get_oews_iowa_from_timeseries(cfg = cfg, refresh = refresh, out = out))
  exdir <- file.path(p$raw, 'oews', tools::file_path_sans_ext(basename(z)))
  fs::dir_create(exdir)
  utils::unzip(z, exdir = exdir)
  files <- list.files(exdir, recursive = TRUE, full.names = TRUE)
  xlsx <- files[stringr::str_detect(tolower(files), '\\.xlsx$')]
  txt <- files[stringr::str_detect(tolower(files), '\\.(txt|csv)$')]
  if (length(xlsx)) {
    raw <- read_oews_workbook(xlsx[1])
    return(parse_oews_iowa_table(raw, cfg = cfg, out = out, source_label = basename(xlsx[1])))
  } else if (length(txt)) {
    raw <- data.table::fread(txt[1], data.table = FALSE, showProgress = FALSE) |>
      janitor::clean_names()
    return(parse_oews_iowa_table(raw, cfg = cfg, out = out, source_label = basename(txt[1])))
  } else {
    stop('No readable OEWS file found inside ', z, call. = FALSE)
  }
}


try_read_xlsx_skips <- function(path, sheets = NULL, max_skip = 8) {
  if (is.null(sheets)) sheets <- readxl::excel_sheets(path)
  candidates <- list()
  k <- 1
  for (sh in sheets) {
    for (sk in 0:max_skip) {
      x <- tryCatch(
        suppressMessages(
          readxl::read_xlsx(
            path, sheet = sh, skip = sk, guess_max = 200000,
            .name_repair = 'unique_quiet'
          ) |>
            janitor::clean_names()
        ),
        error = function(e) NULL
      )
      if (!is.null(x) && ncol(x) >= 5 && nrow(x) >= 10) {
        candidates[[k]] <- x
        k <- k + 1
      }
    }
  }
  candidates
}

find_local_nem_workbooks <- function(cfg = load_config()) {
  p <- paths()
  dirs <- unique(c(
    p$root,
    p$inputs,
    p$raw,
    file.path(p$raw, 'bls_nem'),
    file.path(p$raw, 'nem_manual'),
    path.expand('~/Downloads')
  ))
  dirs <- dirs[dir.exists(dirs)]
  if (!length(dirs)) return(character())
  files <- unique(unlist(lapply(dirs, function(d) {
    list.files(d, pattern = '\\.(xlsx|xlsm|xls)$', full.names = TRUE, ignore.case = TRUE)
  }), use.names = FALSE))
  if (!length(files)) return(character())
  b <- tolower(basename(files))
  keep <- stringr::str_detect(b, '(^matrix\\.xlsx$)|national.*employment.*matrix|nem.*matrix|ind.*occ.*matrix|occupation\\.xlsx$')
  files <- files[keep]
  if (!length(files)) return(character())
  score <- rep(50, length(files))
  bb <- tolower(basename(files))
  score[bb == 'matrix.xlsx'] <- 1
  score[stringr::str_detect(bb, 'national.*employment.*matrix|nem.*matrix|ind.*occ.*matrix')] <- pmin(score[stringr::str_detect(bb, 'national.*employment.*matrix|nem.*matrix|ind.*occ.*matrix')], 2)
  score[bb == 'occupation.xlsx'] <- pmin(score[bb == 'occupation.xlsx'], 20)
  files[order(score, bb)]
}

get_nem_matrix <- function(cfg = load_config(), refresh = FALSE) {
  p <- paths()
  out <- file.path(p$processed, 'bls_nem_occupation_industry.csv')
  if (file.exists(out) && !refresh) return(readr::read_csv(out, show_col_types = FALSE))

  # BLS changed the public researcher download.  The full National Employment
  # Matrix is now matrix.xlsx; the older industry.xlsx path returns a BLS 404
  # page and should not be used.  occupation.xlsx is kept only as a secondary
  # best-effort source because the web table still exposes it as an alternate
  # format, but the full matrix is preferred.
  local_files <- find_local_nem_workbooks(cfg)
  urls <- c(
    'https://www.bls.gov/emp/ind-occ-matrix/matrix.xlsx',
    'https://www.bls.gov/emp/ind-occ-matrix/occupation.xlsx'
  )
  downloaded <- purrr::map(urls, function(url) {
    tryCatch(download_if_needed(url, file.path(p$raw, 'bls_nem', basename(url)), refresh = refresh),
             error = function(e) {
               warning('Could not download BLS NEM file ', basename(url), ': ', conditionMessage(e), call. = FALSE)
               NULL
             })
  }) |> purrr::compact()
  files <- unique(c(local_files, downloaded))
  if (!length(files)) {
    warning('BLS National Employment Matrix could not be downloaded; allocation will use fallback statewide occupation shares.', call. = FALSE)
    return(tibble::tibble())
  }

  parse_one_nem <- function(f) {
    message('Trying BLS National Employment Matrix workbook: ', f)
    candidates <- try_read_xlsx_skips(f, max_skip = 8)
    if (!length(candidates)) return(tibble::tibble())
    score_candidate <- function(x) {
      nms <- names(x)
      sum(stringr::str_detect(nms, 'occupation|soc|industry|naics|employment')) +
        2 * sum(stringr::str_detect(nms, 'code|title')) +
        5 * as.integer(any(stringr::str_detect(nms, 'occupation.*code'))) +
        5 * as.integer(any(stringr::str_detect(nms, 'industry.*code|naics'))) +
        5 * as.integer(any(stringr::str_detect(nms, 'employment_2024|x2024.*employment|employment')))
    }
    candidates <- candidates[order(vapply(candidates, score_candidate, numeric(1)), decreasing = TRUE)]

    parse_emp <- function(x) suppressWarnings(readr::parse_number(as.character(x)))
    for (x in candidates) {
      nms <- names(x)
      code_col <- nms[stringr::str_detect(nms, '(^|_)occupation.*code$|soc.*code|national_employment_matrix.*occupation.*code')][1]
      title_col <- nms[stringr::str_detect(nms, '(^|_)occupation.*title$|national_employment_matrix.*title|occupation.*title')][1]
      ind_code_col <- nms[stringr::str_detect(nms, '(^|_)industry.*code$|naics|national_employment_matrix.*industry.*code')][1]
      ind_title_col <- nms[stringr::str_detect(nms, '(^|_)industry.*title$|industry.*sector|national_employment_matrix.*industry.*title')][1]
      emp_cols <- nms[
        stringr::str_detect(nms, 'employment') &
          !stringr::str_detect(nms, 'change|percent|projected|2034|openings|title|code|distribution|matrix_title|matrix_code')
      ]
      if (!length(emp_cols)) {
        emp_cols <- nms[stringr::str_detect(nms, 'employment_2024|x2024.*employment|(^|_)emp$') &
                          !stringr::str_detect(nms, 'change|percent|2034|title|code|distribution')]
      }
      if (any(is.na(c(code_col, ind_code_col))) || !length(emp_cols)) next
      best_emp <- emp_cols[which.max(vapply(emp_cols, function(cc) {
        vals <- parse_emp(x[[cc]])
        sum(is.finite(vals) & vals > 0, na.rm = TRUE)
      }, numeric(1)))]
      mat <- x |>
        dplyr::transmute(
          soc_code = clean_soc(.data[[code_col]]),
          occupation_title_nem = if (!is.na(title_col)) as.character(.data[[title_col]]) else NA_character_,
          nem_industry_code = stringr::str_squish(as.character(.data[[ind_code_col]])),
          nem_industry_title = if (!is.na(ind_title_col)) stringr::str_squish(as.character(.data[[ind_title_col]])) else NA_character_,
          nem_emp = parse_emp(.data[[best_emp]])
        ) |>
        dplyr::mutate(
          naics2 = dplyr::case_when(
            stringr::str_detect(nem_industry_code, '^31-33') ~ '31',
            stringr::str_detect(nem_industry_code, '^44-45') ~ '44',
            stringr::str_detect(nem_industry_code, '^48-49') ~ '48',
            TRUE ~ stringr::str_extract(nem_industry_code, '\\d{2}')
          )
        ) |>
        dplyr::filter(
          stringr::str_detect(soc_code, '^\\d{2}-\\d{4}$'),
          stringr::str_detect(naics2, '^\\d{2}$'),
          !is.na(nem_emp), nem_emp > 0,
          !soc_code %in% c('00-0000'),
          !stringr::str_detect(nem_industry_code, '^TE')
        )
      if (nrow(mat) > 1000) return(mat)
    }
    tibble::tibble()
  }

  mats <- purrr::map(files, parse_one_nem) |> dplyr::bind_rows()
  if (!nrow(mats)) {
    warning('Could not parse BLS National Employment Matrix; allocation will use fallback statewide occupation shares.', call. = FALSE)
    return(tibble::tibble())
  }
  mats <- mats |>
    dplyr::group_by(soc_code, occupation_title_nem, nem_industry_code, nem_industry_title, naics2) |>
    dplyr::summarise(nem_emp = sum(nem_emp, na.rm = TRUE), .groups = 'drop')
  readr::write_csv(mats, out)
  message('Wrote BLS National Employment Matrix file: ', out)
  mats
}

read_onet_tsv <- function(path) {
  readr::read_tsv(
    path,
    show_col_types = FALSE,
    progress = FALSE,
    guess_max = 200000,
    col_types = readr::cols(.default = readr::col_character())
  ) |>
    janitor::clean_names()
}

get_onet <- function(cfg = load_config(), refresh = FALSE) {
  p <- paths()
  out_dir <- file.path(p$raw, 'onet')
  fs::dir_create(out_dir)
  marker <- file.path(p$processed, 'onet_tasks.csv')
  if (file.exists(marker) && !refresh) {
    return(list(
      tasks = readr::read_csv(marker, show_col_types = FALSE),
      task_ratings = readr::read_csv(file.path(p$processed, 'onet_task_ratings.csv'), show_col_types = FALSE),
      job_zones = readr::read_csv(file.path(p$processed, 'onet_job_zones.csv'), show_col_types = FALSE),
      work_activities = readr::read_csv(file.path(p$processed, 'onet_work_activities.csv'), show_col_types = FALSE)
    ))
  }
  vers <- unique(c(cfg$onet_version, '30_3', '30_2', '30_1', '30_0', '29_3', '29_2', '29_1', '28_3'))
  zip_urls <- glue::glue('https://www.onetcenter.org/dl_files/database/db_{vers}_text.zip')
  z <- tryCatch(
    try_download(zip_urls, out_dir, refresh = refresh),
    error = function(e) {
      warning('O*NET all-files ZIP download failed: ', conditionMessage(e), call. = FALSE)
      NA_character_
    }
  )

  exdir <- file.path(out_dir, 'extracted')
  if (!is.na(z)) {
    exdir <- file.path(out_dir, tools::file_path_sans_ext(basename(z)))
    if (refresh && dir.exists(exdir)) unlink(exdir, recursive = TRUE, force = TRUE)
    fs::dir_create(exdir)
    ok_unzip <- tryCatch({
      suppressWarnings(utils::unzip(z, exdir = exdir))
      TRUE
    }, error = function(e) {
      warning('Could not unzip O*NET archive ', basename(z), ': ', conditionMessage(e), call. = FALSE)
      FALSE
    })
    if (!ok_unzip) exdir <- out_dir
  }

  find_file <- function(patterns, search_dir = exdir) {
    hits_all <- list.files(search_dir, recursive = TRUE, full.names = TRUE)
    if (!length(hits_all)) return(NA_character_)
    for (pat in patterns) {
      hit <- hits_all[stringr::str_detect(basename(hits_all), stringr::regex(pat, ignore_case = TRUE))]
      if (length(hit)) return(hit[1])
    }
    NA_character_
  }

  tasks_file <- find_file(c('^Task Statements\\.txt$', '^Tasks\\.txt$'))
  task_ratings_file <- find_file(c('^Task Ratings\\.txt$'))
  job_zones_file <- find_file(c('^Job Zones\\.txt$'))
  work_act_file <- find_file(c('^Work Activities\\.txt$', '^Work Activities .*\\.txt$'))
  occ_file <- find_file(c('^Occupation Data\\.txt$'))

  # O*NET 30.3 renamed the task file from Tasks.txt to Task Statements.txt.
  # If the all-files ZIP is missing, blocked, or partly extracted, download the
  # specific text files directly from the versioned O*NET directory.
  if (is.na(tasks_file)) {
    message('O*NET task file not found in ZIP extraction; trying direct individual text-file downloads.')
    direct_dir <- file.path(out_dir, 'individual')
    fs::dir_create(direct_dir)
    download_one_of <- function(urls, dest_name) {
      for (u in urls) {
        ans <- tryCatch(
          download_if_needed(as.character(u), file.path(direct_dir, dest_name), refresh = refresh, mode = 'wb'),
          error = function(e) NULL
        )
        if (!is.null(ans)) return(ans)
      }
      NA_character_
    }
    primary_ver <- as.character(vers[1])
    direct_specs <- list(
      tasks = list(
        dest = 'Task Statements.txt',
        urls = c(
          glue::glue('https://www.onetcenter.org/dl_files/database/db_{primary_ver}_text/Task%20Statements.txt'),
          glue::glue('https://www.onetcenter.org/dl_files/database/db_{primary_ver}_text/Tasks.txt')
        )
      ),
      task_ratings = list(
        dest = 'Task Ratings.txt',
        urls = c(glue::glue('https://www.onetcenter.org/dl_files/database/db_{primary_ver}_text/Task%20Ratings.txt'))
      ),
      job_zones = list(
        dest = 'Job Zones.txt',
        urls = c(glue::glue('https://www.onetcenter.org/dl_files/database/db_{primary_ver}_text/Job%20Zones.txt'))
      ),
      work_activities = list(
        dest = 'Work Activities.txt',
        urls = c(glue::glue('https://www.onetcenter.org/dl_files/database/db_{primary_ver}_text/Work%20Activities.txt'))
      ),
      occupation_data = list(
        dest = 'Occupation Data.txt',
        urls = c(glue::glue('https://www.onetcenter.org/dl_files/database/db_{primary_ver}_text/Occupation%20Data.txt'))
      )
    )
    tasks_file <- download_one_of(direct_specs$tasks$urls, direct_specs$tasks$dest)
    task_ratings_file <- download_one_of(direct_specs$task_ratings$urls, direct_specs$task_ratings$dest)
    job_zones_file <- download_one_of(direct_specs$job_zones$urls, direct_specs$job_zones$dest)
    work_act_file <- download_one_of(direct_specs$work_activities$urls, direct_specs$work_activities$dest)
    occ_file <- download_one_of(direct_specs$occupation_data$urls, direct_specs$occupation_data$dest)
  }

  if (is.na(tasks_file) || !file.exists(tasks_file)) {
    available <- list.files(exdir, recursive = TRUE, full.names = FALSE)
    stop('Could not locate the O*NET task statements file. Expected Task Statements.txt or Tasks.txt. Files found include: ',
         paste(utils::head(available, 30), collapse = ', '), call. = FALSE)
  }

  tasks <- read_onet_tsv(tasks_file)
  # O*NET releases can expose the task statement as `task`,
  # `task_statement`, or another close variant after clean_names().
  # Create a canonical `task` column for downstream scoring.
  task_text_cols <- intersect(c('task', 'task_statement', 'task_description', 'description', 'task_text'), names(tasks))
  if (!length(task_text_cols)) {
    stop('Could not find a task text column in ', basename(tasks_file),
         '. Columns present: ', paste(names(tasks), collapse = ', '), call. = FALSE)
  }
  if (!('task' %in% names(tasks))) tasks$task <- tasks[[task_text_cols[[1]]]]
  tasks <- tasks |>
    dplyr::mutate(soc_code = clean_soc(o_net_soc_code))
  task_ratings <- if (!is.na(task_ratings_file) && file.exists(task_ratings_file)) {
    read_onet_tsv(task_ratings_file) |>
      dplyr::mutate(
        soc_code = clean_soc(o_net_soc_code),
        data_value = suppressWarnings(as.numeric(data_value))
      )
  } else tibble::tibble()
  job_zones <- if (!is.na(job_zones_file) && file.exists(job_zones_file)) {
    read_onet_tsv(job_zones_file) |>
      dplyr::mutate(soc_code = clean_soc(o_net_soc_code))
  } else tibble::tibble()
  work_activities <- if (!is.na(work_act_file) && file.exists(work_act_file)) {
    read_onet_tsv(work_act_file) |>
      dplyr::mutate(soc_code = clean_soc(o_net_soc_code))
  } else tibble::tibble()
  occ <- if (!is.na(occ_file) && file.exists(occ_file)) {
    read_onet_tsv(occ_file) |>
      dplyr::mutate(soc_code = clean_soc(o_net_soc_code))
  } else tibble::tibble()

  if (nrow(occ) && 'title' %in% names(occ)) {
    occ_titles <- occ |>
      dplyr::select(soc_code, onet_title = title) |>
      dplyr::filter(!is.na(soc_code), !is.na(onet_title), onet_title != '') |>
      dplyr::distinct(soc_code, .keep_all = TRUE)
    tasks <- tasks |> dplyr::left_join(occ_titles, by = 'soc_code')
  }
  if (!('onet_title' %in% names(tasks))) tasks$onet_title <- NA_character_

  if (!nrow(tasks)) stop('O*NET task statement parser produced zero rows.', call. = FALSE)
  readr::write_csv(tasks, marker)
  readr::write_csv(task_ratings, file.path(p$processed, 'onet_task_ratings.csv'))
  readr::write_csv(job_zones, file.path(p$processed, 'onet_job_zones.csv'))
  readr::write_csv(work_activities, file.path(p$processed, 'onet_work_activities.csv'))
  message('Wrote O*NET task statements: ', marker)
  list(tasks = tasks, task_ratings = task_ratings, job_zones = job_zones, work_activities = work_activities)
}

get_aioe <- function(refresh = FALSE) {
  p <- paths()
  out <- file.path(p$processed, 'aioe_scores.csv')
  if (file.exists(out) && !refresh) return(readr::read_csv(out, show_col_types = FALSE))
  urls <- c(
    'https://raw.githubusercontent.com/AIOE-Data/AIOE/main/AIOE_DataAppendix.xlsx',
    'https://github.com/AIOE-Data/AIOE/raw/main/AIOE_DataAppendix.xlsx'
  )
  f <- tryCatch(try_download(urls, file.path(p$raw, 'aioe'), refresh = refresh), error = function(e) NULL)
  if (is.null(f)) {
    warning('AIOE workbook could not be downloaded; using O*NET task text only.', call. = FALSE)
    return(tibble::tibble())
  }
  sheets <- readxl::excel_sheets(f)
  dat <- NULL
  for (sh in sheets) {
    x <- tryCatch(readxl::read_xlsx(f, sheet = sh, guess_max = 100000) |> janitor::clean_names(), error = function(e) NULL)
    if (is.null(x)) next
    nms <- names(x)
    soc_col <- nms[stringr::str_detect(nms, 'soc')][1]
    score_col <- nms[stringr::str_detect(nms, 'aioe|ai_occupational_exposure|exposure')][1]
    title_col <- nms[stringr::str_detect(nms, 'title|occupation')][1]
    if (!is.na(soc_col) && !is.na(score_col)) {
      dat <- x |>
        dplyr::transmute(
          soc_code = clean_soc(.data[[soc_col]]),
          occupation_title_aioe = if (!is.na(title_col)) as.character(.data[[title_col]]) else NA_character_,
          aioe_score = readr::parse_number(as.character(.data[[score_col]]))
        ) |>
        dplyr::filter(stringr::str_detect(soc_code, '^\\d{2}-\\d{4}$'), !is.na(aioe_score)) |>
        dplyr::distinct(soc_code, .keep_all = TRUE)
      if (nrow(dat) > 100) break
    }
  }
  if (is.null(dat)) dat <- tibble::tibble()
  readr::write_csv(dat, out)
  dat
}

qwi_api_url <- function(year, quarter, industry, cfg = load_config()) {
  base <- 'https://api.census.gov/data/timeseries/qwi/sa'
  query <- list(
    get = paste(c('Emp', 'EmpS', 'HirA', 'Sep', 'EarnS', 'Payroll', 'year', 'quarter', 'industry'), collapse = ','),
    `for` = 'county:*',
    `in` = paste0('state:', cfg$state_fips),
    year = as.character(year), quarter = as.character(quarter),
    industry = industry, sex = '0', agegrp = 'A00', race = 'A0', ethnicity = 'A0',
    education = 'E0', firmage = '0', firmsize = '0', ownercode = 'A00', seasonadj = 'U'
  )
  httr2::request(base) |> httr2::req_url_query(!!!query)
}

get_qwi_iowa <- function(cfg = load_config(), refresh = FALSE) {
  p <- paths()
  out <- file.path(p$processed, 'qwi_iowa_county_industry.csv')
  if (file.exists(out) && !refresh) return(readr::read_csv(out, show_col_types = FALSE))
  sectors <- c('11','21','22','23','31','32','33','42','44','45','48','49','51','52','53','54','55','56','61','62','71','72','81','92')
  attempts <- tidyr::crossing(
    year = seq(as.integer(cfg$qwi_year), as.integer(cfg$qwi_year) - 4, by = -1),
    quarter = c(as.integer(cfg$qwi_quarter), 4, 3, 2, 1)
  ) |>
    dplyr::distinct(year, quarter)
  all <- list(); idx <- 1
  for (ii in seq_len(nrow(attempts))) {
    yr <- attempts$year[ii]; qt <- attempts$quarter[ii]
    message(glue::glue('Trying QWI {yr} Q{qt}...'))
    tmp <- list(); ok_count <- 0
    for (ind in sectors) {
      resp <- tryCatch(qwi_api_url(yr, qt, ind, cfg) |> httr2::req_perform(), error = function(e) NULL)
      if (is.null(resp) || httr2::resp_status(resp) >= 300) next
      txt <- httr2::resp_body_string(resp)
      arr <- tryCatch(jsonlite::fromJSON(txt), error = function(e) NULL)
      if (is.null(arr) || length(arr) < 2) next
      df <- as.data.frame(arr[-1, , drop = FALSE], stringsAsFactors = FALSE)
      names(df) <- arr[1,]
      tmp[[length(tmp)+1]] <- df
      ok_count <- ok_count + 1
      Sys.sleep(0.05)
    }
    if (ok_count >= 10) {
      all <- tmp
      break
    }
  }
  if (!length(all)) {
    warning('QWI API did not return enough industry data; LODES WAC will be used as fallback.', call. = FALSE)
    return(tibble::tibble())
  }
  qwi <- dplyr::bind_rows(all) |>
    janitor::clean_names() |>
    dplyr::mutate(
      county_fips = paste0(state, county),
      naics2 = industry,
      qwi_year = as.integer(year),
      qwi_quarter = as.integer(quarter),
      emp = readr::parse_number(emp),
      emp_stable = readr::parse_number(emp_s),
      hires = readr::parse_number(hir_a),
      separations = readr::parse_number(sep),
      avg_monthly_earnings = readr::parse_number(earn_s),
      payroll = readr::parse_number(payroll)
    ) |>
    dplyr::select(county_fips, naics2, qwi_year, qwi_quarter, emp, emp_stable, hires, separations, avg_monthly_earnings, payroll) |>
    dplyr::filter(!is.na(emp), emp > 0)
  readr::write_csv(qwi, out)
  qwi
}

get_lodes_wac_iowa <- function(cfg = load_config(), refresh = FALSE) {
  p <- paths()
  out <- file.path(p$processed, 'lodes_wac_iowa_county_industry.csv')
  if (file.exists(out) && !refresh) return(readr::read_csv(out, show_col_types = FALSE))
  state <- cfg$state_abb
  year <- cfg$lodes_year
  base <- glue::glue('https://lehd.ces.census.gov/data/lodes/LODES8/{state}/wac')
  url <- glue::glue('{base}/{state}_wac_S000_JT00_{year}.csv.gz')
  xwalk_url <- glue::glue('https://lehd.ces.census.gov/data/lodes/LODES8/{state}/{state}_xwalk.csv.gz')
  wac_file <- tryCatch(download_if_needed(url, file.path(p$raw, 'lodes', basename(url)), refresh = refresh), error = function(e) NULL)
  xwalk_file <- tryCatch(download_if_needed(xwalk_url, file.path(p$raw, 'lodes', basename(xwalk_url)), refresh = refresh), error = function(e) NULL)
  if (is.null(wac_file) || is.null(xwalk_file)) {
    warning('LODES WAC download failed.', call. = FALSE)
    return(tibble::tibble())
  }
  wac <- data.table::fread(wac_file, data.table = FALSE, showProgress = FALSE) |> janitor::clean_names()
  xw <- data.table::fread(xwalk_file, data.table = FALSE, showProgress = FALSE) |> janitor::clean_names()
  # LODES sector columns: CNS01..CNS20. Map to NAICS sectors.
  sector_map <- tibble::tribble(
    ~col, ~naics2,
    'cns01','11', 'cns02','21', 'cns03','22', 'cns04','23', 'cns05','31', 'cns06','42',
    'cns07','44', 'cns08','48', 'cns09','51', 'cns10','52', 'cns11','53', 'cns12','54',
    'cns13','56', 'cns14','61', 'cns15','62', 'cns16','71', 'cns17','72', 'cns18','81',
    'cns19','92', 'cns20','99'
  )
  long <- wac |>
    dplyr::select(w_geocode, dplyr::any_of(sector_map$col)) |>
    tidyr::pivot_longer(-w_geocode, names_to = 'col', values_to = 'emp') |>
    dplyr::left_join(sector_map, by = 'col') |>
    dplyr::filter(!is.na(naics2), emp > 0)
  county <- xw |>
    dplyr::transmute(w_geocode = tabblk2020, county_fips = clean_fips(cty, 5)) |>
    dplyr::distinct()
  outdat <- long |>
    dplyr::left_join(county, by = 'w_geocode') |>
    dplyr::filter(!is.na(county_fips)) |>
    dplyr::group_by(county_fips, naics2) |>
    dplyr::summarise(emp_lodes = sum(emp, na.rm = TRUE), .groups = 'drop')
  readr::write_csv(outdat, out)
  outdat
}

get_lodes_od_labor_shed <- function(cfg = load_config(), refresh = FALSE) {
  p <- paths()
  out <- file.path(p$processed, 'lodes_od_county_flows.csv')
  if (file.exists(out) && !refresh) return(readr::read_csv(out, show_col_types = FALSE))
  state <- cfg$state_abb
  year <- cfg$lodes_year
  od_url <- glue::glue('https://lehd.ces.census.gov/data/lodes/LODES8/{state}/od/{state}_od_main_JT00_{year}.csv.gz')
  xwalk_url <- glue::glue('https://lehd.ces.census.gov/data/lodes/LODES8/{state}/{state}_xwalk.csv.gz')
  od_file <- tryCatch(download_if_needed(od_url, file.path(p$raw, 'lodes', basename(od_url)), refresh = refresh), error = function(e) NULL)
  xwalk_file <- tryCatch(download_if_needed(xwalk_url, file.path(p$raw, 'lodes', basename(xwalk_url)), refresh = refresh), error = function(e) NULL)
  if (is.null(od_file) || is.null(xwalk_file)) {
    warning('LODES OD download failed.', call. = FALSE)
    return(tibble::tibble())
  }
  od <- data.table::fread(od_file, select = c('w_geocode','h_geocode','S000'), data.table = FALSE, showProgress = FALSE) |>
    janitor::clean_names()
  xw <- data.table::fread(xwalk_file, select = c('tabblk2020','cty'), data.table = FALSE, showProgress = FALSE) |>
    janitor::clean_names() |>
    dplyr::transmute(geocode = tabblk2020, county_fips = clean_fips(cty, 5)) |>
    dplyr::distinct()
  flows <- od |>
    dplyr::left_join(xw |> dplyr::rename(w_geocode = geocode, work_county_fips = county_fips), by = 'w_geocode') |>
    dplyr::left_join(xw |> dplyr::rename(h_geocode = geocode, home_county_fips = county_fips), by = 'h_geocode') |>
    dplyr::filter(!is.na(work_county_fips), !is.na(home_county_fips)) |>
    dplyr::group_by(home_county_fips, work_county_fips) |>
    dplyr::summarise(commuters = sum(s000, na.rm = TRUE), .groups = 'drop')
  readr::write_csv(flows, out)
  flows
}
