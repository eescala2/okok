# Iowa AI Workforce Atlas v3.1.3-clean-r10
# Browser PDF completion repair for macOS/Windows/Linux.
#
# Chromium can finish writing a valid PDF while its parent process remains alive.
# Revision 10 treats a complete, stable, parseable PDF as the completion signal,
# terminates the lingering browser tree, and returns the validation metadata
# expected by atlas_v312_create_pdf_outputs().

atlas_v319_pdf_revision <- "3.1.3-clean-r10"

atlas_v319_pdf_probe <- function(path, minimum_bytes = 1024L) {
  result <- list(
    exists = FALSE,
    bytes = 0,
    header_ok = FALSE,
    eof_ok = FALSE,
    complete = FALSE,
    reason = "file was not created"
  )
  if (!is.character(path) || !length(path) || is.na(path[[1L]]) || !file.exists(path[[1L]])) {
    return(result)
  }
  path <- path[[1L]]
  info <- suppressWarnings(file.info(path))
  bytes <- if (nrow(info)) suppressWarnings(as.numeric(info$size[[1L]])) else NA_real_
  result$exists <- TRUE
  result$bytes <- if (is.finite(bytes)) bytes else 0
  if (!is.finite(bytes) || bytes < minimum_bytes) {
    result$reason <- paste0("PDF too small or still being written: ", result$bytes, " bytes")
    return(result)
  }

  con <- file(path, open = "rb")
  on.exit(try(close(con), silent = TRUE), add = TRUE)
  header <- tryCatch(readBin(con, what = "raw", n = 5L), error = function(e) raw())
  result$header_ok <- length(header) == 5L && identical(rawToChar(header), "%PDF-")

  tail_bytes <- min(bytes, 16384)
  try(seek(con, where = max(0, bytes - tail_bytes), origin = "start", rw = "read"), silent = TRUE)
  tail_raw <- tryCatch(readBin(con, what = "raw", n = tail_bytes), error = function(e) raw())
  result$eof_ok <- length(tail_raw) && length(grepRaw("%%EOF", tail_raw, fixed = TRUE)) > 0L
  result$complete <- isTRUE(result$header_ok) && isTRUE(result$eof_ok)
  result$reason <- if (result$complete) {
    "PDF signature and terminal %%EOF marker are present."
  } else if (!result$header_ok) {
    "PDF signature is missing."
  } else {
    "PDF terminal %%EOF marker is not present yet."
  }
  result
}

atlas_v319_validate_pdf <- function(path, min_pages = 1L, min_bytes = 1024L) {
  min_pages <- suppressWarnings(as.integer(min_pages[[1L]]))
  min_bytes <- suppressWarnings(as.integer(min_bytes[[1L]]))
  if (!is.finite(min_pages)) min_pages <- 1L
  if (!is.finite(min_bytes)) min_bytes <- 1024L
  min_pages <- max(1L, min_pages)
  min_bytes <- max(1L, min_bytes)
  probe <- atlas_v319_pdf_probe(path, minimum_bytes = min_bytes)
  result <- list(valid = FALSE, pages = NA_integer_, bytes = probe$bytes, reason = probe$reason)
  if (!isTRUE(probe$complete)) return(result)

  if (exists("atlas_v312_validate_pdf", mode = "function", inherits = TRUE)) {
    checked <- tryCatch(
      atlas_v312_validate_pdf(path, min_pages = min_pages, min_bytes = min_bytes),
      error = function(e) list(
        valid = FALSE,
        pages = NA_integer_,
        bytes = probe$bytes,
        reason = paste0("PDF validation error: ", conditionMessage(e))
      )
    )
    if (!is.null(checked$bytes) && is.finite(checked$bytes)) result$bytes <- checked$bytes
    if (!is.null(checked$pages)) result$pages <- checked$pages
    result$valid <- isTRUE(checked$valid)
    result$reason <- checked$reason %||% if (result$valid) "validated" else "validation failed"
    return(result)
  }

  # Minimal fallback when the full validator has not been sourced.
  result$valid <- TRUE
  result$reason <- "signature and terminal marker validated; page parser unavailable"
  result
}

atlas_v319_flag <- function(x, default = FALSE) {
  if (is.null(x) || !length(x) || is.na(x[[1L]])) return(default)
  if (is.logical(x)) return(isTRUE(x[[1L]]))
  if (is.numeric(x)) return(is.finite(x[[1L]]) && x[[1L]] != 0)
  tolower(trimws(as.character(x[[1L]]))) %in% c("1", "true", "yes", "y", "on")
}

atlas_v319_resolve_pdf_call <- function(args) {
  if (!exists("atlas_v318_resolve_pdf_call", mode = "function", inherits = TRUE)) {
    stop("Revision-10 PDF repair requires the revision-8 PDF helpers to be sourced first.", call. = FALSE)
  }
  base <- atlas_v318_resolve_pdf_call(args)
  flat <- atlas_v318_flatten_arguments(args)
  numeric_scalar <- function(x) is.numeric(x) && length(x) == 1L && is.finite(x[[1L]])

  label <- atlas_v318_argument_value(
    flat,
    c("artifact", "label", "description", "report_label", "name", "title"),
    atlas_v318_scalar_character
  )
  if (is.null(label) || !nzchar(as.character(label))) label <- base$label

  passed_timeout <- atlas_v318_argument_value(
    flat,
    c("timeout_seconds", "timeout_sec", "timeout", "pdf_timeout_seconds"),
    numeric_scalar
  )
  environment_timeout <- suppressWarnings(as.numeric(
    Sys.getenv("IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS", unset = "")
  ))
  timeout <- if (is.finite(environment_timeout)) environment_timeout else passed_timeout
  if (is.null(timeout) || !is.finite(timeout)) timeout <- base$timeout %||% 240
  timeout <- max(20, min(as.numeric(timeout), 240))

  heartbeat <- atlas_v318_argument_value(
    flat,
    c("heartbeat_seconds", "heartbeat_sec", "heartbeat"),
    numeric_scalar
  )
  if (is.null(heartbeat) || !is.finite(heartbeat)) heartbeat <- 15
  heartbeat <- max(2, min(as.numeric(heartbeat), 60))

  min_pages <- atlas_v318_argument_value(flat, c("min_pages", "minimum_pages"), numeric_scalar)
  if (is.null(min_pages) || !is.finite(min_pages)) min_pages <- 1L
  min_pages <- max(1L, as.integer(round(min_pages)))

  min_bytes <- atlas_v318_argument_value(flat, c("min_bytes", "minimum_bytes"), numeric_scalar)
  if (is.null(min_bytes) || !is.finite(min_bytes)) {
    min_bytes <- if (min_pages >= 10L) max(65536L, min_pages * 4096L) else 1024L
  }
  min_bytes <- max(1024L, as.integer(round(min_bytes)))

  tagged_raw <- atlas_v318_argument_value(flat, c("tagged", "generate_tagged_pdf"), NULL)
  tagged <- atlas_v319_flag(tagged_raw, default = FALSE)

  stable_seconds <- suppressWarnings(as.numeric(
    Sys.getenv("IA_ATLAS_BROWSER_PDF_STABLE_SECONDS", unset = "2")
  ))
  if (!is.finite(stable_seconds)) stable_seconds <- 2
  stable_seconds <- max(1, min(stable_seconds, 10))

  list(
    html = base$html,
    pdf = base$pdf,
    label = as.character(label),
    browser = base$browser,
    timeout = timeout,
    heartbeat = heartbeat,
    min_pages = min_pages,
    min_bytes = min_bytes,
    tagged = tagged,
    stable_seconds = stable_seconds
  )
}

atlas_v319_stop_browser <- function(proc) {
  if (is.null(proc)) return(invisible(FALSE))
  alive <- tryCatch(isTRUE(proc$is_alive()), error = function(e) FALSE)
  if (alive) try(proc$kill_tree(), silent = TRUE)
  Sys.sleep(0.15)
  alive <- tryCatch(isTRUE(proc$is_alive()), error = function(e) FALSE)
  if (alive) try(proc$kill(), silent = TRUE)
  try(proc$wait(timeout = 5000), silent = TRUE)
  invisible(TRUE)
}

atlas_v319_write_pdf_status <- function(record, root = getOption("ia.atlas.v312.project_root", getwd())) {
  output <- file.path(root, "outputs", "pdf_print_status_v320.csv")
  dir.create(dirname(output), recursive = TRUE, showWarnings = FALSE)
  row <- as.data.frame(record, stringsAsFactors = FALSE)
  if (file.exists(output)) {
    old <- tryCatch(utils::read.csv(output, stringsAsFactors = FALSE), error = function(e) NULL)
    if (!is.null(old)) {
      columns <- union(names(old), names(row))
      for (name in setdiff(columns, names(old))) old[[name]] <- NA
      for (name in setdiff(columns, names(row))) row[[name]] <- NA
      old <- old[, columns, drop = FALSE]
      row <- row[, columns, drop = FALSE]
      row <- rbind(old, row)
    }
  }
  utils::write.csv(row, output, row.names = FALSE, na = "")
  invisible(output)
}

atlas_v319_browser_print_attempt <- function(
    browser,
    html,
    output,
    label,
    timeout_seconds,
    heartbeat_seconds = 15,
    stable_seconds = 2,
    min_pages = 1L,
    min_bytes = 1024L,
    tagged = FALSE,
    mode = "new",
    attempt = 1L) {

  if (!requireNamespace("processx", quietly = TRUE)) {
    stop("processx is required for bounded browser PDF output.", call. = FALSE)
  }
  root <- getOption("ia.atlas.v312.project_root", getwd())
  log_dir <- file.path(root, "outputs", "pdf_logs_v320")
  dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
  stem <- gsub("[^A-Za-z0-9._-]+", "_", paste0(label, "_", mode, "_", attempt))
  stdout_log <- file.path(log_dir, paste0(stem, "_stdout.log"))
  stderr_log <- file.path(log_dir, paste0(stem, "_stderr.log"))
  unlink(c(stdout_log, stderr_log), force = TRUE)

  profile <- tempfile(pattern = "ia_atlas_chrome_profile_v319_")
  dir.create(profile, recursive = TRUE, showWarnings = FALSE)
  on.exit(unlink(profile, recursive = TRUE, force = TRUE), add = TRUE)
  unlink(output, force = TRUE)

  headless_flag <- if (identical(mode, "new")) "--headless=new" else "--headless"
  browser_args <- c(
    headless_flag,
    "--disable-gpu",
    "--disable-dev-shm-usage",
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-extensions",
    "--disable-background-networking",
    "--disable-component-update",
    "--disable-sync",
    "--metrics-recording-only",
    "--mute-audio",
    "--hide-scrollbars",
    "--allow-file-access-from-files",
    "--run-all-compositor-stages-before-draw",
    "--no-pdf-header-footer",
    paste0("--user-data-dir=", normalizePath(profile, winslash = "/", mustWork = TRUE))
  )
  if (isTRUE(tagged)) {
    browser_args <- c(browser_args, "--generate-tagged-pdf", "--generate-pdf-document-outline")
  }
  browser_args <- c(
    browser_args,
    paste0("--print-to-pdf=", normalizePath(dirname(output), winslash = "/", mustWork = TRUE), "/", basename(output)),
    atlas_v318_file_url(html)
  )

  message(
    "Starting ", label,
    " with print-safe HTML [mode=", mode,
    "; tagged=", tagged,
    "; hard timeout=", timeout_seconds,
    "s; completion=stable valid PDF; logs=", log_dir, "]."
  )

  started <- Sys.time()
  proc <- processx::process$new(
    command = browser,
    args = browser_args,
    stdout = stdout_log,
    stderr = stderr_log,
    cleanup_tree = TRUE,
    windows_hide_window = TRUE,
    supervise = TRUE
  )

  timed_out <- FALSE
  completed_by_file <- FALSE
  browser_terminated_after_output <- FALSE
  completion_reason <- ""
  last_heartbeat <- -Inf
  last_complete_size <- NA_real_
  stable_started <- NA_real_
  stable_for <- 0
  validation <- list(valid = FALSE, pages = NA_integer_, bytes = 0, reason = "PDF was not validated")

  repeat {
    now <- Sys.time()
    elapsed <- as.numeric(difftime(now, started, units = "secs"))
    alive <- tryCatch(isTRUE(proc$is_alive()), error = function(e) FALSE)
    probe <- atlas_v319_pdf_probe(output, minimum_bytes = min_bytes)

    if (isTRUE(probe$complete)) {
      if (!is.na(last_complete_size) && identical(as.numeric(probe$bytes), as.numeric(last_complete_size))) {
        if (!is.finite(stable_started)) stable_started <- as.numeric(now)
      } else {
        last_complete_size <- as.numeric(probe$bytes)
        stable_started <- as.numeric(now)
      }
      stable_for <- max(0, as.numeric(now) - stable_started)

      if (!alive || stable_for >= stable_seconds || elapsed >= timeout_seconds) {
        candidate <- atlas_v319_validate_pdf(output, min_pages = min_pages, min_bytes = min_bytes)
        if (isTRUE(candidate$valid)) {
          validation <- candidate
          completed_by_file <- alive
          browser_terminated_after_output <- alive
          completion_reason <- if (alive) {
            paste0(
              "Complete PDF detected and stable for ", round(stable_for, 1),
              " seconds while the browser remained alive; the browser tree was terminated after output."
            )
          } else {
            "Browser exited after producing a complete, validated PDF."
          }
          if (alive) atlas_v319_stop_browser(proc)
          break
        }
      }
    } else {
      last_complete_size <- NA_real_
      stable_started <- NA_real_
      stable_for <- 0
    }

    if (!alive) {
      Sys.sleep(0.25)
      validation <- atlas_v319_validate_pdf(output, min_pages = min_pages, min_bytes = min_bytes)
      completion_reason <- if (isTRUE(validation$valid)) {
        "Browser exited after producing a complete, validated PDF."
      } else {
        paste0("Browser exited before a valid PDF was complete: ", validation$reason)
      }
      break
    }

    if (elapsed >= timeout_seconds) {
      # A final validation at the deadline prevents a completed PDF from being
      # rejected merely because Chromium's parent process did not terminate.
      validation <- atlas_v319_validate_pdf(output, min_pages = min_pages, min_bytes = min_bytes)
      if (isTRUE(validation$valid)) {
        completed_by_file <- TRUE
        browser_terminated_after_output <- TRUE
        completion_reason <- "A complete PDF was validated at the hard deadline; the lingering browser tree was terminated after output."
      } else {
        timed_out <- TRUE
        completion_reason <- paste0("Browser timed out before a complete PDF was available: ", validation$reason)
      }
      atlas_v319_stop_browser(proc)
      break
    }

    if (elapsed - last_heartbeat >= heartbeat_seconds) {
      message(
        "  PDF watchdog: ", floor(elapsed), "s elapsed; staged file=", probe$exists,
        "; bytes=", format(probe$bytes, big.mark = ",", scientific = FALSE),
        "; complete=", probe$complete,
        "; stable=", round(stable_for, 1), "s",
        "; browser alive=", alive
      )
      last_heartbeat <- elapsed
    }
    Sys.sleep(0.5)
  }

  atlas_v319_stop_browser(proc)
  status <- tryCatch(proc$get_exit_status(), error = function(e) NA_integer_)
  elapsed <- round(as.numeric(difftime(Sys.time(), started, units = "secs")), 1)
  success <- isTRUE(validation$valid)
  stderr_tail <- atlas_v318_read_log_tail(stderr_log)

  list(
    valid = success,
    success = success,
    pages = validation$pages,
    bytes = validation$bytes,
    reason = validation$reason,
    timed_out = timed_out,
    completed_by_file = completed_by_file,
    browser_terminated_after_output = browser_terminated_after_output,
    stable_seconds = round(stable_for, 1),
    completion_reason = completion_reason,
    exit_status = status,
    elapsed_seconds = elapsed,
    stdout_log = stdout_log,
    stderr_log = stderr_log,
    diagnostic = if (success) {
      paste0(completion_reason, " PDF validation: ", validation$reason)
    } else {
      paste0(completion_reason, if (nzchar(stderr_tail)) paste0(" stderr tail: ", stderr_tail) else "")
    }
  )
}

atlas_v319_promote_pdf <- function(staged, output, min_pages, min_bytes) {
  staged_validation <- atlas_v319_validate_pdf(staged, min_pages = min_pages, min_bytes = min_bytes)
  if (!isTRUE(staged_validation$valid)) {
    stop("Staged PDF failed validation before promotion: ", staged_validation$reason, call. = FALSE)
  }

  output <- normalizePath(output, winslash = "/", mustWork = FALSE)
  dir.create(dirname(output), recursive = TRUE, showWarnings = FALSE)
  backup <- file.path(dirname(output), paste0(".", basename(output), ".v320.previous"))
  unlink(backup, force = TRUE)
  had_output <- file.exists(output)
  if (had_output && !file.copy(output, backup, overwrite = TRUE, copy.mode = TRUE, copy.date = TRUE)) {
    stop("Could not create a transactional backup of the existing PDF: ", output, call. = FALSE)
  }

  promoted <- FALSE
  if (file.exists(output)) unlink(output, force = TRUE)
  promoted <- isTRUE(file.rename(staged, output))
  if (!promoted) promoted <- isTRUE(file.copy(staged, output, overwrite = TRUE, copy.mode = TRUE, copy.date = TRUE))

  final_validation <- if (promoted) {
    atlas_v319_validate_pdf(output, min_pages = min_pages, min_bytes = min_bytes)
  } else {
    list(valid = FALSE, pages = NA_integer_, bytes = 0, reason = "staged PDF could not be moved or copied")
  }

  if (!isTRUE(final_validation$valid)) {
    unlink(output, force = TRUE)
    if (had_output && file.exists(backup)) file.copy(backup, output, overwrite = TRUE, copy.mode = TRUE, copy.date = TRUE)
    unlink(backup, force = TRUE)
    stop("Promoted PDF failed validation: ", final_validation$reason, call. = FALSE)
  }

  unlink(backup, force = TRUE)
  final_validation
}

# Late compatibility override used by the maintained one-click publisher.
atlas_v312_print_html_pdf_with_fallback <- function(...) {
  call <- atlas_v319_resolve_pdf_call(list(...))
  html <- atlas_v318_file_url_to_path(call$html)
  pdf <- call$pdf
  if (!atlas_v318_scalar_character(html) || !file.exists(html)) {
    stop("The revision-10 PDF printer could not resolve an existing HTML input from the call.", call. = FALSE)
  }
  if (!atlas_v318_scalar_character(pdf)) {
    stop("The revision-10 PDF printer could not resolve the requested PDF output path from the call.", call. = FALSE)
  }
  pdf <- normalizePath(pdf, winslash = "/", mustWork = FALSE)
  dir.create(dirname(pdf), recursive = TRUE, showWarnings = FALSE)
  browsers <- atlas_v318_browser_candidates(call$browser)
  if (!length(browsers)) stop("No Chrome, Edge, or Chromium executable was found for PDF output.", call. = FALSE)

  safe_html <- atlas_v318_prepare_print_html(html, call$label)
  on.exit(unlink(safe_html, force = TRUE), add = TRUE)
  staged <- file.path(dirname(pdf), paste0(".", basename(pdf), ".v320.partial.pdf"))
  on.exit(unlink(staged, force = TRUE), add = TRUE)

  plans <- if (isTRUE(call$tagged)) {
    list(
      list(browser = browsers[[1L]], mode = "new", tagged = TRUE),
      list(browser = if (length(browsers) >= 2L) browsers[[2L]] else browsers[[1L]], mode = "legacy", tagged = FALSE)
    )
  } else {
    list(
      list(browser = browsers[[1L]], mode = "new", tagged = FALSE),
      list(browser = if (length(browsers) >= 2L) browsers[[2L]] else browsers[[1L]], mode = "legacy", tagged = FALSE)
    )
  }

  results <- list()
  for (i in seq_along(plans)) {
    plan <- plans[[i]]
    result <- tryCatch(
      atlas_v319_browser_print_attempt(
        browser = plan$browser,
        html = safe_html,
        output = staged,
        label = call$label,
        timeout_seconds = call$timeout,
        heartbeat_seconds = call$heartbeat,
        stable_seconds = call$stable_seconds,
        min_pages = call$min_pages,
        min_bytes = call$min_bytes,
        tagged = plan$tagged,
        mode = plan$mode,
        attempt = i
      ),
      error = function(e) list(
        valid = FALSE,
        success = FALSE,
        pages = NA_integer_,
        bytes = if (file.exists(staged)) file.info(staged)$size[[1L]] else 0,
        reason = conditionMessage(e),
        timed_out = FALSE,
        completed_by_file = FALSE,
        browser_terminated_after_output = FALSE,
        stable_seconds = 0,
        completion_reason = conditionMessage(e),
        exit_status = NA_integer_,
        elapsed_seconds = NA_real_,
        stdout_log = "",
        stderr_log = "",
        diagnostic = conditionMessage(e)
      )
    )
    results[[i]] <- result

    atlas_v319_write_pdf_status(list(
      timestamp_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
      revision = atlas_v319_pdf_revision,
      label = call$label,
      html = normalizePath(html, winslash = "/", mustWork = TRUE),
      pdf = pdf,
      browser = plan$browser,
      mode = plan$mode,
      tagged = plan$tagged,
      attempt = i,
      timeout_seconds = call$timeout,
      elapsed_seconds = result$elapsed_seconds,
      exit_status = result$exit_status,
      timed_out = result$timed_out,
      completed_by_file = result$completed_by_file,
      browser_terminated_after_output = result$browser_terminated_after_output,
      stable_seconds = result$stable_seconds,
      pages = result$pages,
      bytes = result$bytes,
      success = result$success,
      diagnostic = result$diagnostic
    ))

    if (isTRUE(result$success)) {
      promoted <- atlas_v319_promote_pdf(
        staged = staged,
        output = pdf,
        min_pages = call$min_pages,
        min_bytes = call$min_bytes
      )
      promoted$attempt <- i
      promoted$tagged <- plan$tagged
      promoted$mode <- plan$mode
      promoted$stale <- FALSE
      promoted$completed_by_file <- result$completed_by_file
      promoted$browser_terminated_after_output <- result$browser_terminated_after_output
      promoted$completion_reason <- result$completion_reason
      message(
        "Completed ", call$label, ": ",
        if (is.finite(promoted$pages)) paste0(promoted$pages, " pages, ") else "",
        round(promoted$bytes / 1024^2, 1), " MB; ",
        if (isTRUE(result$browser_terminated_after_output)) "browser terminated after complete output." else "browser exited normally."
      )
      return(promoted)
    }
    unlink(staged, force = TRUE)
  }

  existing <- atlas_v319_validate_pdf(pdf, min_pages = call$min_pages, min_bytes = call$min_bytes)
  if (isTRUE(existing$valid) && !identical(tolower(Sys.getenv("IA_ATLAS_ALLOW_STALE_PDF_FALLBACK", unset = "true")), "false")) {
    existing$attempt <- 0L
    existing$tagged <- NA
    existing$mode <- "retained-existing"
    existing$stale <- TRUE
    existing$completed_by_file <- FALSE
    existing$browser_terminated_after_output <- FALSE
    existing$completion_reason <- "Fresh attempts failed; an existing validated PDF was retained."
    atlas_v319_write_pdf_status(list(
      timestamp_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
      revision = atlas_v319_pdf_revision,
      label = call$label,
      html = normalizePath(html, winslash = "/", mustWork = TRUE),
      pdf = pdf,
      browser = "",
      mode = "retained-existing",
      tagged = NA,
      attempt = 0L,
      timeout_seconds = call$timeout,
      elapsed_seconds = 0,
      exit_status = NA,
      timed_out = FALSE,
      completed_by_file = FALSE,
      browser_terminated_after_output = FALSE,
      stable_seconds = NA,
      pages = existing$pages,
      bytes = existing$bytes,
      success = TRUE,
      diagnostic = existing$completion_reason
    ))
    warning(
      "Fresh PDF printing failed, but the existing validated PDF was retained: ", pdf,
      ". See outputs/pdf_print_status_v320.csv and outputs/pdf_logs_v320/.",
      call. = FALSE
    )
    return(existing)
  }

  diagnostics <- vapply(
    results,
    function(x) if (is.null(x$diagnostic) || !length(x$diagnostic)) "unknown failure" else as.character(x$diagnostic[[1L]]),
    character(1)
  )
  stop(
    call$label, " failed every revision-10 bounded browser attempt. ",
    paste(sprintf("attempt %d: %s", seq_along(diagnostics), diagnostics), collapse = " || "),
    ". See outputs/pdf_print_status_v320.csv and outputs/pdf_logs_v320/.",
    call. = FALSE
  )
}

atlas_v319_browser_pdf_smoke_test <- function(root = getwd(), timeout_seconds = 60) {
  if (identical(tolower(Sys.getenv("IA_ATLAS_SKIP_BROWSER_PDF_SMOKE", unset = "false")), "true")) {
    message("Revision-10 browser PDF smoke test skipped by IA_ATLAS_SKIP_BROWSER_PDF_SMOKE=true.")
    return(invisible(TRUE))
  }
  old_root <- getOption("ia.atlas.v312.project_root")
  options("ia.atlas.v312.project_root" = normalizePath(root, winslash = "/", mustWork = TRUE))
  on.exit(options("ia.atlas.v312.project_root" = old_root), add = TRUE)

  html <- tempfile(pattern = "atlas_pdf_smoke_v319_", fileext = ".html")
  pdf <- tempfile(pattern = "atlas_pdf_smoke_v319_", fileext = ".pdf")
  on.exit(unlink(c(html, pdf), force = TRUE), add = TRUE)
  blocks <- paste(rep(
    '<figure style="break-inside: avoid; page-break-inside: avoid; height: 10in; margin:1in"><svg width="900" height="650" xmlns="http://www.w3.org/2000/svg"><rect width="900" height="650" fill="white"/><text x="30" y="80" font-size="42">Iowa AI Workforce Atlas PDF smoke test</text><rect x="30" y="120" width="820" height="450" fill="#d9e8f5" stroke="#333"/></svg><figcaption>Deliberately oversized figure block.</figcaption></figure>',
    4L
  ), collapse = "\n")
  writeLines(c(
    '<!doctype html><html><head><meta charset="utf-8"><title>PDF smoke test</title></head><body>',
    blocks,
    '</body></html>'
  ), html, useBytes = TRUE)

  result <- atlas_v312_print_html_pdf_with_fallback(
    html = html,
    pdf = pdf,
    artifact = "revision-10 browser PDF smoke test",
    timeout_seconds = timeout_seconds,
    heartbeat_seconds = 10,
    min_pages = 1L,
    min_bytes = 1024L,
    tagged = FALSE
  )
  required_fields <- c("valid", "pages", "bytes", "attempt", "tagged", "completion_reason")
  if (!is.list(result) || !all(required_fields %in% names(result))) {
    stop("Revision-10 browser PDF smoke test did not return the report-manifest contract.", call. = FALSE)
  }
  if (!isTRUE(result$valid) || !isTRUE(atlas_v319_validate_pdf(pdf, min_pages = 1L, min_bytes = 1024L)$valid)) {
    stop("Revision-10 browser PDF smoke test did not create a complete, parseable PDF.", call. = FALSE)
  }
  message(
    "v3.1.3-clean-r10 stable-PDF completion smoke test passed; ",
    if (isTRUE(result$browser_terminated_after_output)) {
      "the lingering browser was terminated after the validated file became complete."
    } else {
      "the browser exited normally after writing the validated file."
    }
  )
  invisible(TRUE)
}

# Backward-compatible alias for scripts that still call the r8 smoke-test name.
atlas_v318_browser_pdf_smoke_test <- atlas_v319_browser_pdf_smoke_test

# Revision marker used to detect source-order regressions. R/43 defines a
# backward-compatible printer, so the current override must be reactivated after
# R/43 is sourced by the one-click orchestrator.
attr(atlas_v312_print_html_pdf_with_fallback, "atlas_pdf_revision") <- atlas_v319_pdf_revision
atlas_v320_browser_pdf_smoke_test <- atlas_v319_browser_pdf_smoke_test
