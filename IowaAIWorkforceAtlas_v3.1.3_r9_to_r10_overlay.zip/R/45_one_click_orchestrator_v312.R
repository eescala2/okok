# Iowa AI Workforce Atlas one-click cross-platform orchestrator
# Version 3.1.2

`%||%` <- function(x, y) {
  if (is.null(x) || !length(x) || (length(x) == 1L && is.na(x))) y else x
}

atlas_v312_find_root <- function(start = getwd()) {
  current <- normalizePath(start, winslash = "/", mustWork = FALSE)
  repeat {
    if (
      dir.exists(file.path(current, "R")) &&
      file.exists(file.path(current, "R", "run_all.R"))
    ) {
      return(current)
    }
    parent <- dirname(current)
    if (identical(parent, current)) break
    current <- parent
  }
  stop("Could not locate the Iowa Atlas project root.", call. = FALSE)
}


atlas_v3124_verify_early_career_join_contract <- function(root) {
  path <- file.path(root, "R", "24_methodology_v3_early_career.R")
  if (!file.exists(path)) {
    stop(
      "Hotfix 6 requires R/24_methodology_v3_early_career.R.",
      call. = FALSE
    )
  }

  parse_result <- tryCatch(
    {
      parse(file = path)
      TRUE
    },
    error = function(e) {
      result <- FALSE
      attr(result, "error") <- conditionMessage(e)
      result
    }
  )
  if (!isTRUE(parse_result)) {
    stop(
      "The Hotfix 6 early-career source does not parse: ",
      attr(parse_result, "error") %||% "unknown parse error",
      call. = FALSE
    )
  }

  source_text <- paste(
    readLines(path, warn = FALSE, encoding = "UTF-8"),
    collapse = "\n"
  )
  required_markers <- c(
    "IA_ATLAS_V312_HOTFIX4_EARLY_CAREER_JOIN_CONTRACT_BEGIN",
    "v3_prepare_occupation_industry_early_career_join",
    "industry_automation_exposure",
    "industry_estimated_jobs"
  )
  missing <- required_markers[
    !vapply(required_markers, grepl, logical(1L), x = source_text, fixed = TRUE)
  ]
  if (length(missing)) {
    stop(
      "The installed Methodology v3 early-career source is missing the preserved Hotfix 4 join-contract markers required by Hotfix 6: ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }

  invisible(TRUE)
}

atlas_v312_ensure_packages <- function() {
  packages <- c(
    "processx", "pdftools", "png", "magick", "xml2",
    "base64enc", "fs", "svglite", "ragg", "openxlsx2", "rvg"
  )

  missing <- packages[
    !vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  ]

  if (length(missing)) {
    message(
      "Installing one-click output dependencies: ",
      paste(missing, collapse = ", ")
    )
    utils::install.packages(
      missing,
      dependencies = c("Depends", "Imports", "LinkingTo"),
      quiet = TRUE
    )
  }

  still_missing <- packages[
    !vapply(packages, requireNamespace, logical(1), quietly = TRUE)
  ]

  if (length(still_missing)) {
    stop(
      "Required one-click packages remain unavailable: ",
      paste(still_missing, collapse = ", "),
      call. = FALSE
    )
  }

  invisible(TRUE)
}

atlas_v312_census_api_key <- function() {
  trimws(
    Sys.getenv(
      "CENSUS_API_KEY",
      unset = Sys.getenv("IA_ATLAS_CENSUS_API_KEY", unset = "")
    )
  )
}

atlas_v312_qwi_attempt_grid <- function(
    qwi_year,
    qwi_quarter,
    lookback_years = 4L) {

  year <- suppressWarnings(as.integer(qwi_year))
  quarter <- suppressWarnings(as.integer(qwi_quarter))
  lookback_years <- suppressWarnings(as.integer(lookback_years))

  if (!length(year) || !is.finite(year[[1L]])) {
    year <- as.integer(format(Sys.Date(), "%Y")) - 2L
  } else {
    year <- year[[1L]]
  }
  if (!length(quarter) || !is.finite(quarter[[1L]])) {
    quarter <- 4L
  } else {
    quarter <- quarter[[1L]]
  }
  if (
    !length(lookback_years) ||
    !is.finite(lookback_years[[1L]]) ||
    lookback_years[[1L]] < 0L
  ) {
    lookback_years <- 4L
  } else {
    lookback_years <- lookback_years[[1L]]
  }

  quarter <- max(1L, min(4L, quarter))
  first_year <- year
  years <- seq.int(
    from = first_year,
    to = max(1990L, first_year - lookback_years),
    by = -1L
  )

  rows <- lapply(
    seq_along(years),
    function(index) {
      maximum_quarter <- if (index == 1L) quarter else 4L
      data.frame(
        year = years[[index]],
        quarter = seq.int(maximum_quarter, 1L, by = -1L),
        stringsAsFactors = FALSE
      )
    }
  )

  do.call(rbind, rows)
}

atlas_v312_build_qwi_request <- function(
    year,
    quarter,
    industry,
    cfg = NULL,
    state_fips = NULL,
    geography = c("county", "state"),
    agegrp = "A00",
    indicators = c(
      "Emp", "EmpS", "HirA", "Sep", "EarnS", "Payroll",
      "year", "quarter", "industry"
    ),
    timeout_seconds = 90,
    api_key = atlas_v312_census_api_key()) {

  if (!requireNamespace("httr2", quietly = TRUE)) {
    stop("httr2 is required for QWI requests.", call. = FALSE)
  }

  geography <- match.arg(geography)
  if (is.null(state_fips) || !length(state_fips) || is.na(state_fips[[1L]])) {
    state_fips <- if (!is.null(cfg) && !is.null(cfg$state_fips)) {
      cfg$state_fips
    } else {
      "19"
    }
  }
  state_fips <- sprintf("%02d", suppressWarnings(as.integer(state_fips)))

  query <- list(
    get = paste(unique(as.character(indicators)), collapse = ","),
    year = as.character(as.integer(year)),
    quarter = as.character(as.integer(quarter)),
    industry = sprintf("%02d", suppressWarnings(as.integer(industry))),
    sex = "0",
    agegrp = as.character(agegrp),
    ownercode = "A00",
    seasonadj = "U",
    periodicity = "Q"
  )

  if (identical(geography, "county")) {
    query[["for"]] <- "county:*"
    query[["in"]] <- paste0("state:", state_fips)
  } else {
    query[["for"]] <- paste0("state:", state_fips)
  }

  request <- httr2::request(
    "https://api.census.gov/data/timeseries/qwi/sa"
  ) |>
    httr2::req_user_agent(
      "Iowa-AI-Workforce-Atlas/3.1.2 public-research"
    ) |>
    httr2::req_timeout(timeout_seconds)

  request <- do.call(
    httr2::req_url_query,
    c(list(request), query)
  )

  api_key <- trimws(as.character(api_key %||% ""))
  if (nzchar(api_key)) {
    request <- httr2::req_url_query(request, key = api_key)
  }

  request
}

atlas_v312_safe_resp_body_string <- function(response) {
  if (is.null(response) || !requireNamespace("httr2", quietly = TRUE)) {
    return("")
  }

  has_body <- tryCatch(
    httr2::resp_has_body(response),
    error = function(e) {
      body <- tryCatch(response$body, error = function(e2) NULL)
      !is.null(body) && length(body) > 0L
    }
  )

  if (!isTRUE(has_body)) return("")

  tryCatch(
    httr2::resp_body_string(response),
    error = function(e) ""
  )
}

atlas_v312_parse_census_array <- function(text) {
  text <- as.character(text %||% "")
  if (!length(text) || !nzchar(text[[1L]])) return(NULL)

  parsed <- tryCatch(
    jsonlite::fromJSON(text[[1L]], simplifyVector = TRUE),
    error = function(e) NULL
  )
  if (is.null(parsed) || length(parsed) < 2L) return(NULL)

  if (is.matrix(parsed) || is.data.frame(parsed)) {
    header <- as.character(parsed[1L, , drop = TRUE])
    values <- parsed[-1L, , drop = FALSE]
  } else if (is.list(parsed) && length(parsed) >= 2L) {
    header <- as.character(unlist(parsed[[1L]], use.names = FALSE))
    rows <- lapply(
      parsed[-1L],
      function(row) as.character(unlist(row, use.names = FALSE))
    )
    widths <- vapply(rows, length, integer(1L))
    if (!length(rows) || any(widths != length(header))) return(NULL)
    values <- do.call(rbind, rows)
  } else {
    return(NULL)
  }

  if (!length(header) || ncol(values) != length(header)) return(NULL)

  output <- as.data.frame(values, stringsAsFactors = FALSE)
  names(output) <- make.unique(header)
  output
}

atlas_v312_qwi_fetch <- function(
    request,
    max_tries = 3L,
    heartbeat = FALSE) {

  max_tries <- suppressWarnings(as.integer(max_tries))
  if (!length(max_tries) || !is.finite(max_tries[[1L]])) {
    max_tries <- 1L
  } else {
    max_tries <- max(1L, max_tries[[1L]])
  }
  last_result <- list(
    text = "",
    status = NA_integer_,
    has_body = FALSE,
    body_bytes = 0L,
    attempt = 0L,
    error = ""
  )

  for (attempt in seq_len(max_tries)) {
    error_message <- ""
    response <- tryCatch(
      httr2::req_perform(request),
      error = function(e) {
        error_message <<- conditionMessage(e)
        NULL
      }
    )

    status <- if (is.null(response)) {
      NA_integer_
    } else {
      tryCatch(httr2::resp_status(response), error = function(e) NA_integer_)
    }
    text <- atlas_v312_safe_resp_body_string(response)
    has_body <- nzchar(text)

    last_result <- list(
      text = text,
      status = status,
      has_body = has_body,
      body_bytes = if (has_body) nchar(text, type = "bytes") else 0L,
      attempt = attempt,
      error = error_message
    )

    if (
      !is.null(response) &&
      (is.na(status) || status < 300L) &&
      has_body
    ) {
      return(last_result)
    }

    # A completed 2xx response with no body is not parsed and is not retried.
    # Retrying the same empty QWI cell hundreds of times can make a full refresh
    # appear to stall without improving data availability.
    if (
      !is.null(response) &&
      !is.na(status) &&
      status < 300L &&
      !has_body
    ) {
      return(last_result)
    }

    # Deterministic client errors should not consume all retry attempts. Rate
    # limits (429) and server/network failures remain eligible for retry.
    if (
      is.null(response) &&
      nzchar(error_message) &&
      grepl("\\b(400|401|403|404|405|409|410|422)\\b", error_message) &&
      !grepl("\\b429\\b", error_message)
    ) {
      return(last_result)
    }

    if (isTRUE(heartbeat)) {
      message(
        "  QWI attempt ", attempt, "/", max_tries,
        " returned status ", ifelse(is.na(status), "NA", status),
        " and ", last_result$body_bytes, " body bytes."
      )
    }

    if (attempt < max_tries) {
      Sys.sleep(min(4, 0.5 * (2 ^ (attempt - 1L))))
    }
  }

  last_result
}

atlas_v312_write_qwi_diagnostics <- function(rows, filename) {
  if (!length(rows)) return(invisible(FALSE))

  root <- getOption("ia.atlas.v312.project_root", getwd())
  output <- file.path(root, "outputs", filename)
  dir.create(dirname(output), recursive = TRUE, showWarnings = FALSE)
  diagnostics <- dplyr::bind_rows(rows)

  if (requireNamespace("readr", quietly = TRUE)) {
    readr::write_csv(diagnostics, output)
  } else {
    utils::write.csv(diagnostics, output, row.names = FALSE)
  }

  invisible(output)
}

atlas_v312_get_qwi_iowa_hardened <- function(
    cfg = load_config(),
    refresh = FALSE) {

  project_paths <- paths()
  output <- file.path(
    project_paths$processed,
    "qwi_iowa_county_industry.csv"
  )
  if (file.exists(output) && !refresh) {
    return(readr::read_csv(output, show_col_types = FALSE))
  }

  sectors <- c(
    "11", "21", "22", "23", "31", "32", "33", "42", "44",
    "45", "48", "49", "51", "52", "53", "54", "55", "56",
    "61", "62", "71", "72", "81", "92"
  )

  attempts <- atlas_v312_qwi_attempt_grid(
    cfg$qwi_year,
    cfg$qwi_quarter,
    lookback_years = 4L
  )

  selected <- list()
  diagnostics <- list()

  for (row_index in seq_len(nrow(attempts))) {
    year <- attempts$year[[row_index]]
    quarter <- attempts$quarter[[row_index]]
    message("Trying QWI ", year, " Q", quarter, "...")

    period_rows <- list()
    valid_sectors <- 0L
    unusable_sectors <- 0L

    for (industry in sectors) {
      request <- tryCatch(
        atlas_v312_build_qwi_request(
          year = year,
          quarter = quarter,
          industry = industry,
          cfg = cfg,
          geography = "county"
        ),
        error = function(e) NULL
      )

      fetched <- if (is.null(request)) {
        list(
          text = "", status = NA_integer_, has_body = FALSE,
          body_bytes = 0L, attempt = 0L,
          error = "QWI request could not be constructed."
        )
      } else {
        atlas_v312_qwi_fetch(request, max_tries = 3L)
      }

      parsed <- atlas_v312_parse_census_array(fetched$text)
      row_count <- if (is.null(parsed)) 0L else nrow(parsed)

      diagnostics[[length(diagnostics) + 1L]] <- data.frame(
        year = year,
        quarter = quarter,
        industry = industry,
        request_attempts = fetched$attempt,
        status = fetched$status,
        has_body = fetched$has_body,
        body_bytes = fetched$body_bytes,
        parsed = !is.null(parsed),
        rows = row_count,
        error = fetched$error,
        stringsAsFactors = FALSE
      )

      if (!is.null(parsed) && row_count > 0L) {
        period_rows[[length(period_rows) + 1L]] <- parsed
        valid_sectors <- valid_sectors + 1L
      } else {
        unusable_sectors <- unusable_sectors + 1L
      }

      # Five consecutive unusable sector queries before the first successful
      # sector are enough to classify this quarter as unavailable and move on.
      if (valid_sectors == 0L && unusable_sectors >= 5L) {
        message(
          "  QWI ", year, " Q", quarter,
          " returned no usable body for the first five sectors; trying the ",
          "next earlier quarter."
        )
        break
      }

      Sys.sleep(0.05)
    }

    if (valid_sectors >= 10L) {
      selected <- period_rows
      message(
        "QWI refresh selected ", year, " Q", quarter,
        " with ", valid_sectors, " usable industry sectors."
      )
      break
    }
  }

  atlas_v312_write_qwi_diagnostics(
    diagnostics,
    "qwi_request_diagnostics_v312.csv"
  )

  if (!length(selected)) {
    warning(
      "QWI API did not return enough usable industry data after valid-query ",
      "retries; LODES WAC will be used as fallback. See ",
      "outputs/qwi_request_diagnostics_v312.csv.",
      call. = FALSE
    )
    return(tibble::tibble())
  }

  qwi <- dplyr::bind_rows(selected) |>
    janitor::clean_names() |>
    dplyr::mutate(
      state = as.character(.data$state),
      county = as.character(.data$county),
      county_fips = paste0(
        stringr::str_pad(.data$state, 2L, pad = "0"),
        stringr::str_pad(.data$county, 3L, pad = "0")
      ),
      naics2 = stringr::str_pad(
        as.character(.data$industry),
        2L,
        pad = "0"
      ),
      qwi_year = as.integer(.data$year),
      qwi_quarter = as.integer(.data$quarter),
      emp = readr::parse_number(as.character(.data$emp)),
      emp_stable = readr::parse_number(as.character(.data$emp_s)),
      hires = readr::parse_number(as.character(.data$hir_a)),
      separations = readr::parse_number(as.character(.data$sep)),
      avg_monthly_earnings = readr::parse_number(
        as.character(.data$earn_s)
      ),
      payroll = readr::parse_number(as.character(.data$payroll))
    ) |>
    dplyr::select(
      county_fips, naics2, qwi_year, qwi_quarter, emp, emp_stable,
      hires, separations, avg_monthly_earnings, payroll
    ) |>
    dplyr::filter(!is.na(.data$emp), .data$emp > 0)

  readr::write_csv(qwi, output)
  qwi
}

atlas_v312_v3_qwi_query_hardened <- function(
    year,
    quarter,
    agegrp,
    industry,
    key,
    state_fips = "19") {

  indicators <- c(
    "Emp", "EmpS", "HirA", "HirN", "Sep", "EarnS",
    "EarnHirAS", "FrmJbGn", "FrmJbLs", "year", "quarter",
    "industry", "agegrp"
  )

  request <- atlas_v312_build_qwi_request(
    year = year,
    quarter = quarter,
    industry = industry,
    state_fips = state_fips,
    geography = "state",
    agegrp = agegrp,
    indicators = indicators,
    timeout_seconds = 90,
    api_key = as.character(key %||% "")
  )

  fetched <- atlas_v312_qwi_fetch(request, max_tries = 2L)
  output <- atlas_v312_parse_census_array(fetched$text)
  if (is.null(output) || !nrow(output)) return(tibble::tibble())

  if (exists("v3_clean_names", mode = "function", inherits = TRUE)) {
    v3_clean_names(output)
  } else {
    janitor::clean_names(output)
  }
}

atlas_v312_v3_request_json_hardened <- function(
    url,
    query = list(),
    timeout_seconds = 120,
    retries = 3L) {

  request <- httr2::request(url) |>
    httr2::req_user_agent(
      "Iowa-AI-Workforce-Atlas-Methodology-v3/3.1.2 public-research"
    ) |>
    httr2::req_timeout(timeout_seconds)

  if (length(query)) {
    request <- do.call(
      httr2::req_url_query,
      c(list(request), query)
    )
  }

  fetched <- atlas_v312_qwi_fetch(
    request,
    max_tries = max(1L, suppressWarnings(as.integer(retries)))
  )
  if (!nzchar(fetched$text)) return(list())

  tryCatch(
    jsonlite::fromJSON(fetched$text, simplifyVector = TRUE),
    error = function(e) list()
  )
}

atlas_v312_patch_qwi_key <- function() {
  patched <- FALSE

  if (exists("qwi_api_url", mode = "function", inherits = TRUE)) {
    if (!exists(".atlas_v312_original_qwi_api_url", inherits = FALSE)) {
      assign(
        ".atlas_v312_original_qwi_api_url",
        get("qwi_api_url", mode = "function", inherits = TRUE),
        envir = .GlobalEnv
      )
    }

    assign(
      "qwi_api_url",
      function(year, quarter, industry, cfg = load_config()) {
        atlas_v312_build_qwi_request(
          year = year,
          quarter = quarter,
          industry = industry,
          cfg = cfg,
          geography = "county"
        )
      },
      envir = .GlobalEnv
    )
    patched <- TRUE
  }

  if (exists("get_qwi_iowa", mode = "function", inherits = TRUE)) {
    if (!exists(".atlas_v312_original_get_qwi_iowa", inherits = FALSE)) {
      assign(
        ".atlas_v312_original_get_qwi_iowa",
        get("get_qwi_iowa", mode = "function", inherits = TRUE),
        envir = .GlobalEnv
      )
    }
    assign(
      "get_qwi_iowa",
      atlas_v312_get_qwi_iowa_hardened,
      envir = .GlobalEnv
    )
    patched <- TRUE
  }

  if (exists("v3_qwi_query", mode = "function", inherits = TRUE)) {
    if (!exists(".atlas_v312_original_v3_qwi_query", inherits = FALSE)) {
      assign(
        ".atlas_v312_original_v3_qwi_query",
        get("v3_qwi_query", mode = "function", inherits = TRUE),
        envir = .GlobalEnv
      )
    }
    assign(
      "v3_qwi_query",
      atlas_v312_v3_qwi_query_hardened,
      envir = .GlobalEnv
    )
    patched <- TRUE
  }

  if (exists("v3_request_json", mode = "function", inherits = TRUE)) {
    if (!exists(".atlas_v312_original_v3_request_json", inherits = FALSE)) {
      assign(
        ".atlas_v312_original_v3_request_json",
        get("v3_request_json", mode = "function", inherits = TRUE),
        envir = .GlobalEnv
      )
    }
    assign(
      "v3_request_json",
      atlas_v312_v3_request_json_hardened,
      envir = .GlobalEnv
    )
    patched <- TRUE
  }

  previous_version <- getOption("ia.atlas.v312.qwi_hotfix", "")
  if (isTRUE(patched) && !identical(previous_version, "hotfix3")) {
    message(
      "QWI client hardening active: valid Sex-by-Age predicates, newest-",
      "quarter-first ordering, bounded retries, empty-body handling, and ",
      "LODES fallback diagnostics."
    )
    options("ia.atlas.v312.qwi_hotfix" = "hotfix3")
  }

  invisible(patched)
}

atlas_v312_call_head_name <- function(expression) {
  if (!is.call(expression) || !length(expression)) return("")

  head <- expression[[1L]]
  if (is.symbol(head)) return(as.character(head))

  if (
    is.call(head) &&
    length(head) >= 3L &&
    is.symbol(head[[1L]]) &&
    as.character(head[[1L]]) %in% c("::", ":::")
  ) {
    return(as.character(head[[3L]]))
  }

  ""
}

atlas_v312_deferred_names <- function() {
  c(
    "make_pdf_reports",
    "make_editable_excel_figures",
    "make_methodology_v3_editable_excel_figures",
    "make_methodology_v3_editable_figures",
    "v3_make_editable_excel_figures",
    "make_editable_excel_figures_v3",
    "create_methodology_v3_editable_excel_workbook",
    "v3_run_methodology_v3_pdf_stage",
    "validate_run_outputs",
    "validate_methodology_v2_outputs",
    "validate_methodology_v3_outputs",
    "v3_validate_methodology_v3_outputs",
    "v3_validate_methodology_v3_output_quality",
    "v3_validate_methodology_v3_publication_release",
    "v3_validate_publication_release_outputs"
  )
}

atlas_v312_should_defer_name <- function(name) {
  if (!length(name) || !nzchar(name)) return(FALSE)

  name %in% atlas_v312_deferred_names() ||
    grepl(
      "^(make|create|run|repair|finalize).*pdf",
      name,
      ignore.case = TRUE
    ) ||
    grepl(
      "pdf.*(report|stage|compendium)",
      name,
      ignore.case = TRUE
    ) ||
    grepl(
      "^(make|create).*editable.*excel",
      name,
      ignore.case = TRUE
    ) ||
    grepl(
      "editable_excel.*(figure|workbook)",
      name,
      ignore.case = TRUE
    ) ||
    grepl("^validate_.*outputs?$", name) ||
    grepl("^v3_validate_.*outputs?$", name)
}

atlas_v312_reset_rewrite_log <- function() {
  assign(
    ".atlas_v312_rewrite_events",
    list(),
    envir = .GlobalEnv
  )
  invisible(TRUE)
}

atlas_v312_record_rewrite <- function(
    action,
    name,
    source_file = getOption(
      "ia.atlas.v312.current_source",
      ""
    )) {

  if (!exists(
    ".atlas_v312_rewrite_events",
    envir = .GlobalEnv,
    inherits = FALSE
  )) {
    atlas_v312_reset_rewrite_log()
  }

  events <- get(
    ".atlas_v312_rewrite_events",
    envir = .GlobalEnv,
    inherits = FALSE
  )

  events[[length(events) + 1L]] <- data.frame(
    source_file = as.character(source_file),
    action = as.character(action),
    call_name = as.character(name),
    recorded_at_utc = format(
      as.POSIXct(Sys.time(), tz = "UTC"),
      "%Y-%m-%d %H:%M:%S UTC"
    ),
    stringsAsFactors = FALSE
  )

  assign(
    ".atlas_v312_rewrite_events",
    events,
    envir = .GlobalEnv
  )

  invisible(TRUE)
}

atlas_v312_rewrite_log <- function() {
  if (!exists(
    ".atlas_v312_rewrite_events",
    envir = .GlobalEnv,
    inherits = FALSE
  )) {
    return(data.frame(
      source_file = character(),
      action = character(),
      call_name = character(),
      recorded_at_utc = character(),
      stringsAsFactors = FALSE
    ))
  }

  events <- get(
    ".atlas_v312_rewrite_events",
    envir = .GlobalEnv,
    inherits = FALSE
  )

  if (!length(events)) {
    return(data.frame(
      source_file = character(),
      action = character(),
      call_name = character(),
      recorded_at_utc = character(),
      stringsAsFactors = FALSE
    ))
  }

  do.call(rbind, events)
}

atlas_v312_resolve_source_path <- function(file) {
  if (!is.character(file) || length(file) != 1L || !nzchar(file)) {
    return(NA_character_)
  }

  expanded <- path.expand(file)
  absolute <- grepl("^/", expanded) ||
    grepl("^[A-Za-z]:[/\\\\]", expanded)

  candidate <- if (absolute) {
    expanded
  } else {
    file.path(getwd(), expanded)
  }

  normalizePath(
    candidate,
    winslash = "/",
    mustWork = FALSE
  )
}

atlas_v312_is_project_r_source <- function(file) {
  path <- atlas_v312_resolve_source_path(file)
  if (is.na(path) || !file.exists(path)) return(FALSE)
  if (!grepl("\\.[Rr]$", path)) return(FALSE)

  root <- getOption(
    "ia.atlas.v312.project_root",
    getwd()
  )
  root <- normalizePath(root, winslash = "/", mustWork = TRUE)

  identical(path, root) ||
    startsWith(path, paste0(root, "/"))
}

atlas_v312_collect_call_names <- function(expression) {
  if (!is.call(expression)) return(character())

  current <- atlas_v312_call_head_name(expression)
  nested <- unlist(
    lapply(
      as.list(expression)[-1L],
      atlas_v312_collect_call_names
    ),
    use.names = FALSE
  )

  unique(c(current, nested[nzchar(nested)]))
}

atlas_v312_write_transformed_source_copy <- function(
    source_file,
    expressions) {

  root <- getOption("ia.atlas.v312.project_root", getwd())
  root <- normalizePath(root, winslash = "/", mustWork = TRUE)
  source_file <- normalizePath(
    source_file,
    winslash = "/",
    mustWork = TRUE
  )

  relative <- if (startsWith(source_file, paste0(root, "/"))) {
    substring(source_file, nchar(root) + 2L)
  } else {
    basename(source_file)
  }

  target <- file.path(
    root,
    "outputs",
    "one_click_v312_rewritten_sources",
    relative
  )
  dir.create(dirname(target), recursive = TRUE, showWarnings = FALSE)

  rendered <- unlist(
    lapply(
      expressions,
      function(expression) {
        c(
          paste(
            deparse(expression, width.cutoff = 500L),
            collapse = "\n"
          ),
          ""
        )
      }
    ),
    use.names = FALSE
  )

  writeLines(rendered, target, useBytes = TRUE)
  parse(target)
  invisible(target)
}

atlas_v312_transform_source_file <- function(file) {
  path <- normalizePath(file, winslash = "/", mustWork = TRUE)
  old_source <- getOption("ia.atlas.v312.current_source", "")
  on.exit(
    options("ia.atlas.v312.current_source" = old_source),
    add = TRUE
  )
  options("ia.atlas.v312.current_source" = path)

  expressions <- parse(path, keep.source = TRUE)
  transformed <- lapply(
    as.list(expressions),
    atlas_v312_rewrite_runner_expression
  )

  remaining <- unique(unlist(
    lapply(transformed, atlas_v312_collect_call_names),
    use.names = FALSE
  ))
  remaining <- remaining[
    vapply(
      remaining,
      atlas_v312_should_defer_name,
      logical(1)
    )
  ]

  if (length(remaining)) {
    stop(
      "A transformed source file still contains legacy output calls: ",
      paste(remaining, collapse = ", "),
      " in ",
      path,
      call. = FALSE
    )
  }

  atlas_v312_write_transformed_source_copy(path, transformed)
  atlas_v312_record_rewrite("transformed_source", basename(path), path)
  transformed
}

atlas_v312_eval_transformed_source <- function(
    file,
    envir,
    chdir = FALSE) {

  path <- normalizePath(file, winslash = "/", mustWork = TRUE)
  expressions <- atlas_v312_transform_source_file(path)

  old_wd <- getwd()
  if (isTRUE(chdir)) {
    setwd(dirname(path))
    on.exit(setwd(old_wd), add = TRUE)
  }

  last_value <- NULL
  last_visible <- FALSE

  for (expression in expressions) {
    evaluated <- withVisible(eval(expression, envir = envir))
    last_value <- evaluated$value
    last_visible <- evaluated$visible
  }

  invisible(list(
    value = last_value,
    visible = last_visible
  ))
}

atlas_v312_source_rewritten <- function(
    file,
    local = FALSE,
    echo = verbose,
    print.eval = echo,
    exprs,
    spaced = TRUE,
    verbose = getOption("verbose"),
    prompt.echo = getOption("prompt"),
    max.deparse.length = 150,
    width.cutoff = 60L,
    deparseCtrl = "showAttributes",
    chdir = FALSE,
    encoding = getOption("encoding"),
    continue.echo = getOption("continue"),
    skip.echo = 0,
    keep.source = getOption("keep.source"),
    ...) {

  if (!atlas_v312_is_project_r_source(file)) {
    return(base::source(
      file = file,
      local = local,
      echo = echo,
      print.eval = print.eval,
      spaced = spaced,
      verbose = verbose,
      prompt.echo = prompt.echo,
      max.deparse.length = max.deparse.length,
      width.cutoff = width.cutoff,
      deparseCtrl = deparseCtrl,
      chdir = chdir,
      encoding = encoding,
      continue.echo = continue.echo,
      skip.echo = skip.echo,
      keep.source = keep.source,
      ...
    ))
  }

  evaluation_environment <- if (identical(local, FALSE)) {
    .GlobalEnv
  } else if (identical(local, TRUE)) {
    parent.frame()
  } else if (is.environment(local)) {
    local
  } else {
    stop("'local' must be FALSE, TRUE, or an environment.", call. = FALSE)
  }

  atlas_v312_eval_transformed_source(
    file = atlas_v312_resolve_source_path(file),
    envir = evaluation_environment,
    chdir = chdir
  )
}

atlas_v312_sys_source_rewritten <- function(
    file,
    envir = baseenv(),
    chdir = FALSE,
    keep.source = getOption("keep.source.pkgs"),
    toplevel.env = as.environment(envir)) {

  if (!atlas_v312_is_project_r_source(file)) {
    return(base::sys.source(
      file = file,
      envir = envir,
      chdir = chdir,
      keep.source = keep.source,
      toplevel.env = toplevel.env
    ))
  }

  atlas_v312_eval_transformed_source(
    file = atlas_v312_resolve_source_path(file),
    envir = envir,
    chdir = chdir
  )
}

atlas_v312_deferred_call <- function(name) {
  atlas_v312_record_rewrite("deferred_call", name)
  call(
    "message",
    paste0(
      "[one-click v3.1.3-clean-r10] Deferred legacy call: ",
      name,
      ". The bounded replacement will run after analytics and HTML."
    )
  )
}

atlas_v312_rewrite_runner_expression <- function(expression) {
  if (!is.call(expression)) return(expression)

  head_name <- atlas_v312_call_head_name(expression)
  arguments <- as.list(expression)[-1L]
  transformed_arguments <- lapply(
    arguments,
    atlas_v312_rewrite_runner_expression
  )
  names(transformed_arguments) <- names(arguments)

  if (head_name %in% c("source", "sys.source")) {
    replacement_head <- if (identical(head_name, "source")) {
      as.name("atlas_v312_source_rewritten")
    } else {
      as.name("atlas_v312_sys_source_rewritten")
    }

    return(as.call(c(
      list(replacement_head),
      transformed_arguments
    )))
  }

  if (atlas_v312_should_defer_name(head_name)) {
    return(atlas_v312_deferred_call(head_name))
  }

  if (identical(head_name, "do.call") && length(arguments)) {
    target <- arguments[[1L]]
    target_name <- if (is.character(target) && length(target) == 1L) {
      target
    } else if (is.symbol(target)) {
      as.character(target)
    } else {
      ""
    }

    if (atlas_v312_should_defer_name(target_name)) {
      return(atlas_v312_deferred_call(target_name))
    }
  }

  if (identical(head_name, "match_font")) {
    atlas_v312_record_rewrite("systemfonts_match_fonts_compat", head_name)
    return(as.call(c(
      list(as.name("atlas_v3125_match_font_compat")),
      transformed_arguments
    )))
  }

  if (identical(head_name, "geom_errorbarh")) {
    argument_names <- names(transformed_arguments)
    height_position <- which(argument_names == "height")
    if (length(height_position)) {
      argument_names[height_position[[1L]]] <- "width"
      names(transformed_arguments) <- argument_names
    }
    if (!"orientation" %in% names(transformed_arguments)) {
      transformed_arguments[["orientation"]] <- "y"
    }

    original_head <- expression[[1L]]
    replacement_head <- if (
      is.call(original_head) &&
      length(original_head) >= 3L &&
      is.symbol(original_head[[1L]]) &&
      as.character(original_head[[1L]]) %in% c("::", ":::")
    ) {
      as.call(list(
        original_head[[1L]],
        original_head[[2L]],
        as.name("geom_errorbar")
      ))
    } else {
      as.name("geom_errorbar")
    }

    atlas_v312_record_rewrite("geom_errorbarh_to_orientation_y", head_name)
    return(as.call(c(list(replacement_head), transformed_arguments)))
  }

  if (head_name %in% c(
    "geom_text", "geom_label", "geom_point",
    "geom_text_repel", "geom_label_repel"
  )) {
    if (!"na.rm" %in% names(transformed_arguments)) {
      transformed_arguments[["na.rm"]] <- TRUE
      atlas_v312_record_rewrite("plot_geom_na_rm_true", head_name)
    }
  }

  rebuilt <- as.call(c(
    list(expression[[1L]]),
    transformed_arguments
  ))

  if (
    identical(head_name, "system2") &&
    length(transformed_arguments) &&
    is.character(transformed_arguments[[1L]]) &&
    length(transformed_arguments[[1L]]) == 1L &&
    identical(tolower(transformed_arguments[[1L]]), "git")
  ) {
    atlas_v312_record_rewrite("suppress_non_git_rev_parse_warning", head_name)
    return(call("suppressWarnings", rebuilt))
  }

  data_calls <- c(
    "build_atlas",
    "apply_methodology_v2",
    "apply_methodology_v3"
  )

  if (head_name %in% data_calls) {
    rebuilt_arguments <- as.list(rebuilt)
    argument_names <- names(rebuilt_arguments)
    refresh_position <- which(argument_names == "refresh")
    refresh_expression <- call(
      "isTRUE",
      call("getOption", "ia.atlas.v312.refresh", TRUE)
    )

    if (length(refresh_position)) {
      rebuilt[[refresh_position[[1L]]]] <- refresh_expression
    } else {
      rebuilt <- as.call(c(
        as.list(rebuilt),
        list(refresh = refresh_expression)
      ))
    }

    atlas_v312_record_rewrite("one_click_refresh_setting", head_name)

    rebuilt <- as.call(list(
      as.name("{"),
      call("atlas_v312_patch_qwi_key"),
      rebuilt
    ))
  }

  rebuilt
}

atlas_v312_write_transformed_runner <- function(root) {
  source_file <- file.path(root, "R", "run_all.R")
  source_file <- normalizePath(
    source_file,
    winslash = "/",
    mustWork = TRUE
  )

  options("ia.atlas.v312.project_root" = root)
  transformed <- atlas_v312_transform_source_file(source_file)

  target <- file.path(
    root,
    "outputs",
    "_one_click_v312_analytics_runner.R"
  )
  dir.create(dirname(target), recursive = TRUE, showWarnings = FALSE)

  rendered <- unlist(
    lapply(
      transformed,
      function(expression) {
        c(
          paste(
            deparse(expression, width.cutoff = 500L),
            collapse = "\n"
          ),
          ""
        )
      }
    ),
    use.names = FALSE
  )

  writeLines(rendered, target, useBytes = TRUE)
  parse(target)
  target
}

atlas_v312_write_rewrite_manifest <- function(root) {
  manifest <- atlas_v312_rewrite_log()
  output <- file.path(
    root,
    "outputs",
    "one_click_v312_rewrite_manifest.csv"
  )

  if (requireNamespace("readr", quietly = TRUE)) {
    readr::write_csv(manifest, output)
  } else {
    utils::write.csv(manifest, output, row.names = FALSE)
  }

  deferred_pdf <- manifest$action == "deferred_call" &
    grepl("pdf", manifest$call_name, ignore.case = TRUE)

  if (!nrow(manifest) || !any(deferred_pdf)) {
    stop(
      "The nested-source rewrite did not intercept a legacy PDF call. ",
      "The one-click run is stopping before any Cairo/XQuartz stage can execute. ",
      "See ",
      output,
      ".",
      call. = FALSE
    )
  }

  message(
    "Nested-source guard intercepted ",
    sum(deferred_pdf),
    " legacy PDF call(s) across ",
    length(unique(manifest$source_file)),
    " transformed project source file(s)."
  )

  invisible(manifest)
}

atlas_v312_call_supported <- function(
    candidates,
    arguments = list(),
    required = FALSE,
    label = NULL) {

  candidates <- unique(as.character(candidates))

  # Resolve candidate functions explicitly from the environment where this
  # dispatcher was defined. Passing base::exists directly to vapply() leaves
  # exists() to infer its lookup frame from vapply's internal evaluation
  # context; that can miss functions stored in an isolated sys.source()
  # environment even though they are valid and visible to the dispatcher.
  lookup_env <- environment(sys.function())

  resolve_candidate <- function(name) {
    if (!exists(
      name,
      envir = lookup_env,
      mode = "function",
      inherits = TRUE
    )) return(NULL)

    get(
      name,
      envir = lookup_env,
      mode = "function",
      inherits = TRUE
    )
  }

  resolved <- lapply(candidates, resolve_candidate)
  hit_index <- which(vapply(resolved, is.function, logical(1L)))

  if (!length(hit_index)) {
    if (isTRUE(required)) {
      stop(
        "Could not find required function for ",
        label %||% paste(candidates, collapse = "/"),
        ".",
        call. = FALSE
      )
    }
    return(invisible(NULL))
  }

  selected_index <- hit_index[[1L]]
  function_name <- candidates[[selected_index]]
  function_object <- resolved[[selected_index]]

  formal_names <- names(formals(function_object))
  if (length(arguments) && anyDuplicated(names(arguments))) {
    arguments <- arguments[!duplicated(names(arguments), fromLast = TRUE)]
  }
  if (!"..." %in% formal_names) {
    arguments <- arguments[names(arguments) %in% formal_names]
  }

  message("Calling ", function_name, "().")
  do.call(function_object, arguments)
}

atlas_v312_source_module <- function(root, file) {
  path <- file.path(root, file)
  if (!file.exists(path)) {
    stop("Missing one-click module: ", path, call. = FALSE)
  }
  sys.source(path, envir = .GlobalEnv, keep.source = FALSE)
  invisible(path)
}


atlas_v312_activate_latest_pdf_printer <- function(root) {
  repair <- file.path(root, "R", "48_browser_pdf_completion_v319.R")
  if (!file.exists(repair)) {
    stop("Missing current PDF completion module: ", repair, call. = FALSE)
  }

  target_env <- environment(sys.function())
  sys.source(repair, envir = target_env, keep.source = FALSE)
  if (!exists(
    "atlas_v312_print_html_pdf_with_fallback",
    envir = target_env,
    mode = "function",
    inherits = TRUE
  )) {
    stop("The current browser-PDF override was not installed.", call. = FALSE)
  }

  printer <- get(
    "atlas_v312_print_html_pdf_with_fallback",
    envir = target_env,
    mode = "function",
    inherits = TRUE
  )
  revision <- attr(printer, "atlas_pdf_revision", exact = TRUE)
  if (!identical(revision, "3.1.3-clean-r10")) {
    stop(
      "PDF printer source-order guard failed; expected 3.1.3-clean-r10 but found ",
      if (is.null(revision)) "an unmarked legacy printer" else revision,
      ".",
      call. = FALSE
    )
  }
  message("Active browser-PDF printer: ", revision, ".")
  invisible(revision)
}

atlas_v312_start_caffeinate <- function() {
  if (
    identical(Sys.info()[["sysname"]], "Darwin") &&
    nzchar(Sys.which("caffeinate")) &&
    requireNamespace("processx", quietly = TRUE)
  ) {
    process <- processx::process$new(
      command = Sys.which("caffeinate"),
      args = c("-dimsu"),
      stdout = "|",
      stderr = "|",
      cleanup_tree = TRUE
    )
    return(process)
  }
  NULL
}

atlas_v312_render_all_reports <- function(root) {
  atlas_v312_call_supported(
    c("render_reports"),
    list(
      refresh = FALSE,
      stop_on_error = TRUE,
      quiet = FALSE,
      make_core_figures = FALSE
    ),
    required = TRUE,
    label = "Methodology v2 HTML rendering"
  )

  paths_v3 <- if (exists("v3_paths", mode = "function")) {
    v3_paths()
  } else {
    list(root = root)
  }

  atlas_v312_call_supported(
    c("render_methodology_v3_reports"),
    list(
      quiet = FALSE,
      paths = paths_v3
    ),
    required = TRUE,
    label = "Methodology v3 HTML rendering"
  )

  invisible(TRUE)
}

atlas_v312_create_pdf_outputs <- function(root) {
  # R/43 is sourced during the one-click bootstrap and contains a legacy
  # compatibility printer. Reactivate the current stable-file implementation
  # immediately before publication so a full run cannot regress to that path.
  atlas_v312_activate_latest_pdf_printer(root)
  browser <- atlas_v312_find_browser()
  timeout_text <- Sys.getenv("IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS", unset = "")
  if (!nzchar(timeout_text)) {
    timeout_text <- Sys.getenv("IA_ATLAS_ONE_CLICK_PDF_TIMEOUT_SEC", unset = "240")
  }
  timeout <- suppressWarnings(as.numeric(timeout_text))
  if (!is.finite(timeout)) timeout <- 240
  timeout <- max(20, min(timeout, 240))
  heartbeat <- suppressWarnings(
    as.numeric(
      Sys.getenv(
        "IA_ATLAS_ONE_CLICK_PDF_HEARTBEAT_SEC",
        unset = "15"
      )
    )
  )
  tagged <- tolower(
    Sys.getenv(
      "IA_ATLAS_ONE_CLICK_PDF_TAGGED",
      unset = if (.Platform$OS.type == "windows") "true" else "false"
    )
  ) %in% c("true", "1", "yes", "y")

  reports <- list(
    list(
      name = "Methodology v2 Quarto report",
      input = file.path(root, "outputs", "atlas_quarto.html"),
      print = file.path(root, "outputs", "atlas_quarto_article_print.html"),
      assets = file.path(root, "outputs", "atlas_quarto_article_assets"),
      pdf = file.path(root, "outputs", "atlas_quarto_with_all_figures.pdf")
    ),
    list(
      name = "Methodology v2 R Markdown report",
      input = file.path(root, "outputs", "atlas_rmarkdown.html"),
      print = file.path(root, "outputs", "atlas_rmarkdown_article_print.html"),
      assets = file.path(root, "outputs", "atlas_rmarkdown_article_assets"),
      pdf = file.path(root, "outputs", "atlas_rmarkdown_with_all_figures.pdf")
    ),
    list(
      name = "Methodology v3 Quarto report",
      input = file.path(root, "outputs", "atlas_methodology_v3_quarto.html"),
      print = file.path(root, "outputs", "atlas_methodology_v3_quarto_article_print.html"),
      assets = file.path(root, "outputs", "atlas_methodology_v3_quarto_article_assets"),
      pdf = file.path(root, "outputs", "atlas_methodology_v3_quarto.pdf")
    ),
    list(
      name = "Methodology v3 R Markdown report",
      input = file.path(root, "outputs", "atlas_methodology_v3_rmarkdown.html"),
      print = file.path(root, "outputs", "atlas_methodology_v3_rmarkdown_article_print.html"),
      assets = file.path(root, "outputs", "atlas_methodology_v3_rmarkdown_article_assets"),
      pdf = file.path(root, "outputs", "atlas_methodology_v3_rmarkdown.pdf")
    )
  )

  manifest <- list()

  for (report in reports) {
    if (!file.exists(report$input)) {
      stop("Missing rendered HTML: ", report$input, call. = FALSE)
    }

    atlas_v312_externalize_print_html(
      input_html = report$input,
      output_html = report$print,
      asset_dir = report$assets
    )

    result <- atlas_v312_print_html_pdf_with_fallback(
      browser = browser,
      html = report$print,
      pdf = report$pdf,
      artifact = report$name,
      timeout_sec = timeout,
      heartbeat_sec = heartbeat,
      tagged = tagged,
      min_pages = 10L,
      min_bytes = 65536L
    )

    manifest[[length(manifest) + 1L]] <- data.frame(
      artifact = report$name,
      html = report$print,
      pdf = report$pdf,
      pages = result$pages,
      bytes = result$bytes,
      valid = result$valid,
      attempt = result$attempt %||% 1L,
      tagged = result$tagged %||% FALSE,
      stringsAsFactors = FALSE
    )

    gc(verbose = FALSE)
  }

  v2_figures <- list.files(
    file.path(root, "figures"),
    pattern = "\\.png$",
    recursive = TRUE,
    full.names = TRUE
  )
  v2_figures <- v2_figures[
    !grepl(
      "/methodology_v3/|_white_preview\\.png$|/before_article_",
      gsub("\\\\", "/", v2_figures)
    )
  ]

  v3_figures <- list.files(
    file.path(root, "figures", "methodology_v3"),
    pattern = "\\.png$",
    full.names = TRUE
  )
  v3_figures <- v3_figures[
    !grepl("_white_preview\\.png$", v3_figures)
  ]

  atlas_v312_create_compendium(
    figures = v2_figures,
    output_pdf = file.path(
      root,
      "outputs",
      "all_generated_figures_printable.pdf"
    )
  )

  atlas_v312_create_compendium(
    figures = v3_figures,
    output_pdf = file.path(
      root,
      "outputs",
      "all_generated_figures_methodology_v3_printable.pdf"
    )
  )

  manifest_data <- dplyr::bind_rows(manifest)
  readr::write_csv(
    manifest_data,
    file.path(
      root,
      "outputs",
      "one_click_v312_pdf_manifest.csv"
    )
  )

  invisible(manifest_data)
}

atlas_v312_build_excel_outputs <- function(
    root,
    article_plots) {
  # v3.1.3-clean-r6 Excel compatibility aliases. The maintained v3 builder
  # is make_methodology_v3_editable_excel(); older one-click candidate names
  # remain aliases so cached/source-order variants cannot stop Stage 6.
  if (exists("make_methodology_v3_editable_excel", mode = "function", inherits = TRUE)) {
    .atlas_v313_excel_builder <- get(
      "make_methodology_v3_editable_excel",
      mode = "function",
      inherits = TRUE
    )
    if (!exists("v3_make_methodology_v3_editable_excel", mode = "function", inherits = TRUE)) {
      assign(
        "v3_make_methodology_v3_editable_excel",
        .atlas_v313_excel_builder,
        envir = .GlobalEnv
      )
    }
    if (!exists("make_methodology_v3_editable_excel_workbook", mode = "function", inherits = TRUE)) {
      assign(
        "make_methodology_v3_editable_excel_workbook",
        .atlas_v313_excel_builder,
        envir = .GlobalEnv
      )
    }
  }


  if (
    exists("atlas_override_excel_core_plots", mode = "function")
  ) {
    atlas_override_excel_core_plots()
  }

  message('  Stage 6.1/4: Methodology v2 editable workbook.')
  atlas_v312_call_supported(
    c("make_editable_excel_figures"),
    list(
      install_missing = TRUE,
      build_if_missing = FALSE,
      refresh = FALSE
    ),
    required = TRUE,
    label = "Methodology v2 editable Excel"
  )

  paths_v3 <- if (exists("v3_paths", mode = "function")) {
    v3_paths()
  } else {
    list(root = root)
  }

  message('  Stage 6.2/4: Methodology v3 editable workbook.')
  atlas_v312_call_supported(
    c(
      "make_methodology_v3_editable_excel",
      "make_methodology_v3_editable_excel_figures",
      "make_methodology_v3_editable_figures",
      "v3_make_editable_excel_figures",
      "make_editable_excel_figures_v3",
      "create_methodology_v3_editable_excel_workbook"
    ),
    list(
      paths = paths_v3,
      install_missing = TRUE,
      build_if_missing = FALSE,
      refresh = FALSE
    ),
    required = TRUE,
    label = "Methodology v3 editable Excel"
  )

  v2_workbook <- file.path(
    root,
    "outputs",
    "iowa_ai_workforce_atlas_editable_figures.xlsx"
  )
  v3_workbook <- file.path(
    root,
    "outputs",
    "iowa_ai_workforce_atlas_methodology_v3_editable_figures.xlsx"
  )

  message('  Stage 6.3/4: optional article-ready editable sheets.')
  article_manifest <- atlas_v312_add_article_plot_sheets(
    workbook_file = v2_workbook,
    plots = article_plots,
    prefix = "Article"
  )
  readr::write_csv(
    article_manifest,
    file.path(
      root,
      "outputs",
      "article_editable_figure_manifest_v312.csv"
    )
  )

  master <- file.path(
    root,
    "outputs",
    "iowa_ai_workforce_atlas_all_editable_figures.xlsx"
  )

  message('  Stage 6.4/4: consolidated editable workbook.')
  consolidated <- atlas_v312_create_master_editable_workbook(
    v2_file = v2_workbook,
    v3_file = v3_workbook,
    output_file = master,
    stop_on_failure = TRUE
  )

  invisible(
    list(
      v2 = v2_workbook,
      v3 = v3_workbook,
      master = if (isTRUE(consolidated)) master else NA_character_,
      master_valid = isTRUE(consolidated)
    )
  )
}

atlas_v312_validate_outputs <- function(root, excel_outputs) {
  checks <- list()

  add <- function(check, path, passed, detail = "") {
    checks[[length(checks) + 1L]] <<- data.frame(
      check = check,
      path = path,
      passed = isTRUE(passed),
      detail = as.character(detail),
      checked_at_utc = format(
        as.POSIXct(Sys.time(), tz = "UTC"),
        "%Y-%m-%d %H:%M:%S UTC"
      ),
      stringsAsFactors = FALSE
    )
  }

  figure_quality <- atlas_v3125_validate_figure_sets(
    root,
    stop_on_failure = FALSE
  )
  failed_required_figures <- figure_quality$required & !figure_quality$passed
  add(
    "Required figure integrity contract",
    file.path(root, "outputs", "one_click_v312_figure_quality_check.csv"),
    !any(failed_required_figures),
    paste0(
      "required=", sum(figure_quality$required),
      "; failed=", sum(failed_required_figures)
    )
  )

  public <- list.files(
    file.path(root, "figures", "public"),
    pattern = "^public_[0-9]{2}_.*\\.png$",
    full.names = TRUE
  )
  method_v2 <- list.files(
    file.path(root, "figures", "methodology_v2"),
    pattern = "\\.png$",
    full.names = TRUE
  )
  method_v3 <- list.files(
    file.path(root, "figures", "methodology_v3"),
    pattern = "\\.png$",
    full.names = TRUE
  )

  add(
    "26 public figures",
    file.path(root, "figures", "public"),
    length(public) >= 26L,
    paste("count=", length(public))
  )
  add(
    "10 Methodology v2 figures",
    file.path(root, "figures", "methodology_v2"),
    length(method_v2) >= 10L,
    paste("count=", length(method_v2))
  )
  add(
    "13 Methodology v3 figures",
    file.path(root, "figures", "methodology_v3"),
    length(method_v3) >= 13L,
    paste("count=", length(method_v3))
  )

  pdfs <- file.path(
    root,
    "outputs",
    c(
      "atlas_quarto_with_all_figures.pdf",
      "atlas_rmarkdown_with_all_figures.pdf",
      "atlas_methodology_v3_quarto.pdf",
      "atlas_methodology_v3_rmarkdown.pdf",
      "all_generated_figures_printable.pdf",
      "all_generated_figures_methodology_v3_printable.pdf"
    )
  )

  for (path in pdfs) {
    minimum <- if (grepl("all_generated", basename(path))) 5L else 10L
    result <- atlas_v312_validate_pdf(
      path,
      min_pages = minimum,
      min_bytes = if (grepl("all_generated", basename(path))) 32768L else 65536L
    )
    add(
      paste("PDF", basename(path)),
      path,
      result$valid,
      paste0(
        "pages=", result$pages,
        "; bytes=", result$bytes,
        "; ", result$reason
      )
    )
  }

  workbook_requirements <- data.frame(
    path = c(excel_outputs$v2, excel_outputs$v3),
    minimum_drawings = c(40L, 13L),
    stringsAsFactors = FALSE
  )

  for (index in seq_len(nrow(workbook_requirements))) {
    path <- workbook_requirements$path[[index]]
    minimum <- workbook_requirements$minimum_drawings[[index]]
    drawing_count <- atlas_v312_count_drawings(path)
    add(
      paste("Editable workbook", basename(path)),
      path,
      file.exists(path) && drawing_count >= minimum,
      paste0(
        "drawing_xml=", drawing_count,
        "; minimum=", minimum
      )
    )
  }

  if (!is.na(excel_outputs$master)) {
    master_drawings <- atlas_v312_count_drawings(excel_outputs$master)
    add(
      "Consolidated editable workbook",
      excel_outputs$master,
      master_drawings >= 53L,
      paste("drawing_xml=", master_drawings)
    )
  } else {
    add(
      "Consolidated editable workbook",
      file.path(
        root,
        "outputs",
        "iowa_ai_workforce_atlas_all_editable_figures.xlsx"
      ),
      FALSE,
      paste(
        "The installed openxlsx2 clone API did not preserve every drawing.",
        "The separate v2 and v3 editable workbooks are authoritative."
      )
    )
  }

  result <- dplyr::bind_rows(checks)
  output <- file.path(
    root,
    "outputs",
    "one_click_v312_output_check.csv"
  )
  readr::write_csv(result, output)

  if (!all(result$passed)) {
    stop(
      "One-click output validation failed. See ",
      output,
      ".",
      call. = FALSE
    )
  }

  invisible(result)
}

atlas_run_iowa_ai_atlas_one_click_v312 <- function(
    root = getwd(),
    refresh = TRUE) {

  root <- atlas_v312_find_root(root)
  old <- getwd()
  on.exit(setwd(old), add = TRUE)
  setwd(root)
  options("ia.atlas.v312.refresh" = isTRUE(refresh))

  dir.create(file.path(root, "outputs"), recursive = TRUE, showWarnings = FALSE)

  started <- Sys.time()
  caffeinate <- NULL
  on.exit({
    if (!is.null(caffeinate) && caffeinate$is_alive()) {
      try(caffeinate$kill_tree(), silent = TRUE)
    }
  }, add = TRUE)

  message("Iowa AI Workforce Atlas one-click v3.1.3-clean-r10")
  message("Project root: ", root)
  message("Operating system: ", Sys.info()[["sysname"]])
  message("R version: ", getRversion())
  message("Refresh public data: ", refresh)

  Sys.setenv(
    IA_ATLAS_V3_SKIP_V2 = "false",
    IA_ATLAS_REFRESH = if (isTRUE(refresh)) "always" else "never",
    IA_ATLAS_V2_REFRESH = if (isTRUE(refresh)) "always" else "never",
    IA_ATLAS_V3_REFRESH = if (isTRUE(refresh)) "always" else "never"
  )

  key_status <- data.frame(
    key = c("CENSUS_API_KEY", "BEA_API_KEY"),
    configured = c(
      nzchar(Sys.getenv("CENSUS_API_KEY")),
      nzchar(Sys.getenv("BEA_API_KEY"))
    ),
    stringsAsFactors = FALSE
  )
  readr::write_csv(
    key_status,
    file.path(root, "outputs", "one_click_v312_api_key_status.csv")
  )

  if (!key_status$configured[key_status$key == "CENSUS_API_KEY"]) {
    warning(
      "CENSUS_API_KEY is not configured. ACS/QWI requests may be more limited.",
      call. = FALSE
    )
  }
  if (!key_status$configured[key_status$key == "BEA_API_KEY"]) {
    warning(
      "BEA_API_KEY is not configured. BEA-dependent Methodology v3 modules ",
      "may remain unavailable.",
      call. = FALSE
    )
  }

  atlas_v3124_verify_early_career_join_contract(root)
  message(
    "Hotfix 6 early-career join contract verified: occupation-industry ",
    "exposure and employment remain canonical; industry benchmarks are ",
    "retained under explicit audit names."
  )

  if (file.exists(file.path(root, "R", "00_setup.R"))) {
    sys.source(
      file.path(root, "R", "00_setup.R"),
      envir = .GlobalEnv,
      keep.source = FALSE
    )
    if (exists("setup_packages", mode = "function")) {
      setup_packages(install_optional = FALSE)
    }
  }

  atlas_v312_ensure_packages()
  caffeinate <- atlas_v312_start_caffeinate()

  atlas_v312_source_module(root, "R/41_article_visual_optimizer.R")
  atlas_v312_source_module(root, "R/42_article_plot_overrides_v312.R")
  atlas_v312_source_module(root, "R/43_cross_platform_pdf_v312.R")
  atlas_v312_source_module(root, "R/44_editable_excel_master_v312.R")
  atlas_v312_source_module(root, "R/46_one_click_figure_runtime_v312.R")
  # Re-source later repairs after legacy modules. This ordering is essential:
  # R/43 otherwise replaces the stable-file browser-PDF implementation.
  atlas_v312_source_module(root, "R/47_htops_visual_polish_v317.R")
  if (exists("atlas_v317_install_runtime_wrappers", mode = "function", inherits = TRUE)) {
    atlas_v317_install_runtime_wrappers(root = root)
  }
  atlas_v312_source_module(root, "R/47_public_source_and_excel_repairs_v313.R")
  if (exists("atlas_v313_install_repairs", mode = "function", inherits = TRUE)) {
    atlas_v313_install_repairs()
  }
  atlas_v312_source_module(root, "R/48_browser_pdf_completion_v319.R")
  atlas_v3125_reset_warning_audit()
  atlas_v3125_set_figure_defaults()

  message("Stage 1/8: running the full v2 + v3 analytical runner through the recursive nested-source guard.")
  message("One-click refresh contract: build_atlas(), apply_methodology_v2(), and apply_methodology_v3() will receive the IA_ATLAS_ONE_CLICK_REFRESH setting; QWI requests use the current Census API contract and nonfatal empty-body handling; the Methodology v3 early-career join preserves distinct cell and industry exposure fields.")
  options("ia.atlas.v312.project_root" = root)
  atlas_v312_reset_rewrite_log()
  transformed <- atlas_v312_write_transformed_runner(root)
  atlas_v3125_with_warning_audit(
    "Stage 1 analytics and initial figures",
    root,
    function() base::source(transformed, chdir = FALSE)
  )
  atlas_v312_write_rewrite_manifest(root)

  message("Stage 2/8: regenerating all v2 and v3 figures with article defaults.")
  if (exists("atlas_apply_article_defaults", mode = "function")) {
    atlas_apply_article_defaults()
  }
  atlas_v3125_set_figure_defaults()

  atlas_v3125_with_warning_audit(
    "Stage 2 core report figures",
    root,
    function() atlas_v312_call_supported(
      c("make_figures"),
      list(refresh = FALSE),
      required = TRUE,
      label = "core figures"
    )
  )

  atlas_v3125_with_warning_audit(
    "Stage 2 public figures 01-26",
    root,
    function() atlas_v312_call_supported(
      c("make_public_visualizations"),
      list(
        install_missing = TRUE,
        build_if_missing = FALSE,
        refresh = FALSE
      ),
      required = TRUE,
      label = "26 public figures"
    )
  )

  atlas_v3125_with_warning_audit(
    "Stage 2 Methodology v2 figures 27-36",
    root,
    function() atlas_v312_call_supported(
      c("make_methodology_v2_visualizations"),
      list(
        build_if_missing = TRUE,
        refresh = FALSE,
        stop_on_error = TRUE
      ),
      required = TRUE,
      label = "10 Methodology v2 figures"
    )
  )

  paths_v3_figures <- if (exists("v3_paths", mode = "function")) {
    v3_paths()
  } else {
    list(root = root)
  }
  atlas_v3125_with_warning_audit(
    "Stage 2 Methodology v3 figures 37-49",
    root,
    function() atlas_v3125_run_v3_figure_stage(
      root = root,
      paths = paths_v3_figures,
      refresh = FALSE,
      stop_on_error = TRUE
    )
  )

  atlas_v3125_validate_figure_sets(root, stop_on_failure = TRUE)
  atlas_v3125_write_warning_audit(root)

  message("Stage 3/8: applying article-specific plot redesigns and margin trimming.")
  article_plots <- atlas_v3125_with_warning_audit(
    "Stage 3 article redesigns and trimming",
    root,
    function() {
      if (exists("atlas_rebuild_core_article_figures", mode = "function")) {
        tryCatch(
          atlas_rebuild_core_article_figures(
            root = root,
            overwrite = TRUE,
            backup = TRUE
          ),
          error = function(e) {
            warning(
              "Core article-figure redesign could not replace every core plot: ",
              conditionMessage(e),
              ". Existing core plots were retained.",
              call. = FALSE
            )
          }
        )
      }
      plots <- atlas_v312_build_article_overrides(
        root = root,
        save = TRUE
      )
      if (exists("atlas_trim_existing_figures", mode = "function")) {
        tryCatch(
          atlas_trim_existing_figures(
            root = root,
            overwrite = TRUE,
            backup = TRUE,
            fuzz = 2,
            border_px = 12L
          ),
          error = function(e) {
            warning(
              "Automatic outer-margin trimming was incomplete: ",
              conditionMessage(e),
              call. = FALSE
            )
          }
        )
      }
      plots
    }
  )
  atlas_v3125_validate_figure_sets(root, stop_on_failure = TRUE)
  atlas_v3125_write_warning_audit(root)

  message("Stage 4/8: rendering clean v2 and v3 HTML reports.")
  atlas_v312_render_all_reports(root)

  html_files <- file.path(
    root,
    "outputs",
    c(
      "atlas_quarto.html",
      "atlas_rmarkdown.html",
      "atlas_methodology_v3_quarto.html",
      "atlas_methodology_v3_rmarkdown.html"
    )
  )
  if (exists("atlas_inject_article_css", mode = "function")) {
    invisible(
      lapply(
        html_files[file.exists(html_files)],
        atlas_inject_article_css
      )
    )
  }

  message("Stage 5/8: creating bounded, heartbeat-enabled PDFs and XQuartz-free compendia.")
  pdf_manifest <- atlas_v312_create_pdf_outputs(root)

  message("Stage 6/8: creating editable v2 and v3 Excel workbooks.")
  excel_outputs <- atlas_v312_build_excel_outputs(
    root,
    article_plots
  )

  message("Stage 7/8: validating all figures, reports, PDFs, and editable drawings.")
  validation <- atlas_v312_validate_outputs(
    root,
    excel_outputs
  )

  atlas_v3125_write_warning_audit(root)
  message("Stage 8/8: writing the final run manifest.")
  finished <- Sys.time()
  run_manifest <- data.frame(
    field = c(
      "version",
      "project_root",
      "started_at",
      "finished_at",
      "elapsed_minutes",
      "R_version",
      "operating_system",
      "refresh_public_data",
      "browser",
      "v2_excel",
      "v3_excel",
      "consolidated_excel",
      "figure_warning_audit",
      "figure_quality_check"
    ),
    value = c(
      "3.1.3-clean-r10",
      root,
      format(started, "%Y-%m-%d %H:%M:%S %Z"),
      format(finished, "%Y-%m-%d %H:%M:%S %Z"),
      round(as.numeric(difftime(finished, started, units = "mins")), 2),
      as.character(getRversion()),
      paste(Sys.info()[c("sysname", "release", "machine")], collapse = " | "),
      as.character(refresh),
      atlas_v312_find_browser(),
      excel_outputs$v2,
      excel_outputs$v3,
      excel_outputs$master %||% "",
      file.path(root, "outputs", "one_click_v312_figure_warning_audit.csv"),
      file.path(root, "outputs", "one_click_v312_figure_quality_check.csv")
    ),
    stringsAsFactors = FALSE
  )
  readr::write_csv(
    run_manifest,
    file.path(root, "outputs", "one_click_v312_run_manifest.csv")
  )

  message(
    "Iowa AI Workforce Atlas one-click v3.1.3-clean-r10 completed.\n",
    "Validated outputs: outputs/one_click_v312_output_check.csv\n",
    "Run manifest: outputs/one_click_v312_run_manifest.csv"
  )

  invisible(
    list(
      pdf_manifest = pdf_manifest,
      excel = excel_outputs,
      validation = validation,
      run_manifest = run_manifest
    )
  )
}

# -----------------------------------------------------------------------------
# v3.1.3-clean-r8: bounded, transactional, print-safe browser PDF pipeline.
# This late definition intentionally overrides the earlier PDF printer.
# -----------------------------------------------------------------------------

atlas_v318_pdf_revision <- "3.1.3-clean-r8"

atlas_v318_scalar_character <- function(x) {
  is.character(x) && length(x) >= 1L && !is.na(x[[1L]]) && nzchar(x[[1L]])
}

atlas_v318_flatten_arguments <- function(x, prefix = "", depth = 0L) {
  output <- list()
  if (depth > 2L || !is.list(x) || is.data.frame(x)) return(output)
  nms <- names(x)
  if (is.null(nms)) nms <- rep("", length(x))
  for (i in seq_along(x)) {
    value <- x[[i]]
    name <- nms[[i]]
    key <- if (nzchar(prefix) && nzchar(name)) paste(prefix, name, sep = ".") else if (nzchar(name)) name else prefix
    if (atlas_v318_scalar_character(value) || (is.numeric(value) && length(value) == 1L) || (is.logical(value) && length(value) == 1L)) {
      output[[length(output) + 1L]] <- list(name = key, value = value[[1L]])
    } else if (is.list(value) && !is.data.frame(value)) {
      output <- c(output, atlas_v318_flatten_arguments(value, key, depth + 1L))
    }
  }
  output
}

atlas_v318_argument_value <- function(flat, names, predicate = NULL) {
  wanted <- tolower(names)
  for (item in flat) {
    key <- tolower(sub("^.*\\.", "", if (is.null(item$name)) "" else item$name))
    if (key %in% wanted) {
      value <- item$value
      if (is.null(predicate) || isTRUE(predicate(value))) return(value)
    }
  }
  NULL
}

atlas_v318_file_url_to_path <- function(x) {
  if (!atlas_v318_scalar_character(x)) return(x)
  value <- x[[1L]]
  if (!grepl("^file://", value, ignore.case = TRUE)) return(value)
  value <- sub("^file:///?", "", value, ignore.case = TRUE)
  value <- utils::URLdecode(value)
  if (.Platform$OS.type == "windows" && grepl("^[A-Za-z]:", value)) return(value)
  paste0("/", sub("^/+", "", value))
}

atlas_v318_valid_pdf <- function(path, minimum_bytes = 1024L) {
  if (!atlas_v318_scalar_character(path) || !file.exists(path)) return(FALSE)
  info <- suppressWarnings(file.info(path))
  if (!nrow(info) || is.na(info$size[[1L]]) || info$size[[1L]] < minimum_bytes) return(FALSE)
  con <- file(path, open = "rb")
  on.exit(close(con), add = TRUE)
  identical(rawToChar(readBin(con, what = "raw", n = 5L)), "%PDF-")
}

atlas_v318_browser_candidates <- function(explicit = NULL) {
  values <- character()
  add <- function(x) {
    if (atlas_v318_scalar_character(x)) values <<- c(values, x[[1L]])
  }
  add(explicit)
  add(Sys.getenv("IA_ATLAS_BROWSER", unset = ""))
  add(Sys.getenv("CHROME_BIN", unset = ""))
  if (exists("atlas_v312_find_browser", mode = "function", inherits = TRUE)) {
    add(tryCatch(atlas_v312_find_browser(), error = function(e) ""))
  }
  if (Sys.info()[["sysname"]] == "Darwin") {
    values <- c(values,
      "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
      "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
      "/Applications/Chromium.app/Contents/MacOS/Chromium",
      file.path(path.expand("~/Applications"), "Google Chrome.app/Contents/MacOS/Google Chrome"),
      file.path(path.expand("~/Applications"), "Microsoft Edge.app/Contents/MacOS/Microsoft Edge")
    )
  } else if (.Platform$OS.type == "windows") {
    roots <- unique(c(
      Sys.getenv("PROGRAMFILES", unset = ""),
      Sys.getenv("PROGRAMFILES(X86)", unset = ""),
      Sys.getenv("LOCALAPPDATA", unset = "")
    ))
    roots <- roots[nzchar(roots)]
    for (base in roots) {
      values <- c(values,
        file.path(base, "Google", "Chrome", "Application", "chrome.exe"),
        file.path(base, "Microsoft", "Edge", "Application", "msedge.exe"),
        file.path(base, "Chromium", "Application", "chrome.exe")
      )
    }
  }
  commands <- c("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "msedge", "chrome")
  found <- Sys.which(commands)
  values <- c(values, unname(found[nzchar(found)]))
  values <- unique(normalizePath(values[file.exists(values)], winslash = "/", mustWork = FALSE))
  values[nzchar(values)]
}

atlas_v318_prepare_print_html <- function(input_html, label = "report") {
  input_html <- atlas_v318_file_url_to_path(input_html)
  if (!file.exists(input_html)) stop("HTML input does not exist: ", input_html, call. = FALSE)
  size <- suppressWarnings(file.info(input_html)$size[[1L]])
  con <- file(input_html, open = "rb")
  on.exit(close(con), add = TRUE)
  raw <- readBin(con, what = "raw", n = if (is.finite(size)) size else 1e9)
  text <- rawToChar(raw)

  # Static report printing does not require remote MathJax. Removing the remote
  # loader prevents the browser from waiting on a network resource indefinitely.
  text <- gsub(
    "(?is)<script\\b[^>]*\\bsrc\\s*=\\s*[\"'][^\"']*mathjax[^\"']*[\"'][^>]*>.*?</script>",
    "", text, perl = TRUE
  )

  # break-inside: avoid on large Quarto cells/figures can make Chromium's
  # paginated layout pathologically slow. The print copy permits page breaks and
  # constrains each rendered image to the printable Letter page.
  text <- gsub(
    "(?i)(page-break-inside|break-inside)\\s*:\\s*avoid(?:-page|-column)?\\s*(?:!important)?\\s*;?",
    "\\1: auto !important;", text, perl = TRUE
  )

  safe_css <- paste0(
    "\n<style id=\"ia-atlas-print-safe-v318\">\n",
    "@media print {\n",
    "  @page { size: Letter portrait; margin: 0.45in 0.42in 0.45in 0.42in; }\n",
    "  html, body { width: auto !important; height: auto !important; overflow: visible !important; }\n",
    "  body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }\n",
    "  main, .content, #quarto-document-content, .page-columns, .page-layout-article {\n",
    "    width: 100% !important; max-width: none !important; margin: 0 !important; padding: 0 !important;\n",
    "  }\n",
    "  figure, .quarto-figure, .cell, .cell-output-display, .figure {\n",
    "    break-inside: auto !important; page-break-inside: auto !important;\n",
    "    margin-top: 0.06in !important; margin-bottom: 0.08in !important;\n",
    "  }\n",
    "  img, svg, canvas {\n",
    "    display: block !important; max-width: 100% !important; max-height: 7.25in !important;\n",
    "    width: auto !important; height: auto !important; object-fit: contain !important;\n",
    "    margin-left: auto !important; margin-right: auto !important;\n",
    "  }\n",
    "  figcaption, .figure-caption { margin-top: 0.03in !important; break-before: avoid !important; }\n",
    "  table { max-width: 100% !important; font-size: 8.2pt !important; break-inside: auto !important; }\n",
    "  pre, code { white-space: pre-wrap !important; overflow-wrap: anywhere !important; }\n",
    "  h1, h2, h3 { break-after: avoid !important; page-break-after: avoid !important; margin-top: 0.12in !important; }\n",
    "  p { orphans: 2; widows: 2; margin-top: 0.03in !important; margin-bottom: 0.06in !important; }\n",
    "  nav, #TOC, .quarto-title-meta-heading, .quarto-alternate-formats { break-inside: auto !important; }\n",
    "}\n",
    "</style>\n"
  )
  if (grepl("</head>", text, ignore.case = TRUE, fixed = FALSE)) {
    text <- sub("(?i)</head>", paste0(safe_css, "</head>"), text, perl = TRUE)
  } else {
    text <- paste0(safe_css, text)
  }

  output <- tempfile(
    pattern = paste0(".atlas_print_safe_", gsub("[^A-Za-z0-9]+", "_", label), "_"),
    tmpdir = dirname(normalizePath(input_html, mustWork = TRUE)),
    fileext = ".html"
  )
  writeBin(charToRaw(text), output)
  output
}

atlas_v318_file_url <- function(path) {
  path <- normalizePath(path, winslash = "/", mustWork = TRUE)
  if (.Platform$OS.type == "windows") {
    paste0("file:///", utils::URLencode(path, reserved = FALSE))
  } else {
    paste0("file://", utils::URLencode(path, reserved = FALSE))
  }
}

atlas_v318_read_log_tail <- function(path, max_lines = 30L) {
  if (!file.exists(path)) return("")
  lines <- readLines(path, warn = FALSE)
  if (length(lines) > max_lines) lines <- tail(lines, max_lines)
  paste(lines, collapse = " | ")
}

atlas_v318_write_pdf_status <- function(record, root = getOption("ia.atlas.v312.project_root", getwd())) {
  output <- file.path(root, "outputs", "pdf_print_status_v318.csv")
  dir.create(dirname(output), recursive = TRUE, showWarnings = FALSE)
  row <- as.data.frame(record, stringsAsFactors = FALSE)
  if (file.exists(output)) {
    old <- tryCatch(utils::read.csv(output, stringsAsFactors = FALSE), error = function(e) NULL)
    if (!is.null(old)) row <- rbind(old, row)
  }
  utils::write.csv(row, output, row.names = FALSE, na = "")
  invisible(output)
}

atlas_v318_resolve_pdf_call <- function(args) {
  flat <- atlas_v318_flatten_arguments(args)
  is_html <- function(x) atlas_v318_scalar_character(x) && grepl("(?:\\.html?|^file://)", x, ignore.case = TRUE)
  is_pdf <- function(x) atlas_v318_scalar_character(x) && grepl("\\.pdf$", x, ignore.case = TRUE)
  html <- atlas_v318_argument_value(flat,
    c("html", "input", "input_html", "html_file", "html_path", "source", "source_file", "url"), is_html)
  pdf <- atlas_v318_argument_value(flat,
    c("pdf", "output", "output_pdf", "pdf_file", "pdf_path", "target", "target_file"), is_pdf)
  label <- atlas_v318_argument_value(flat,
    c("label", "description", "report_label", "name", "title"), atlas_v318_scalar_character)
  browser <- atlas_v318_argument_value(flat,
    c("browser", "browser_path", "chrome", "chrome_path"), atlas_v318_scalar_character)
  timeout <- atlas_v318_argument_value(flat,
    c("timeout_seconds", "timeout", "pdf_timeout_seconds"), function(x) is.numeric(x) && is.finite(x))

  scalar_strings <- vapply(flat, function(item) {
    if (atlas_v318_scalar_character(item$value)) as.character(item$value) else NA_character_
  }, character(1))
  scalar_strings <- scalar_strings[!is.na(scalar_strings)]
  if (is.null(html)) {
    candidate <- scalar_strings[grepl("(?:\\.html?$|^file://)", scalar_strings, ignore.case = TRUE)]
    candidate_paths <- vapply(candidate, atlas_v318_file_url_to_path, character(1))
    existing <- candidate[file.exists(candidate_paths)]
    if (length(existing)) html <- existing[[1L]] else if (length(candidate)) html <- candidate[[1L]]
  }
  if (is.null(pdf)) {
    candidate <- scalar_strings[grepl("\\.pdf$", scalar_strings, ignore.case = TRUE)]
    if (length(candidate)) pdf <- candidate[[1L]]
  }
  if (is.null(label) || !nzchar(label)) label <- if (!is.null(pdf)) tools::file_path_sans_ext(basename(pdf)) else "HTML report"
  if (is.null(timeout)) timeout <- suppressWarnings(as.numeric(Sys.getenv("IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS", unset = "240")))
  if (!is.finite(timeout)) timeout <- 240
  timeout <- max(45, min(timeout, 420))

  list(html = html, pdf = pdf, label = as.character(label), browser = browser, timeout = timeout)
}

atlas_v318_browser_print_attempt <- function(browser, html, output, label, timeout_seconds, mode = "new", attempt = 1L) {
  if (!requireNamespace("processx", quietly = TRUE)) stop("processx is required for bounded browser PDF output.", call. = FALSE)
  root <- getOption("ia.atlas.v312.project_root", getwd())
  log_dir <- file.path(root, "outputs", "pdf_logs_v318")
  dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)
  stem <- gsub("[^A-Za-z0-9._-]+", "_", paste0(label, "_", mode, "_", attempt))
  stdout_log <- file.path(log_dir, paste0(stem, "_stdout.log"))
  stderr_log <- file.path(log_dir, paste0(stem, "_stderr.log"))
  unlink(c(stdout_log, stderr_log), force = TRUE)
  profile <- tempfile(pattern = "ia_atlas_chrome_profile_v318_")
  dir.create(profile, recursive = TRUE, showWarnings = FALSE)
  on.exit(unlink(profile, recursive = TRUE, force = TRUE), add = TRUE)
  unlink(output, force = TRUE)

  headless_flag <- if (identical(mode, "new")) "--headless=new" else "--headless"
  args <- c(
    headless_flag,
    "--disable-gpu",
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-extensions",
    "--disable-background-networking",
    "--disable-component-update",
    "--disable-sync",
    "--metrics-recording-only",
    "--mute-audio",
    "--hide-scrollbars",
    "--allow-file-access-from-files",
    "--run-all-compositor-stages-before-draw",
    "--no-pdf-header-footer",
    paste0("--user-data-dir=", normalizePath(profile, winslash = "/", mustWork = TRUE)),
    paste0("--print-to-pdf=", normalizePath(dirname(output), winslash = "/", mustWork = TRUE), "/", basename(output)),
    atlas_v318_file_url(html)
  )
  message("Starting ", label, " with print-safe HTML [mode=", mode,
          "; hard timeout=", timeout_seconds, "s; logs=", log_dir, "].")

  started <- Sys.time()
  proc <- processx::process$new(
    command = browser,
    args = args,
    stdout = stdout_log,
    stderr = stderr_log,
    cleanup_tree = TRUE,
    windows_hide_window = TRUE,
    supervise = TRUE
  )
  timed_out <- FALSE
  last_heartbeat <- -15
  repeat {
    alive <- isTRUE(proc$is_alive())
    elapsed <- as.numeric(difftime(Sys.time(), started, units = "secs"))
    if (!alive) break
    if (elapsed >= timeout_seconds) {
      timed_out <- TRUE
      try(proc$kill_tree(), silent = TRUE)
      try(proc$kill(), silent = TRUE)
      try(proc$wait(timeout = 5000), silent = TRUE)
      break
    }
    if (elapsed - last_heartbeat >= 15) {
      message("  PDF watchdog: ", floor(elapsed), "s elapsed; staged file=",
              file.exists(output), "; browser alive=", alive)
      last_heartbeat <- elapsed
    }
    Sys.sleep(1)
  }
  try(proc$wait(timeout = 5000), silent = TRUE)
  status <- tryCatch(proc$get_exit_status(), error = function(e) NA_integer_)
  elapsed <- round(as.numeric(difftime(Sys.time(), started, units = "secs")), 1)
  success <- !timed_out && atlas_v318_valid_pdf(output)
  list(
    success = success,
    timed_out = timed_out,
    exit_status = status,
    elapsed_seconds = elapsed,
    stdout_log = stdout_log,
    stderr_log = stderr_log,
    diagnostic = if (success) "PDF created and signature validated."
      else paste0(
        if (timed_out) "Browser attempt timed out. " else "Browser exited without a valid PDF. ",
        "stderr tail: ", atlas_v318_read_log_tail(stderr_log)
      )
  )
}

atlas_v312_print_html_pdf_with_fallback <- function(...) {
  call <- atlas_v318_resolve_pdf_call(list(...))
  html <- atlas_v318_file_url_to_path(call$html)
  pdf <- call$pdf
  if (!atlas_v318_scalar_character(html) || !file.exists(html)) {
    stop("The revision-8 PDF printer could not resolve an existing HTML input from the call.", call. = FALSE)
  }
  if (!atlas_v318_scalar_character(pdf)) {
    stop("The revision-8 PDF printer could not resolve the requested PDF output path from the call.", call. = FALSE)
  }
  pdf <- normalizePath(pdf, winslash = "/", mustWork = FALSE)
  dir.create(dirname(pdf), recursive = TRUE, showWarnings = FALSE)
  browsers <- atlas_v318_browser_candidates(call$browser)
  if (!length(browsers)) stop("No Chrome, Edge, or Chromium executable was found for PDF output.", call. = FALSE)

  safe_html <- atlas_v318_prepare_print_html(html, call$label)
  on.exit(unlink(safe_html, force = TRUE), add = TRUE)
  staged <- file.path(dirname(pdf), paste0(".", basename(pdf), ".v318.partial.pdf"))
  on.exit(unlink(staged, force = TRUE), add = TRUE)

  plans <- list(
    list(browser = browsers[[1L]], mode = "new"),
    list(browser = if (length(browsers) >= 2L) browsers[[2L]] else browsers[[1L]], mode = "legacy")
  )
  results <- list()
  for (i in seq_along(plans)) {
    plan <- plans[[i]]
    result <- tryCatch(
      atlas_v318_browser_print_attempt(
        browser = plan$browser,
        html = safe_html,
        output = staged,
        label = call$label,
        timeout_seconds = call$timeout,
        mode = plan$mode,
        attempt = i
      ),
      error = function(e) list(
        success = FALSE, timed_out = FALSE, exit_status = NA_integer_,
        elapsed_seconds = NA_real_, stdout_log = "", stderr_log = "",
        diagnostic = conditionMessage(e)
      )
    )
    results[[i]] <- result
    atlas_v318_write_pdf_status(list(
      timestamp_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
      revision = atlas_v318_pdf_revision,
      label = call$label,
      html = normalizePath(html, winslash = "/", mustWork = TRUE),
      pdf = pdf,
      browser = plan$browser,
      mode = plan$mode,
      attempt = i,
      timeout_seconds = call$timeout,
      elapsed_seconds = result$elapsed_seconds,
      exit_status = result$exit_status,
      timed_out = result$timed_out,
      success = result$success,
      diagnostic = result$diagnostic
    ))
    if (isTRUE(result$success)) {
      if (!file.copy(staged, pdf, overwrite = TRUE, copy.mode = TRUE, copy.date = TRUE)) {
        stop("A valid staged PDF was created but could not be promoted to: ", pdf, call. = FALSE)
      }
      if (!atlas_v318_valid_pdf(pdf)) stop("Promoted PDF failed signature validation: ", pdf, call. = FALSE)
      message("Completed ", call$label, ": ", round(file.info(pdf)$size[[1L]] / 1024^2, 1), " MB.")
      return(invisible(pdf))
    }
    unlink(staged, force = TRUE)
  }

  # Never destroy a previous valid publication merely because a refresh failed.
  if (atlas_v318_valid_pdf(pdf) && !identical(tolower(Sys.getenv("IA_ATLAS_ALLOW_STALE_PDF_FALLBACK", unset = "true")), "false")) {
    warning("Fresh PDF printing failed, but the existing valid PDF was retained: ", pdf,
            ". See outputs/pdf_print_status_v318.csv and outputs/pdf_logs_v318/.", call. = FALSE)
    return(invisible(pdf))
  }
  diagnostics <- vapply(results, function(x) if (is.null(x$diagnostic) || !length(x$diagnostic)) "unknown failure" else as.character(x$diagnostic[[1L]]), character(1))
  stop(
    call$label, " failed every revision-8 bounded browser attempt. ",
    paste(sprintf("attempt %d: %s", seq_along(diagnostics), diagnostics), collapse = " || "),
    ". See outputs/pdf_print_status_v318.csv and outputs/pdf_logs_v318/.",
    call. = FALSE
  )
}

atlas_v318_browser_pdf_smoke_test <- function(root = getwd(), timeout_seconds = 60) {
  if (identical(tolower(Sys.getenv("IA_ATLAS_SKIP_BROWSER_PDF_SMOKE", unset = "false")), "true")) {
    message("Revision-8 browser PDF smoke test skipped by IA_ATLAS_SKIP_BROWSER_PDF_SMOKE=true.")
    return(invisible(TRUE))
  }
  html <- tempfile(pattern = "atlas_pdf_smoke_v318_", fileext = ".html")
  pdf <- tempfile(pattern = "atlas_pdf_smoke_v318_", fileext = ".pdf")
  on.exit(unlink(c(html, pdf), force = TRUE), add = TRUE)
  blocks <- paste(rep(
    '<figure style="break-inside: avoid; page-break-inside: avoid; height: 10in; margin:1in"><svg width="900" height="650" xmlns="http://www.w3.org/2000/svg"><rect width="900" height="650" fill="white"/><text x="30" y="80" font-size="42">Iowa AI Workforce Atlas PDF smoke test</text><rect x="30" y="120" width="820" height="450" fill="#d9e8f5" stroke="#333"/></svg><figcaption>Deliberately oversized figure block.</figcaption></figure>',
    4L
  ), collapse = "\n")
  writeLines(c(
    '<!doctype html><html><head><meta charset="utf-8"><title>PDF smoke test</title></head><body>',
    blocks,
    '</body></html>'
  ), html, useBytes = TRUE)
  old_timeout <- Sys.getenv("IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS", unset = NA_character_)
  on.exit({
    if (is.na(old_timeout)) Sys.unsetenv("IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS")
    else Sys.setenv(IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS = old_timeout)
  }, add = TRUE)
  Sys.setenv(IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS = as.character(timeout_seconds))
  atlas_v312_print_html_pdf_with_fallback(
    html = html, pdf = pdf, label = "revision-8 browser PDF smoke test",
    timeout_seconds = timeout_seconds
  )
  if (!atlas_v318_valid_pdf(pdf)) stop("Revision-8 browser PDF smoke test did not create a valid PDF.", call. = FALSE)
  message("v3.1.3-clean-r8 print-safe browser PDF smoke test passed.")
  invisible(TRUE)
}

