# Iowa AI Workforce Atlas v3.1.3-clean-r10
# Resume from PDF publication without rerunning downloads, analytics, figures, or HTML.

.atlas_stage5_root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
version <- trimws(readLines(file.path(.atlas_stage5_root, "VERSION"), warn = FALSE)[[1L]])
if (!identical(version, "3.1.3-clean-r10")) {
  stop("resume_publication_from_stage5.R requires VERSION 3.1.3-clean-r10; found ", version, call. = FALSE)
}

message("Stage 5-only resume: reusing existing analytics, figures, and HTML.")
message("Executable runners excluded: R/run_all.R and R/run_all_v2.R.")

r_files <- sort(list.files(file.path(.atlas_stage5_root, "R"), pattern = "\\.R$", full.names = TRUE))
r_files <- r_files[!basename(r_files) %in% c("run_all.R", "run_all_v2.R")]
message("Loading maintained function definitions only (", length(r_files), " files).")
for (file in r_files) sys.source(file, envir = .GlobalEnv)

if (!exists("activate_atlas_package_library", mode = "function", inherits = TRUE)) {
  stop("Atlas package-library bootstrap was not loaded.", call. = FALSE)
}
activate_atlas_package_library()

if (!exists("atlas_v312_create_pdf_outputs", mode = "function", inherits = TRUE)) {
  stop("Could not find atlas_v312_create_pdf_outputs().", call. = FALSE)
}
if (!exists("atlas_v312_print_html_pdf_with_fallback", mode = "function", inherits = TRUE)) {
  stop("Could not find the revision-10 PDF printer.", call. = FALSE)
}
if (!exists("atlas_v319_browser_print_attempt", mode = "function", inherits = TRUE)) {
  stop("Could not find the revision-10 stable-file PDF completion repair.", call. = FALSE)
}

options("ia.atlas.v312.project_root" = .atlas_stage5_root)
message("Stage 5 recovery 1/3: creating transactional, print-safe report PDFs and compendia.")
atlas_v312_create_pdf_outputs(.atlas_stage5_root)

message("Stage 5 recovery 2/3: resuming validated editable-workbook phases.")
source(file.path(.atlas_stage5_root, "resume_publication_from_stage6.R"), local = .GlobalEnv)

message("Stage 5 recovery 3/3: running the visual-readability audit when available.")
if (file.exists(file.path(.atlas_stage5_root, "verify_visual_readability.R"))) {
  source(file.path(.atlas_stage5_root, "verify_visual_readability.R"), local = .GlobalEnv)
}

manifest <- data.frame(
  revision = version,
  completed_at_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
  pdf_status = file.exists(file.path(.atlas_stage5_root, "outputs", "pdf_print_status_v320.csv")),
  stage6_manifest = file.exists(file.path(.atlas_stage5_root, "outputs", "stage6_resume_manifest_v316.csv")),
  visual_audit = file.exists(file.path(.atlas_stage5_root, "outputs", "figure_readability_audit_v317.csv")),
  stringsAsFactors = FALSE
)
utils::write.csv(manifest, file.path(.atlas_stage5_root, "outputs", "stage5_resume_manifest_v320.csv"), row.names = FALSE)
message("Stage 5-only publication resume completed.")
message("Review outputs/pdf_print_status_v320.csv, outputs/pdf_logs_v320/, and outputs/stage5_resume_manifest_v320.csv.")
