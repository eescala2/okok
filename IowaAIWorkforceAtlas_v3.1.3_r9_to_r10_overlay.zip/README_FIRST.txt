Iowa AI Workforce Atlas v3.1.3-clean-r10 - Windows PDF validation repair

1. Restart R and confirm readLines("VERSION") returns 3.1.3-clean-r10.
2. Run source("verify_install.R").
3. Run source("tests/smoke_test_v313.R").
4. Reuse completed analytics/HTML with:
   Sys.setenv(IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS = "120")
   source("resume_publication_from_stage5.R")

Revision 10 removes the arbitrary 500 KB PDF rejection rule, restores the
latest printer after legacy modules are sourced, and hardens local OEWS header
and SOC-column detection. No Census, BEA, or HTOPS refresh is needed for the
Stage 5 recovery.
