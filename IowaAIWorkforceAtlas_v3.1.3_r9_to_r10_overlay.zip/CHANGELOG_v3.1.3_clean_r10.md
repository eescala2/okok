# Iowa AI Workforce Atlas v3.1.3-clean-r10

- Fixes the full-run source order that reloaded the legacy R/43 PDF printer after
  the revision-9 stable-file implementation.
- Reactivates and verifies the current printer immediately before Stage 5.
- Replaces the fixed 500 KB PDF threshold with signature, terminal `%%EOF`,
  parseability, page-count, and content validation plus a low corruption floor.
- Caps the full-run browser timeout at 240 seconds and recognizes the current
  `IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS` setting.
- Adds a regression test for valid ten-page PDFs below 500 KB.
- Hardens local OEWS workbook header detection and SOC-code discovery, including
  custom Iowa wage-workbook column names and value-based SOC recognition.
- Adds `IA_ATLAS_IGNORE_LOCAL_OEWS=true` and `diagnose_local_oews.R`.
- Does not change analytical formulas, scores, thresholds, or evidence rules.
