# Maintained one-click entry point for the cleaned v3.1.3 distribution.
atlas_root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)

# v3.1.3-clean-r10: HTOPS/visual publication plus stable-file browser PDF completion.
source(file.path(atlas_root, "R", "47_htops_visual_polish_v317.R"), local = .GlobalEnv)
atlas_v317_install_runtime_wrappers(root = atlas_root)
if (!file.exists(file.path(atlas_root, "R", "45_one_click_orchestrator_v312.R"))) {
  stop("Run this script from the project root containing R/ and config/.", call. = FALSE)
}
# The orchestrator uses readr before it reaches setup_packages(). Make the
# dedicated Atlas library visible immediately after an R restart.
.bootstrap_env <- new.env(parent = globalenv())
sys.source(file.path(atlas_root, "R", "00_setup.R"), envir = .bootstrap_env, keep.source = FALSE)
.bootstrap_env$activate_atlas_package_library()
rm(.bootstrap_env)
refresh_text <- tolower(trimws(Sys.getenv("IA_ATLAS_ONE_CLICK_REFRESH", unset = "false")))
refresh <- refresh_text %in% c("1", "true", "yes", "y", "always")
source(file.path(atlas_root, "R", "45_one_click_orchestrator_v312.R"), chdir = FALSE)
source(file.path(atlas_root, "R", "48_browser_pdf_completion_v319.R"), chdir = FALSE)
if (!identical(attr(atlas_v312_print_html_pdf_with_fallback, "atlas_pdf_revision", exact = TRUE), "3.1.3-clean-r10")) {
  stop("The revision-10 browser-PDF override was not loaded.", call. = FALSE)
}
source(file.path("R", "47_public_source_and_excel_repairs_v313.R"))

atlas_run_iowa_ai_atlas_one_click_v312(root = atlas_root, refresh = refresh)

if (exists("atlas_v317_finalize_publication", mode = "function")) atlas_v317_finalize_publication(root = atlas_root)
