# Contract smoke tests that do not download data or render reports.
root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
if (!file.exists(file.path(root,"R","45_one_click_orchestrator_v312.R"))) stop("Run this smoke test from the project root.",call.=FALSE)
.bootstrap_env <- new.env(parent = globalenv())
sys.source(file.path(root, "R", "00_setup.R"), envir = .bootstrap_env, keep.source = FALSE)
.bootstrap_env$activate_atlas_package_library()
rm(.bootstrap_env)
r_files <- sort(list.files(file.path(root,"R"),pattern="[.]R$",full.names=TRUE)); for(f in r_files) parse(file=f)
source(file.path("R", "47_public_source_and_excel_repairs_v313.R"))

env <- new.env(parent=globalenv())
sys.source(file.path(root,"R","20_methodology_v3_setup.R"),envir=env)
sys.source(file.path(root,"R","30_methodology_v3_render.R"),envir=env)
sys.source(file.path(root,"R","40_methodology_v3_publication_completion_v309.R"),envir=env)
stopifnot(identical(names(formals(env$render_methodology_v3_reports)),c("quiet","paths")))
sys.source(file.path(root,"R","45_one_click_orchestrator_v312.R"),envir=env)
env$strict_renderer_for_test <- function(quiet=FALSE,paths=list()) identical(quiet,FALSE)&&is.list(paths)
helper_result <- suppressMessages(env$atlas_v312_call_supported("strict_renderer_for_test",list(quiet=FALSE,paths=list(root=root),refresh=FALSE),required=TRUE,label="strict renderer smoke test"))
stopifnot(isTRUE(helper_result))
r45 <- paste(readLines(file.path(root,"R","45_one_click_orchestrator_v312.R"),warn=FALSE),collapse="\n")
block <- regmatches(r45,regexpr("c\\(\\\"render_methodology_v3_reports\\\"\\)[\\s\\S]{0,260}label = \\\"Methodology v3 HTML rendering\\\"",r45,perl=TRUE))
stopifnot(length(block)==1L,nzchar(block),!grepl("refresh",block,fixed=TRUE))
message("v3.1.3 renderer/orchestrator smoke tests passed.")


# v3.1.3-clean-r3 public-source parser fixtures (no network).
if (!exists("atlas_v313_parse_json_rows", mode = "function", inherits = TRUE)) {
  source(file.path("R", "47_public_source_and_excel_repairs_v313.R"))
}
.qwi_fixture <- '[["Emp","time","sex","agegrp","ownercode","industry","seasonadj","state"],["123","2024-Q4","0","A01","A00","00","U","19"]]'
.qwi_rows <- atlas_v313_parse_json_rows(.qwi_fixture)
stopifnot(NROW(.qwi_rows) == 1L)

.btos_fixture <- '[{"PERIOD_ID":"132","STATE":"19","QUESTION_ID":"AI_USE","ESTIMATE":"12.3"}]'
.btos_rows <- atlas_v313_parse_json_rows(.btos_fixture)
stopifnot(NROW(.btos_rows) == 1L)

.bea_fixture <- '{"BEAAPI":{"Results":{"Data":[{"Code":"SAINC1-3","GeoFips":"19000","GeoName":"Iowa","TimePeriod":"2024","DataValue":"250,000"}]}}}'
.bea_json <- jsonlite::fromJSON(.bea_fixture, simplifyDataFrame = TRUE, flatten = TRUE)
stopifnot(NROW(.bea_json$BEAAPI$Results$Data) == 1L)

.atlas_v313_synthetic_excel_builder <- FALSE
if (!exists("make_methodology_v3_editable_excel", mode = "function", inherits = TRUE)) {
  assign(
    "make_methodology_v3_editable_excel",
    function(...) invisible(TRUE),
    envir = .GlobalEnv
  )
  .atlas_v313_synthetic_excel_builder <- TRUE
}
atlas_v313_install_repairs()
stopifnot(exists("v3_make_methodology_v3_editable_excel", mode = "function", inherits = TRUE))
stopifnot(exists("make_methodology_v3_editable_excel_workbook", mode = "function", inherits = TRUE))
if (isTRUE(.atlas_v313_synthetic_excel_builder)) {
  rm(
    "make_methodology_v3_editable_excel",
    "v3_make_methodology_v3_editable_excel",
    "make_methodology_v3_editable_excel_workbook",
    envir = .GlobalEnv
  )
}
rm(.atlas_v313_synthetic_excel_builder)




message("v3.1.3-clean-r3 public-source and Stage 6 smoke tests passed.")

# v3.1.3-clean-r4 regression tests for the three-hour resume/Cairo failure.
.resume_text <- paste(readLines(file.path(root, "resume_publication_from_stage6.R"), warn = FALSE), collapse = "\n")
stopifnot(grepl(
  '.atlas_excluded_runners <- c("run_all.R", "run_all_v2.R")',
  .resume_text,
  fixed = TRUE
))
stopifnot(grepl(
  '!basename(.atlas_definition_files) %in% .atlas_excluded_runners',
  .resume_text,
  fixed = TRUE
))

.portable_files <- file.path(root, "R", c(
  "08_pdf_reports.R",
  "10_iowa_report_style.R",
  "39_methodology_v3_publication_release.R",
  "40_methodology_v3_publication_completion_v309.R"
))
.portable_text <- paste(vapply(
  .portable_files,
  function(path) paste(readLines(path, warn = FALSE), collapse = "\n"),
  character(1L)
), collapse = "\n")
stopifnot(!grepl(
  "grDevices::cairo_pdf|capabilities\\([^)]*cairo|cairo-png|grSoftVersion\\(|cairoVersion\\(",
  .portable_text,
  ignore.case = TRUE,
  perl = TRUE
))

.browser_files <- file.path(root, "R", c(
  "08_pdf_reports.R",
  "30_methodology_v3_render.R",
  "37_methodology_v3_output_quality.R",
  "38_methodology_v3_pdf_watchdog.R",
  "43_cross_platform_pdf_v312.R"
))
.browser_text <- paste(vapply(
  .browser_files,
  function(path) paste(readLines(path, warn = FALSE), collapse = "\n"),
  character(1L)
), collapse = "\n")
stopifnot(!grepl("system2\\(browser", .browser_text, perl = TRUE))
stopifnot(grepl("processx::", .browser_text, fixed = TRUE))
stopifnot(grepl("timeout", .browser_text, fixed = TRUE))

.pdf_env <- new.env(parent = globalenv())
sys.source(file.path(root, "R", "08_pdf_reports.R"), envir = .pdf_env, keep.source = FALSE)
.pdf_path <- tempfile(fileext = ".pdf")
stopifnot(isTRUE(.pdf_env$.open_atlas_pdf_device(.pdf_path, width = 4, height = 3)))
grid::grid.newpage()
grid::grid.text("Portable base-PDF smoke test", gp = grid::gpar(fontfamily = "Helvetica"))
grDevices::dev.off()
stopifnot(file.exists(.pdf_path), file.info(.pdf_path)$size > 500)
unlink(.pdf_path, force = TRUE)

.qmd_text <- paste(readLines(file.path(root, "atlas.qmd"), warn = FALSE), collapse = "\n")
.rmd_text <- paste(readLines(file.path(root, "atlas.Rmd"), warn = FALSE), collapse = "\n")
stopifnot(grepl("if \\(file[.]exists\\(lwda_map_path\\)\\)", .qmd_text, perl = TRUE))
stopifnot(grepl("if \\(file[.]exists\\(lwda_map_path\\)\\)", .rmd_text, perl = TRUE))

message("v3.1.3-clean-r4 resume isolation, portable PDF, and warning-remediation smoke tests passed.")

# v3.1.3-clean-r5/r6 regression tests for editable alluvial figures and Stage 6
# phase checkpoints. These tests do not read project analytical outputs.
.alluvial_files <- file.path(root, "R", c(
  "07_public_visualizations.R",
  "42_article_plot_overrides_v312.R"
))
.alluvial_text <- paste(vapply(
  .alluvial_files,
  function(path) paste(readLines(path, warn = FALSE), collapse = "\n"),
  character(1L)
), collapse = "\n")
stopifnot(!grepl(
  "stat[[:space:]]*=[[:space:]]*['\"]stratum['\"]",
  .alluvial_text,
  perl = TRUE
))
stopifnot(lengths(regmatches(
  .alluvial_text,
  gregexpr("ggalluvial::stat_stratum\\(", .alluvial_text, perl = TRUE)
)) >= 3L)

.excel_source_text <- paste(
  readLines(file.path(root, "R", "12_excel_editable_figures.R"), warn = FALSE),
  collapse = "\n"
)
stopifnot(grepl(
  "install_public_viz_packages(install_missing = install_missing)",
  .excel_source_text,
  fixed = TRUE
))
stopifnot(grepl("'ggalluvial'", .excel_source_text, fixed = TRUE))

.stage6_checkpoint_text <- paste(
  readLines(file.path(root, "resume_publication_from_stage6.R"), warn = FALSE),
  collapse = "\n"
)
stopifnot(grepl(".stage6_checkpoints_r6", .stage6_checkpoint_text, fixed = TRUE))
stopifnot(grepl("atlas_validate_xlsx_package", .stage6_checkpoint_text, fixed = TRUE))
stopifnot(grepl("minimum_drawings = c(40L, 13L, 53L)", .stage6_checkpoint_text, fixed = TRUE))

if (!requireNamespace("ggalluvial", quietly = TRUE)) {
  stop("ggalluvial is required for the r5/r6 editable-alluvial smoke test.", call. = FALSE)
}
if (!requireNamespace("rvg", quietly = TRUE)) {
  stop("rvg is required for the r5/r6 DrawingML smoke test.", call. = FALSE)
}
if (!requireNamespace("openxlsx2", quietly = TRUE)) {
  stop("openxlsx2 is required for the r5/r6 XLSX package smoke test.", call. = FALSE)
}

.alluvial_env <- new.env(parent = globalenv())
sys.source(
  file.path(root, "R", "07_public_visualizations.R"),
  envir = .alluvial_env,
  keep.source = FALSE
)
sys.source(
  file.path(root, "R", "12_excel_editable_figures.R"),
  envir = .alluvial_env,
  keep.source = FALSE
)

.synthetic_atlas <- tibble::tibble(
  lwda_combined = rep(c("Central Iowa LWDA", "Northeast Iowa LWDA"), each = 4L),
  iowa_priority_sector = rep(c("Advanced Manufacturing", "Health Care"), 4L),
  transition_priority = rep(
    c("Protect and redesign", "Upgrade through AI-complementary training"),
    4L
  ),
  estimated_jobs = c(1200, 900, 800, 700, 1100, 850, 750, 650)
)
.synthetic_flows <- tibble::tibble(
  home_lwda = c(
    "Central Iowa LWDA", "Central Iowa LWDA",
    "Northeast Iowa LWDA", "Northeast Iowa LWDA"
  ),
  work_lwda = c(
    "Central Iowa LWDA", "Northeast Iowa LWDA",
    "Central Iowa LWDA", "Northeast Iowa LWDA"
  ),
  commuters = c(5200, 1300, 900, 4100)
)
.synthetic_sector <- tibble::tibble(
  iowa_priority_sector = c("Advanced Manufacturing", "Health Care", "Finance"),
  automation_exposure = c(0.96, 0.98, 0.99),
  pro_worker_opportunity = c(0.95, 0.97, 0.99),
  new_task_opportunity = c(0.92, 0.94, 0.98),
  estimated_jobs = c(4000, 3500, 2200)
)
.synthetic_data <- list(
  atlas = .synthetic_atlas,
  flows = .synthetic_flows,
  sector = .synthetic_sector
)

.p7 <- .alluvial_env$plot_07_training_pipeline_alluvial(.synthetic_data)
.p10 <- .alluvial_env$plot_10_lwda_commuting_alluvial(.synthetic_data)
.p5 <- .alluvial_env$plot_05_sector_policy_quadrant(.synthetic_data)
stopifnot(inherits(.p7, "ggplot"), inherits(.p10, "ggplot"), inherits(.p5, "ggplot"))

# ggplot_build() is where ggplot2 resolves extension stat objects. This is the
# exact phase that previously failed with "Can't find stat called stratum".
suppressWarnings(ggplot2::ggplot_build(.p7))
suppressWarnings(ggplot2::ggplot_build(.p10))

# Exercise the same rvg device used by the editable workbook. Also assert that
# the edge-case quadrant labels no longer generate dropped geom_text rows.
.warning_box <- new.env(parent = emptyenv())
.warning_box$messages <- character()
.p5_dml <- withCallingHandlers(
  .alluvial_env$excel_render_dml(.p5, width = 8, height = 5),
  warning = function(w) {
    .warning_box$messages <- c(.warning_box$messages, conditionMessage(w))
    invokeRestart("muffleWarning")
  }
)
.p7_dml <- .alluvial_env$excel_render_dml(.p7, width = 9, height = 5.5)
stopifnot(
  file.exists(.p5_dml), file.info(.p5_dml)$size > 500,
  file.exists(.p7_dml), file.info(.p7_dml)$size > 500
)
stopifnot(!any(grepl(
  "Removed .*row containing missing|geom_text",
  .warning_box$messages,
  ignore.case = TRUE,
  perl = TRUE
)))

# Build an XLSX package containing both a pure-vector DrawingML figure and a
# raster-bearing DrawingML figure. openxlsx2 1.24/1.25 could retain the drawing
# relationship while dropping the companion PNG; this is the exact regression
# that produced missing xl/media/image*.png targets in the 40-figure workbook.
stopifnot(package_version(as.character(getNamespaceVersion("openxlsx2"))) >= package_version("1.26.0"))
.raster_matrix <- matrix(
  grDevices::rgb(
    red = c(0.08, 0.25, 0.55, 0.85),
    green = c(0.20, 0.60, 0.30, 0.70),
    blue = c(0.75, 0.35, 0.20, 0.10)
  ),
  nrow = 2L
)
.raster_plot <- ggplot2::ggplot(
  data.frame(x = c(0.25, 0.75), y = c(0.25, 0.75)),
  ggplot2::aes(x = x, y = y)
) +
  ggplot2::annotation_raster(
    raster = as.raster(.raster_matrix),
    xmin = 0, xmax = 1, ymin = 0, ymax = 1,
    interpolate = FALSE
  ) +
  ggplot2::geom_point(size = 3) +
  ggplot2::coord_cartesian(xlim = c(0, 1), ylim = c(0, 1), expand = FALSE) +
  ggplot2::theme_void()
.raster_dml <- .alluvial_env$excel_render_dml(.raster_plot, width = 4, height = 3)

.xlsx_smoke <- tempfile(fileext = ".xlsx")
.xlsx_wb <- openxlsx2::wb_workbook()
.xlsx_wb$add_worksheet("Alluvial")
.xlsx_wb$add_drawing(sheet = "Alluvial", dims = "A1", xml = .p7_dml)
.xlsx_wb$add_worksheet("Raster")
.xlsx_wb$add_drawing(sheet = "Raster", dims = "A1", xml = .raster_dml)
atlas_save_workbook_validated(
  .xlsx_wb,
  .xlsx_smoke,
  minimum_drawings = 2L,
  label = "r6 raster-media smoke workbook"
)
.validator_env <- new.env(parent = globalenv())
.old_validator_option <- getOption("ia.atlas.xlsx_validator.define_only")
options("ia.atlas.xlsx_validator.define_only" = TRUE)
sys.source(
  file.path(root, "validate_excel_packages.R"),
  envir = .validator_env,
  keep.source = FALSE
)
options("ia.atlas.xlsx_validator.define_only" = .old_validator_option)
.xlsx_check <- .validator_env$atlas_validate_xlsx_package(
  .xlsx_smoke,
  minimum_drawings = 2L
)
.xlsx_listing <- utils::unzip(.xlsx_smoke, list = TRUE)$Name
stopifnot(
  isTRUE(.xlsx_check$valid_zip[[1L]]),
  .xlsx_check$drawing_count[[1L]] >= 2L,
  .xlsx_check$media_count[[1L]] >= 1L,
  any(grepl("^xl/media/", .xlsx_listing)),
  identical(.xlsx_check$missing_targets[[1L]], 0L),
  isTRUE(.xlsx_check$passed[[1L]])
)

# Exercise the same cross-workbook worksheet clone used by the consolidated
# 53-drawing workbook. The cloned raster sheet must carry its media target.
.clone_smoke <- tempfile(fileext = ".xlsx")
.clone_source <- openxlsx2::wb_load(.xlsx_smoke)
.clone_target <- openxlsx2::wb_workbook()
.clone_target$add_worksheet("Base")
.clone_target$clone_worksheet(old = "Raster", new = "ClonedRaster", from = .clone_source)
atlas_save_workbook_validated(
  .clone_target,
  .clone_smoke,
  minimum_drawings = 1L,
  label = "r6 cross-workbook clone smoke workbook"
)
.clone_check <- .validator_env$atlas_validate_xlsx_package(
  .clone_smoke,
  minimum_drawings = 1L
)
stopifnot(
  isTRUE(.clone_check$passed[[1L]]),
  .clone_check$media_count[[1L]] >= 1L,
  identical(.clone_check$missing_targets[[1L]], 0L)
)
unlink(c(.p5_dml, .p7_dml, .raster_dml, .xlsx_smoke, .clone_smoke), force = TRUE)

message("v3.1.3-clean-r5 editable-alluvial, bounded-label, checkpoint, and XLSX-integrity smoke tests passed.")
message("v3.1.3-clean-r7 raster-media registration, direct-save, and cross-workbook-clone smoke tests passed.")



# v3.1.3-clean-r7 HTOPS contract and visual whitespace smoke tests.
source(file.path(getwd(), "R", "47_htops_visual_polish_v317.R"), local = .GlobalEnv)
stopifnot(requireNamespace("png", quietly = TRUE))
.htops_test <- data.frame(
  cycle = "test", geography = "United States", population = "test population",
  subgroup_type = "all", subgroup_value = "All", measure = "work_ai_use",
  estimate = 0.25, stringsAsFactors = FALSE
)
stopifnot(isTRUE(atlas_v317_validate_htops(.htops_test)$ok))
.tmp_png <- tempfile(fileext = ".png")
.img <- array(1, dim = c(180, 300, 4)); .img[, , 4] <- 1
.img[45:135, 70:230, 1:3] <- 0
png::writePNG(.img, .tmp_png)
.before <- dim(png::readPNG(.tmp_png))
.trim <- atlas_v317_trim_png(.tmp_png, padding_px = 10L, rewrite = TRUE)
.after <- dim(png::readPNG(.tmp_png))
stopifnot(.after[[1L]] < .before[[1L]], .after[[2L]] < .before[[2L]], isTRUE(.trim$cropped[[1L]]))
.tmp_html <- tempfile(fileext = ".html")
writeLines("<html><head></head><body><figure><img src='x.png'></figure></body></html>", .tmp_html)
atlas_v317_polish_html(.tmp_html)
stopifnot(any(grepl("atlas-v317-compact-readable-figures", readLines(.tmp_html), fixed = TRUE)))
unlink(c(.tmp_png, .tmp_html))
rm(.htops_test, .tmp_png, .img, .before, .trim, .after, .tmp_html)
message("v3.1.3-clean-r7 HTOPS contract, compact-theme, PNG-trim, and HTML-print smoke tests passed.")

# v3.1.3-clean-r10: test print-safe HTML rewriting, stable-file completion,
# process-tree termination after output, and the report-manifest return contract.
.orchestrator_v319 <- file.path(getwd(), "R", "45_one_click_orchestrator_v312.R")
.pdf_repair_v319 <- file.path(getwd(), "R", "48_browser_pdf_completion_v319.R")
sys.source(.orchestrator_v319, envir = environment())
sys.source(.pdf_repair_v319, envir = environment())
.stopifnot_v319 <- function(condition, message) {
  if (!isTRUE(condition)) stop(message, call. = FALSE)
}
.html_v319 <- tempfile(fileext = ".html")
writeLines(c(
  '<html><head><style>@media print { figure, .cell { break-inside: avoid; page-break-inside: avoid; } }</style>',
  '<script src="https://mathjax.example.invalid/MathJax.js"></script></head>',
  '<body><figure style="height:10in"><p>oversized</p></figure></body></html>'
), .html_v319)
.safe_v319 <- atlas_v318_prepare_print_html(.html_v319, "rewrite smoke")
.safe_text_v319 <- paste(readLines(.safe_v319, warn = FALSE), collapse = "\n")
.stopifnot_v319(
  !grepl("break-inside\\s*:\\s*avoid", .safe_text_v319, ignore.case = TRUE, perl = TRUE),
  "Revision-10 safe print copy retained break-inside: avoid."
)
.stopifnot_v319(
  !grepl("mathjax\\.example\\.invalid", .safe_text_v319, ignore.case = TRUE),
  "Revision-10 safe print copy retained a remote MathJax loader."
)
unlink(c(.html_v319, .safe_v319), force = TRUE)
atlas_v319_browser_pdf_smoke_test(root = getwd(), timeout_seconds = 60)
message("v3.1.3-clean-r10 completed-file acceptance, process termination, transactional promotion, and manifest-contract smoke tests passed.")

# v3.1.3-clean-r10: reproduce the Windows source-order regression and prove that
# a valid multipage PDF below 500 KB is accepted by structural/page validation.
.r43_v320 <- file.path(root, "R", "43_cross_platform_pdf_v312.R")
.r45_v320 <- file.path(root, "R", "45_one_click_orchestrator_v312.R")
.r48_v320 <- file.path(root, "R", "48_browser_pdf_completion_v319.R")
.pdf_order_env_v320 <- new.env(parent = globalenv())
sys.source(.r45_v320, envir = .pdf_order_env_v320, keep.source = FALSE)
sys.source(.r48_v320, envir = .pdf_order_env_v320, keep.source = FALSE)
stopifnot(identical(
  attr(.pdf_order_env_v320$atlas_v312_print_html_pdf_with_fallback, "atlas_pdf_revision", exact = TRUE),
  "3.1.3-clean-r10"
))
# Simulate the one-click bootstrap sourcing R/43 after the current repair.
sys.source(.r43_v320, envir = .pdf_order_env_v320, keep.source = FALSE)
stopifnot(is.null(attr(
  .pdf_order_env_v320$atlas_v312_print_html_pdf_with_fallback,
  "atlas_pdf_revision",
  exact = TRUE
)))
.pdf_order_env_v320$atlas_v312_activate_latest_pdf_printer(root)
stopifnot(identical(
  attr(.pdf_order_env_v320$atlas_v312_print_html_pdf_with_fallback, "atlas_pdf_revision", exact = TRUE),
  "3.1.3-clean-r10"
))

.small_pdf_v320 <- tempfile(fileext = ".pdf")
grDevices::pdf(.small_pdf_v320, width = 8.5, height = 11, onefile = TRUE, compress = TRUE)
for (.page_v320 in seq_len(10L)) {
  graphics::plot.new()
  graphics::text(0.5, 0.62, paste("Iowa AI Workforce Atlas structural PDF test - page", .page_v320), cex = 1.2)
  graphics::text(0.5, 0.48, paste(rep("Validated report text", 20L), collapse = " "), cex = 0.55)
}
grDevices::dev.off()
stopifnot(file.exists(.small_pdf_v320), file.info(.small_pdf_v320)$size[[1L]] < 500000)
.small_validation_v320 <- .pdf_order_env_v320$atlas_v312_validate_pdf(
  .small_pdf_v320,
  min_pages = 10L,
  min_bytes = 1024L
)
stopifnot(
  isTRUE(.small_validation_v320$valid),
  identical(.small_validation_v320$pages, 10L)
)
unlink(.small_pdf_v320, force = TRUE)

# Test custom/state-workbook column conventions without reading a real workbook.
.oews_env_v320 <- new.env(parent = globalenv())
sys.source(file.path(root, "R", "00_setup.R"), envir = .oews_env_v320, keep.source = FALSE)
sys.source(file.path(root, "R", "01_lwda_crosswalk.R"), envir = .oews_env_v320, keep.source = FALSE)
sys.source(file.path(root, "R", "02_data_download.R"), envir = .oews_env_v320, keep.source = FALSE)
.synthetic_oews_v320 <- data.frame(
  `Standard Occupational Classification Code` = c("11-1011", "13-2011", "15-1252"),
  Occupation = c("Chief Executives", "Accountants and Auditors", "Software Developers"),
  `Estimated Employment` = c("1,200", "9,500", "4,100"),
  `Mean Hourly Wage` = c("$72.10", "$39.50", "$56.20"),
  check.names = FALSE,
  stringsAsFactors = FALSE
)
.synthetic_oews_path_v320 <- tempfile(fileext = ".csv")

.synthetic_oews_result_v320 <- suppressWarnings(
  .oews_env_v320$parse_oews_iowa_table(
    .synthetic_oews_v320,
    out = .synthetic_oews_path_v320,
    source_label = "synthetic Windows Iowa wage workbook"
  )
)
stopifnot(
  nrow(.synthetic_oews_result_v320) == 3L,
  all(c("11-1011", "13-2011", "15-1252") %in% .synthetic_oews_result_v320$soc_code),
  all(.synthetic_oews_result_v320$state_emp > 0)
)
unlink(.synthetic_oews_path_v320, force = TRUE)
message("v3.1.3-clean-r10 Windows source-order, sub-500KB PDF, and local-OEWS semantic parser smoke tests passed.")

