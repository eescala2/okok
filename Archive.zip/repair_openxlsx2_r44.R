# repair_openxlsx2_r44.R
#
# Purpose: reliably upgrade openxlsx2 in the Iowa AI Workforce Atlas's
# R-major/minor-specific library without loading an older namespace first.
# Run this as the FIRST project command in a freshly restarted R session.

repair_openxlsx2_r44 <- function(minimum = "1.26.0") {
  options(warn = 1)

  root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
  setup_file <- file.path(root, "R", "00_setup.R")
  if (!file.exists(setup_file)) {
    stop(
      "Run this script while the Iowa AI Workforce Atlas project root is the working directory. ",
      "Missing: ", setup_file,
      call. = FALSE
    )
  }

  source(setup_file, chdir = FALSE)
  atlas_lib <- activate_atlas_package_library()
  atlas_lib <- normalizePath(atlas_lib, winslash = "/", mustWork = TRUE)
  minimum_version <- package_version(minimum)

  version_from_description <- function(lib) {
    description <- file.path(lib, "openxlsx2", "DESCRIPTION")
    if (!file.exists(description)) return(package_version("0.0.0"))
    value <- tryCatch(
      read.dcf(description, fields = "Version")[1L, "Version"],
      error = function(e) "0.0.0"
    )
    package_version(as.character(value))
  }

  installed_copies <- function() {
    rows <- lapply(.libPaths(), function(lib) {
      version <- version_from_description(lib)
      if (version == package_version("0.0.0")) return(NULL)
      data.frame(
        Version = as.character(version),
        LibPath = normalizePath(lib, winslash = "/", mustWork = FALSE),
        stringsAsFactors = FALSE
      )
    })
    rows <- Filter(Negate(is.null), rows)
    if (!length(rows)) {
      data.frame(Version = character(), LibPath = character())
    } else {
      do.call(rbind, rows)
    }
  }

  message("Atlas package library: ", atlas_lib)
  message("Library search order:")
  for (i in seq_along(.libPaths())) message("  ", i, ": ", .libPaths()[[i]])

  copies_before <- installed_copies()
  if (nrow(copies_before)) {
    message("Installed openxlsx2 copies before repair:")
    print(copies_before, row.names = FALSE)
  } else {
    message("No installed openxlsx2 copy was found before repair.")
  }

  # getNamespaceVersion("openxlsx2") calls asNamespace(), which loads the
  # namespace if needed. Updating a package after loading the old namespace is
  # unsafe and the current R session would continue using the old code.
  if ("openxlsx2" %in% loadedNamespaces()) {
    loaded_version <- tryCatch(
      as.character(getNamespaceVersion("openxlsx2")),
      error = function(e) "unknown"
    )
    stop(
      "openxlsx2 is already loaded in this R session (", loaded_version, "). ",
      "Restart R, do not call getNamespaceVersion(), library(openxlsx2), ",
      "requireNamespace(openxlsx2), or source another Atlas script first, and ",
      "then source repair_openxlsx2_r44.R as the first project command.",
      call. = FALSE
    )
  }

  current <- version_from_description(atlas_lib)
  if (current >= minimum_version) {
    message(
      "The Atlas library already contains openxlsx2 ", current,
      ", which satisfies >= ", minimum, "."
    )
    message("Restart R, run source(\"verify_install.R\"), and then run the smoke test.")
    return(invisible(TRUE))
  }

  # Remove stale installation locks only; do not remove the existing package
  # until a replacement has been downloaded and installation has begun.
  locks <- list.files(
    atlas_lib,
    pattern = "^00LOCK($|-openxlsx2$)",
    full.names = TRUE
  )
  if (length(locks)) {
    message("Removing stale installation lock(s): ", paste(basename(locks), collapse = ", "))
    unlink(locks, recursive = TRUE, force = TRUE)
  }

  binary_repo <- trimws(Sys.getenv(
    "IA_ATLAS_CRAN_REPO",
    unset = "https://packagemanager.posit.co/cran/latest"
  ))
  source_repo <- "https://cloud.r-project.org"
  options(download.file.method = "libcurl")

  available_version <- function(repo, type) {
    tryCatch({
      contrib <- contrib.url(repo, type = type)
      ap <- utils::available.packages(contriburl = contrib, type = type)
      if (!"openxlsx2" %in% rownames(ap)) return(package_version("0.0.0"))
      package_version(ap["openxlsx2", "Version"])
    }, error = function(e) {
      message(
        "Could not query ", type, " repository ", repo, ": ",
        conditionMessage(e)
      )
      package_version("0.0.0")
    })
  }

  binary_type <- if (
    .Platform$OS.type == "windows" ||
      identical(Sys.info()[["sysname"]], "Darwin")
  ) "binary" else "source"

  binary_available <- available_version(binary_repo, binary_type)
  source_available <- available_version(source_repo, "source")
  message("Available ", binary_type, " version from Posit Package Manager: ", binary_available)
  message("Available source version from CRAN: ", source_available)

  install_and_verify <- function(repo, type) {
    message(
      "Installing openxlsx2 into ", atlas_lib,
      " from ", repo, " (type=", type, ")."
    )
    cores <- suppressWarnings(parallel::detectCores(logical = TRUE))
    if (!length(cores) || is.na(cores) || cores < 2L) cores <- 2L
    ncpus <- max(1L, min(4L, as.integer(cores) - 1L))
    result <- tryCatch({
      utils::install.packages(
        "openxlsx2",
        lib = atlas_lib,
        repos = c(CRAN = repo),
        type = type,
        dependencies = c("Depends", "Imports", "LinkingTo"),
        Ncpus = ncpus
      )
      TRUE
    }, error = function(e) {
      message("Installation error: ", conditionMessage(e))
      FALSE
    })

    installed <- version_from_description(atlas_lib)
    message("Atlas-library version after this attempt: ", installed)
    isTRUE(result) && installed >= minimum_version
  }

  installed_ok <- FALSE
  if (binary_available >= minimum_version) {
    installed_ok <- install_and_verify(binary_repo, binary_type)
  } else {
    message(
      "The configured binary repository did not advertise openxlsx2 >= ",
      minimum, "."
    )
  }

  if (!installed_ok && source_available >= minimum_version) {
    message("Trying the official CRAN source package as a fallback.")
    installed_ok <- install_and_verify(source_repo, "source")
  }

  final_version <- version_from_description(atlas_lib)
  if (!installed_ok || final_version < minimum_version) {
    stop(
      "openxlsx2 was not upgraded successfully. Atlas library still reports ",
      final_version, ". Keep the full console output. On macOS, a CRAN-source ",
      "fallback may require Apple's Command Line Tools (`xcode-select --install`).",
      call. = FALSE
    )
  }

  copies_after <- installed_copies()
  message("Installed openxlsx2 copies after repair:")
  print(copies_after, row.names = FALSE)
  message(
    "Repair completed: Atlas-library openxlsx2 ", final_version,
    ". Restart R now. In the next session, run source(\"verify_install.R\") ",
    "before calling getNamespaceVersion(\"openxlsx2\")."
  )
  invisible(TRUE)
}

repair_openxlsx2_r44()
