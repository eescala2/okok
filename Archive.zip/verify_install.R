# Source/platform preflight for R 4.4.0 on macOS ARM64 and Windows x64.
`%||%` <- function(x, y) if (is.null(x) || !length(x) || all(is.na(x))) y else x
root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
if (!file.exists(file.path(root, "VERSION")) || !dir.exists(file.path(root, "R"))) stop("Run verify_install.R from the project root.", call. = FALSE)
# install_dependencies.R uses an R-4.4-specific Atlas library. A restarted R
# session does not automatically retain that path, so activate it before any
# namespace checks. Without this bootstrap, installed packages can be reported
# as missing even though they are present in the project library.
setup_env <- new.env(parent = globalenv())
sys.source(file.path(root, "R", "00_setup.R"), envir = setup_env, keep.source = FALSE)
atlas_library <- setup_env$activate_atlas_package_library()
dir.create(file.path(root, "outputs"), recursive = TRUE, showWarnings = FALSE)
source(file.path("R", "47_public_source_and_excel_repairs_v313.R"))

checks <- list()
add_check <- function(check, passed, blocking, detail) checks[[length(checks)+1L]] <<- data.frame(check=check, passed=isTRUE(passed), blocking=isTRUE(blocking), detail=as.character(detail), stringsAsFactors=FALSE)
add_check("Atlas R-version-specific package library is active", identical(normalizePath(.libPaths()[1L], winslash = "/", mustWork = FALSE), normalizePath(atlas_library, winslash = "/", mustWork = FALSE)), TRUE, .libPaths()[1L])
rv <- getRversion()
add_check("R version is at least 4.4.0", rv >= package_version("4.4.0"), TRUE, paste(as.character(rv), R.version[["nickname"]] %||% ""))
add_check("Supported operating-system family", .Platform$OS.type == "windows" || identical(Sys.info()[["sysname"]], "Darwin"), TRUE, paste(Sys.info()[c("sysname","release","machine")], collapse=" | "))
r_files <- sort(list.files(file.path(root,"R"), pattern="[.]R$", full.names=TRUE))
parse_errors <- character()
for (f in r_files) { err <- tryCatch({parse(file=f); ""}, error=function(e) conditionMessage(e)); if (nzchar(err)) parse_errors <- c(parse_errors, paste(basename(f),err,sep=": ")) }
add_check("Every maintained R source parses", !length(parse_errors), TRUE, if(length(parse_errors)) paste(parse_errors,collapse=" | ") else paste(length(r_files),"files parsed"))
critical <- c("R/run_all.R","R/run_all_v2.R","R/21_methodology_v3_public_data.R","R/33_methodology_v3_apply.R","R/40_methodology_v3_publication_completion_v309.R","R/45_one_click_orchestrator_v312.R","run_atlas.R")
missing <- critical[!file.exists(file.path(root,critical))]
add_check("Critical source files exist", !length(missing), TRUE, if(length(missing)) paste(missing,collapse=", ") else paste(length(critical),"files present"))
finder_junk <- list.files(root, recursive=TRUE, all.files=TRUE, full.names=TRUE)
finder_junk <- finder_junk[grepl("(^|/)__MACOSX(/|$)|[.]DS_Store$", gsub("\\\\", "/", finder_junk), ignore.case=TRUE)]
if (length(finder_junk)) unlink(finder_junk, recursive=TRUE, force=TRUE)
junk <- list.files(root,recursive=TRUE,all.files=TRUE,full.names=FALSE); junk <- junk[grepl("(^|/)__MACOSX(/|$)|[.]bak($|[.])|[.]DS_Store$",junk,ignore.case=TRUE)]
add_check("No backup or macOS archive debris", !length(junk), FALSE, if(length(junk)) paste(utils::head(junk,20),collapse=", ") else if(length(finder_junk)) paste("removed",length(finder_junk),"Finder metadata item(s)") else "clean")
scan_files <- list.files(root,recursive=TRUE,full.names=TRUE); scan_files <- scan_files[file.info(scan_files)$isdir %in% FALSE]
scan_files <- scan_files[tools::file_ext(scan_files) %in% c("R","Rmd","qmd","md","yml","yaml","txt","example")]
secret_hits <- character(); secret_pattern <- paste0("(CENSUS_API_KEY|IA_ATLAS_CENSUS_API_KEY)[[:space:]]*=[[:space:]]*[\\\"']?[A-Fa-f0-9]{24,}","|","(BEA_API_KEY|IA_ATLAS_BEA_API_KEY)[[:space:]]*=[[:space:]]*[\\\"']?[A-Za-z0-9-]{20,}")
for (f in scan_files) { text <- tryCatch(paste(readLines(f,warn=FALSE,encoding="UTF-8"),collapse="\n"),error=function(e)""); if(grepl(secret_pattern,text,perl=TRUE)) secret_hits <- c(secret_hits,substring(f,nchar(root)+2L)) }
add_check("No literal Census or BEA API keys", !length(secret_hits), TRUE, if(length(secret_hits)) paste(secret_hits,collapse=", ") else "no literal keys detected")
r40 <- paste(readLines(file.path(root,"R","40_methodology_v3_publication_completion_v309.R"),warn=FALSE),collapse="\n")
r45 <- paste(readLines(file.path(root,"R","45_one_click_orchestrator_v312.R"),warn=FALSE),collapse="\n")
contract_ok <- grepl("render_methodology_v3_reports <- function\\(quiet = FALSE, paths = v3_paths\\(\\)\\)",r40) && !grepl("render_methodology_v3_reports <- function\\([^)]*[.][.][.]",r40)
call_block <- regmatches(r45,regexpr("c\\(\\\"render_methodology_v3_reports\\\"\\)[\\s\\S]{0,260}label = \\\"Methodology v3 HTML rendering\\\"",r45,perl=TRUE))
call_ok <- length(call_block)==1L && nzchar(call_block) && !grepl("refresh",call_block,fixed=TRUE)
add_check("v3 renderer argument contract is repaired", contract_ok && call_ok, TRUE, if(contract_ok&&call_ok) "renderer accepts quiet/paths only; orchestration call does not pass refresh" else "renderer/call contract mismatch")
dispatch_detail <- "isolated source-environment lookup passed"
dispatch_ok <- tryCatch({
  dispatch_env <- new.env(parent = globalenv())
  sys.source(file.path(root,"R","45_one_click_orchestrator_v312.R"), envir = dispatch_env, keep.source = FALSE)
  dispatch_env$strict_renderer_for_preflight <- function(quiet=FALSE,paths=list()) identical(quiet,FALSE) && is.list(paths)
  source_result <- suppressMessages(dispatch_env$atlas_v312_call_supported("strict_renderer_for_preflight",list(quiet=FALSE,paths=list(root=root),refresh=FALSE),required=TRUE,label="source-environment preflight renderer"))
  isTRUE(source_result)
}, error=function(e) {
  dispatch_detail <<- conditionMessage(e)
  FALSE
})
add_check("Generic dispatcher resolves functions in its explicit source environment", dispatch_ok, TRUE, dispatch_detail)
resume_text <- paste(readLines(file.path(root,"resume_publication_from_stage6.R"),warn=FALSE),collapse="\n")
resume_excludes_runners <- grepl(
  '.atlas_excluded_runners <- c("run_all.R", "run_all_v2.R")',
  resume_text,
  fixed=TRUE
) && grepl(
  '!basename(.atlas_definition_files) %in% .atlas_excluded_runners',
  resume_text,
  fixed=TRUE
)
add_check("Stage 6 resume excludes executable analytical runners", resume_excludes_runners, TRUE, if(resume_excludes_runners) "run_all.R and run_all_v2.R are definition-load exclusions" else "Stage 6 loader could replay the full pipeline")
checkpoint_ok <- grepl(".stage6_checkpoints_r6", resume_text, fixed = TRUE) &&
  grepl("atlas_validate_xlsx_package", resume_text, fixed = TRUE) &&
  grepl("minimum_drawings = c(40L, 13L, 53L)", resume_text, fixed = TRUE)
add_check(
  "Stage 6 workbooks use validated phase checkpoints",
  checkpoint_ok,
  TRUE,
  if (checkpoint_ok) "v2, v3, and consolidated workbooks are independently reusable after ZIP/DrawingML validation" else "Stage 6 phase checkpoint contract is incomplete"
)
portable_files <- file.path(root,"R",c("08_pdf_reports.R","10_iowa_report_style.R","39_methodology_v3_publication_release.R","40_methodology_v3_publication_completion_v309.R"))
portable_text <- paste(vapply(portable_files,function(f) paste(readLines(f,warn=FALSE),collapse="\n"),character(1)),collapse="\n")
forbidden_device_calls <- grepl("grDevices::cairo_pdf|capabilities\\([^)]*cairo|cairo-png|grSoftVersion\\(|cairoVersion\\(", portable_text, ignore.case=TRUE, perl=TRUE)
add_check("Publication graphics avoid Cairo and X11 runtime calls", !forbidden_device_calls, TRUE, if(forbidden_device_calls) "Cairo/X11 runtime token remains in maintained publication code" else "base pdf(), ragg, and bounded browser subprocesses only")
browser_files <- file.path(root,"R",c("08_pdf_reports.R","30_methodology_v3_render.R","37_methodology_v3_output_quality.R","38_methodology_v3_pdf_watchdog.R","43_cross_platform_pdf_v312.R"))
browser_text <- paste(vapply(browser_files,function(f) paste(readLines(f,warn=FALSE),collapse="\n"),character(1)),collapse="\n")
unbounded_browser <- grepl("system2\\(browser", browser_text, perl=TRUE) || !grepl("processx::", browser_text, fixed=TRUE) || !grepl("timeout", browser_text, fixed=TRUE)
add_check("Browser PDF subprocesses are bounded and have no system2 fallback", !unbounded_browser, TRUE, if(unbounded_browser) "Unbounded browser process path remains" else "processx timeout only")

# Editable alluvial plots must not depend on package attachment side effects.
# ggplot2 cannot resolve an extension stat supplied only as the string
# `stat = "stratum"` in a fresh Stage 6 session. Require the exported,
# namespaced ggalluvial stat and an explicit visualization dependency load.
alluvial_files <- file.path(root, "R", c(
  "07_public_visualizations.R",
  "42_article_plot_overrides_v312.R"
))
alluvial_text <- paste(vapply(
  alluvial_files,
  function(f) paste(readLines(f, warn = FALSE), collapse = "\n"),
  character(1L)
), collapse = "\n")
excel_text <- paste(
  readLines(file.path(root, "R", "12_excel_editable_figures.R"), warn = FALSE),
  collapse = "\n"
)
string_stat_remains <- grepl(
  "stat[[:space:]]*=[[:space:]]*['\"]stratum['\"]",
  alluvial_text,
  perl = TRUE
)
namespaced_stratum_count <- lengths(regmatches(
  alluvial_text,
  gregexpr("ggalluvial::stat_stratum\\(", alluvial_text, perl = TRUE)
))
alluvial_contract_ok <- !string_stat_remains &&
  namespaced_stratum_count >= 3L &&
  grepl("install_public_viz_packages(install_missing = install_missing)", excel_text, fixed = TRUE) &&
  grepl("'ggalluvial'", excel_text, fixed = TRUE)
add_check(
  "Editable alluvial figures use namespaced stats and explicit dependencies",
  alluvial_contract_ok,
  TRUE,
  if (alluvial_contract_ok) {
    "Figure 07, Figure 10, and article override use ggalluvial::stat_stratum; Stage 6 loads visualization dependencies"
  } else {
    "Unqualified stratum stat or incomplete Stage 6 dependency bootstrap remains"
  }
)


setup_text <- paste(readLines(file.path(root, "R", "00_setup.R"), warn = FALSE), collapse = "\n")
workbook_files <- file.path(root, "R", c(
  "12_excel_editable_figures.R",
  "31_methodology_v3_excel.R",
  "44_editable_excel_master_v312.R"
))
workbook_text <- paste(vapply(
  workbook_files,
  function(f) paste(readLines(f, warn = FALSE), collapse = "\n"),
  character(1L)
), collapse = "\n")
xlsx_media_contract_ok <- grepl("openxlsx2 = '1.26.0'", setup_text, fixed = TRUE) &&
  grepl("getNamespaceVersion('openxlsx2')", setup_text, fixed = TRUE) &&
  grepl("atlas_save_workbook_validated", setup_text, fixed = TRUE) &&
  grepl("atlas_restore_promoted_file", setup_text, fixed = TRUE) &&
  grepl("workbook\\$save", setup_text, perl = TRUE) &&
  !grepl("openxlsx2::wb_save", workbook_text, fixed = TRUE) &&
  grepl("clone_worksheet", workbook_text, fixed = TRUE)
add_check(
  "Editable workbooks require the raster-media fix and use validated direct saves",
  xlsx_media_contract_ok,
  TRUE,
  if (xlsx_media_contract_ok) {
    "openxlsx2 >= 1.26; direct bound-method save; temporary package validation; cross-workbook media cloning"
  } else {
    "The openxlsx2 raster-media or direct-save contract is incomplete"
  }
)

write_test <- file.path(root,"outputs",".write_test"); write_ok <- tryCatch({writeLines("ok",write_test);unlink(write_test);TRUE},error=function(e)FALSE)
add_check("Project output directory is writable",write_ok,TRUE,file.path(root,"outputs"))
quarto_path <- Sys.which("quarto"); if(!nzchar(quarto_path)&&requireNamespace("quarto",quietly=TRUE)) quarto_path <- tryCatch(quarto::quarto_path(),error=function(e)"")
add_check("Quarto executable is discoverable",nzchar(quarto_path),FALSE,if(nzchar(quarto_path)) quarto_path else "Select the correct R interpreter in Positron and confirm its bundled/system Quarto")
required_packages <- c("tidyverse","data.table","readxl","janitor","httr2","jsonlite","tidycensus","tigris","sf","quarto","rmarkdown","knitr","DT","scales","glue","yaml","fs","Matrix","cli","ggrepel","png","digest","processx","pdftools","magick","xml2","base64enc","svglite","ragg","systemfonts","gdtools","officer","rvg","openxlsx2","patchwork","ggalluvial","ggforce","ggridges","treemapify","ggtext","viridis","htmltools","forcats")
minimum_versions <- c(systemfonts="1.3.1", gdtools="0.5.0", rvg="0.4.1", openxlsx2="1.26.0")
pkg_status <- do.call(rbind,lapply(required_packages,function(pkg){
  installed <- requireNamespace(pkg,quietly=TRUE)
  version <- if(installed) as.character(getNamespaceVersion(pkg)) else ""
  minimum <- unname(minimum_versions[pkg])
  if(!length(minimum) || is.na(minimum)) minimum <- ""
  meets_minimum <- installed && (!nzchar(minimum) || package_version(version) >= package_version(minimum))
  data.frame(package=pkg,installed=installed,version=version,minimum=minimum,meets_minimum=meets_minimum,stringsAsFactors=FALSE)
}))
package_ready <- all(pkg_status$installed & pkg_status$meets_minimum)
package_problem <- pkg_status$package[!pkg_status$installed | !pkg_status$meets_minimum]
add_check("Required package namespaces and versions are available",package_ready,TRUE,if(package_ready)paste(nrow(pkg_status),"packages available")else paste(package_problem,collapse=", "))
key_status <- data.frame(key=c("CENSUS_API_KEY","BEA_API_KEY"),configured=c(nzchar(Sys.getenv("CENSUS_API_KEY")),nzchar(Sys.getenv("BEA_API_KEY"))),stringsAsFactors=FALSE)
add_check("Census API key is configured",key_status$configured[[1]],FALSE,"only presence is recorded")
add_check("BEA API key is configured",key_status$configured[[2]],FALSE,"only presence is recorded")
result <- do.call(rbind,checks)
utils::write.csv(result,file.path(root,"outputs","preflight_v313.csv"),row.names=FALSE,na="")
utils::write.csv(pkg_status,file.path(root,"outputs","package_status_v313.csv"),row.names=FALSE,na="")
utils::write.csv(key_status,file.path(root,"outputs","api_key_status_v313.csv"),row.names=FALSE,na="")
print(result,row.names=FALSE)
if(any(result$blocking & !result$passed)) stop("Blocking preflight checks failed. See outputs/preflight_v313.csv.",call.=FALSE)
message("Static/platform preflight passed. Run source(\"tests/smoke_test_v313.R\") next.")


# v3.1.3-clean-r7 visual/HTOPS dependencies.
.atlas_v317_required <- c("png", "yaml", "readxl")
.atlas_v317_missing <- .atlas_v317_required[!vapply(.atlas_v317_required, requireNamespace, logical(1), quietly = TRUE)]
if (length(.atlas_v317_missing)) stop("Missing r7 visual/HTOPS package(s): ", paste(.atlas_v317_missing, collapse = ", "), ". Run source(\"install_dependencies.R\") and restart R.", call. = FALSE)
message("v3.1.3-clean-r7 visual/HTOPS dependencies are available.")
rm(.atlas_v317_required, .atlas_v317_missing)

# Revision-8 source-contract checks (no browser process is started here).
.pdf_source_v318 <- paste(readLines(file.path(getwd(), "R", "45_one_click_orchestrator_v312.R"), warn = FALSE), collapse = "\n")
.pdf_checks_v318 <- c(
  safe_print_copy = grepl("atlas_v318_prepare_print_html", .pdf_source_v318, fixed = TRUE),
  file_redirected_logs = grepl("stdout = stdout_log", .pdf_source_v318, fixed = TRUE) && grepl("stderr = stderr_log", .pdf_source_v318, fixed = TRUE),
  hard_kill_tree = grepl("kill_tree", .pdf_source_v318, fixed = TRUE),
  transactional_staging = grepl("v318.partial.pdf", .pdf_source_v318, fixed = TRUE),
  safe_print_css_present = grepl("break-inside: auto !important", .pdf_source_v318, fixed = TRUE) &&
    grepl("atlas_v318_prepare_print_html", .pdf_source_v318, fixed = TRUE)
)
if (!all(.pdf_checks_v318)) {
  stop("Revision-8 PDF source-contract check failed: ", paste(names(.pdf_checks_v318)[!.pdf_checks_v318], collapse = ", "), call. = FALSE)
}
message("v3.1.3-clean-r8 bounded browser-PDF source contract is present.")

# Revision-9 source-contract checks. A complete stable PDF is authoritative even
# when Chromium's parent process remains alive after writing it.
.pdf_repair_path_v319 <- file.path(getwd(), "R", "48_browser_pdf_completion_v319.R")
if (!file.exists(.pdf_repair_path_v319)) {
  stop("Missing revision-9 PDF repair module: R/48_browser_pdf_completion_v319.R", call. = FALSE)
}
.pdf_source_v319 <- paste(readLines(.pdf_repair_path_v319, warn = FALSE), collapse = "\n")
.pdf_checks_v319 <- c(
  terminal_eof_validation = grepl("%%EOF", .pdf_source_v319, fixed = TRUE),
  stable_file_completion = grepl("stable_seconds", .pdf_source_v319, fixed = TRUE) &&
    grepl("completed_by_file", .pdf_source_v319, fixed = TRUE),
  post_output_process_kill = grepl("browser_terminated_after_output", .pdf_source_v319, fixed = TRUE) &&
    grepl("atlas_v319_stop_browser", .pdf_source_v319, fixed = TRUE),
  manifest_return_contract = all(vapply(
    c("pages =", "bytes =", "attempt <-", "tagged <-", "return(promoted)"),
    grepl,
    logical(1),
    x = .pdf_source_v319,
    fixed = TRUE
  )),
  transactional_promotion = grepl("atlas_v319_promote_pdf", .pdf_source_v319, fixed = TRUE),
  status_schema_union = grepl("columns <- union", .pdf_source_v319, fixed = TRUE)
)
if (!all(.pdf_checks_v319)) {
  stop(
    "Revision-9 PDF source-contract check failed: ",
    paste(names(.pdf_checks_v319)[!.pdf_checks_v319], collapse = ", "),
    call. = FALSE
  )
}
message("v3.1.3-clean-r9 stable-file browser-PDF completion and return-contract repair is present.")

