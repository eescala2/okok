Iowa AI Workforce Atlas v3.1.3-clean-r9 — completed-file PDF recovery

The revision-8 smoke test demonstrated that Chrome wrote a PDF (26,552 bytes)
but its parent process remained alive until timeout. Revision 9 treats a stable,
complete, parseable PDF as success, kills the lingering browser tree after
output, and returns the pages/bytes/valid metadata required by the one-click
manifest. It still rejects partial files lacking the terminal %%EOF marker.

Recommended recovery after applying the r8-to-r9 overlay and restarting R:

  source("verify_install.R")
  source("tests/smoke_test_v313.R")
  Sys.setenv(IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS = "120")
  source("resume_publication_from_stage5.R")

Do not rerun the analytical stages merely to recover the PDFs. Existing valid
PDFs are retained until a new staged PDF passes signature, %%EOF, page-count,
and content validation.
