# Iowa AI Workforce Atlas v3.1.3-clean-r8 validation report

## Observed failure

The r7 run completed the analytical, figure, and HTML stages. The first browser
PDF subprocess remained alive for the full 900-second watchdog interval and
never created the staged PDF. The failure was isolated to browser-based print
transport; it was not a Cairo/X11 error and did not invalidate the completed
analytics or HTML.

## Revision-8 remediation

- Redirects browser stdout and stderr to disk files instead of unread pipes.
- Creates a temporary print-safe HTML copy.
- Removes remote MathJax loading from that temporary copy.
- Neutralizes `break-inside: avoid` and `page-break-inside: avoid`, which can
  make large Quarto cells pathologically expensive during paginated layout.
- Constrains images to the printable US Letter body while retaining full width.
- Uses isolated browser profiles and two bounded headless modes.
- Kills the complete browser process tree at the hard timeout.
- Saves transactionally to a partial PDF and promotes only after `%PDF-`
  signature and minimum-size validation.
- Preserves an already valid PDF if a fresh attempt fails, while recording that
  fallback in the PDF status audit.
- Adds a Stage-5-only recovery entry point, so the user does not need to rerun
  downloads, analytics, figures, or HTML.
- Adds a real browser smoke test with deliberately oversized print blocks.

## Files changed

- `APPLY_R7_TO_R8.txt`
- `MANIFEST_SHA256.txt`
- `R/08_pdf_reports.R`
- `R/40_methodology_v3_publication_completion_v309.R`
- `R/41_article_visual_optimizer.R`
- `R/43_cross_platform_pdf_v312.R`
- `R/45_one_click_orchestrator_v312.R`
- `R/47_htops_visual_polish_v317.R`
- `README_FIRST_R8.txt`
- `VERSION`
- `atlas.Rmd`
- `atlas.qmd`
- `atlas_v3.Rmd`
- `atlas_v3.qmd`
- `diagnose_pdf_print_v318.R`
- `resume_publication_from_stage5.R`
- `run_atlas.R`
- `tests/smoke_test_v313.R`
- `verify_install.R`

## Static checks

- PASS: VERSION is r8
- PASS: PDF override exists
- PASS: stdout/stderr redirected to files
- PASS: browser tree hard-kill present
- PASS: transactional partial PDF present
- PASS: safe print CSS neutralizes avoid
- PASS: remote MathJax removal present
- PASS: stage5 resume exists
- PASS: diagnostic exists
- PASS: smoke test contains actual browser print
- PASS: no literal API keys
- PASS: no unsafe archive paths planned
- PASS: nonempty R/45_one_click_orchestrator_v312.R
- PASS: nonempty resume_publication_from_stage5.R
- PASS: nonempty diagnose_pdf_print_v318.R
- PASS: nonempty tests/smoke_test_v313.R
- PASS: nonempty verify_install.R

## Archive integrity

- Full archive files: 135
- Overlay files: 19
- Full ZIP SHA-256: `7a0adcefecb96dc9a86105b487b6b4a7eeca2673348d8ba416590da55a3d5735`
- Overlay ZIP SHA-256: `f32824d8698fe2dec2224d11ce4c7249f337d803c753ebeff975dbe0d74f8045`
- Duplicate ZIP paths: none
- Unsafe ZIP paths: none
- Full ZIP content compared byte-for-byte with the build tree
- Overlay ZIP content compared byte-for-byte with the changed-file set

## Runtime validation required

This packaging environment did not execute R 4.4.0, Positron, or macOS Chrome.
The definitive target-platform tests are:

```r
source("verify_install.R")
source("tests/smoke_test_v313.R")
Sys.setenv(IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS = "240")
source("resume_publication_from_stage5.R")
```

The actual browser smoke test must pass before the long publication recovery is
started.
