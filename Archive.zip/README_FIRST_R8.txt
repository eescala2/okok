Iowa AI Workforce Atlas v3.1.3-clean-r8 — PDF recovery first

The r7 analytics and HTML stages completed. The failure was isolated to the
Chrome/Edge command-line PDF subprocess. Revision 8 changes only publication
transport and diagnostics; it does not change Methodology v2/v3 calculations.

Recommended recovery in the existing project:

1. Apply IowaAIWorkforceAtlas_v3.1.3_r7_to_r8_overlay.zip.
2. Restart R.
3. Run source("verify_install.R").
4. Run source("tests/smoke_test_v313.R").
5. Run:

   Sys.setenv(IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS = "240")
   source("resume_publication_from_stage5.R")

Do not rerun run_atlas.R merely to recover the PDFs. The Stage-5 resume reuses
the already generated analytics, figures, and HTML, then reuses validated
Stage-6 workbook checkpoints.

A future complete cached run remains:

   Sys.setenv(IA_ATLAS_ONE_CLICK_REFRESH = "false")
   source("run_atlas.R")

No Census or BEA key is needed for the Stage-5 publication recovery. HTOPS
remains optional unless configured through configure_htops.R.
