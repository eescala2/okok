# Iowa AI Workforce Atlas v3.1.3 — public-source contract probe
# Safe diagnostic: it never writes API-key values to output.

options(timeout = max(180, getOption("timeout", 60)))

atlas_root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
if (file.exists(file.path(atlas_root, "R", "00_setup.R"))) {
  source(file.path(atlas_root, "R", "00_setup.R"), local = globalenv())
  if (exists("activate_atlas_package_library", mode = "function", inherits = TRUE)) {
    activate_atlas_package_library()
  }
}

required <- c("httr2", "jsonlite", "readr", "tibble")
missing <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) {
  stop("Missing required package(s): ", paste(missing, collapse = ", "), call. = FALSE)
}

`%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x

out_dir <- file.path(atlas_root, "outputs", "methodology_v3", "public_source_probe")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

census_key <- Sys.getenv("CENSUS_API_KEY", unset = "")
bea_key <- Sys.getenv("BEA_API_KEY", unset = "")

redact <- function(x) {
  x <- as.character(x %||% "")
  for (secret in c(census_key, bea_key)) {
    if (nzchar(secret)) x <- gsub(secret, "<REDACTED>", x, fixed = TRUE)
  }
  x
}

safe_name <- function(x) gsub("[^A-Za-z0-9._-]+", "_", x)

perform_probe <- function(label, url, query = list()) {
  req <- httr2::request(url)
  if (length(query)) req <- do.call(httr2::req_url_query, c(list(req), query))
  req <- httr2::req_headers(
    req,
    Accept = "application/json, text/plain;q=0.9, */*;q=0.1",
    `User-Agent` = "IowaAIWorkforceAtlas-v3.1.3-contract-probe"
  )
  req <- httr2::req_retry(req, max_tries = 2)
  req <- httr2::req_error(req, is_error = function(resp) FALSE)

  started <- Sys.time()
  result <- tryCatch({
    resp <- httr2::req_perform(req)
    body <- httr2::resp_body_string(resp)
    list(
      ok = httr2::resp_status(resp) >= 200L && httr2::resp_status(resp) < 300L,
      status_code = httr2::resp_status(resp),
      content_type = httr2::resp_header(resp, "content-type") %||% "",
      body = body,
      error = ""
    )
  }, error = function(e) {
    list(ok = FALSE, status_code = NA_integer_, content_type = "", body = "", error = conditionMessage(e))
  })

  raw_path <- file.path(out_dir, paste0(safe_name(label), ".txt"))
  writeLines(redact(result$body), raw_path, useBytes = TRUE)

  parsed <- NULL
  parse_error <- ""
  if (nzchar(result$body)) {
    parsed <- tryCatch(
      jsonlite::fromJSON(result$body, simplifyVector = FALSE),
      error = function(e) {
        parse_error <<- conditionMessage(e)
        NULL
      }
    )
  }

  list(
    label = label,
    url = url,
    ok = result$ok,
    status_code = result$status_code,
    content_type = result$content_type,
    body_bytes = nchar(result$body, type = "bytes"),
    body = result$body,
    parsed = parsed,
    request_error = result$error,
    parse_error = parse_error,
    elapsed_seconds = as.numeric(difftime(Sys.time(), started, units = "secs")),
    raw_path = raw_path
  )
}

census_matrix_to_df <- function(x) {
  if (is.null(x)) return(data.frame())
  if (is.data.frame(x)) return(x)
  if (is.matrix(x)) {
    if (!nrow(x)) return(data.frame())
    header <- as.character(x[1, , drop = TRUE])
    if (nrow(x) == 1L) return(stats::setNames(as.data.frame(matrix(nrow = 0L, ncol = length(header))), header))
    out <- as.data.frame(x[-1, , drop = FALSE], stringsAsFactors = FALSE)
    names(out) <- make.unique(header)
    return(out)
  }
  if (is.list(x) && length(x) >= 1L) {
    # Census APIs conventionally return [[header], [row1], ...].
    header <- unlist(x[[1]], recursive = TRUE, use.names = FALSE)
    if (!length(header)) return(data.frame())
    if (length(x) == 1L) return(stats::setNames(as.data.frame(matrix(nrow = 0L, ncol = length(header))), make.unique(as.character(header))))
    rows <- lapply(x[-1], function(row) {
      row <- unlist(row, recursive = TRUE, use.names = FALSE)
      length(row) <- length(header)
      row
    })
    out <- as.data.frame(do.call(rbind, rows), stringsAsFactors = FALSE)
    names(out) <- make.unique(as.character(header))
    return(out)
  }
  data.frame()
}

recursive_row_count <- function(x) {
  if (is.null(x)) return(0L)
  if (is.data.frame(x) || is.matrix(x)) return(nrow(x))
  if (!is.list(x)) return(as.integer(length(x) > 0L))
  # Count a list of record-like objects as rows; otherwise descend.
  if (length(x) && all(vapply(x, is.list, logical(1))) &&
      any(vapply(x, function(z) !is.null(names(z)) && length(names(z)), logical(1)))) {
    return(length(x))
  }
  sum(vapply(x, recursive_row_count, integer(1)))
}

extract_period_ids <- function(x) {
  found <- character()
  walk <- function(z, nm = "") {
    if (is.list(z)) {
      nms <- names(z) %||% rep("", length(z))
      for (i in seq_along(z)) walk(z[[i]], nms[[i]])
    } else if (length(z) == 1L && grepl("period|id", nm, ignore.case = TRUE)) {
      val <- as.character(z)
      if (grepl("^[0-9]+$", val)) found <<- c(found, val)
    }
  }
  walk(x)
  unique(found)
}

rows <- list()
add_row <- function(source, test, p, parsed_rows = 0L, diagnostic = "") {
  rows[[length(rows) + 1L]] <<- tibble::tibble(
    source = source,
    test = test,
    ok = isTRUE(p$ok),
    status_code = as.integer(p$status_code),
    content_type = as.character(p$content_type),
    body_bytes = as.integer(p$body_bytes),
    parsed_rows = as.integer(parsed_rows),
    request_error = redact(p$request_error),
    parse_error = redact(p$parse_error),
    diagnostic = redact(diagnostic),
    raw_response = normalizePath(p$raw_path, winslash = "/", mustWork = FALSE)
  )
}

# 1. QWI: use one stable Iowa all-industry/all-age request and try several released quarters.
qwi_success <- FALSE
if (!nzchar(census_key)) {
  rows[[length(rows) + 1L]] <- tibble::tibble(
    source = "QWI", test = "configuration", ok = FALSE, status_code = NA_integer_,
    content_type = "", body_bytes = 0L, parsed_rows = 0L,
    request_error = "", parse_error = "", diagnostic = "CENSUS_API_KEY is not configured.", raw_response = ""
  )
} else {
  qwi_periods <- c("2024-Q4", "2024-Q3", "2024-Q2", "2023-Q4", "2023-Q3", "2022-Q4")
  for (period in qwi_periods) {
    p <- perform_probe(
      paste0("qwi_", period),
      "https://api.census.gov/data/timeseries/qwi/sa",
      list(
        get = "Emp",
        `for` = "state:19",
        time = period,
        sex = "0",
        agegrp = "A00",
        ownercode = "A00",
        industry = "00",
        seasonadj = "U",
        key = census_key
      )
    )
    dat <- census_matrix_to_df(p$parsed)
    diag <- if (nrow(dat)) paste("columns:", paste(names(dat), collapse = ", ")) else substr(redact(p$body), 1L, 500L)
    add_row("QWI", period, p, nrow(dat), diag)
    if (p$ok && nrow(dat)) {
      qwi_success <- TRUE
      readr::write_csv(dat, file.path(out_dir, "qwi_successful_sample.csv"))
      break
    }
  }
}

# 2. BTOS: probe both documented path variants, discover a period id, then request Iowa.
btos_bases <- c(
  "https://www.census.gov/hfp/btos/api",
  "https://www.census.gov/hfp/btos/api/v1"
)
btos_period_ids <- character()
for (base in btos_bases) {
  p <- perform_probe(paste0("btos_periods_", safe_name(base)), paste0(base, "/periods"))
  n <- recursive_row_count(p$parsed)
  ids <- extract_period_ids(p$parsed)
  btos_period_ids <- unique(c(btos_period_ids, ids))
  add_row("BTOS", paste0(base, "/periods"), p, n,
          paste0("period_ids_detected=", paste(ids, collapse = ","), "; body_prefix=", substr(redact(p$body), 1L, 300L)))
}
if (!length(btos_period_ids)) btos_period_ids <- c("1")
# Test up to three period ids, prioritizing the numerically largest when possible.
ord <- suppressWarnings(order(as.numeric(btos_period_ids), decreasing = TRUE, na.last = TRUE))
btos_period_ids <- btos_period_ids[ord]
btos_period_ids <- head(unique(btos_period_ids), 3L)
for (base in btos_bases) {
  for (period_id in btos_period_ids) {
    endpoint <- paste0(base, "/periods/", period_id, "/data/state/IA")
    p <- perform_probe(paste0("btos_state_IA_", safe_name(base), "_", period_id), endpoint)
    n <- recursive_row_count(p$parsed)
    add_row("BTOS", endpoint, p, n,
            paste0("body_prefix=", substr(redact(p$body), 1L, 500L)))
    if (p$ok && n > 0L) {
      writeLines(redact(p$body), file.path(out_dir, "btos_successful_state_IA.json"), useBytes = TRUE)
      break
    }
  }
}

# 3. BEA Regional: a stable Iowa state personal-income request.
if (!nzchar(bea_key)) {
  rows[[length(rows) + 1L]] <- tibble::tibble(
    source = "BEA Regional", test = "configuration", ok = FALSE, status_code = NA_integer_,
    content_type = "", body_bytes = 0L, parsed_rows = 0L,
    request_error = "", parse_error = "", diagnostic = "BEA_API_KEY is not configured.", raw_response = ""
  )
} else {
  p <- perform_probe(
    "bea_regional_sainc1_iowa",
    "https://apps.bea.gov/api/data/",
    list(
      UserID = bea_key,
      method = "GetData",
      datasetname = "Regional",
      TableName = "SAINC1",
      LineCode = "3",
      GeoFIPS = "19000",
      Year = "LAST5",
      ResultFormat = "JSON"
    )
  )
  bea_data <- tryCatch(p$parsed$BEAAPI$Results$Data, error = function(e) NULL)
  if (is.data.frame(bea_data)) {
    bea_df <- bea_data
  } else if (is.list(bea_data) && length(bea_data)) {
    bea_df <- tryCatch(do.call(rbind.data.frame, c(bea_data, stringsAsFactors = FALSE)), error = function(e) data.frame())
  } else {
    bea_df <- data.frame()
  }
  bea_error <- tryCatch(p$parsed$BEAAPI$Results$Error, error = function(e) NULL)
  diag <- if (nrow(bea_df)) {
    paste("columns:", paste(names(bea_df), collapse = ", "))
  } else {
    paste0("BEA_error=", paste(unlist(bea_error), collapse = " | "), "; body_prefix=", substr(redact(p$body), 1L, 500L))
  }
  add_row("BEA Regional", "SAINC1 line 3, Iowa, LAST5", p, nrow(bea_df), diag)
  if (nrow(bea_df)) readr::write_csv(bea_df, file.path(out_dir, "bea_regional_successful_sample.csv"))
}

result <- do.call(rbind, rows)
summary_path <- file.path(atlas_root, "outputs", "methodology_v3", "public_source_probe_v313.csv")
readr::write_csv(result, summary_path)

cat("\nPublic-source contract probe complete.\n")
cat("Summary: ", normalizePath(summary_path, winslash = "/", mustWork = FALSE), "\n", sep = "")
cat("Raw redacted responses: ", normalizePath(out_dir, winslash = "/", mustWork = FALSE), "\n\n", sep = "")
print(result[, c("source", "test", "ok", "status_code", "body_bytes", "parsed_rows", "diagnostic")], n = Inf, width = Inf)
