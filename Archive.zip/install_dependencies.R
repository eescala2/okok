# Install the supported dependency set into an R-major/minor-specific user library.
# Run in a fresh R 4.4.0 session before loading tidyverse, ragg, or systemfonts.
root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
setup_file <- file.path(root, "R", "00_setup.R")
v3_setup_file <- file.path(root, "R", "20_methodology_v3_setup.R")
if (!file.exists(setup_file) || !file.exists(v3_setup_file)) stop("Run install_dependencies.R from the project root.", call. = FALSE)
source(setup_file, chdir = FALSE)
setup_repos()
message("Atlas package library: ", .libPaths()[1L])
message("Primary CRAN repository: ", getOption("repos")[["CRAN"]])
setup_packages(install_optional = FALSE, strict_r = TRUE)
source(v3_setup_file, chdir = FALSE)
additional_required <- unique(c(v3_required_packages(), "processx", "pdftools", "magick", "xml2", "base64enc", "svglite", "ragg", "openxlsx2", "rvg", "patchwork", "ggalluvial", "ggforce", "ggridges", "treemapify", "ggtext", "viridis", "htmltools", "forcats"))
install_if_missing(additional_required, optional = FALSE)
additional_optional <- unique(c(v3_optional_packages(), "fixest", "arrow", "duckdb"))
install_optional <- tolower(trimws(Sys.getenv("IA_ATLAS_INSTALL_OPTIONAL", unset = "false"))) %in% c("1", "true", "yes", "y")
if (isTRUE(install_optional)) {
  install_if_missing(additional_optional, optional = TRUE)
} else {
  message("Skipping optional packages (fixest/arrow/duckdb and other nonblocking extras). Set IA_ATLAS_INSTALL_OPTIONAL=true to request them.")
}
message("Dependency installation completed in: ", .libPaths()[1L])
message("Installed openxlsx2 files report version: ", as.character(utils::packageVersion("openxlsx2")))
message("Restart the R session before running verify_install.R or run_atlas.R; the current session may still hold an older loaded namespace.")


# v3.1.3-clean-r7 visual/HTOPS helpers.
.atlas_v317_visual_packages <- c("png", "yaml", "readxl")
.atlas_v317_missing <- .atlas_v317_visual_packages[!vapply(.atlas_v317_visual_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(.atlas_v317_missing)) {
  install.packages(.atlas_v317_missing, lib = .libPaths()[1L], repos = getOption("repos"), type = if (.Platform$OS.type == "windows" || identical(Sys.info()[["sysname"]], "Darwin")) "binary" else "source")
}
rm(.atlas_v317_visual_packages, .atlas_v317_missing)
