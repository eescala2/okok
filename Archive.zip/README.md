# Current release: 3.1.3-clean-r9

For a revision-8 project whose browser wrote the PDF but did not exit, apply the
r8-to-r9 overlay and run `resume_publication_from_stage5.R`. Revision 9 validates
the complete stable PDF and terminates the lingering browser after output.

# Iowa AI Workforce Atlas - Methodology v3.1.3 clean distribution, revision 6

This is the reduced maintained distribution of the working Methodology v2 atlas plus the Methodology v3 evidence extensions. It removes accumulated installers, backups, generated output, duplicate verifiers, and macOS ZIP metadata while preserving the analytical, reporting, PDF, and editable-Excel paths.


## Revision 5: editable alluvial repair and restartable Stage 6

Revision 5 fixes the Stage 6-only Excel failure at Public Figure 07: `Can't find stat called "stratum"`. Figures 07 and 10 and the article alluvial override no longer depend on `ggplot2` finding an extension stat by string after a prior package-attachment side effect. They call `ggalluvial::stat_stratum(geom = "text")` directly, and the editable-Excel bootstrap explicitly loads the full public-visualization dependency set.

The Stage 6 recovery is now restartable by phase. It validates and checkpoints the v2 workbook (at least 40 native DrawingML parts), the v3 workbook (at least 13), and the consolidated workbook (at least 53). A later interruption or error reuses any completed workbook whose revision, MD5, DrawingML count, and relationship targets still validate. Revision 5 used `outputs/.stage6_checkpoints_r5/`; revision 6 intentionally uses `outputs/.stage6_checkpoints_r6/` so invalid r5 workbooks cannot be reused.

The Excel package validator now covers all three workbooks, checks native drawing counts, and verifies every internal drawing/media relationship target. Figure 05's quadrant labels use bounded quadrant-center coordinates so edge thresholds no longer produce dropped `geom_text()` rows during DrawingML rendering.

Revision 4's no-Cairo/no-X11 publication policy remains unchanged. The Figure 07 error is unrelated to Cairo, and no XQuartz installation is required.


## Revision 4: Stage 6 isolation and Cairo/X11 removal

Revision 4 fixes the three-hour publication stall observed on R 4.4.0 Apple Silicon. The Stage-6 resume script had sourced `R/run_all.R` and `R/run_all_v2.R`, which replayed analytics, figures, HTML, and the legacy PDF stage before reaching Excel. It now loads function definitions only and explicitly excludes both executable runners.

All maintained publication devices now avoid `cairo_pdf()`, `capabilities("cairo")`, `cairo-png`, X11, and XQuartz. Figure compendia use base `grDevices::pdf()` with Helvetica; PNG export uses `ragg` with a plain platform-PNG fallback; report PDFs use a bounded `processx`-managed Chrome or Edge subprocess. An unbounded `system2()` browser fallback is no longer used. `pagedown::chrome_print()` is disabled; the workflow never delegates an unbounded browser process.

The revision-4 resume path was isolated to the v2, v3, and consolidated editable-workbook phases and no longer replayed analytics or PDFs. Revision 5 preserves that isolation and repairs the Figure 07 failure encountered before the first workbook could be saved. The Stage 6-only command must never print `Step 1/10`, `Stage 1/8`, or `Step 8/10`.

Additional warning remediation includes conditional handling of the optional `inputs/iowa_lwda_map.png`, a no-repository Git check, current horizontal-errorbar syntax, visible Excel progress messages, `na.rm = TRUE` for figure labels, unlimited intentional `ggrepel` labels, and automatic removal of `.DS_Store`/`__MACOSX` metadata during preflight.


## What was fixed

The terminal failure was an interface mismatch, not a failed model run. `render_methodology_v3_reports()` accepts only `quiet` and `paths`; a later completion wrapper exposed `...`, and the one-click orchestrator supplied `refresh = FALSE`. The wrapper forwarded that unsupported argument. The maintained wrapper is strict and the v3 render call no longer supplies `refresh`.

BTOS acquisition now uses the official `/hfp/btos/api` endpoints before the JavaScript-page fallback. QWI omits incompatible firm-age/firm-size predicates. Public status distinguishes configuration, request, schema, and availability failures instead of reporting every zero-row source as simply “unavailable.”

Revision 1 also fixes package-library bootstrapping exposed by the first Apple Silicon preflight. The installer writes to an R-4.4-specific Atlas library; `verify_install.R`, `run_atlas.R`, `verify_data_sources.R`, and the smoke test now activate that library automatically after an R restart. The installer also selects Posit Package Manager deterministically unless `IA_ATLAS_CRAN_REPO` is explicitly set, which preserves R 4.4 macOS/Windows binary availability.

Revision 2 fixes the isolated-environment lookup defect exposed by the strict smoke test. The generic dispatcher now resolves candidate functions explicitly from its definition environment instead of relying on `exists()` to infer a frame while running inside `vapply()`. The verifier now exercises this behavior before reporting success.

## Target environments and validation boundary

- R 4.4.0 “Puppy Cup”
- Positron with the R 4.4 interpreter selected
- Apple Silicon Mac (including M1)
- 64-bit Windows 11 on Intel/AMD (including Dell Latitude 5550)

The source and verification scripts target both environments. This build environment did not contain R, macOS, or Windows, so a fresh target-machine run was not falsely claimed. Run the included parser/preflight and smoke test on each machine.

## First clean installation

1. Extract the ZIP into a normal local folder and open that folder in Positron.
2. Select R 4.4.0, start a fresh R session, and run `source("install_dependencies.R")`. Optional Arrow/DuckDB/fixest packages are skipped unless `IA_ATLAS_INSTALL_OPTIONAL=true`.
3. Restart R and run the commands separately: `source("verify_install.R")`, then `source("tests/smoke_test_v313.R")`.
4. Put newly issued keys in the user-level `~/.Renviron`, restart R, then optionally run `source("verify_data_sources.R")`.
5. Run `source("run_atlas.R")`. The default reuses caches. Set `Sys.setenv(IA_ATLAS_ONE_CLICK_REFRESH="true")` before sourcing to force public refresh.

## Local evidence

Methodology v3 intentionally does not fabricate employer pulse, worker outcomes, apprenticeship, transition validation, industrial readiness, pilot/ARIA, or project-scenario evidence. Header-only schemas are in `inputs/`. `public_data_status_v3.csv` diagnoses public sources; `methodology_v3_module_status.csv` diagnoses each analytical extension.

## Immediate security action

Rotate both exposed API keys before running this package. See `SECURITY.md`.

## Interpreting the package preflight

A failure naming `rvg` and `openxlsx2` is a dependency/bootstrap issue, not a Methodology v3 analytical failure. Run `source("install_dependencies.R")` in a fresh session, restart R, and rerun the verifier. API-key checks are deliberately nonblocking; they are required only for the corresponding live public-source requests.


## Recovery and standard commands

Run the standard checks:

```r
source("verify_install.R")
source("tests/smoke_test_v313.R")
```

Run public-source verification after loading API keys:

```r
Sys.setenv(IA_ATLAS_ONE_CLICK_REFRESH = "true")
source("verify_data_sources.R")
```

Run the full workflow:

```r
Sys.setenv(IA_ATLAS_ONE_CLICK_REFRESH = "false")
source("run_atlas.R")
```

When a previous r2 session already completed analytics, figures, HTML, and PDF,
copy that run's `data_raw/`, `data_processed/`, `figures/`, and `outputs/`
directories into this project and run only the remaining publication stage:

```r
source("resume_publication_from_stage6.R")
# Validation is already run by the resume script; rerunning it is harmless:
source("validate_excel_packages.R")
```

The Stage-6 resume finishes the existing analytical run; it does not recompute
Methodology v3. It validates and checkpoints each workbook independently, so a
later retry can reuse completed phases. To incorporate newly recovered BTOS or
BEA Regional records, run `verify_data_sources.R`, confirm both are available,
and then rerun `run_atlas.R`.


## Revision 6: validated raster-media XLSX publication

Revision 6 requires openxlsx2 1.26.0 or newer because 1.24/1.25 could omit
raster media generated inside `rvg::dml_xlsx()` drawings. Stage 6 now uses the
bound workbook `$save()` method, validates a temporary OOXML package, and only
then replaces the public workbook. A raster-bearing smoke test checks the exact
failure mode before the 40-figure workbook is rebuilt.

Run this sequence after applying the overlay:

```r
source("install_dependencies.R")
# Restart R
source("verify_install.R")
source("tests/smoke_test_v313.R")
source("resume_publication_from_stage6.R")
```

The Stage 6 completion manifest records the loaded `openxlsx2` and `rvg`
versions. No API key is needed for this recovery-only operation.
