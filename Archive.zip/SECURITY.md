# Security

The earlier shared bundle and console transcript contained literal Census and BEA API keys. Revoke or rotate both keys, remove the old bundle/transcript from shared locations, and store replacements only in the user-level `~/.Renviron`. This distribution contains placeholders only; `verify_install.R` scans maintained text files for likely literal keys.
