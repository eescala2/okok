# Iowa AI Workforce Atlas v3.1.3-clean-r7 validation report

## Scope

- Added mapping-driven HTOPS configuration with a strict normalized 0–1 estimate contract.
- Added compact ggplot publication defaults without changing analytical values or colors.
- Replaced accidental named palette scalars with unnamed scalar access where detected.
- Added lossless-content PNG outer-whitespace trimming with protective padding, executed immediately before report rendering rather than after every figure function.
- Added HTML print CSS injection before bounded browser-PDF publication.
- Added a per-file readability audit and visual review gallery.
- Preserved r6 openxlsx2 1.26+ transactional workbook validation.

## Static checks

- Required r7 files present: PASS.
- HTOPS template is header-only: PASS.
- No Cairo/X11 calls introduced by r7: PASS.
- Mapping and normalized-input modes both implemented: PASS.
- PNG trim and HTML CSS smoke-test code included: PASS.
- Full archive and overlay created from the r6 maintained tree: PASS.

## Runtime limitation

R 4.4.0/macOS and R 4.4.0/Windows runtime execution is performed by the included preflight and smoke tests on the target machines. This packaging environment did not execute the full R publication workflow.

## Changed/new paths

- `HTOPS_AND_VISUAL_READABILITY_GUIDE.md`
- `MANIFEST_SHA256.txt`
- `R/05_visualize.R`
- `R/07_public_visualizations.R`
- `R/12_excel_editable_figures.R`
- `R/15_methodology_v2_visualizations.R`
- `R/29_methodology_v3_visualizations.R`
- `R/47_htops_visual_polish_v317.R`
- `REVISION_7_NOTES.md`
- `config/htops_mapping.yml`
- `configure_htops.R`
- `inputs/htops_ai_benchmark_template.csv`
- `install_dependencies.R`
- `polish_existing_figures.R`
- `resume_publication_from_stage6.R`
- `run_atlas.R`
- `tests/smoke_test_v313.R`
- `verify_data_sources.R`
- `verify_install.R`
- `verify_visual_readability.R`
