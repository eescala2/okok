# Validate that every drawing/media relationship target in generated XLSX
# packages exists inside the ZIP container. The validator also checks the
# minimum number of native DrawingML parts expected for each Atlas workbook.

atlas_xlsx_normalize_zip_path <- function(path) {
  parts <- strsplit(gsub("\\\\", "/", path), "/", fixed = TRUE)[[1L]]
  output <- character()
  for (part in parts) {
    if (!nzchar(part) || identical(part, ".")) next
    if (identical(part, "..")) {
      if (length(output)) output <- output[-length(output)]
    } else {
      output <- c(output, part)
    }
  }
  paste(output, collapse = "/")
}

atlas_validate_xlsx_package <- function(path, minimum_drawings = 0L) {
  minimum_drawings <- suppressWarnings(as.integer(minimum_drawings))
  if (!length(minimum_drawings) || !is.finite(minimum_drawings[[1L]]) || minimum_drawings[[1L]] < 0L) {
    minimum_drawings <- 0L
  } else {
    minimum_drawings <- minimum_drawings[[1L]]
  }

  empty_result <- function(exists, valid_zip, detail) {
    data.frame(
      workbook = path,
      exists = isTRUE(exists),
      valid_zip = isTRUE(valid_zip),
      drawing_count = NA_integer_,
      media_count = NA_integer_,
      minimum_drawings = minimum_drawings,
      missing_targets = NA_integer_,
      passed = FALSE,
      detail = detail,
      stringsAsFactors = FALSE
    )
  }

  if (!file.exists(path)) {
    return(empty_result(FALSE, FALSE, "workbook not found"))
  }

  listing <- tryCatch(
    utils::unzip(path, list = TRUE),
    error = function(e) NULL
  )
  if (is.null(listing)) {
    return(empty_result(TRUE, FALSE, "not a readable ZIP/XLSX package"))
  }

  files <- gsub("\\\\", "/", listing$Name)
  drawing_count <- sum(grepl(
    "^xl/drawings/drawing[0-9]+[.]xml$",
    files,
    perl = TRUE
  ))
  media_count <- sum(grepl("^xl/media/[^/]+$", files, perl = TRUE))
  rel_files <- files[grepl("_rels/.*[.]rels$", files, perl = TRUE)]

  tmp <- tempfile("atlas_xlsx_")
  dir.create(tmp)
  on.exit(unlink(tmp, recursive = TRUE, force = TRUE), add = TRUE)
  if (length(rel_files)) {
    utils::unzip(path, files = rel_files, exdir = tmp)
  }

  missing <- character()
  for (rel in rel_files) {
    rel_path <- file.path(tmp, rel)
    rel_xml <- tryCatch(
      xml2::read_xml(rel_path),
      error = function(e) NULL
    )
    if (is.null(rel_xml)) {
      missing <- c(missing, paste0(rel, " -> unreadable relationships XML"))
      next
    }
    nodes <- xml2::xml_find_all(
      rel_xml,
      "//*[local-name()='Relationship']"
    )
    if (!length(nodes)) next
    targets <- xml2::xml_attr(nodes, "Target")
    target_modes <- xml2::xml_attr(nodes, "TargetMode")
    internal <- is.na(target_modes) | tolower(target_modes) != "external"
    targets <- unique(targets[internal & !is.na(targets) & nzchar(targets)])
    base <- if (identical(rel, "_rels/.rels")) {
      ""
    } else {
      sub("/_rels/[^/]+[.]rels$", "", rel, perl = TRUE)
    }

    for (target in targets) {
      if (grepl("^#", target)) next
      candidate <- if (grepl("^/", target)) {
        sub("^/+", "", target)
      } else {
        atlas_xlsx_normalize_zip_path(paste(base, target, sep = "/"))
      }
      if (!candidate %in% files) {
        missing <- c(missing, paste0(rel, " -> ", target))
      }
    }
  }

  missing <- unique(missing)
  passed <- length(missing) == 0L && drawing_count >= minimum_drawings
  detail <- c(
    if (length(missing)) {
      paste("missing relationship targets:", paste(missing, collapse = " | "))
    } else {
      "all relationship targets present"
    },
    paste0("drawings=", drawing_count, "; required>=", minimum_drawings),
    paste0("media=", media_count)
  )

  data.frame(
    workbook = path,
    exists = TRUE,
    valid_zip = TRUE,
    drawing_count = drawing_count,
    media_count = media_count,
    minimum_drawings = minimum_drawings,
    missing_targets = length(missing),
    passed = passed,
    detail = paste(detail, collapse = "; "),
    stringsAsFactors = FALSE
  )
}

atlas_run_xlsx_package_validation <- function(
    workbooks = c(
      file.path("outputs", "iowa_ai_workforce_atlas_editable_figures.xlsx"),
      file.path("outputs", "iowa_ai_workforce_atlas_methodology_v3_editable_figures.xlsx"),
      file.path("outputs", "iowa_ai_workforce_atlas_all_editable_figures.xlsx")
    ),
    minimum_drawings = c(40L, 13L, 53L),
    output_file = file.path("outputs", "excel_package_validation_v313.csv"),
    stop_on_failure = TRUE) {

  if (length(minimum_drawings) == 1L) {
    minimum_drawings <- rep(minimum_drawings, length(workbooks))
  }
  if (length(workbooks) != length(minimum_drawings)) {
    stop("workbooks and minimum_drawings must have the same length.", call. = FALSE)
  }

  results <- do.call(rbind, Map(
    atlas_validate_xlsx_package,
    path = as.list(workbooks),
    minimum_drawings = as.list(minimum_drawings)
  ))

  print(results, row.names = FALSE)
  dir.create(dirname(output_file), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(results, output_file, row.names = FALSE, na = "")

  if (isTRUE(stop_on_failure) && any(!results$passed)) {
    stop(
      "One or more generated Excel packages failed ZIP, DrawingML, or relationship validation. See ",
      output_file,
      ".",
      call. = FALSE
    )
  }
  invisible(results)
}

if (!isTRUE(getOption("ia.atlas.xlsx_validator.define_only", FALSE))) {
  atlas_run_xlsx_package_validation()
}
