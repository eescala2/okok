# Configure the optional HTOPS benchmark for Iowa AI Workforce Atlas v3.1.3-clean-r7.
project_root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
setup <- file.path(project_root, "R", "00_setup.R")
if (file.exists(setup)) source(setup, local = .GlobalEnv)
if (exists("activate_atlas_package_library", mode = "function")) activate_atlas_package_library()
source(file.path(project_root, "R", "47_htops_visual_polish_v317.R"), local = .GlobalEnv)
input <- Sys.getenv("IA_ATLAS_HTOPS_INPUT", unset = "")
atlas_v317_configure_htops(input_file = input, root = project_root)
cat("\nNext: source(\"verify_data_sources.R\") and inspect the HTOPS row.\n")
