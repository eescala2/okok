# v3.1.3-clean-r7 HTOPS status adapter.
if (file.exists(file.path(getwd(), "R", "47_htops_visual_polish_v317.R"))) {
  source(file.path(getwd(), "R", "47_htops_visual_polish_v317.R"), local = .GlobalEnv)
  atlas_v317_install_runtime_wrappers(root = getwd())
}

# Focused live-source diagnostic. This does not run the analytical/report stages.
root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
# Activate the R-version-specific library populated by install_dependencies.R.
.bootstrap_env <- new.env(parent = globalenv())
sys.source(file.path(root, "R", "00_setup.R"), envir = .bootstrap_env, keep.source = FALSE)
.bootstrap_env$activate_atlas_package_library()
rm(.bootstrap_env)
for (f in c("R/20_methodology_v3_setup.R","R/21_methodology_v3_public_data.R")) sys.source(file.path(root,f),envir=.GlobalEnv)
v3_setup_packages(install_optional=FALSE)
paths <- v3_paths(root); v3_ensure_directories(paths); cfg <- v3_load_config(root)
refresh <- tolower(Sys.getenv("IA_ATLAS_ONE_CLICK_REFRESH",unset="true")) %in% c("1","true","yes","y","always")
source(file.path("R", "47_public_source_and_excel_repairs_v313.R"))

result <- v3_refresh_public_inputs(refresh=refresh,paths=paths,cfg=cfg)
print(result$status,row.names=FALSE)
message("Wrote: ",file.path(paths$outputs,"public_data_status_v3.csv"))

if (exists("atlas_v313_reconcile_public_status", mode = "function", inherits = TRUE)) {
  atlas_v313_reconcile_public_status(getwd())
  status_path <- file.path(
    getwd(), "outputs", "methodology_v3", "public_data_status_v3.csv"
  )
  if (file.exists(status_path)) {
    message("Reconciled live BTOS and BEA Regional controls: ", status_path)
    .atlas_v313_status <- readr::read_csv(
      status_path,
      show_col_types = FALSE
    )
    print(.atlas_v313_status, n = Inf, width = Inf)
    rm(.atlas_v313_status)
  }
}

if (exists("atlas_v317_reconcile_htops_status", mode = "function")) {
  atlas_v317_reconcile_htops_status(root = getwd())
  htops_status <- file.path(getwd(), "outputs", "methodology_v3", "htops_configuration_status_v317.csv")
  if (file.exists(htops_status)) print(utils::read.csv(htops_status, stringsAsFactors = FALSE), row.names = FALSE)
}
