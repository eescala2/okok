# Iowa AI Workforce Atlas v3.1.3-clean-r9 browser-PDF diagnostic.
root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
version <- trimws(readLines(file.path(root, "VERSION"), warn = FALSE)[[1L]])
stopifnot(identical(version, "3.1.3-clean-r9"))
source(file.path(root, "R", "00_setup.R"), local = .GlobalEnv)
activate_atlas_package_library()
source(file.path(root, "R", "45_one_click_orchestrator_v312.R"), local = .GlobalEnv)
source(file.path(root, "R", "48_browser_pdf_completion_v319.R"), local = .GlobalEnv)
options("ia.atlas.v312.project_root" = root)
atlas_v319_browser_pdf_smoke_test(root = root, timeout_seconds = 60)
cat("\nDetected browser candidates:\n")
print(atlas_v318_browser_candidates())
status_path <- file.path(root, "outputs", "pdf_print_status_v319.csv")
if (file.exists(status_path)) {
  cat("\nRevision-9 PDF status:\n")
  print(utils::read.csv(status_path, stringsAsFactors = FALSE), row.names = FALSE)
}
cat("\nLogs: outputs/pdf_logs_v319/\n")
