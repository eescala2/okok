# Configuring HTOPS and producing compact, readable figures

## What HTOPS does in this Atlas

HTOPS is an optional household/worker-side benchmark. It can show national patterns in AI use for a precisely defined survey cycle and population. It must not be used as a substitute for an Iowa employer pulse, Iowa worker outcomes, observed productivity, or causal pilot evidence.

## Preferred configuration: published normalized estimates

1. Select one official HTOPS cycle whose questionnaire contains the AI item(s) needed for the benchmark.
2. Use that cycle's questionnaire and data dictionary. Keep changed question wording in separate cycle rows.
3. Copy `inputs/htops_ai_benchmark_template.csv` to `inputs/htops_ai_benchmark.csv`.
4. Enter estimates as proportions from 0 through 1, not percentages. Example: 18 percent is `0.18`.
5. Use one row per cycle × geography × population × subgroup × measure.
6. Include standard errors or confidence limits when officially published.
7. Run:

```r
source("configure_htops.R")
source("verify_data_sources.R")
```

When the input is already normalized, set its path before calling the configuration script:

```r
Sys.setenv(IA_ATLAS_HTOPS_INPUT = "/absolute/path/to/your/htops_normalized.csv")
source("configure_htops.R")
```

## Raw public-use-file configuration

Edit `config/htops_mapping.yml` with the exact variable names and response codes from the selected cycle. Then:

```r
Sys.setenv(IA_ATLAS_HTOPS_INPUT = "/absolute/path/to/the/downloaded_htops_file.csv")
source("configure_htops.R")
```

The script applies the configured survey weight and writes:

- `inputs/htops_ai_benchmark.csv`
- `data_processed/methodology_v3/htops_ai_benchmark.csv`
- `outputs/methodology_v3/htops_configuration_status_v317.csv`

Microdata confidence intervals use a Kish effective-sample-size approximation. For final inferential publication, replace them with the survey's officially published precision measures or an approved replicate-weight calculation.

## Visual readability and whitespace

Revision 7 performs three presentation steps before report rendering:

1. It applies compact publication typography and smaller plot/legend margins.
2. It trims only uniform outer PNG background, retaining a protective pixel border around titles, labels, legends, and captions.
3. It injects compact print CSS into the generated HTML before browser-based PDF creation.

It writes:

- `outputs/figure_readability_audit_v317.csv`
- `outputs/figure_readability_gallery_v317.html`

Run the visual-only pass without rerunning analytics:

```r
source("polish_existing_figures.R")
source("verify_visual_readability.R")
```

For self-contained HTML/PDF reports to embed the optimized figures, run the complete cached workflow afterward:

```r
Sys.setenv(IA_ATLAS_ONE_CLICK_REFRESH = "false")
source("run_atlas.R")
```
