# Iowa AI Workforce Atlas Methodology v2 model card

**Build ID:** `20260830T120821_3b9657ec`  
**Methodology version:** `2.0.0`  

- **Model name:** Iowa AI Exposure and Pro-Worker AI Opportunity Atlas Methodology v2
- **Version:** 2.0.0
- **Intended use:** Strategic prioritization, scenario analysis, employer validation, training planning, and pilot selection
- **Prohibited interpretation:** Not a job-loss forecast, not an official county-SOC count, and not proof that small score differences are statistically meaningful
- **Core unit:** Synthetic county x industry x detailed-SOC cell constrained to public margins
- **Task framework:** O*NET task-importance-weighted mean exposure, exposure concentration, reallocation potential, automation, augmentation, expertise leveling, new-task opportunity, and physical AI
- **Small-area method:** Conjugate empirical-Bayes Dirichlet/Beta-style partial pooling toward combined-LWDA sector priors followed by iterative benchmark reconciliation; production approximation rather than full MCMC
- **Benchmark universe:** OEWS detailed-SOC shares are scaled to the QWI/LODES county-industry employment universe before simultaneous reconciliation; raw and scaled targets are retained
- **Uncertainty:** Model-based 95% intervals and A/B/C reliability classes; intervals describe synthetic allocation uncertainty, not causal forecast uncertainty
- **Observed adoption:** Maintained separately; Census BTOS and Iowa employer-pulse estimates are retained by source and combined only through a published precision-weighted nowcast; missing observations are not imputed from technical exposure
- **External benchmark:** AIOE is retained as an external benchmark and is not used to silently rescale the primary score
- **Training capacity:** Multi-component ACS/local-input index with explicit component coverage and reliability
- **Sensitivity:** Proactive/balanced/cautious action thresholds plus worker-capability, balanced, substitution-stress, and physical-AI score-weight scenarios
- **Publication and suppression:** Modeled cells remain available for reproducibility, while public interpretation relies on aggregated outputs, reliability classes, interval widths, and explicit warnings rather than presenting sparse cells as observed counts
- **Validation:** 6 of 6 automated reconciliation/schema tests passed
- **Required source coverage:** 5 of 5 required registry entries available
- **Governance:** NIST AI RMF-oriented Govern, Map, Measure, and Manage profile template
- **Known limitations:** No direct county-SOC observations for all counties; limited local workflow/adoption/outcome data; task dictionaries and sector modifiers require employer validation; no causal claims from exposure maps

## Automated reconciliation tests

- CI_MARGIN: PASS — Maximum relative residual against county-industry employment controls (statistic=2.3134e-15, tolerance=0.005)
- SOC_MARGIN: PASS — Maximum relative residual against Iowa state occupation controls (statistic=7.0832e-07, tolerance=0.005)
- DUPLICATE_CELL: PASS — Duplicate county-industry-occupation keys (statistic=0, tolerance=0)
- SCORE_SCHEMA: PASS — Typed score-schema issues (statistic=0, tolerance=0)
- LWDA_COVERAGE: PASS — Atlas rows without a combined LWDA (statistic=0, tolerance=0)
- FINITE_JOBS: PASS — Rows with non-finite or negative employment (statistic=0, tolerance=0)
