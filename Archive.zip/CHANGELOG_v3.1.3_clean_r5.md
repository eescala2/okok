# Iowa AI Workforce Atlas v3.1.3-clean-r5

## Editable alluvial failure fixed

The Stage 6-only recovery reached Public Figure 07 and stopped with:

```text
Can't find stat called "stratum".
```

Figures 07 and 10, plus the article-ready alluvial override, previously asked
`ggplot2` to find an extension stat by the string `stat = "stratum"`. That can
work after `ggalluvial` has been attached by an earlier full run, but it is not
a safe contract in a fresh Stage 6-only R session.

The three layers now call the exported stat directly:

```r
ggalluvial::stat_stratum(
  mapping = ggplot2::aes(label = ggplot2::after_stat(stratum)),
  geom = "text"
)
```

The editable-Excel dependency bootstrap now explicitly loads the full public
visualization package set. `ggalluvial`, `ggforce`, `ggridges`, `treemapify`,
`ggtext`, `viridis`, `htmltools`, and `forcats` are also explicit installer and
preflight dependencies rather than accidental full-run side effects.

## Stage 6 checkpoints

The Stage 6 recovery now validates and checkpoints the Methodology v2,
Methodology v3, and consolidated workbooks independently. A later failure or
interruption reuses any completed workbook whose version, MD5, DrawingML count,
and internal relationship targets still validate. This prevents another
failure in a later phase from forcing the 40-figure v2 workbook to be rebuilt.

Expected minimum native DrawingML counts are:

- Methodology v2 workbook: 40
- Methodology v3 workbook: 13
- Consolidated workbook: 53

Checkpoint files are written under `outputs/.stage6_checkpoints_r5/`.

## XLSX validation strengthened

`validate_excel_packages.R` now:

- validates all three workbooks, including the consolidated workbook;
- counts native `xl/drawings/drawing*.xml` parts;
- verifies every internal relationship target;
- records a single `passed` field for ZIP, drawing-count, and relationship
  integrity;
- can be sourced in definition-only mode for per-phase validation.

## Label warnings remediated

The Figure 05 quadrant annotations now use bounded quadrant-center coordinates.
The earlier fixed `+/- 0.18` offsets could leave the `[0, 1]` plotting scales
when a statewide threshold was near an edge, producing dropped `geom_text()`
rows during DrawingML rendering.

## Regression coverage

The r5 smoke test now constructs synthetic Figures 05, 07, and 10, resolves the
alluvial stats through `ggplot_build()`, renders Figures 05 and 07 through the
same `rvg::dml_xlsx()` device used by Stage 6, and checks the checkpoint and
minimum-drawing contracts.

No Methodology v2/v3 formulas, scores, weights, thresholds, evidence rules,
public-source contracts, or report conclusions were changed. Revision 4's
Cairo/X11/XQuartz removal and bounded browser-PDF handling remain unchanged.
