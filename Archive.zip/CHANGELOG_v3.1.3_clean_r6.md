# Iowa AI Workforce Atlas v3.1.3-clean-r6

## Purpose

Repair the Stage 6 XLSX package failure observed after all 40 Methodology v2
DrawingML figures were created. The failed workbook contained 40 drawing parts
but 13 drawing relationships pointed to missing `xl/media/image*.png` files.

## Root cause

Revision 5 accepted `openxlsx2` 1.25. Upstream openxlsx2 1.24/1.25 could create
DrawingML relationships while failing to register raster files emitted by
`rvg::dml_xlsx()`. openxlsx2 1.26 restored that image/raster registration.
The warning's `wb$clone()$save()` path also showed that the wrapper save cloned
the workbook before serialization.

## Changes

- Require the actually loaded `openxlsx2` namespace to be version 1.26.0 or newer.
- Stop Stage 6 before rebuilding 40 figures when the old namespace is resident.
- Save with the bound `wbWorkbook$save()` method rather than `wb_save()`.
- Serialize to a same-directory temporary XLSX package.
- Validate ZIP readability, DrawingML counts, media counts, and every internal
  OOXML relationship before publishing the file.
- Preserve and restore any prior workbook if promotion or final validation fails.
- Add a raster-bearing `rvg` smoke workbook that must contain at least one
  `xl/media` part and zero missing relationship targets.
- Add a cross-workbook worksheet-clone smoke test for the consolidated workbook.
- Clone complete Methodology v3 worksheets into the consolidated workbook so
  data, drawings, media, and relationship parts move together.
- Record openxlsx2 and rvg runtime versions in the Stage 6 completion manifest.
- Preserve all earlier renderer, public-source, alluvial, Cairo/X11, and
  checkpoint repairs.

## Runtime sequence

Run `source("install_dependencies.R")` in a fresh session, restart R, run the
preflight and smoke test, and only then run
`source("resume_publication_from_stage6.R")`.
