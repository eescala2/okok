# Methodology v3 observed adoption nowcast

v3_read_employer_pulse <- function(paths = v3_paths()) {
  path <- file.path(paths$inputs, "iowa_employer_pulse.csv")
  if (!file.exists(path)) path <- file.path(paths$inputs, "iowa_employer_pulse_template.csv")
  x <- v3_drop_example_rows(v3_read_csv(path))
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(x)
  required <- c("response_id", "collection_date", "naics2", "current_ai_use", "expected_ai_use_6m")
  v3_require_columns(x, required, "Iowa employer pulse")
  x |>
    dplyr::mutate(
      county_fips = if ("county_fips" %in% names(x)) v3_normalize_fips5(county_fips) else NA_character_,
      naics2 = v3_normalize_naics2(naics2),
      employment_size_class = if ("employment_size_class" %in% names(x)) as.character(employment_size_class) else "All sizes",
      business_function = if ("business_function" %in% names(x)) as.character(business_function) else NA_character_,
      current_ai_use = v3_as_binary(current_ai_use),
      expected_ai_use_6m = v3_as_binary(expected_ai_use_6m),
      worker_task_use = if ("worker_task_use" %in% names(x)) v3_as_binary(worker_task_use) else NA_integer_,
      employees = if ("employees" %in% names(x)) pmax(v3_as_numeric(employees), 1) else 1,
      weight = if ("weight" %in% names(x)) pmax(v3_as_numeric(weight), 0) else 1,
      pulse_weight = weight * sqrt(employees),
      collection_date = as.Date(collection_date)
    ) |>
    dplyr::filter(!is.na(naics2), !is.na(collection_date))
}

v3_select_btos_ai <- function(btos) {
  if (!nrow(btos)) return(tibble::tibble())
  required <- c("canonical_metric", "estimate", "schema_valid")
  if (!all(required %in% names(btos))) return(tibble::tibble())
  btos |>
    dplyr::filter(
      schema_valid,
      canonical_metric %in% c(
        "current_ai_use", "expected_ai_use_6m", "worker_task_use",
        "function_breadth", "employment_decrease", "training_change",
        "workflow_change", "technology_investment"
      ),
      is.finite(estimate)
    ) |>
    dplyr::mutate(
      estimate = v3_validate_unit_interval(estimate, "BTOS estimate"),
      period_date = v3_parse_date(period_end),
      standard_error = v3_weighted_rate_se(estimate, denominator, standard_error),
      state_fips = ifelse(state_fips %in% c("19", "019"), "19", state_fips),
      geography_level = dplyr::case_when(
        state_fips == "19" | grepl("Iowa", geography_name %||% "", ignore.case = TRUE) ~ "Iowa",
        !is.na(naics2) & !is.na(employment_size_class) ~ "sector_size",
        !is.na(naics2) ~ "sector",
        !is.na(employment_size_class) ~ "size",
        TRUE ~ "national"
      )
    )
}

v3_precision_pool <- function(prior_mean, prior_se, local_successes, local_total, prior_strength = 25) {
  prior_mean <- v3_clamp(prior_mean, 0.001, 0.999)
  prior_se <- v3_as_numeric(prior_se)
  # Prefer the published standard error; otherwise use the configured effective prior strength.
  effective_n <- ifelse(is.finite(prior_se) & prior_se > 0,
                        pmax(prior_mean * (1 - prior_mean) / prior_se^2 - 1, 2),
                        prior_strength)
  a0 <- prior_mean * effective_n
  b0 <- (1 - prior_mean) * effective_n
  a1 <- a0 + pmax(local_successes, 0)
  b1 <- b0 + pmax(local_total - local_successes, 0)
  mean <- a1 / (a1 + b1)
  low <- stats::qbeta(0.025, a1, b1)
  high <- stats::qbeta(0.975, a1, b1)
  tibble::tibble(mean = mean, lower = low, upper = high, effective_n = a1 + b1)
}

v3_fit_logit_nowcast <- function(data, forecast_months = 6, draws = 2000L) {
  if (!nrow(data)) return(tibble::tibble())
  data <- data |>
    dplyr::filter(is.finite(estimate), !is.na(period_date)) |>
    dplyr::mutate(
      time_days = as.numeric(period_date - min(period_date, na.rm = TRUE)),
      y = v3_logit(estimate),
      model_weight = ifelse(is.finite(standard_error) & standard_error > 0,
                            1 / pmax(standard_error^2, 1e-6),
                            1)
    )
  if (nrow(data) < 3L || dplyr::n_distinct(data$period_date) < 2L) {
    latest <- data |>
      dplyr::slice_max(period_date, n = 1, with_ties = FALSE)
    return(latest |>
      dplyr::transmute(
        forecast_date = period_date + round(30.4375 * forecast_months),
        nowcast_mean = estimate,
        nowcast_lower = v3_clamp(estimate - 1.96 * standard_error),
        nowcast_upper = v3_clamp(estimate + 1.96 * standard_error),
        model = "latest_observation",
        observations = nrow(data)
      ))
  }
  fit <- stats::lm(y ~ stats::poly(time_days, degree = min(2L, dplyr::n_distinct(data$period_date) - 1L), raw = TRUE),
                   data = data, weights = model_weight)
  fdate <- max(data$period_date, na.rm = TRUE) + round(30.4375 * forecast_months)
  new <- data.frame(time_days = as.numeric(fdate - min(data$period_date, na.rm = TRUE)))
  pred <- stats::predict(fit, newdata = new, se.fit = TRUE)
  tibble::tibble(
    forecast_date = fdate,
    nowcast_mean = v3_inv_logit(as.numeric(pred$fit)),
    nowcast_lower = v3_inv_logit(as.numeric(pred$fit) - 1.96 * as.numeric(pred$se.fit)),
    nowcast_upper = v3_inv_logit(as.numeric(pred$fit) + 1.96 * as.numeric(pred$se.fit)),
    model = "weighted_logit_time_trend",
    observations = nrow(data)
  )
}

v3_btos_nowcast_cells <- function(btos_ai, cfg) {
  if (!nrow(btos_ai)) return(tibble::tibble())
  group_vars <- c("canonical_metric", "geography_level", "state_fips", "geography_name", "naics2", "employment_size_class", "business_function")
  group_vars <- intersect(group_vars, names(btos_ai))
  btos_ai |>
    dplyr::group_by(dplyr::across(dplyr::all_of(group_vars))) |>
    dplyr::group_modify(~v3_fit_logit_nowcast(
      .x,
      forecast_months = cfg$adoption$forecast_months %||% 6,
      draws = cfg$adoption$uncertainty_draws %||% 2000
    )) |>
    dplyr::ungroup()
}

v3_local_pulse_summary <- function(pulse) {
  if (!nrow(pulse)) return(tibble::tibble())
  pulse |>
    dplyr::group_by(naics2, employment_size_class) |>
    dplyr::summarise(
      pulse_n = dplyr::n(),
      pulse_weight = sum(pulse_weight, na.rm = TRUE),
      current_success = sum(pulse_weight * current_ai_use, na.rm = TRUE),
      expected_success = sum(pulse_weight * expected_ai_use_6m, na.rm = TRUE),
      current_rate = current_success / pulse_weight,
      expected_rate = expected_success / pulse_weight,
      .groups = "drop"
    )
}

v3_integrate_btos_pulse <- function(nowcast, pulse_summary, cfg) {
  if (!nrow(nowcast)) return(tibble::tibble())
  base <- nowcast |>
    dplyr::filter(canonical_metric %in% c("current_ai_use", "expected_ai_use_6m")) |>
    dplyr::mutate(
      metric_key = canonical_metric,
      prior_se = (nowcast_upper - nowcast_lower) / (2 * 1.96)
    )
  if (!nrow(pulse_summary)) {
    return(base |>
      dplyr::transmute(
        canonical_metric, geography_level, state_fips, geography_name, naics2,
        employment_size_class, business_function, forecast_date,
        adoption_mean = nowcast_mean, adoption_lower = nowcast_lower,
        adoption_upper = nowcast_upper, local_pulse_n = 0L,
        evidence_status = "BENCHMARKED", reliability_class = "B",
        integration_method = "BTOS observed estimates with time-trend nowcast"
      ))
  }
  long_pulse <- dplyr::bind_rows(
    pulse_summary |>
      dplyr::transmute(naics2, employment_size_class, canonical_metric = "current_ai_use", pulse_n, success = current_success, total = pulse_weight),
    pulse_summary |>
      dplyr::transmute(naics2, employment_size_class, canonical_metric = "expected_ai_use_6m", pulse_n, success = expected_success, total = pulse_weight)
  )
  joined <- base |>
    dplyr::left_join(long_pulse, by = c("naics2", "employment_size_class", "canonical_metric"))
  pooled <- purrr::pmap_dfr(
    list(joined$nowcast_mean, joined$prior_se, joined$success, joined$total),
    function(pm, ps, s, n) {
      if (!is.finite(s) || !is.finite(n) || n <= 0) {
        return(tibble::tibble(mean = pm, lower = v3_clamp(pm - 1.96 * ps), upper = v3_clamp(pm + 1.96 * ps), effective_n = NA_real_))
      }
      v3_precision_pool(pm, ps, s, n, cfg$adoption$local_pulse_prior_strength %||% 25)
    }
  )
  dplyr::bind_cols(joined, pooled) |>
    dplyr::transmute(
      canonical_metric, geography_level, state_fips, geography_name, naics2,
      employment_size_class, business_function, forecast_date,
      adoption_mean = mean, adoption_lower = lower, adoption_upper = upper,
      local_pulse_n = dplyr::coalesce(pulse_n, 0L),
      evidence_status = ifelse(local_pulse_n > 0, "BENCHMARKED", "BENCHMARKED"),
      reliability_class = dplyr::case_when(
        local_pulse_n >= (cfg$adoption$minimum_local_pulse_n %||% 30) ~ "A",
        local_pulse_n > 0 ~ "B",
        TRUE ~ "B"
      ),
      integration_method = ifelse(local_pulse_n > 0, "BTOS prior plus Iowa employer pulse", "BTOS only")
    )
}

v3_county_lwda_adoption <- function(atlas, adoption_cells, cfg) {
  if (!nrow(atlas) || !nrow(adoption_cells)) return(tibble::tibble())
  v3_require_columns(atlas, c("county_fips", "naics2", "estimated_jobs"), "Methodology v2 atlas")
  current <- adoption_cells |>
    dplyr::filter(canonical_metric == "current_ai_use") |>
    dplyr::filter(!is.na(naics2)) |>
    dplyr::group_by(naics2) |>
    dplyr::summarise(
      sector_adoption_mean = v3_weighted_mean(adoption_mean, ifelse(local_pulse_n > 0, local_pulse_n, 1)),
      sector_adoption_lower = v3_weighted_mean(adoption_lower, ifelse(local_pulse_n > 0, local_pulse_n, 1)),
      sector_adoption_upper = v3_weighted_mean(adoption_upper, ifelse(local_pulse_n > 0, local_pulse_n, 1)),
      sector_reliability = ifelse(any(reliability_class == "A"), "A", "B"),
      .groups = "drop"
    )
  if (!nrow(current)) {
    statewide <- adoption_cells |>
      dplyr::filter(canonical_metric == "current_ai_use") |>
      dplyr::slice_max(forecast_date, n = 1, with_ties = FALSE)
    if (!nrow(statewide)) return(tibble::tibble())
    current <- tibble::tibble(
      naics2 = unique(atlas$naics2),
      sector_adoption_mean = statewide$adoption_mean[[1]],
      sector_adoption_lower = statewide$adoption_lower[[1]],
      sector_adoption_upper = statewide$adoption_upper[[1]],
      sector_reliability = "C"
    )
  }
  x <- atlas |>
    dplyr::mutate(
      county_fips = v3_normalize_fips5(county_fips),
      naics2 = v3_normalize_naics2(naics2),
      jobs_weight = pmax(v3_as_numeric(estimated_jobs), 0)
    ) |>
    dplyr::left_join(current, by = "naics2")
  # Missing sector estimates are imputed only from the observed statewide adoption rate, never from exposure.
  fallback_mean <- v3_weighted_mean(current$sector_adoption_mean, rep(1, nrow(current)))
  fallback_low <- v3_weighted_mean(current$sector_adoption_lower, rep(1, nrow(current)))
  fallback_high <- v3_weighted_mean(current$sector_adoption_upper, rep(1, nrow(current)))
  x <- x |>
    dplyr::mutate(
      sector_adoption_mean = dplyr::coalesce(sector_adoption_mean, fallback_mean),
      sector_adoption_lower = dplyr::coalesce(sector_adoption_lower, fallback_low),
      sector_adoption_upper = dplyr::coalesce(sector_adoption_upper, fallback_high),
      sector_reliability = dplyr::coalesce(sector_reliability, "C")
    )
  county <- x |>
    dplyr::group_by(county_fips, dplyr::across(dplyr::any_of(c("county_name", "lwda_combined")))) |>
    dplyr::summarise(
      estimated_jobs = sum(jobs_weight, na.rm = TRUE),
      adoption_nowcast = v3_weighted_mean(sector_adoption_mean, jobs_weight),
      adoption_lower = v3_weighted_mean(sector_adoption_lower, jobs_weight),
      adoption_upper = v3_weighted_mean(sector_adoption_upper, jobs_weight),
      sectors_observed = sum(!is.na(sector_reliability)),
      evidence_status = "BENCHMARKED",
      reliability_class = ifelse(any(sector_reliability == "C"), "C", "B"),
      .groups = "drop"
    )
  county
}

apply_methodology_v3_adoption <- function(public_inputs, atlas, paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  btos_ai <- v3_select_btos_ai(public_inputs$btos)
  nowcast <- v3_btos_nowcast_cells(btos_ai, cfg)
  pulse <- v3_read_employer_pulse(paths)
  pulse_summary <- v3_local_pulse_summary(pulse)
  integrated <- v3_integrate_btos_pulse(nowcast, pulse_summary, cfg)
  county <- v3_county_lwda_adoption(atlas, integrated, cfg)
  lwda <- if (nrow(county) && "lwda_combined" %in% names(county)) county |>
    dplyr::filter(!is.na(lwda_combined)) |>
    dplyr::mutate(jobs_weight = estimated_jobs) |>
    dplyr::group_by(lwda_combined) |>
    dplyr::summarise(
      estimated_jobs = sum(jobs_weight, na.rm = TRUE),
      adoption_nowcast = v3_weighted_mean(adoption_nowcast, jobs_weight),
      adoption_lower = v3_weighted_mean(adoption_lower, jobs_weight),
      adoption_upper = v3_weighted_mean(adoption_upper, jobs_weight),
      reliability_class = ifelse(any(reliability_class == "C"), "C", "B"),
      evidence_status = "BENCHMARKED",
      .groups = "drop"
    ) else tibble::tibble()

  v3_write_csv(btos_ai, file.path(paths$processed, "btos_ai_observed.csv"))
  v3_write_csv(nowcast, file.path(paths$processed, "btos_ai_nowcast_cells.csv"))
  v3_write_csv(pulse_summary, file.path(paths$processed, "iowa_employer_pulse_summary.csv"))
  v3_write_csv(integrated, file.path(paths$processed, "adoption_nowcast_integrated.csv"))
  v3_write_csv(county, file.path(paths$processed, "county_adoption_nowcast.csv"))
  status <- tibble::tibble(
    module = "observed_adoption_nowcast",
    btos_rows = nrow(btos_ai),
    nowcast_cells = nrow(integrated),
    local_pulse_cells = nrow(pulse_summary),
    county_benchmarks = nrow(county),
    evidence_status = if (nrow(integrated)) "BENCHMARKED" else "UNAVAILABLE",
    note = if (nrow(integrated))
      "Adoption is estimated from observed BTOS and optional Iowa employer-pulse evidence; technical exposure is never used as adoption."
    else
      "No usable BTOS AI observations or Iowa employer pulse were available; adoption remains unavailable."
  )
  v3_write_csv(status, file.path(paths$outputs, "adoption_nowcast_status_v3.csv"))
  v3_write_csv(lwda, file.path(paths$processed, "lwda_adoption_nowcast.csv"))
  list(btos_observed = btos_ai, nowcast = nowcast, pulse = pulse_summary, integrated = integrated, county = county, lwda = lwda, status = status)
}
