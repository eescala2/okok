# Auto-generated Methodology v3 report bootstrap.
# Quarto/R Markdown use a clean R session and do not inherit run_all.R globals.

v3_report_find_project_root <- function(start = getwd()) {
  starts <- c(start)
  if (requireNamespace("knitr", quietly = TRUE)) {
    input <- tryCatch(knitr::current_input(dir = TRUE), error = function(e) character())
    input <- as.character(input)
    input <- input[!is.na(input) & nzchar(input)]
    if (length(input)) starts <- c(starts, dirname(input[[1L]]))
  }
  starts <- unique(normalizePath(starts, winslash = "/", mustWork = FALSE))
  for (candidate in starts) {
    current <- candidate
    for (i in seq_len(12L)) {
      if (dir.exists(file.path(current, "R")) &&
          (file.exists(file.path(current, "atlas_v3.qmd")) ||
           file.exists(file.path(current, "atlas_v3.Rmd")))) {
        return(normalizePath(current, winslash = "/", mustWork = TRUE))
      }
      parent <- dirname(current)
      if (identical(parent, current)) break
      current <- parent
    }
  }
  stop("Methodology v3 report bootstrap could not locate the project root.", call. = FALSE)
}

v3_bootstrap_methodology_v3_report <- function(root = NULL, envir = NULL, verbose = FALSE) {
  if (is.null(root)) root <- v3_report_find_project_root()
  if (is.null(envir)) {
    envir <- if (requireNamespace("knitr", quietly = TRUE)) knitr::knit_global() else globalenv()
  }

  source_files <- c(
    "R/00_setup.R",
    "R/10_iowa_report_style.R",
    "R/20_methodology_v3_setup.R",
    "R/21_methodology_v3_public_data.R",
    "R/22_methodology_v3_adoption_nowcast.R",
    "R/23_methodology_v3_worker_outcomes.R",
    "R/24_methodology_v3_early_career.R",
    "R/25_methodology_v3_feasible_transitions.R",
    "R/26_methodology_v3_industrial_readiness.R",
    "R/27_methodology_v3_pilots_assurance.R",
    "R/28_methodology_v3_value_capture.R",
    "R/29_methodology_v3_visualizations.R",
    "R/30_methodology_v3_render.R",
    "R/31_methodology_v3_excel.R",
    "R/32_methodology_v3_validate.R",
    "R/33_methodology_v3_apply.R",
    "R/34_methodology_v3_provenance.R"
  )
  source_files <- unique(source_files)

  for (relative in source_files) {
    path <- if (grepl("^(/|[A-Za-z]:[/\\])", relative)) relative else file.path(root, relative)
    if (!file.exists(path)) {
      stop(sprintf("Methodology v3 report bootstrap is missing required module: %s", path), call. = FALSE)
    }
    if (isTRUE(verbose)) message("Report bootstrap sourcing: ", path)
    tryCatch(
      sys.source(path, envir = envir, keep.source = FALSE),
      error = function(e) {
        stop(sprintf("Failed while sourcing Methodology v3 report module %s: %s", path, conditionMessage(e)), call. = FALSE)
      }
    )
  }

  if (!exists("v3_load_results", envir = envir, mode = "function", inherits = TRUE)) {
    stop(
      paste0(
        "Methodology v3 report bootstrap completed, but v3_load_results() is still unavailable. ",
        "Confirm that the function is defined in one of the sourced Methodology v3 modules."
      ),
      call. = FALSE
    )
  }

  invisible(TRUE)
}

if (!isTRUE(getOption("ia_atlas_v3_bootstrap_no_autorun", FALSE))) {
  v3_bootstrap_methodology_v3_report()
}
