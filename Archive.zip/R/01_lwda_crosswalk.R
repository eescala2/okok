# 01_lwda_crosswalk.R ------------------------------------------------------
# Versioned county-to-LWDA geography. County assignments and requested LWDA
# combinations are data files under config/ rather than reporting-code rules.

make_lwda_crosswalk <- function() {
  root <- project_root()
  county_file <- file.path(root, 'config', 'county_lwda_crosswalk.csv')
  combo_file <- file.path(root, 'config', 'lwda_combinations.csv')
  if (!file.exists(county_file)) stop('Missing versioned county LWDA crosswalk: ', county_file, call. = FALSE)
  county <- readr::read_csv(county_file, show_col_types = FALSE, progress = FALSE) |>
    dplyr::mutate(
      county_name = stringr::str_squish(as.character(county_name)),
      lwda_original = stringr::str_squish(as.character(lwda_original)),
      county_name_key = stringr::str_to_lower(county_name)
    )
  if (nrow(county) != 99L || dplyr::n_distinct(county$county_name_key) != 99L) {
    stop('config/county_lwda_crosswalk.csv must contain exactly 99 unique Iowa counties.', call. = FALSE)
  }
  combo <- if (file.exists(combo_file)) {
    readr::read_csv(combo_file, show_col_types = FALSE, progress = FALSE) |>
      dplyr::distinct(lwda_original, .keep_all = TRUE)
  } else {
    tibble::tibble(lwda_original = unique(county$lwda_original), lwda_combined = unique(county$lwda_original))
  }
  out <- county |>
    dplyr::left_join(combo |> dplyr::select(lwda_original, lwda_combined), by = 'lwda_original') |>
    dplyr::mutate(lwda_combined = dplyr::coalesce(lwda_combined, lwda_original)) |>
    dplyr::arrange(lwda_combined, county_name)
  missing_original <- setdiff(unique(county$lwda_original), unique(combo$lwda_original))
  if (length(missing_original)) warning('No combination rule for: ', paste(missing_original, collapse = ', '), '; original names retained.', call. = FALSE)
  out
}

write_lwda_crosswalk <- function() {
  p <- paths()
  x <- make_lwda_crosswalk()
  out <- file.path(p$processed, 'iowa_lwda_county_crosswalk.csv')
  readr::write_csv(x, out)
  out
}
