# 04_build_atlas.R -----------------------------------------------------------
# Main build pipeline: downloads public data, scores occupations, estimates
# county-by-industry-by-occupation employment, and creates atlas outputs.

source(file.path(project_root(), 'R', '00_setup.R'))
source(file.path(project_root(), 'R', '01_lwda_crosswalk.R'))
source(file.path(project_root(), 'R', '02_data_download.R'))
source(file.path(project_root(), 'R', '03_ai_scores.R'))

normalize_naics2 <- function(x) {
  # Keep NAICS2 keys stable across CSV/XLSX readers. LODES and QWI can
  # arrive as numeric (e.g., 31) while sector labels and BLS NEM are
  # character strings (e.g., '31'). dplyr 1.1+ correctly refuses to join
  # mixed types, so normalize before every NAICS join.
  y <- stringr::str_trim(as.character(x))
  y[y %in% c('', 'NA', 'NaN', 'NULL')] <- NA_character_
  y <- stringr::str_replace(y, '\\.[0]+$', '')
  y <- dplyr::case_when(
    is.na(y) ~ NA_character_,
    stringr::str_detect(y, '^\\d+$') ~ stringr::str_pad(y, width = 2, side = 'left', pad = '0'),
    TRUE ~ stringr::str_extract(y, '\\d{2}')
  )
  y
}

normalize_fips5 <- function(x) {
  y <- stringr::str_trim(as.character(x))
  y[y %in% c('', 'NA', 'NaN', 'NULL')] <- NA_character_
  y <- stringr::str_replace(y, '\\.[0]+$', '')
  stringr::str_pad(y, width = 5, side = 'left', pad = '0')
}

industry_sector_labels <- function() {
  tibble::tribble(
    ~naics2, ~sector_title, ~iowa_priority_sector,
    '11','Agriculture, forestry, fishing, and hunting','Agriculture-adjacent services',
    '21','Mining, quarrying, and oil and gas extraction','Other',
    '22','Utilities','Infrastructure and energy',
    '23','Construction','Construction and skilled trades',
    '31','Manufacturing','Manufacturing',
    '32','Manufacturing','Manufacturing',
    '33','Manufacturing','Manufacturing',
    '42','Wholesale trade','Logistics and trade',
    '44','Retail trade','Retail and local services',
    '45','Retail trade','Retail and local services',
    '48','Transportation and warehousing','Logistics and trade',
    '49','Transportation and warehousing','Logistics and trade',
    '51','Information','Digital and information services',
    '52','Finance and insurance','Insurance and finance',
    '53','Real estate and rental and leasing','Business services',
    '54','Professional, scientific, and technical services','Professional and technical services',
    '55','Management of companies and enterprises','Business services',
    '56','Administrative and support services','Administrative services',
    '61','Educational services','Education',
    '62','Health care and social assistance','Health care',
    '71','Arts, entertainment, and recreation','Local services',
    '72','Accommodation and food services','Local services',
    '81','Other services','Local services',
    '92','Public administration','Public administration',
    '99','Other/unknown','Other'
  ) |>
    dplyr::mutate(naics2 = normalize_naics2(naics2))
}

make_demo_data <- function() {
  # Explicitly flagged fallback for report layout testing. Not for policy analysis.
  counties <- make_lwda_crosswalk() |>
    dplyr::mutate(county_fips = stringr::str_pad(row_number() + 19000, 5, pad = '0'))
  occ <- tibble::tribble(
    ~soc_code, ~occupation_title, ~state_emp, ~hourly_mean, ~automation_exposure, ~augmentation_potential, ~expertise_leveling_potential, ~new_task_opportunity, ~pro_worker_opportunity,
    '43-9061','Office Clerks, General', 25000, 20, .75, .44, .40, .42, .38,
    '29-1141','Registered Nurses', 33000, 38, .35, .78, .70, .70, .82,
    '51-2098','Miscellaneous Assemblers and Fabricators', 16000, 21, .68, .50, .52, .48, .43,
    '13-2011','Accountants and Auditors', 12000, 36, .70, .65, .58, .62, .55,
    '49-9041','Industrial Machinery Mechanics', 9000, 28, .45, .75, .72, .70, .77
  )
  ci <- tidyr::crossing(county_fips = counties$county_fips, naics2 = c('31','52','62','11','48','56')) |>
    dplyr::mutate(emp_source = 'demo', county_industry_emp = 100 + as.numeric(factor(county_fips))*3 + as.numeric(factor(naics2))*20)
  atlas <- tidyr::crossing(ci, occ) |>
    dplyr::mutate(estimated_jobs = county_industry_emp * state_emp / sum(state_emp) / 6,
                  demo_fallback = TRUE) |>
    dplyr::left_join(counties |> dplyr::select(county_fips, county_name, lwda_original, lwda_combined), by = 'county_fips') |>
    dplyr::left_join(industry_sector_labels(), by = 'naics2')
  list(atlas = atlas, occ_scores = occ, county_shapes = NULL, acs = tibble::tibble(), qwi = tibble::tibble())
}

prepare_county_industry <- function(qwi, lodes) {
  sectors <- industry_sector_labels() |>
    dplyr::mutate(naics2 = normalize_naics2(naics2))
  if (nrow(qwi)) {
    q <- qwi |>
      dplyr::mutate(
        county_fips = normalize_fips5(county_fips),
        naics2 = normalize_naics2(naics2),
        county_industry_emp = dplyr::coalesce(emp_stable, emp),
        emp_source = 'QWI'
      ) |>
      dplyr::select(county_fips, naics2, county_industry_emp, hires, separations, avg_monthly_earnings, payroll, emp_source)
    return(q |> dplyr::left_join(sectors, by = 'naics2'))
  }
  if (nrow(lodes)) {
    l <- lodes |>
      dplyr::mutate(
        county_fips = normalize_fips5(county_fips),
        naics2 = normalize_naics2(naics2),
        county_industry_emp = emp_lodes,
        hires = NA_real_, separations = NA_real_, avg_monthly_earnings = NA_real_,
        payroll = NA_real_, emp_source = 'LODES WAC'
      ) |>
      dplyr::select(county_fips, naics2, county_industry_emp, hires, separations, avg_monthly_earnings, payroll, emp_source)
    return(l |> dplyr::left_join(sectors, by = 'naics2'))
  }
  tibble::tibble()
}

make_fallback_occ_industry_shares <- function(oews, sectors = industry_sector_labels()) {
  # Cross-industry occupation shares repeated by sector. Used only if NEM parsing fails.
  occ <- oews |>
    dplyr::filter(stringr::str_detect(soc_code, '^\\d{2}-\\d{4}$'), !is.na(state_emp), state_emp > 0) |>
    dplyr::mutate(occ_state_share = state_emp / sum(state_emp, na.rm = TRUE)) |>
    dplyr::select(soc_code, occ_state_share)
  tidyr::crossing(sectors |> dplyr::select(naics2), occ) |>
    dplyr::group_by(naics2) |>
    dplyr::mutate(share_occ_within_naics2 = occ_state_share / sum(occ_state_share, na.rm = TRUE)) |>
    dplyr::ungroup() |>
    dplyr::select(naics2, soc_code, share_occ_within_naics2)
}

complete_naics_shares <- function(shares, sectors = industry_sector_labels()) {
  # The BLS NEM often reports combined sectors such as 31-33, 44-45, and 48-49.
  # QWI/LODES may split those sectors. Reuse the combined-sector staffing pattern
  # for the component NAICS2 sectors when direct rows are unavailable.
  shares <- shares |> dplyr::mutate(naics2 = normalize_naics2(naics2))
  sectors <- sectors |> dplyr::mutate(naics2 = normalize_naics2(naics2))
  all_naics <- unique(sectors$naics2)
  group_source <- tibble::tribble(
    ~naics2, ~source_naics2,
    '31','31', '32','31', '33','31',
    '44','44', '45','44',
    '48','48', '49','48'
  ) |>
    dplyr::right_join(tibble::tibble(naics2 = all_naics), by = 'naics2') |>
    dplyr::mutate(source_naics2 = dplyr::coalesce(source_naics2, naics2))

  direct_naics <- unique(shares$naics2)
  add <- group_source |>
    dplyr::filter(!naics2 %in% direct_naics, source_naics2 %in% direct_naics) |>
    dplyr::left_join(shares, by = c('source_naics2' = 'naics2')) |>
    dplyr::select(naics2, soc_code, share_occ_within_naics2)

  dplyr::bind_rows(shares, add) |>
    dplyr::filter(!is.na(naics2), !is.na(soc_code), !is.na(share_occ_within_naics2), share_occ_within_naics2 > 0) |>
    dplyr::group_by(naics2) |>
    dplyr::mutate(share_occ_within_naics2 = share_occ_within_naics2 / sum(share_occ_within_naics2, na.rm = TRUE)) |>
    dplyr::ungroup()
}

make_occ_industry_shares <- function(nem, oews) {
  # Keep only detailed SOC occupations with valid Iowa OEWS employment. The BLS
  # National Employment Matrix also contains major/minor/summary SOC rows; if
  # those are retained, they double-count employment and enter downstream plots as
  # NA-scored “Monitor” jobs. Filtering here keeps the atlas analytically clean.
  valid_soc <- oews |>
    dplyr::filter(stringr::str_detect(soc_code, '^\\d{2}-\\d{4}$'), !is.na(state_emp), state_emp > 0) |>
    dplyr::distinct(soc_code) |>
    dplyr::pull(soc_code)

  if (nrow(nem)) {
    shares <- nem |>
      dplyr::mutate(naics2 = normalize_naics2(naics2)) |>
      dplyr::filter(!is.na(naics2), !is.na(soc_code), soc_code %in% valid_soc, !is.na(nem_emp), nem_emp > 0) |>
      dplyr::group_by(naics2, soc_code) |>
      dplyr::summarise(nem_emp = sum(nem_emp, na.rm = TRUE), .groups = 'drop') |>
      dplyr::group_by(naics2) |>
      dplyr::mutate(share_occ_within_naics2 = nem_emp / sum(nem_emp, na.rm = TRUE)) |>
      dplyr::ungroup() |>
      dplyr::select(naics2, soc_code, share_occ_within_naics2) |>
      complete_naics_shares()
    if (dplyr::n_distinct(shares$naics2) >= 10 && nrow(shares) > 1000) return(shares)
    warning('Parsed BLS NEM has too few usable detailed NAICS/SOC rows; using fallback OEWS shares.', call. = FALSE)
  }
  make_fallback_occ_industry_shares(oews)
}

rake_estimated_jobs <- function(seed, occ_targets, ci_targets, iter = 8) {
  x <- seed |>
    dplyr::mutate(estimated_jobs = pmax(estimated_jobs, 0))
  for (i in seq_len(iter)) {
    # Occupation control to BLS OEWS state employment.
    occ_sum <- x |>
      dplyr::group_by(soc_code) |>
      dplyr::summarise(current = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop') |>
      dplyr::left_join(occ_targets, by = 'soc_code') |>
      dplyr::mutate(f_occ = dplyr::if_else(current > 0 & !is.na(state_emp), state_emp / current, 1)) |>
      dplyr::select(soc_code, f_occ)
    x <- x |> dplyr::left_join(occ_sum, by = 'soc_code') |>
      dplyr::mutate(estimated_jobs = estimated_jobs * dplyr::coalesce(f_occ, 1)) |>
      dplyr::select(-f_occ)
    # County-industry control to QWI/LODES employment.
    ci_sum <- x |>
      dplyr::group_by(county_fips, naics2) |>
      dplyr::summarise(current = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop') |>
      dplyr::left_join(ci_targets, by = c('county_fips','naics2')) |>
      dplyr::mutate(f_ci = dplyr::if_else(current > 0 & !is.na(county_industry_emp), county_industry_emp / current, 1)) |>
      dplyr::select(county_fips, naics2, f_ci)
    x <- x |> dplyr::left_join(ci_sum, by = c('county_fips','naics2')) |>
      dplyr::mutate(estimated_jobs = estimated_jobs * dplyr::coalesce(f_ci, 1)) |>
      dplyr::select(-f_ci)
  }
  x
}

build_atlas <- function(refresh = NULL, install_optional = FALSE) {
  setup_packages(install_optional = install_optional)
  cfg <- load_config()
  refresh <- if (is.null(refresh)) isTRUE(cfg$refresh_downloads) else refresh
  p <- paths()
  write_log('Starting Iowa AI Workforce Atlas build.')
  write_lwda_crosswalk()

  # Download/read public data.
  oews <- get_oews_iowa(cfg, refresh = refresh)
  nem <- get_nem_matrix(cfg, refresh = refresh)
  onet <- get_onet(cfg, refresh = refresh)
  aioe <- get_aioe(refresh = refresh)
  qwi <- get_qwi_iowa(cfg, refresh = refresh)
  lodes_wac <- if (nrow(qwi)) tibble::tibble() else get_lodes_wac_iowa(cfg, refresh = refresh)
  acs <- get_acs_county_demographics(cfg, refresh = refresh) |>
    dplyr::mutate(county_fips = normalize_fips5(county_fips))
  county_shapes <- tryCatch(get_county_shapes(cfg, refresh = refresh), error = function(e) NULL)
  lodes_od <- tryCatch(get_lodes_od_labor_shed(cfg, refresh = refresh), error = function(e) tibble::tibble())

  if (!nrow(oews) || !nrow(onet$tasks)) {
    if (isTRUE(cfg$allow_demo_fallback)) {
      warning('Core public data did not load; using demo fallback because allow_demo_fallback=true.', call. = FALSE)
      demo <- make_demo_data()
      write_compat_table(demo$atlas, 'county_industry_occupation_atlas', p$processed)
      readr::write_csv(demo$occ_scores, file.path(p$processed, 'occupation_ai_scores.csv'))
      return(invisible(demo$atlas))
    }
    stop('Core public data failed to load. Check internet access and data-source availability.', call. = FALSE)
  }

  occ_scores <- summarise_occupation_scores(onet, aioe, oews)
  readr::write_csv(occ_scores, file.path(p$processed, 'occupation_ai_scores.csv'))
  write_compat_table(occ_scores, 'occupation_ai_scores', p$processed)

  county_industry <- prepare_county_industry(qwi, lodes_wac) |>
    dplyr::mutate(county_fips = normalize_fips5(county_fips), naics2 = normalize_naics2(naics2))
  if (!nrow(county_industry)) stop('No county-industry employment data from QWI or LODES.', call. = FALSE)
  shares <- make_occ_industry_shares(nem, oews) |>
    dplyr::mutate(naics2 = normalize_naics2(naics2))
  seed <- county_industry |>
    dplyr::select(county_fips, naics2, county_industry_emp, dplyr::everything()) |>
    dplyr::inner_join(shares, by = 'naics2', relationship = 'many-to-many') |>
    dplyr::mutate(estimated_jobs = county_industry_emp * share_occ_within_naics2)
  occ_targets <- oews |> dplyr::select(soc_code, state_emp) |> dplyr::filter(!is.na(state_emp), state_emp > 0)
  ci_targets <- county_industry |>
    dplyr::mutate(county_fips = normalize_fips5(county_fips), naics2 = normalize_naics2(naics2)) |>
    dplyr::select(county_fips, naics2, county_industry_emp)
  cell_jobs <- rake_estimated_jobs(seed, occ_targets, ci_targets, iter = 8)

  lwda <- make_lwda_crosswalk()
  county_lookup <- if (!is.null(county_shapes)) {
    sf::st_drop_geometry(county_shapes) |>
      dplyr::mutate(county_fips = normalize_fips5(county_fips)) |>
      dplyr::select(county_fips, county_name, county_name_key)
  } else {
    lwda |> dplyr::mutate(county_fips = NA_character_) |> dplyr::select(county_fips, county_name, county_name_key)
  }

  atlas <- cell_jobs |>
    dplyr::left_join(occ_scores, by = 'soc_code') |>
    dplyr::left_join(county_lookup, by = 'county_fips') |>
    dplyr::left_join(lwda, by = c('county_name_key','county_name')) |>
    dplyr::left_join(acs |> dplyr::select(county_fips, population, median_household_income, share_bachelors_plus), by = 'county_fips') |>
    dplyr::mutate(
      industry_new_task_multiplier = dplyr::case_when(
        iowa_priority_sector %in% c('Manufacturing','Insurance and finance','Health care','Agriculture-adjacent services','Logistics and trade','Administrative services') ~ 1.10,
        iowa_priority_sector %in% c('Professional and technical services','Education') ~ 1.05,
        TRUE ~ 1.00
      ),
      new_task_opportunity_local = rescale01(new_task_opportunity * industry_new_task_multiplier),
      pro_worker_opportunity_local = rescale01(0.30 * augmentation_potential + 0.25 * expertise_leveling_potential +
                                                0.30 * new_task_opportunity_local - 0.15 * automation_exposure),
      transition_priority = dplyr::case_when(
        automation_exposure >= 0.70 & pro_worker_opportunity_local < 0.45 ~ 'Protect and redesign',
        automation_exposure >= 0.65 & pro_worker_opportunity_local >= 0.45 ~ 'Upgrade through AI-complementary training',
        automation_exposure < 0.65 & pro_worker_opportunity_local >= 0.60 ~ 'Scale pro-worker AI opportunity',
        TRUE ~ 'Monitor'
      ),
      demo_fallback = FALSE
    ) |>
    dplyr::filter(
      !is.na(estimated_jobs), estimated_jobs > 0,
      stringr::str_detect(soc_code, '^\\d{2}-\\d{4}$'),
      is.finite(automation_exposure), is.finite(pro_worker_opportunity_local)
    )

  write_compat_table(atlas, 'county_industry_occupation_atlas', p$processed)
  readr::write_csv(dplyr::slice_head(atlas, n = min(100000, nrow(atlas))), file.path(p$processed, 'county_industry_occupation_atlas_preview.csv'))

  county_summary <- atlas |>
    dplyr::group_by(county_fips, county_name, lwda_original, lwda_combined) |>
    dplyr::summarise(
      automation_exposure = stats::weighted.mean(automation_exposure, estimated_jobs, na.rm = TRUE),
      augmentation_potential = stats::weighted.mean(augmentation_potential, estimated_jobs, na.rm = TRUE),
      expertise_leveling_potential = stats::weighted.mean(expertise_leveling_potential, estimated_jobs, na.rm = TRUE),
      new_task_opportunity = stats::weighted.mean(new_task_opportunity_local, estimated_jobs, na.rm = TRUE),
      pro_worker_opportunity = stats::weighted.mean(pro_worker_opportunity_local, estimated_jobs, na.rm = TRUE),
      protective_redesign_jobs = sum(estimated_jobs[transition_priority == 'Protect and redesign'], na.rm = TRUE),
      upgrade_training_jobs = sum(estimated_jobs[transition_priority == 'Upgrade through AI-complementary training'], na.rm = TRUE),
      scale_opportunity_jobs = sum(estimated_jobs[transition_priority == 'Scale pro-worker AI opportunity'], na.rm = TRUE),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::mutate(
      risk_opportunity_gap = automation_exposure - pro_worker_opportunity,
      protective_redesign_share = protective_redesign_jobs / estimated_jobs,
      upgrade_training_share = upgrade_training_jobs / estimated_jobs,
      scale_opportunity_share = scale_opportunity_jobs / estimated_jobs
    ) |>
    dplyr::arrange(dplyr::desc(risk_opportunity_gap))
  readr::write_csv(county_summary, file.path(p$processed, 'county_summary.csv'))

  lwda_summary <- atlas |>
    dplyr::group_by(lwda_combined) |>
    dplyr::summarise(
      automation_exposure = stats::weighted.mean(automation_exposure, estimated_jobs, na.rm = TRUE),
      augmentation_potential = stats::weighted.mean(augmentation_potential, estimated_jobs, na.rm = TRUE),
      expertise_leveling_potential = stats::weighted.mean(expertise_leveling_potential, estimated_jobs, na.rm = TRUE),
      new_task_opportunity = stats::weighted.mean(new_task_opportunity_local, estimated_jobs, na.rm = TRUE),
      pro_worker_opportunity = stats::weighted.mean(pro_worker_opportunity_local, estimated_jobs, na.rm = TRUE),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::mutate(risk_opportunity_gap = automation_exposure - pro_worker_opportunity) |>
    dplyr::arrange(dplyr::desc(pro_worker_opportunity))
  readr::write_csv(lwda_summary, file.path(p$processed, 'lwda_summary.csv'))

  sector_summary <- atlas |>
    dplyr::group_by(lwda_combined, iowa_priority_sector) |>
    dplyr::summarise(
      automation_exposure = stats::weighted.mean(automation_exposure, estimated_jobs, na.rm = TRUE),
      pro_worker_opportunity = stats::weighted.mean(pro_worker_opportunity_local, estimated_jobs, na.rm = TRUE),
      new_task_opportunity = stats::weighted.mean(new_task_opportunity_local, estimated_jobs, na.rm = TRUE),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::arrange(lwda_combined, dplyr::desc(estimated_jobs))
  readr::write_csv(sector_summary, file.path(p$processed, 'sector_lwda_summary.csv'))

  top_training <- atlas |>
    dplyr::filter(transition_priority %in% c('Upgrade through AI-complementary training', 'Scale pro-worker AI opportunity')) |>
    dplyr::group_by(lwda_combined, iowa_priority_sector, soc_code, occupation_title, transition_priority) |>
    dplyr::summarise(
      automation_exposure = stats::weighted.mean(automation_exposure, estimated_jobs, na.rm = TRUE),
      augmentation_potential = stats::weighted.mean(augmentation_potential, estimated_jobs, na.rm = TRUE),
      expertise_leveling_potential = stats::weighted.mean(expertise_leveling_potential, estimated_jobs, na.rm = TRUE),
      new_task_opportunity = stats::weighted.mean(new_task_opportunity_local, estimated_jobs, na.rm = TRUE),
      pro_worker_opportunity = stats::weighted.mean(pro_worker_opportunity_local, estimated_jobs, na.rm = TRUE),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::group_by(lwda_combined) |>
    dplyr::slice_max(order_by = estimated_jobs * pro_worker_opportunity, n = 25, with_ties = FALSE) |>
    dplyr::ungroup() |>
    dplyr::arrange(lwda_combined, dplyr::desc(estimated_jobs * pro_worker_opportunity))
  readr::write_csv(top_training, file.path(p$processed, 'training_priority_occupations.csv'))

  if (nrow(lodes_od)) {
    flows_lwda <- lodes_od |>
      dplyr::mutate(
        home_county_fips = normalize_fips5(home_county_fips),
        work_county_fips = normalize_fips5(work_county_fips)
      ) |>
      dplyr::left_join(county_lookup |> dplyr::rename(home_county_fips = county_fips, home_county = county_name, home_key = county_name_key), by = 'home_county_fips') |>
      dplyr::left_join(county_lookup |> dplyr::rename(work_county_fips = county_fips, work_county = county_name, work_key = county_name_key), by = 'work_county_fips') |>
      dplyr::left_join(lwda |> dplyr::select(county_name_key, home_lwda = lwda_combined), by = c('home_key' = 'county_name_key')) |>
      dplyr::left_join(lwda |> dplyr::select(county_name_key, work_lwda = lwda_combined), by = c('work_key' = 'county_name_key')) |>
      dplyr::group_by(home_lwda, work_lwda) |>
      dplyr::summarise(commuters = sum(commuters, na.rm = TRUE), .groups = 'drop') |>
      dplyr::filter(!is.na(home_lwda), !is.na(work_lwda))
    readr::write_csv(flows_lwda, file.path(p$processed, 'lwda_commuting_flows.csv'))
  }

  write_log('Completed Iowa AI Workforce Atlas build.')
  invisible(atlas)
}
