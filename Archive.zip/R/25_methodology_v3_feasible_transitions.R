# Methodology v3 credential-feasible occupational transition graph
# Release hotfix 3.0.2: typed empty contracts and evidence-safe publication filtering.

v3_empty_transition_candidates <- function() {
  tibble::tibble(
    origin_soc = character(),
    destination_soc = character(),
    origin_title = character(),
    destination_title = character(),
    skill_similarity = double(),
    origin_wage = double(),
    destination_wage = double(),
    origin_job_zone = double(),
    destination_job_zone = double(),
    lwda_combined = character()
  )
}

v3_empty_feasible_transition_graph <- function() {
  tibble::tibble(
    origin_soc = character(),
    destination_soc = character(),
    origin_title = character(),
    destination_title = character(),
    lwda_combined = character(),
    skill_similarity = double(),
    origin_wage = double(),
    destination_wage = double(),
    candidate_origin_job_zone = double(),
    candidate_destination_job_zone = double(),
    origin_job_zone = double(),
    destination_job_zone = double(),
    origin_minimum_education_level = character(),
    destination_minimum_education_level = character(),
    origin_education_rank = double(),
    destination_education_rank = double(),
    origin_minimum_experience_months = double(),
    destination_minimum_experience_months = double(),
    origin_physical_demand_level = double(),
    destination_physical_demand_level = double(),
    origin_schedule_profile = character(),
    destination_schedule_profile = character(),
    destination_license_required = integer(),
    destination_certification_required = integer(),
    wage_ratio = double(),
    effective_wage_floor = double(),
    job_zone_gap = double(),
    education_gap = double(),
    experience_gap_months = double(),
    training_programs = double(),
    training_months = double(),
    training_cost = double(),
    annual_training_seats = double(),
    annual_completions = double(),
    annual_openings = double(),
    license_preparation_available = logical(),
    certification_preparation_available = logical(),
    employer_openings_expected = double(),
    employer_minimum_wage = double(),
    employer_license_support = logical(),
    employer_training_support = logical(),
    commute_or_remote_support = logical(),
    commute_minutes = double(),
    training_travel_minutes = double(),
    physical_accommodation_validated = logical(),
    schedule_accommodation_validated = logical(),
    effective_commute_minutes = double(),
    access_support_score = double(),
    training_bridge_documented = logical(),
    credential_record_available = logical(),
    license_required = logical(),
    license_resolution = logical(),
    certification_required = logical(),
    certification_resolution = logical(),
    physical_compatibility = logical(),
    schedule_compatibility = logical(),
    commute_pass = logical(),
    skill_pass = logical(),
    job_zone_pass = logical(),
    education_pass = logical(),
    experience_pass = logical(),
    wage_pass = logical(),
    training_duration_pass = logical(),
    training_cost_pass = logical(),
    openings_pass = logical(),
    employer_validation_status = character(),
    employer_validation_pass = logical(),
    employer_rejected = logical(),
    hard_constraint_pass = logical(),
    publication_eligible = logical(),
    reason_codes = character(),
    feasibility_score = double(),
    evidence_status = character(),
    reliability_class = character()
  )
}

v3_empty_transition_rejection_summary <- function() {
  tibble::tibble(
    reason = character(),
    candidate_pairs = integer()
  )
}


v3_typed_na <- function(template_column, n) {
  if (is.character(template_column)) return(rep(NA_character_, n))
  if (is.logical(template_column)) return(rep(NA, n))
  if (is.integer(template_column)) return(rep(NA_integer_, n))
  if (is.numeric(template_column)) return(rep(NA_real_, n))
  rep(NA, n)
}

v3_transition_as_logical <- function(x) {
  if (is.logical(x)) return(x)
  if (is.numeric(x) || is.integer(x)) return(ifelse(is.na(x), NA, x != 0))
  y <- tolower(trimws(as.character(x)))
  dplyr::case_when(
    y %in% c("true", "t", "yes", "y", "1", "pass", "passed", "eligible") ~ TRUE,
    y %in% c("false", "f", "no", "n", "0", "fail", "failed", "ineligible") ~ FALSE,
    TRUE ~ NA
  )
}

v3_transition_candidate_contract <- function(x) {
  template <- v3_empty_transition_candidates()
  if (is.null(x) || !is.data.frame(x)) return(template)
  n <- nrow(x)
  for (nm in names(template)) {
    if (!nm %in% names(x)) x[[nm]] <- v3_typed_na(template[[nm]], n)
  }
  char_cols <- c("origin_soc", "destination_soc", "origin_title", "destination_title", "lwda_combined")
  num_cols <- c("skill_similarity", "origin_wage", "destination_wage", "origin_job_zone", "destination_job_zone")
  x <- x |>
    dplyr::mutate(
      dplyr::across(dplyr::all_of(char_cols), as.character),
      dplyr::across(dplyr::all_of(num_cols), v3_as_numeric),
      origin_soc = v3_normalize_soc(.data$origin_soc),
      destination_soc = v3_normalize_soc(.data$destination_soc)
    )
  x
}

v3_transition_graph_contract <- function(x) {
  template <- v3_empty_feasible_transition_graph()
  if (is.null(x) || !is.data.frame(x)) return(template)
  n <- nrow(x)
  for (nm in names(template)) {
    if (!nm %in% names(x)) x[[nm]] <- v3_typed_na(template[[nm]], n)
  }
  char_cols <- names(template)[vapply(template, is.character, logical(1))]
  num_cols <- names(template)[vapply(template, is.numeric, logical(1))]
  logical_cols <- names(template)[vapply(template, is.logical, logical(1))]
  x <- x |>
    dplyr::mutate(
      dplyr::across(dplyr::all_of(char_cols), as.character),
      dplyr::across(dplyr::all_of(num_cols), v3_as_numeric),
      dplyr::across(dplyr::all_of(logical_cols), v3_transition_as_logical),
      publication_eligible = dplyr::coalesce(.data$publication_eligible, FALSE),
      hard_constraint_pass = dplyr::coalesce(.data$hard_constraint_pass, FALSE)
    )
  preferred <- unique(c(names(template), names(x)))
  dplyr::select(x, dplyr::any_of(preferred))
}

v3_transition_candidate_paths <- function(paths = v3_paths()) {
  unique(c(
    file.path(paths$root, "data_processed", "occupation_transition_pathways.csv"),
    file.path(paths$root, "data_processed", "methodology_v2", "occupation_transition_pathways.csv"),
    file.path(paths$root, "data_processed", "skill_transition_pathways.csv"),
    file.path(paths$root, "data_processed", "methodology_v2", "skill_transition_pathways.csv"),
    file.path(paths$root, "data_processed", "occupation_skill_transition_pathways.csv"),
    file.path(paths$processed, "occupation_transition_candidates.csv")
  ))
}

v3_normalize_transition_candidate_table <- function(raw, path = NA_character_) {
  raw <- v3_clean_names(raw)
  aliases <- list(
    origin_soc = c("origin_soc", "origin_soc_code", "from_soc", "from_soc_code", "source_soc", "source_soc_code", "origin_code"),
    destination_soc = c("destination_soc", "destination_soc_code", "to_soc", "to_soc_code", "target_soc", "target_soc_code", "destination_code"),
    origin_title = c("origin_title", "origin_occupation", "origin_occupation_title", "from_title", "source_title", "source_occupation_title"),
    destination_title = c("destination_title", "destination_occupation", "destination_occupation_title", "to_title", "target_title", "target_occupation_title"),
    skill_similarity = c("skill_similarity", "skill_similarity_score", "activity_similarity", "transition_similarity", "cosine_similarity", "similarity", "similarity_score"),
    origin_wage = c("origin_wage", "origin_hourly_wage", "origin_hourly_mean", "from_wage", "source_wage"),
    destination_wage = c("destination_wage", "destination_hourly_wage", "destination_hourly_mean", "to_wage", "target_wage"),
    origin_job_zone = c("origin_job_zone", "from_job_zone", "source_job_zone"),
    destination_job_zone = c("destination_job_zone", "to_job_zone", "target_job_zone"),
    lwda_combined = c("lwda_combined", "combined_lwda", "lwda")
  )
  for (nm in names(aliases)) {
    hit <- intersect(aliases[[nm]], names(raw))
    if (!nm %in% names(raw)) {
      raw[[nm]] <- if (length(hit)) raw[[hit[[1]]]] else rep(NA, nrow(raw))
    }
  }

  out <- raw |>
    dplyr::mutate(
      origin_soc = v3_normalize_soc(.data$origin_soc),
      destination_soc = v3_normalize_soc(.data$destination_soc),
      skill_similarity = v3_as_numeric(.data$skill_similarity),
      origin_wage = v3_as_numeric(.data$origin_wage),
      destination_wage = v3_as_numeric(.data$destination_wage),
      origin_job_zone = v3_as_numeric(.data$origin_job_zone),
      destination_job_zone = v3_as_numeric(.data$destination_job_zone),
      lwda_combined = as.character(.data$lwda_combined)
    ) |>
    dplyr::filter(!is.na(.data$origin_soc), !is.na(.data$destination_soc), .data$origin_soc != .data$destination_soc) |>
    v3_transition_candidate_contract()

  attr(out, "source_path") <- normalizePath(path, winslash = "/", mustWork = FALSE)
  attr(out, "raw_rows") <- nrow(raw)
  attr(out, "available_columns") <- names(raw)
  out
}

v3_read_transition_candidates <- function(paths = v3_paths()) {
  candidate_paths <- v3_transition_candidate_paths(paths)
  existing <- candidate_paths[file.exists(candidate_paths)]
  if (!length(existing)) {
    out <- v3_empty_transition_candidates()
    attr(out, "source_path") <- NA_character_
    attr(out, "input_status") <- "UNAVAILABLE"
    attr(out, "input_note") <- "No Methodology v2 occupation-transition candidate file was found. The v3 pathway module will continue and publish no recommendations."
    attr(out, "raw_rows") <- 0L
    attr(out, "candidate_inventory") <- tibble::tibble(
      source_path = character(), raw_rows = integer(), normalized_rows = integer(), status = character(), note = character()
    )
    return(out)
  }

  inventory <- vector("list", length(existing))
  selected <- NULL
  selected_index <- NA_integer_

  for (i in seq_along(existing)) {
    path <- existing[[i]]
    read_result <- tryCatch(
      list(data = v3_read_csv(path), error = NULL),
      error = function(e) list(data = NULL, error = conditionMessage(e))
    )
    raw <- read_result$data
    if (is.null(raw)) {
      inventory[[i]] <- tibble::tibble(
        source_path = normalizePath(path, winslash = "/", mustWork = FALSE),
        raw_rows = NA_integer_,
        normalized_rows = 0L,
        status = "READ_ERROR",
        note = read_result$error %||% "Unknown read error"
      )
      next
    }

    normalize_result <- tryCatch(
      list(data = v3_normalize_transition_candidate_table(raw, path), error = NULL),
      error = function(e) list(data = NULL, error = conditionMessage(e))
    )
    normalized <- normalize_result$data
    if (is.null(normalized)) {
      inventory[[i]] <- tibble::tibble(
        source_path = normalizePath(path, winslash = "/", mustWork = FALSE),
        raw_rows = nrow(raw),
        normalized_rows = 0L,
        status = "SCHEMA_ERROR",
        note = normalize_result$error %||% "Unknown schema error"
      )
      next
    }

    inventory[[i]] <- tibble::tibble(
      source_path = normalizePath(path, winslash = "/", mustWork = FALSE),
      raw_rows = nrow(raw),
      normalized_rows = nrow(normalized),
      status = if (nrow(normalized)) "AVAILABLE" else "NO_VALID_PAIRS",
      note = if (nrow(normalized)) {
        "Candidate pairs normalized successfully."
      } else {
        paste0("No valid origin/destination SOC pairs remained. Available columns: ", paste(names(raw), collapse = ", "))
      }
    )

    if (is.null(selected) && nrow(normalized)) {
      selected <- normalized
      selected_index <- i
      break
    }
  }

  inventory <- dplyr::bind_rows(inventory[!vapply(inventory, is.null, logical(1))])
  if (!is.null(selected)) {
    attr(selected, "source_path") <- normalizePath(existing[[selected_index]], winslash = "/", mustWork = FALSE)
    attr(selected, "raw_rows") <- attr(selected, "raw_rows") %||% NA_integer_
    attr(selected, "input_status") <- "AVAILABLE"
    attr(selected, "input_note") <- "Transition candidates were normalized successfully. Public recommendations still require every configured hard constraint to pass."
    attr(selected, "candidate_inventory") <- inventory
    return(selected)
  }

  out <- v3_empty_transition_candidates()
  attr(out, "source_path") <- if (length(existing)) normalizePath(existing[[1]], winslash = "/", mustWork = FALSE) else NA_character_
  attr(out, "input_status") <- "UNAVAILABLE"
  attr(out, "input_note") <- "Candidate files were found, but none contained a valid origin/destination SOC pair after schema normalization. The module will continue without fabricating recommendations."
  attr(out, "raw_rows") <- if (nrow(inventory)) sum(inventory$raw_rows, na.rm = TRUE) else 0L
  attr(out, "candidate_inventory") <- inventory
  out
}

v3_read_credentials <- function(paths = v3_paths()) {
  path <- file.path(paths$inputs, "credential_requirements.csv")
  if (!file.exists(path)) path <- file.path(paths$inputs, "credential_requirements_template.csv")
  x <- v3_drop_example_rows(v3_read_csv(path))
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(x)
  x |>
    dplyr::mutate(
      soc_code = v3_normalize_soc(soc_code),
      license_required = v3_as_binary(license_required),
      certification_required = v3_as_binary(certification_required),
      minimum_experience_months = v3_as_numeric(minimum_experience_months),
      job_zone = v3_as_numeric(job_zone),
      physical_demand_level = v3_as_numeric(physical_demand_level),
      verified_date = suppressWarnings(as.Date(verified_date))
    )
}

v3_read_training_programs <- function(paths = v3_paths()) {
  path <- file.path(paths$inputs, "training_programs.csv")
  if (!file.exists(path)) path <- file.path(paths$inputs, "training_programs_template.csv")
  x <- v3_drop_example_rows(v3_read_csv(path))
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(x)
  x |>
    dplyr::mutate(
      county_fips = v3_normalize_fips5(county_fips),
      target_soc_code = v3_normalize_soc(target_soc_code),
      license_preparation = v3_as_binary(license_preparation),
      duration_months = v3_as_numeric(duration_months),
      tuition_and_fees = v3_as_numeric(tuition_and_fees),
      annual_seats = v3_as_numeric(annual_seats),
      annual_completions = v3_as_numeric(annual_completions),
      evening_weekend = v3_as_binary(evening_weekend),
      employer_release_time_available = v3_as_binary(employer_release_time_available),
      childcare_support = v3_as_binary(childcare_support),
      transportation_support = v3_as_binary(transportation_support),
      training_travel_minutes = if ("training_travel_minutes" %in% names(x)) v3_as_numeric(training_travel_minutes) else NA_real_
    )
}

v3_read_local_openings <- function(paths = v3_paths()) {
  path <- file.path(paths$inputs, "local_openings.csv")
  if (!file.exists(path)) path <- file.path(paths$inputs, "local_openings_template.csv")
  x <- v3_drop_example_rows(v3_read_csv(path))
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(x)
  x |>
    dplyr::mutate(
      county_fips = v3_normalize_fips5(county_fips),
      naics2 = v3_normalize_naics2(naics2),
      soc_code = v3_normalize_soc(soc_code),
      annual_openings = v3_as_numeric(annual_openings)
    )
}

v3_read_employer_validation <- function(paths = v3_paths()) {
  path <- file.path(paths$inputs, "employer_transition_validation.csv")
  if (!file.exists(path)) path <- file.path(paths$inputs, "employer_transition_validation_template.csv")
  x <- v3_drop_example_rows(v3_read_csv(path))
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(x)
  x |>
    dplyr::mutate(
      county_fips = v3_normalize_fips5(county_fips),
      origin_soc = v3_normalize_soc(origin_soc),
      destination_soc = v3_normalize_soc(destination_soc),
      validation_status = tolower(trimws(as.character(validation_status))),
      openings_expected = v3_as_numeric(openings_expected),
      minimum_wage = v3_as_numeric(minimum_wage),
      license_support = v3_as_binary(license_support),
      training_support = v3_as_binary(training_support),
      commute_or_remote_support = v3_as_binary(commute_or_remote_support),
      commute_minutes = if ("commute_minutes" %in% names(x)) v3_as_numeric(commute_minutes) else NA_real_,
      physical_accommodation_validated = if ("physical_accommodation_validated" %in% names(x)) v3_as_binary(physical_accommodation_validated) else NA_integer_,
      schedule_accommodation_validated = if ("schedule_accommodation_validated" %in% names(x)) v3_as_binary(schedule_accommodation_validated) else NA_integer_
    )
}

v3_education_rank <- function(x) {
  y <- tolower(trimws(as.character(x)))
  dplyr::case_when(
    grepl("no formal|less than high", y) ~ 0,
    grepl("high school|ged", y) ~ 1,
    grepl("some college|certificate|postsecondary", y) ~ 2,
    grepl("associate", y) ~ 3,
    grepl("bachelor", y) ~ 4,
    grepl("master", y) ~ 5,
    grepl("doctoral|professional degree", y) ~ 6,
    TRUE ~ NA_real_
  )
}

v3_destination_support <- function(programs, openings, validation) {
  prog <- if (nrow(programs)) programs |>
    dplyr::group_by(lwda_combined, target_soc_code) |>
    dplyr::summarise(
      training_programs = dplyr::n_distinct(program_id),
      training_months = if (all(is.na(duration_months))) NA_real_ else min(duration_months, na.rm = TRUE),
      training_cost = if (all(is.na(tuition_and_fees))) NA_real_ else min(tuition_and_fees, na.rm = TRUE),
      annual_training_seats = sum(annual_seats, na.rm = TRUE),
      annual_completions = sum(annual_completions, na.rm = TRUE),
      license_preparation_available = any(license_preparation == 1, na.rm = TRUE),
      certification_preparation_available = any(nzchar(trimws(as.character(credential_awarded))) & !is.na(credential_awarded), na.rm = TRUE),
      training_travel_minutes = if (all(is.na(training_travel_minutes))) NA_real_ else min(training_travel_minutes, na.rm = TRUE),
      access_support_score = mean(c(
        mean(evening_weekend, na.rm = TRUE),
        mean(employer_release_time_available, na.rm = TRUE),
        mean(childcare_support, na.rm = TRUE),
        mean(transportation_support, na.rm = TRUE)
      ), na.rm = TRUE),
      .groups = "drop"
    ) else tibble::tibble()
  open <- if (nrow(openings)) openings |>
    dplyr::group_by(lwda_combined, soc_code) |>
    dplyr::summarise(annual_openings = sum(annual_openings, na.rm = TRUE), .groups = "drop") else tibble::tibble()
  valid <- if (nrow(validation)) validation |>
    dplyr::group_by(lwda_combined, origin_soc, destination_soc) |>
    dplyr::summarise(
      employer_validation_status = dplyr::case_when(
        any(validation_status %in% c("validated", "approved", "yes")) ~ "validated",
        any(validation_status %in% c("rejected", "no", "not feasible")) ~ "rejected",
        TRUE ~ "provisional"
      ),
      employer_openings_expected = sum(openings_expected, na.rm = TRUE),
      employer_minimum_wage = if (all(is.na(minimum_wage))) NA_real_ else max(minimum_wage, na.rm = TRUE),
      employer_license_support = any(license_support == 1, na.rm = TRUE),
      employer_training_support = any(training_support == 1, na.rm = TRUE),
      commute_or_remote_support = any(commute_or_remote_support == 1, na.rm = TRUE),
      commute_minutes = if (all(is.na(commute_minutes))) NA_real_ else min(commute_minutes, na.rm = TRUE),
      physical_accommodation_validated = any(physical_accommodation_validated == 1, na.rm = TRUE),
      schedule_accommodation_validated = any(schedule_accommodation_validated == 1, na.rm = TRUE),
      .groups = "drop"
    ) else tibble::tibble()
  list(programs = prog, openings = open, validation = valid)
}

v3_expand_transition_geography <- function(candidates, atlas) {
  if (!nrow(candidates)) return(candidates)
  if ("lwda_combined" %in% names(candidates) && any(!is.na(candidates$lwda_combined))) return(candidates)
  lwdas <- if (nrow(atlas) && "lwda_combined" %in% names(atlas)) sort(unique(stats::na.omit(atlas$lwda_combined))) else "Statewide"
  tidyr::crossing(candidates, lwda_combined = lwdas)
}

v3_prefixed_credentials <- function(credentials, prefix) {
  if (!nrow(credentials)) return(tibble::tibble())
  id <- paste0(prefix, "_soc")
  out <- credentials |>
    dplyr::rename(!!id := soc_code)
  names(out)[names(out) != id] <- paste0(prefix, "_", names(out)[names(out) != id])
  out
}

v3_feasibility_contract <- function(candidates, credentials, programs, openings, validation, atlas, cfg) {
  candidates <- v3_transition_candidate_contract(candidates)
  if (!nrow(candidates)) return(v3_empty_feasible_transition_graph())
  candidates <- v3_expand_transition_geography(candidates, atlas)
  if ("origin_job_zone" %in% names(candidates)) {
    names(candidates)[names(candidates) == "origin_job_zone"] <- "candidate_origin_job_zone"
  } else {
    candidates$candidate_origin_job_zone <- NA_real_
  }
  if ("destination_job_zone" %in% names(candidates)) {
    names(candidates)[names(candidates) == "destination_job_zone"] <- "candidate_destination_job_zone"
  } else {
    candidates$candidate_destination_job_zone <- NA_real_
  }
  origin_cred <- v3_prefixed_credentials(credentials, "origin")
  dest_cred <- v3_prefixed_credentials(credentials, "destination")
  support <- v3_destination_support(programs, openings, validation)

  x <- candidates
  if (nrow(origin_cred)) x <- x |> dplyr::left_join(origin_cred, by = "origin_soc")
  if (nrow(dest_cred)) x <- x |> dplyr::left_join(dest_cred, by = "destination_soc")
  if (nrow(support$programs)) x <- x |>
    dplyr::left_join(support$programs, by = c("lwda_combined", "destination_soc" = "target_soc_code"))
  if (nrow(support$openings)) x <- x |>
    dplyr::left_join(support$openings, by = c("lwda_combined", "destination_soc" = "soc_code"))
  if (nrow(support$validation)) x <- x |>
    dplyr::left_join(support$validation, by = c("lwda_combined", "origin_soc", "destination_soc"))

  # Explicitly create every contract field; no missing field is interpreted as a pass.
  ensure <- list(
    origin_job_zone = NA_real_, destination_job_zone = NA_real_,
    origin_minimum_education_level = NA_character_, destination_minimum_education_level = NA_character_,
    origin_physical_demand_level = NA_real_, destination_physical_demand_level = NA_real_,
    origin_schedule_profile = NA_character_, destination_schedule_profile = NA_character_,
    destination_license_required = NA_integer_, destination_certification_required = NA_integer_,
    origin_minimum_experience_months = NA_real_, destination_minimum_experience_months = NA_real_,
    training_programs = NA_real_, training_months = NA_real_,
    training_cost = NA_real_, annual_openings = NA_real_, license_preparation_available = NA,
    certification_preparation_available = NA,
    access_support_score = NA_real_, employer_validation_status = NA_character_,
    employer_openings_expected = NA_real_, employer_minimum_wage = NA_real_,
    employer_license_support = NA, employer_training_support = NA,
    commute_or_remote_support = NA, commute_minutes = NA_real_, training_travel_minutes = NA_real_,
    physical_accommodation_validated = NA, schedule_accommodation_validated = NA
  )
  for (nm in names(ensure)) if (!nm %in% names(x)) x[[nm]] <- ensure[[nm]]

  x <- x |>
    dplyr::mutate(
      origin_job_zone = dplyr::coalesce(v3_as_numeric(origin_job_zone), v3_as_numeric(candidate_origin_job_zone)),
      destination_job_zone = dplyr::coalesce(v3_as_numeric(destination_job_zone), v3_as_numeric(candidate_destination_job_zone)),
      origin_education_rank = v3_education_rank(origin_minimum_education_level),
      destination_education_rank = v3_education_rank(destination_minimum_education_level),
      origin_wage = v3_as_numeric(origin_wage),
      destination_wage = v3_as_numeric(destination_wage),
      skill_similarity = v3_as_numeric(skill_similarity),
      wage_ratio = destination_wage / pmax(origin_wage, 0.01),
      effective_wage_floor = pmax(
        cfg$transitions$default_hourly_wage_floor %||% 18,
        dplyr::coalesce(v3_as_numeric(employer_minimum_wage), -Inf),
        na.rm = TRUE
      ),
      job_zone_gap = destination_job_zone - origin_job_zone,
      education_gap = destination_education_rank - origin_education_rank,
      experience_gap_months = v3_as_numeric(destination_minimum_experience_months) - v3_as_numeric(origin_minimum_experience_months),
      training_bridge_documented = dplyr::coalesce(v3_as_numeric(training_programs), 0) > 0,
      credential_record_available = !is.na(destination_license_required) | !is.na(destination_minimum_education_level) | !is.na(destination_job_zone),
      license_required = dplyr::case_when(
        destination_license_required == 1 ~ TRUE,
        destination_license_required == 0 ~ FALSE,
        TRUE ~ NA
      ),
      license_resolution = dplyr::case_when(
        license_required == FALSE ~ TRUE,
        license_required == TRUE & (dplyr::coalesce(license_preparation_available, FALSE) | dplyr::coalesce(employer_license_support, FALSE)) ~ TRUE,
        TRUE ~ FALSE
      ),
      certification_required = dplyr::case_when(
        destination_certification_required == 1 ~ TRUE,
        destination_certification_required == 0 ~ FALSE,
        TRUE ~ NA
      ),
      certification_resolution = dplyr::case_when(
        certification_required == FALSE ~ TRUE,
        certification_required == TRUE & (dplyr::coalesce(certification_preparation_available, FALSE) | dplyr::coalesce(employer_training_support, FALSE)) ~ TRUE,
        TRUE ~ FALSE
      ),
      physical_compatibility = dplyr::case_when(
        dplyr::coalesce(physical_accommodation_validated, FALSE) ~ TRUE,
        is.na(origin_physical_demand_level) | is.na(destination_physical_demand_level) ~ NA,
        v3_as_numeric(destination_physical_demand_level) <= v3_as_numeric(origin_physical_demand_level) + 1 ~ TRUE,
        TRUE ~ FALSE
      ),
      schedule_compatibility = dplyr::case_when(
        dplyr::coalesce(schedule_accommodation_validated, FALSE) | dplyr::coalesce(commute_or_remote_support, FALSE) ~ TRUE,
        is.na(origin_schedule_profile) | is.na(destination_schedule_profile) ~ NA,
        tolower(origin_schedule_profile) == tolower(destination_schedule_profile) ~ TRUE,
        TRUE ~ FALSE
      ),
      effective_commute_minutes = dplyr::coalesce(v3_as_numeric(commute_minutes), v3_as_numeric(training_travel_minutes)),
      commute_pass = dplyr::case_when(
        dplyr::coalesce(commute_or_remote_support, FALSE) ~ TRUE,
        is.finite(effective_commute_minutes) ~ effective_commute_minutes <= (cfg$transitions$maximum_commute_minutes %||% 60),
        TRUE ~ NA
      ),
      skill_pass = is.finite(skill_similarity) & skill_similarity >= (cfg$transitions$minimum_skill_similarity %||% 0.55),
      job_zone_pass = (is.finite(job_zone_gap) & job_zone_gap <= (cfg$transitions$maximum_job_zone_gap %||% 1)) | training_bridge_documented,
      education_pass = (is.finite(education_gap) & education_gap <= 1) | training_bridge_documented,
      experience_pass = (is.finite(experience_gap_months) & experience_gap_months <= (cfg$transitions$maximum_experience_months_increase %||% 12)) | training_bridge_documented,
      wage_pass = is.finite(destination_wage) & destination_wage >= effective_wage_floor & wage_ratio >= (cfg$transitions$minimum_wage_ratio %||% 0.90),
      training_duration_pass = is.finite(training_months) & training_months <= (cfg$transitions$maximum_training_months %||% 24),
      training_cost_pass = is.finite(training_cost) & training_cost <= (cfg$transitions$maximum_training_cost %||% 25000),
      openings_pass = (is.finite(annual_openings) & annual_openings >= (cfg$transitions$minimum_annual_openings %||% 5)) |
        dplyr::coalesce(employer_openings_expected, 0) >= (cfg$transitions$minimum_annual_openings %||% 5),
      employer_validation_pass = employer_validation_status == "validated",
      employer_rejected = employer_validation_status == "rejected",
      hard_constraint_pass = skill_pass & job_zone_pass & education_pass & experience_pass & wage_pass &
        training_duration_pass & training_cost_pass & openings_pass & !dplyr::coalesce(employer_rejected, FALSE) &
        license_resolution & certification_resolution & dplyr::coalesce(physical_compatibility, FALSE) &
        dplyr::coalesce(schedule_compatibility, FALSE) & dplyr::coalesce(commute_pass, FALSE),
      publication_eligible = hard_constraint_pass &
        (!isTRUE(cfg$transitions$require_employer_validation_for_public_recommendation) | dplyr::coalesce(employer_validation_pass, FALSE)),
      reason_codes = purrr::pmap_chr(
        list(skill_pass, job_zone_pass, education_pass, experience_pass, wage_pass, training_duration_pass,
             training_cost_pass, openings_pass, license_resolution, certification_resolution, employer_validation_pass,
             employer_rejected, physical_compatibility, schedule_compatibility, commute_pass,
             credential_record_available),
        function(skill, zone, edu, experience, wage, duration, cost, openings_ok, license, certification, validated,
                 rejected, physical, schedule, commute, credential) {
          reasons <- character()
          if (!isTRUE(skill)) reasons <- c(reasons, "insufficient_skill_similarity")
          if (!isTRUE(zone)) reasons <- c(reasons, "job_zone_gap_or_missing_bridge")
          if (!isTRUE(edu)) reasons <- c(reasons, "education_gap_or_missing_bridge")
          if (!isTRUE(experience)) reasons <- c(reasons, "experience_gap_or_missing_bridge")
          if (!isTRUE(wage)) reasons <- c(reasons, "wage_floor_or_preservation")
          if (!isTRUE(duration)) reasons <- c(reasons, "training_duration_missing_or_excessive")
          if (!isTRUE(cost)) reasons <- c(reasons, "training_cost_missing_or_excessive")
          if (!isTRUE(openings_ok)) reasons <- c(reasons, "local_openings_missing_or_insufficient")
          if (!isTRUE(credential)) reasons <- c(reasons, "credential_requirements_unverified")
          if (!isTRUE(license)) reasons <- c(reasons, "license_unresolved")
          if (!isTRUE(certification)) reasons <- c(reasons, "certification_unresolved")
          if (isTRUE(rejected)) reasons <- c(reasons, "employer_rejected")
          if (!isTRUE(validated)) reasons <- c(reasons, "employer_validation_missing")
          if (!isTRUE(physical)) reasons <- c(reasons, "physical_demand_unresolved")
          if (identical(schedule, FALSE)) reasons <- c(reasons, "schedule_incompatible")
          if (!isTRUE(commute)) reasons <- c(reasons, "commute_or_transport_unresolved")
          if (!length(reasons)) "feasible" else paste(unique(reasons), collapse = ";")
        }
      ),
      feasibility_score = v3_clamp(
        0.25 * dplyr::coalesce(skill_similarity, 0) +
          0.15 * v3_clamp(wage_ratio, 0, 1.25) / 1.25 +
          0.07 * as.numeric(job_zone_pass) +
          0.07 * as.numeric(education_pass) +
          0.06 * as.numeric(experience_pass) +
          0.07 * as.numeric(license_resolution) +
          0.06 * as.numeric(certification_resolution) +
          0.08 * as.numeric(openings_pass) +
          0.07 * as.numeric(dplyr::coalesce(employer_validation_pass, FALSE)) +
          0.04 * as.numeric(dplyr::coalesce(physical_compatibility, FALSE)) +
          0.03 * as.numeric(dplyr::coalesce(schedule_compatibility, FALSE)) +
          0.03 * as.numeric(dplyr::coalesce(commute_pass, FALSE)) +
          0.02 * dplyr::coalesce(access_support_score, 0),
        0, 1
      ),
      evidence_status = dplyr::case_when(
        publication_eligible ~ "BENCHMARKED",
        TRUE ~ "PROVISIONAL"
      ),
      reliability_class = dplyr::case_when(
        publication_eligible & is.finite(training_months) & is.finite(annual_openings) & employer_validation_pass ~ "A",
        hard_constraint_pass ~ "B",
        TRUE ~ "C"
      )
    ) |>
    dplyr::arrange(dplyr::desc(publication_eligible), dplyr::desc(feasibility_score), origin_soc, destination_soc, lwda_combined)
  v3_transition_graph_contract(x)
}

apply_methodology_v3_transitions <- function(atlas, paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  candidates <- v3_read_transition_candidates(paths)
  candidate_source <- attr(candidates, "source_path") %||% NA_character_
  candidate_input_status <- attr(candidates, "input_status") %||% if (nrow(candidates)) "AVAILABLE" else "UNAVAILABLE"
  candidate_input_note <- attr(candidates, "input_note") %||% "No transition-candidate input note was recorded."
  candidate_raw_rows <- attr(candidates, "raw_rows") %||% NA_integer_
  candidate_inventory <- attr(candidates, "candidate_inventory") %||% tibble::tibble(
    source_path = character(), raw_rows = integer(), normalized_rows = integer(), status = character(), note = character()
  )

  credentials <- v3_read_credentials(paths)
  programs <- v3_read_training_programs(paths)
  openings <- v3_read_local_openings(paths)
  validation <- v3_read_employer_validation(paths)
  feasible <- v3_feasibility_contract(candidates, credentials, programs, openings, validation, atlas, cfg) |>
    v3_transition_graph_contract()

  public <- if (nrow(feasible)) {
    feasible |>
      dplyr::filter(dplyr::coalesce(.data$publication_eligible, FALSE)) |>
      dplyr::group_by(.data$lwda_combined, .data$origin_soc) |>
      dplyr::slice_max(.data$feasibility_score, n = 5, with_ties = FALSE) |>
      dplyr::ungroup() |>
      v3_transition_graph_contract()
  } else {
    v3_empty_feasible_transition_graph()
  }

  rejection <- if (nrow(feasible)) {
    feasible |>
      dplyr::mutate(
        reason_codes = dplyr::if_else(
          is.na(.data$reason_codes) | !nzchar(trimws(.data$reason_codes)),
          "unclassified_constraint_failure",
          .data$reason_codes
        ),
        reason = strsplit(.data$reason_codes, ";", fixed = TRUE)
      ) |>
      tidyr::unnest_longer(reason) |>
      dplyr::count(reason, sort = TRUE, name = "candidate_pairs")
  } else {
    v3_empty_transition_rejection_summary()
  }

  input_status <- tibble::tibble(
    module = "credential_feasible_transitions",
    source_path = as.character(candidate_source),
    source_status = as.character(candidate_input_status),
    raw_rows = as.integer(candidate_raw_rows),
    normalized_candidate_pairs = nrow(candidates),
    note = as.character(candidate_input_note)
  )

  status_note <- if (!nrow(candidates)) {
    paste0(candidate_input_note, " No pathway was fabricated.")
  } else if (nrow(feasible) && !nrow(public)) {
    "Candidate pathways were evaluated, but none passed every configured publication constraint. Results remain provisional and the public recommendation file contains a typed zero-row schema."
  } else {
    "Raw O*NET similarity is never sufficient for a public pathway. Licenses, education, training, openings, wages, physical demands, access, and employer validation are explicit constraints."
  }

  status <- tibble::tibble(
    module = "credential_feasible_transitions",
    candidate_pairs = nrow(candidates),
    evaluated_pairs = nrow(feasible),
    public_recommendations = nrow(public),
    credentials_records = nrow(credentials),
    training_program_records = nrow(programs),
    openings_records = nrow(openings),
    employer_validation_records = nrow(validation),
    evidence_status = if (nrow(public)) "BENCHMARKED" else if (nrow(feasible)) "PROVISIONAL" else "UNAVAILABLE",
    note = status_note
  )

  v3_write_csv(feasible, file.path(paths$processed, "credential_feasible_transition_graph.csv"))
  v3_write_csv(public, file.path(paths$processed, "credential_feasible_transition_recommendations.csv"))
  v3_write_csv(rejection, file.path(paths$processed, "transition_constraint_reasons.csv"))
  v3_write_csv(input_status, file.path(paths$outputs, "transition_candidate_input_status_v3.csv"))
  v3_write_csv(candidate_inventory, file.path(paths$outputs, "transition_candidate_input_inventory_v3.csv"))
  v3_write_csv(status, file.path(paths$outputs, "transition_pathway_status_v3.csv"))
  list(candidates = candidates, evaluated = feasible, public = public, rejection = rejection, input_status = input_status, status = status)
}
