# Methodology v3 causal pilots, preregistered outcomes, NIST AI RMF, and ARIA-style evaluation

v3_read_pilot_registry <- function(paths = v3_paths()) {
  path <- file.path(paths$inputs, "ai_pilot_registry_v3.csv")
  if (!file.exists(path)) path <- file.path(paths$inputs, "ai_pilot_registry_v3_template.csv")
  x <- v3_drop_example_rows(v3_read_csv(path))
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(x)
  v3_require_columns(x, c("pilot_id", "start_date", "preregistered_date", "comparison_design"), "Pilot registry")
  optional_defaults <- list(
    primary_outcome = NA_character_,
    primary_outcome_direction = "higher_is_better",
    minimum_practical_effect = 0,
    minimum_follow_up_days = NA_real_
  )
  for (nm in names(optional_defaults)) {
    if (!nm %in% names(x)) x[[nm]] <- rep(optional_defaults[[nm]], nrow(x))
  }
  x |>
    dplyr::mutate(
      county_fips = v3_normalize_fips5(county_fips),
      naics2 = v3_normalize_naics2(naics2),
      start_date = as.Date(start_date),
      preregistered_date = as.Date(preregistered_date),
      preregistered_before_start = !is.na(preregistered_date) & !is.na(start_date) & preregistered_date <= start_date,
      primary_outcome = trimws(as.character(primary_outcome)),
      primary_outcome = dplyr::na_if(primary_outcome, ""),
      primary_outcome_direction = dplyr::case_when(
        tolower(trimws(as.character(primary_outcome_direction))) %in% c("lower", "lower_is_better", "decrease") ~ "lower_is_better",
        TRUE ~ "higher_is_better"
      ),
      minimum_practical_effect = dplyr::coalesce(v3_as_numeric(minimum_practical_effect), 0),
      minimum_follow_up_days = v3_as_numeric(minimum_follow_up_days),
      comparison_design = trimws(as.character(comparison_design)),
      comparison_design_pass = !is.na(comparison_design) & nzchar(comparison_design) &
        !tolower(comparison_design) %in% c("none", "no comparison", "uncontrolled", "not applicable", "na", "n/a"),
      dplyr::across(dplyr::any_of(c("human_oversight", "appeal_process", "incident_response", "worker_participation", "data_governance")), v3_as_binary),
      rmf_governance_coverage = rowMeans(dplyr::pick(dplyr::any_of(c("human_oversight", "appeal_process", "incident_response", "worker_participation", "data_governance"))), na.rm = TRUE),
      evidence_status = "OBSERVED"
    )
}

v3_read_pilot_measurements <- function(paths = v3_paths()) {
  path <- file.path(paths$inputs, "pilot_measurements_v3.csv")
  if (!file.exists(path)) path <- file.path(paths$inputs, "pilot_measurements_v3_template.csv")
  x <- v3_drop_example_rows(v3_read_csv(path))
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(x)
  v3_require_columns(x, c("pilot_id", "unit_id", "group", "measurement_date", "days_since_start", "outcome_name", "outcome_family", "value"), "Pilot measurements")
  x |>
    dplyr::mutate(
      measurement_date = as.Date(measurement_date),
      days_since_start = v3_as_numeric(days_since_start),
      value = v3_as_numeric(value),
      denominator = v3_as_numeric(denominator),
      worker_count = v3_as_numeric(worker_count),
      customer_count = v3_as_numeric(customer_count),
      severe_incident_count = dplyr::coalesce(v3_as_numeric(severe_incident_count), 0),
      unresolved_appeal_count = dplyr::coalesce(v3_as_numeric(unresolved_appeal_count), 0),
      group = tolower(trimws(as.character(group))),
      post = as.integer(days_since_start >= 0),
      treatment = as.integer(group %in% c("treatment", "pilot", "intervention"))
    )
}

v3_read_aria_results <- function(paths = v3_paths()) {
  path <- file.path(paths$inputs, "aria_test_results.csv")
  if (!file.exists(path)) path <- file.path(paths$inputs, "aria_test_results_template.csv")
  x <- v3_drop_example_rows(v3_read_csv(path))
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(x)
  v3_require_columns(x, c("pilot_id", "evaluation_level", "observed_value", "pass"), "ARIA test results")
  x |>
    dplyr::mutate(
      test_date = suppressWarnings(as.Date(test_date)),
      observed_value = v3_as_numeric(observed_value),
      threshold = v3_as_numeric(threshold),
      pass = v3_as_binary(pass),
      evaluation_level = trimws(as.character(evaluation_level)),
      severity = tolower(trimws(as.character(severity))),
      remediation_status = tolower(trimws(as.character(remediation_status)))
    )
}

v3_pilot_did_one <- function(x) {
  x <- x |>
    dplyr::filter(is.finite(value), treatment %in% c(0, 1), post %in% c(0, 1))
  if (dplyr::n_distinct(x$treatment) < 2L || dplyr::n_distinct(x$post) < 2L || nrow(x) < 8L) {
    return(tibble::tibble(
      estimate = NA_real_, standard_error = NA_real_, lower = NA_real_, upper = NA_real_,
      p_value = NA_real_, model = "insufficient_comparison_data", observations = nrow(x)
    ))
  }
  fit <- stats::lm(value ~ treatment + post + treatment:post, data = x,
                   weights = ifelse(is.finite(denominator) & denominator > 0, denominator, 1))
  co <- summary(fit)$coefficients
  term <- "treatment:post"
  if (!term %in% rownames(co)) return(tibble::tibble(estimate = NA_real_, standard_error = NA_real_, lower = NA_real_, upper = NA_real_, p_value = NA_real_, model = "did_term_missing", observations = nrow(x)))
  est <- co[term, "Estimate"]; se <- co[term, "Std. Error"]
  tibble::tibble(
    estimate = est,
    standard_error = se,
    lower = est - 1.96 * se,
    upper = est + 1.96 * se,
    p_value = co[term, "Pr(>|t|)"],
    model = "difference_in_differences",
    observations = nrow(x)
  )
}

v3_evaluate_pilots <- function(registry, measurements) {
  if (!nrow(registry)) return(list(estimates = tibble::tibble(), checkpoints = tibble::tibble()))
  estimates <- if (nrow(measurements)) measurements |>
    dplyr::group_by(pilot_id, outcome_name, outcome_family) |>
    dplyr::group_modify(~v3_pilot_did_one(.x)) |>
    dplyr::ungroup() else tibble::tibble()
  checkpoints <- if (nrow(measurements)) measurements |>
    dplyr::mutate(
      checkpoint_day = dplyr::case_when(
        days_since_start >= 180 ~ 180,
        days_since_start >= 90 ~ 90,
        days_since_start >= 30 ~ 30,
        TRUE ~ NA_real_
      )
    ) |>
    dplyr::filter(!is.na(checkpoint_day)) |>
    dplyr::group_by(pilot_id, checkpoint_day, outcome_name, outcome_family, group) |>
    dplyr::summarise(
      value = v3_weighted_mean(value, dplyr::coalesce(denominator, 1)),
      observations = dplyr::n(),
      worker_count = sum(worker_count, na.rm = TRUE),
      customer_count = sum(customer_count, na.rm = TRUE),
      severe_incident_count = sum(severe_incident_count, na.rm = TRUE),
      unresolved_appeal_count = sum(unresolved_appeal_count, na.rm = TRUE),
      .groups = "drop"
    ) else tibble::tibble()
  list(estimates = estimates, checkpoints = checkpoints)
}

v3_aria_summary <- function(aria, paths = v3_paths()) {
  levels <- v3_read_csv(file.path(paths$config, "v3_aria_evaluation_levels.csv"), required = TRUE)
  if (!nrow(aria)) return(tidyr::crossing(pilot_id = character(), levels))
  aria |>
    dplyr::group_by(pilot_id, evaluation_level) |>
    dplyr::summarise(
      tests = dplyr::n(),
      pass_rate = mean(pass, na.rm = TRUE),
      high_severity_failures = sum(pass == 0 & severity %in% c("high", "critical", "severe"), na.rm = TRUE),
      open_remediations = sum(!remediation_status %in% c("closed", "resolved", "complete"), na.rm = TRUE),
      .groups = "drop"
    ) |>
    dplyr::left_join(levels, by = c("evaluation_level" = "level_name")) |>
    dplyr::mutate(level_pass = pass_rate >= minimum_pass_rate & high_severity_failures == 0)
}

v3_pilot_metric_wide <- function(measurements) {
  if (!nrow(measurements)) return(tibble::tibble())
  latest <- measurements |>
    dplyr::filter(post == 1, treatment == 1) |>
    dplyr::group_by(pilot_id, outcome_name) |>
    dplyr::slice_max(days_since_start, n = 1, with_ties = FALSE) |>
    dplyr::ungroup() |>
    dplyr::select(pilot_id, outcome_name, value)
  tidyr::pivot_wider(latest, names_from = outcome_name, values_from = value)
}

v3_read_pilot_decision_rules <- function(paths = v3_paths()) {
  x <- v3_read_csv(file.path(paths$config, "v3_pilot_decision_rules.csv"), required = TRUE)
  v3_require_columns(x, c("priority", "decision", "condition_id", "operator", "threshold", "measure"), "Pilot decision rules")
  x |>
    dplyr::mutate(
      priority = as.integer(v3_as_numeric(priority)),
      decision = toupper(trimws(as.character(decision))),
      condition_id = trimws(as.character(condition_id)),
      operator = trimws(as.character(operator)),
      threshold = v3_as_numeric(threshold),
      measure = trimws(as.character(measure))
    ) |>
    dplyr::arrange(priority, condition_id)
}

v3_pilot_rule_threshold <- function(rules, condition_id, default = NA_real_) {
  hit <- rules |> dplyr::filter(.data$condition_id == !!condition_id)
  if (!nrow(hit) || !is.finite(hit$threshold[[1]])) return(default)
  as.numeric(hit$threshold[[1]])
}

v3_primary_pilot_effects <- function(registry, estimates) {
  base <- registry |>
    dplyr::select(
      pilot_id, primary_outcome, primary_outcome_direction,
      minimum_practical_effect, comparison_design_pass
    )
  if (!nrow(estimates)) {
    return(base |>
      dplyr::mutate(
        primary_effect = NA_real_, primary_effect_lower = NA_real_, primary_effect_upper = NA_real_,
        primary_effect_p_value = NA_real_, primary_effect_observations = NA_real_,
        primary_effect_model = NA_character_, primary_effect_available = FALSE,
        primary_effect_pass = FALSE
      ))
  }
  e <- estimates |>
    dplyr::select(
      pilot_id, outcome_name, estimate, lower, upper, p_value, observations, model
    )
  out <- base |>
    dplyr::left_join(e, by = c("pilot_id", "primary_outcome" = "outcome_name")) |>
    dplyr::mutate(
      primary_effect = v3_as_numeric(estimate),
      primary_effect_lower = v3_as_numeric(lower),
      primary_effect_upper = v3_as_numeric(upper),
      primary_effect_p_value = v3_as_numeric(p_value),
      primary_effect_observations = v3_as_numeric(observations),
      primary_effect_model = as.character(model),
      primary_effect_available = dplyr::coalesce(
        !is.na(primary_outcome) & is.finite(primary_effect) &
          primary_effect_model == "difference_in_differences",
        FALSE
      ),
      primary_effect_pass = dplyr::case_when(
        !primary_effect_available ~ FALSE,
        primary_outcome_direction == "lower_is_better" ~ primary_effect <= -abs(minimum_practical_effect),
        TRUE ~ primary_effect >= minimum_practical_effect
      )
    ) |>
    dplyr::select(-dplyr::any_of(c("estimate", "lower", "upper", "p_value", "observations", "model")))
  out
}

v3_decision_engine <- function(registry, measurements, aria_summary, estimates = tibble::tibble(), paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  if (!nrow(registry)) return(tibble::tibble())
  rules <- v3_read_pilot_decision_rules(paths)
  metrics <- v3_pilot_metric_wide(measurements)
  primary_effects <- v3_primary_pilot_effects(registry, estimates)
  incidents <- if (nrow(measurements)) measurements |>
    dplyr::group_by(pilot_id) |>
    dplyr::summarise(
      severe_incident_count = sum(severe_incident_count, na.rm = TRUE),
      unresolved_appeal_count = sum(unresolved_appeal_count, na.rm = TRUE),
      maximum_follow_up_days = if (all(is.na(days_since_start))) NA_real_ else max(days_since_start, na.rm = TRUE),
      treatment_post_observations = sum(treatment == 1 & post == 1, na.rm = TRUE),
      comparison_post_observations = sum(treatment == 0 & post == 1, na.rm = TRUE),
      .groups = "drop"
    ) else tibble::tibble(
      pilot_id = character(), severe_incident_count = numeric(), unresolved_appeal_count = numeric(),
      maximum_follow_up_days = numeric(), treatment_post_observations = numeric(), comparison_post_observations = numeric()
    )
  aria <- if (nrow(aria_summary)) aria_summary |>
    dplyr::group_by(pilot_id) |>
    dplyr::summarise(
      aria_levels_completed = dplyr::n_distinct(evaluation_level),
      aria_overall_pass_rate = mean(pass_rate, na.rm = TRUE),
      aria_model_testing_pass_rate = mean(pass_rate[grepl("model", evaluation_level, ignore.case = TRUE)], na.rm = TRUE),
      aria_red_teaming_pass_rate = mean(pass_rate[grepl("red", evaluation_level, ignore.case = TRUE)], na.rm = TRUE),
      aria_field_testing_pass_rate = mean(pass_rate[grepl("field", evaluation_level, ignore.case = TRUE)], na.rm = TRUE),
      aria_system_pass_rate = mean(pass_rate[grepl("system", evaluation_level, ignore.case = TRUE)], na.rm = TRUE),
      aria_high_severity_failures = sum(high_severity_failures, na.rm = TRUE),
      .groups = "drop"
    ) else tibble::tibble(pilot_id = character())
  # Guarantee the decision data contract even when a pilot has not yet reported every outcome.
  for (nm in c("quality_adjusted_productivity_ratio", "quality_ratio", "worker_benefit_index")) {
    if (!nm %in% names(metrics)) metrics[[nm]] <- NA_real_
  }
  for (nm in c("aria_levels_completed", "aria_overall_pass_rate", "aria_model_testing_pass_rate",
               "aria_red_teaming_pass_rate", "aria_field_testing_pass_rate", "aria_system_pass_rate",
               "aria_high_severity_failures")) {
    if (!nm %in% names(aria)) aria[[nm]] <- if (nm %in% c("aria_levels_completed", "aria_high_severity_failures")) 0 else NA_real_
  }
  severe_stop <- v3_pilot_rule_threshold(rules, "severe_incidents", cfg$pilots$severe_incident_stop_threshold %||% 1)
  appeal_suspend <- v3_pilot_rule_threshold(rules, "unresolved_appeals", cfg$pilots$unresolved_appeal_suspend_threshold %||% 1)
  quality_scale <- v3_pilot_rule_threshold(rules, "quality_ratio", cfg$pilots$minimum_quality_ratio_to_scale %||% 1)
  worker_scale <- v3_pilot_rule_threshold(rules, "worker_benefit", cfg$pilots$minimum_worker_benefit_to_scale %||% 0)
  productivity_scale <- v3_pilot_rule_threshold(rules, "productivity_ratio", cfg$pilots$minimum_productivity_ratio_to_scale %||% 1)
  field_pass <- v3_pilot_rule_threshold(rules, "aria_field_testing", cfg$pilots$minimum_aria_field_testing_pass_rate %||% 0.70)
  follow_up_scale <- v3_pilot_rule_threshold(rules, "minimum_follow_up", cfg$pilots$minimum_follow_up_days_to_scale %||% 180)
  min_did_observations <- v3_pilot_rule_threshold(rules, "minimum_did_observations", cfg$pilots$minimum_did_observations_to_scale %||% 8)
  x <- registry |>
    dplyr::left_join(metrics, by = "pilot_id") |>
    dplyr::left_join(incidents, by = "pilot_id") |>
    dplyr::left_join(aria, by = "pilot_id") |>
    dplyr::left_join(
      primary_effects |>
        dplyr::select(-dplyr::any_of(c("primary_outcome", "primary_outcome_direction", "minimum_practical_effect", "comparison_design_pass"))),
      by = "pilot_id"
    ) |>
    dplyr::mutate(
      severe_incident_count = dplyr::coalesce(severe_incident_count, 0),
      unresolved_appeal_count = dplyr::coalesce(unresolved_appeal_count, 0),
      maximum_follow_up_days = dplyr::coalesce(maximum_follow_up_days, 0),
      treatment_post_observations = dplyr::coalesce(treatment_post_observations, 0),
      comparison_post_observations = dplyr::coalesce(comparison_post_observations, 0),
      required_follow_up_days = dplyr::coalesce(minimum_follow_up_days, follow_up_scale),
      sufficient_follow_up = maximum_follow_up_days >= required_follow_up_days,
      sufficient_comparison_observations = comparison_design_pass &
        primary_effect_observations >= min_did_observations &
        treatment_post_observations > 0 & comparison_post_observations > 0,
      quality_adjusted_productivity_ratio = dplyr::coalesce(quality_adjusted_productivity_ratio, NA_real_),
      quality_ratio = dplyr::coalesce(quality_ratio, NA_real_),
      worker_benefit_index = dplyr::coalesce(worker_benefit_index, NA_real_),
      scale_evidence_complete = preregistered_before_start & comparison_design_pass &
        sufficient_follow_up & sufficient_comparison_observations & primary_effect_available &
        is.finite(quality_ratio) & is.finite(worker_benefit_index) &
        is.finite(quality_adjusted_productivity_ratio) &
        is.finite(aria_field_testing_pass_rate),
      decision = dplyr::case_when(
        severe_incident_count >= severe_stop | dplyr::coalesce(aria_high_severity_failures, 0) >= 1 ~ "STOP",
        unresolved_appeal_count >= appeal_suspend ~ "SUSPEND",
        !is.na(aria_field_testing_pass_rate) & aria_field_testing_pass_rate < field_pass ~ "SUSPEND",
        !preregistered_before_start ~ "REDESIGN",
        !comparison_design_pass ~ "REDESIGN",
        !is.na(quality_ratio) & quality_ratio < quality_scale ~ "REDESIGN",
        !is.na(worker_benefit_index) & worker_benefit_index < worker_scale ~ "REDESIGN",
        !is.na(quality_adjusted_productivity_ratio) & quality_adjusted_productivity_ratio < productivity_scale ~ "REDESIGN",
        sufficient_follow_up & primary_effect_available & !primary_effect_pass ~ "REDESIGN",
        !sufficient_follow_up | !primary_effect_available | !sufficient_comparison_observations ~ "CONTINUE MEASUREMENT",
        scale_evidence_complete & primary_effect_pass & quality_ratio >= quality_scale &
          worker_benefit_index >= worker_scale & quality_adjusted_productivity_ratio >= productivity_scale &
          aria_field_testing_pass_rate >= field_pass ~ "SCALE",
        TRUE ~ "CONTINUE MEASUREMENT"
      ),
      decision_reason = dplyr::case_when(
        decision == "STOP" ~ "Predetermined severe-incident or high-severity assurance stop rule was triggered",
        decision == "SUSPEND" ~ "Unresolved appeal or insufficient ARIA-style field-testing assurance requires remediation and independent review",
        decision == "REDESIGN" & !preregistered_before_start ~ "Pilot outcomes were not preregistered before implementation",
        decision == "REDESIGN" & !comparison_design_pass ~ "No acceptable comparison design was documented",
        decision == "REDESIGN" & primary_effect_available & !primary_effect_pass ~ "Preregistered primary outcome did not meet the minimum practical effect",
        decision == "REDESIGN" ~ "At least one predetermined quality, worker-benefit, or quality-adjusted productivity threshold was not met",
        decision == "SCALE" ~ "Preregistration, comparison evidence, primary effect, follow-up, quality, worker-benefit, productivity, and field-testing thresholds were met",
        !sufficient_follow_up ~ "Minimum follow-up period has not been reached",
        !primary_effect_available ~ "Preregistered primary-outcome causal estimate is unavailable",
        !sufficient_comparison_observations ~ "Comparison evidence is not yet sufficient for a scale decision",
        TRUE ~ "Evidence remains incomplete at the current checkpoint"
      ),
      evidence_status = "OBSERVED",
      reliability_class = dplyr::case_when(
        decision %in% c("STOP", "SUSPEND") & severe_incident_count > 0 ~ "A",
        scale_evidence_complete & preregistered_before_start & dplyr::coalesce(aria_levels_completed, 0) >= 3 ~ "A",
        preregistered_before_start & comparison_design_pass ~ "B",
        TRUE ~ "C"
      )
    )
  x
}

apply_methodology_v3_pilots <- function(paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  registry <- v3_read_pilot_registry(paths)
  measurements <- v3_read_pilot_measurements(paths)
  aria <- v3_read_aria_results(paths)
  eval <- v3_evaluate_pilots(registry, measurements)
  aria_summary <- v3_aria_summary(aria, paths)
  decisions <- v3_decision_engine(registry, measurements, aria_summary, eval$estimates, paths, cfg)
  status <- tibble::tibble(
    module = "causal_pilots_and_system_evaluation",
    pilots = nrow(registry),
    measurement_rows = nrow(measurements),
    did_estimates = nrow(eval$estimates),
    aria_tests = nrow(aria),
    decisions = nrow(decisions),
    evidence_status = if (nrow(registry)) "OBSERVED" else "UNAVAILABLE",
    note = if (nrow(registry))
      "Decisions use preregistered stop, suspend, redesign, continue-measurement, and scale rules plus ARIA-style model, red-team, field, and system-level evidence."
    else
      "No pilot registry was supplied; no claims are made about realized productivity, safety, or pro-worker outcomes."
  )
  v3_write_csv(eval$estimates, file.path(paths$processed, "pilot_difference_in_differences.csv"))
  v3_write_csv(eval$checkpoints, file.path(paths$processed, "pilot_30_90_180_day_scorecard.csv"))
  v3_write_csv(aria_summary, file.path(paths$processed, "aria_assurance_summary.csv"))
  v3_write_csv(decisions, file.path(paths$processed, "pilot_decision_rules_results.csv"))
  v3_write_csv(v3_read_pilot_decision_rules(paths), file.path(paths$outputs, "pilot_decision_rules_applied_v3.csv"))
  v3_write_csv(status, file.path(paths$outputs, "pilot_assurance_status_v3.csv"))
  list(registry = registry, measurements = measurements, estimates = eval$estimates, checkpoints = eval$checkpoints, aria = aria_summary, decisions = decisions, status = status)
}
