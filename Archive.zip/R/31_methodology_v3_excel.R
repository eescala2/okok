# Methodology v3 editable Excel workbook (Office DrawingML)

v3_excel_packages <- function(install_missing = TRUE) {
  pkgs <- c("openxlsx2", "rvg", "systemfonts", "gdtools", "officer")
  if (install_missing) v3_install_packages(pkgs, required = TRUE)
  missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) stop("Editable Methodology v3 workbook requires: ", paste(missing, collapse = ", "), call. = FALSE)
  if (package_version(as.character(getNamespaceVersion("openxlsx2"))) < package_version("1.26.0")) stop("openxlsx2 >= 1.26.0 is required for editable DrawingML insertion.", call. = FALSE)
  invisible(TRUE)
}

v3_excel_sheet_name <- function(x, used = character()) {
  x <- gsub("[^A-Za-z0-9 _.-]", "_", as.character(x))
  x <- trimws(gsub("\\s+", " ", x))
  if (!nzchar(x)) x <- "Sheet"
  base <- substr(x, 1, 31); out <- base; i <- 1L
  while (tolower(out) %in% tolower(used)) {
    suffix <- paste0("_", i); out <- paste0(substr(base, 1, 31 - nchar(suffix)), suffix); i <- i + 1L
  }
  out
}

v3_excel_color <- function(hex) {
  z <- gsub("#", "", hex); if (nchar(z) == 6L) z <- paste0("FF", z)
  openxlsx2::wb_color(hex = z)
}

v3_excel_clean_data <- function(x, max_rows = 250000L) {
  if (is.null(x)) return(tibble::tibble())
  if (inherits(x, "sf")) x <- sf::st_drop_geometry(x)
  x <- as.data.frame(x, stringsAsFactors = FALSE)
  for (nm in names(x)) {
    if (inherits(x[[nm]], c("Date", "POSIXct", "POSIXlt"))) x[[nm]] <- as.character(x[[nm]])
    if (is.list(x[[nm]])) x[[nm]] <- vapply(x[[nm]], function(z) paste(z, collapse = "; "), character(1))
  }
  if (nrow(x) > max_rows) x <- x[seq_len(max_rows), , drop = FALSE]
  tibble::as_tibble(x)
}

v3_excel_style_header <- function(wb, sheet, dims) {
  try(wb$add_fill(sheet = sheet, dims = dims, color = v3_excel_color("#1C5DBA")), silent = TRUE)
  try(wb$add_font(sheet = sheet, dims = dims, name = "Arial", size = "10", bold = "1", color = v3_excel_color("#FFFFFF")), silent = TRUE)
  try(wb$add_cell_style(sheet = sheet, dims = dims, horizontal = "center", vertical = "center", wrap_text = TRUE), silent = TRUE)
  invisible(wb)
}

v3_excel_add_data_sheet <- function(wb, name, data, used, description = NULL) {
  sheet <- v3_excel_sheet_name(name, used); used <- c(used, sheet)
  wb$add_worksheet(sheet)
  row <- 1L
  if (!is.null(description)) {
    wb$add_data(sheet, data.frame(description = description), start_row = row, start_col = 1, col_names = FALSE)
    try(wb$add_font(sheet = sheet, dims = "A1", name = "Arial", size = "11", color = v3_excel_color("#000000")), silent = TRUE)
    row <- 3L
  }
  data <- v3_excel_clean_data(data)
  if (ncol(data)) {
    table_name <- substr(gsub("[^A-Za-z0-9_]", "_", paste0("tbl_", sheet)), 1, 240)
    tryCatch(
      wb$add_data_table(sheet = sheet, x = data, start_row = row, start_col = 1, table_name = table_name, with_filter = TRUE),
      error = function(e) wb$add_data(sheet = sheet, x = data, start_row = row, start_col = 1, with_filter = TRUE)
    )
    v3_excel_style_header(wb, sheet, openxlsx2::wb_dims(rows = row, cols = seq_len(ncol(data))))
    try(wb$freeze_pane(sheet = sheet, first_row = TRUE), silent = TRUE)
    try(wb$set_col_widths(sheet = sheet, cols = seq_len(min(ncol(data), 35L)), widths = "auto"), silent = TRUE)
    try(wb$add_cell_style(sheet = sheet, dims = openxlsx2::wb_dims(rows = row:(row + min(nrow(data), 500L)), cols = seq_len(ncol(data))), wrap_text = TRUE, vertical = "top"), silent = TRUE)
  } else {
    wb$add_data(sheet, data.frame(note = "No data available for this module in the current run."), start_row = row, start_col = 1)
  }
  list(wb = wb, used = used, sheet = sheet)
}

v3_excel_render_dml <- function(plot, width = 13, height = 8) {
  tmp <- tempfile(fileext = ".xml")
  rvg::dml_xlsx(
    file = tmp, width = width, height = height, bg = "transparent",
    fonts = list(sans = "Arial", serif = "Arial", mono = "Courier New"),
    pointsize = 10, editable = TRUE, standalone = TRUE
  )
  on.exit(if (grDevices::dev.cur() > 1L) try(grDevices::dev.off(), silent = TRUE), add = TRUE)
  print(plot)
  grDevices::dev.off()
  tmp
}

v3_excel_add_figure <- function(wb, used, id, title, audience, plot, png_path, data_sheets) {
  sheet <- v3_excel_sheet_name(paste0("Fig_", id, "_", substr(gsub("[^A-Za-z0-9]", "_", title), 1, 18)), used)
  used <- c(used, sheet); wb$add_worksheet(sheet)
  wb$add_data(sheet, data.frame(title = paste0("Figure ", id, ". ", title)), start_row = 1, start_col = 1, col_names = FALSE)
  try(wb$merge_cells(sheet = sheet, dims = "A1:M1"), silent = TRUE)
  try(wb$add_font(sheet = sheet, dims = "A1", name = "Arial", size = "12", bold = "1", color = v3_excel_color("#000000")), silent = TRUE)
  try(wb$add_cell_style(sheet = sheet, dims = "A1", horizontal = "center", vertical = "center", wrap_text = TRUE), silent = TRUE)
  meta <- data.frame(
    field = c("Primary audience", "How to edit", "Source data sheets", "PNG reference"),
    value = c(
      audience,
      "Select the drawing, right-click, and choose Group > Ungroup if needed. Text, fills, lines, legends, and labels can then be edited manually. Changing source cells does not automatically redraw the vector.",
      paste(data_sheets, collapse = ", "),
      normalizePath(png_path, winslash = "/", mustWork = FALSE)
    )
  )
  wb$add_data(sheet, meta, start_row = 3, start_col = 1, col_names = TRUE)
  v3_excel_style_header(wb, sheet, "A3:B3")
  try(wb$add_cell_style(sheet = sheet, dims = "A3:B7", wrap_text = TRUE, vertical = "top"), silent = TRUE)
  xml <- v3_excel_render_dml(plot)
  wb$add_drawing(sheet = sheet, dims = "A9", xml = xml)
  try(wb$set_col_widths(sheet = sheet, cols = 1:13, widths = c(18, rep(14, 12))), silent = TRUE)
  list(wb = wb, used = used, sheet = sheet, status = "created_editable_drawing")
}

v3_excel_source_tables <- function(run, paths = v3_paths()) {
  files <- list.files(c(paths$processed, paths$outputs), pattern = "(?i)\\.csv$", recursive = TRUE, full.names = TRUE)
  files <- files[file.exists(files)]
  out <- list()
  for (f in files) {
    key <- paste0("Data_", substr(gsub("[^A-Za-z0-9]", "_", tools::file_path_sans_ext(basename(f))), 1, 24))
    if (key %in% names(out)) key <- paste0(key, "_", length(out) + 1L)
    out[[key]] <- tryCatch(v3_read_csv(f), error = function(e) tibble::tibble())
  }
  out
}

make_methodology_v3_editable_excel <- function(run = NULL, install_missing = TRUE, paths = v3_paths()) {
  v3_excel_packages(install_missing)
  if (is.null(run)) {
    run <- list(atlas = v3_read_v2_atlas(paths$root), results = v3_load_results(paths))
  }
  figures <- make_methodology_v3_figures(run$results, run$atlas, paths, return_plots = TRUE)
  manifest <- figures$manifest
  wb <- openxlsx2::wb_workbook(); used <- character()

  readme <- v3_excel_sheet_name("00_READ_ME", used); used <- c(used, readme); wb$add_worksheet(readme)
  info <- data.frame(
    field = c("Purpose", "Methodology", "Editing", "Data linkage limitation", "Evidence principle", "Created"),
    value = c(
      "Editable Office-vector versions of every Methodology v3 figure, with source data sheets.",
      "Methodology v3 adds observed adoption, worker outcomes, early-career safeguards, constrained transitions, industrial readiness, causal pilots, assurance, and regional value capture while preserving Methodology v2 outputs.",
      "Select a Fig_* drawing and ungroup it in Excel to edit text, colors, fonts, shapes, legends, and lines.",
      "DrawingML figures are manually editable but are not native data-linked Excel charts. Rerun the project to regenerate them from changed source data.",
      "Exposure is not adoption; adoption is not productivity; and productivity is not automatically pro-worker.",
      format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")
    )
  )
  wb$add_data_table(readme, info, start_row = 1, start_col = 1, table_name = "MethodologyV3ReadMe", with_filter = FALSE)
  v3_excel_style_header(wb, readme, "A1:B1")
  try(wb$set_col_widths(sheet = readme, cols = c(1, 2), widths = c(28, 110)), silent = TRUE)
  try(wb$add_cell_style(sheet = readme, dims = "A1:B20", wrap_text = TRUE, vertical = "top"), silent = TRUE)

  tables <- v3_excel_source_tables(run, paths)
  message('  Editable v3 workbook: writing ', length(tables), ' source-data sheets.')
  data_sheets <- character()
  for (nm in names(tables)) {
    z <- v3_excel_add_data_sheet(wb, nm, tables[[nm]], used, paste0("Methodology v3 source/output table: ", nm))
    wb <- z$wb; used <- z$used; data_sheets <- c(data_sheets, z$sheet)
  }

  rows <- list()
  plot_lookup <- figures$plots
  for (i in seq_len(nrow(manifest))) {
    message('  Editable v3 figure ', i, '/', nrow(manifest), ': ', manifest$id[[i]], ' - ', manifest$title[[i]])
    file <- manifest$filename[[i]]; plot <- plot_lookup[[file]]
    if (is.null(plot)) next
    z <- v3_excel_add_figure(
      wb, used, as.character(manifest$id[[i]]), manifest$title[[i]], manifest$audience[[i]],
      plot, manifest$path[[i]], data_sheets
    )
    wb <- z$wb; used <- z$used
    rows[[length(rows) + 1L]] <- tibble::tibble(
      id = as.character(manifest$id[[i]]), title = manifest$title[[i]], sheet = z$sheet,
      status = z$status, png = manifest$path[[i]], source_data_sheets = paste(data_sheets, collapse = ", ")
    )
  }
  index <- dplyr::bind_rows(rows)
  z <- v3_excel_add_data_sheet(wb, "Figure_Index", index, used, "Index of editable Methodology v3 drawings.")
  wb <- z$wb
  output <- file.path(paths$root, "outputs", "iowa_ai_workforce_atlas_methodology_v3_editable_figures.xlsx")
  message('  Editable v3 workbook: saving XLSX package (this can take several minutes).')
  atlas_save_workbook_validated(
    wb,
    output,
    minimum_drawings = 13L,
    label = 'Editable Methodology v3 workbook'
  )
  v3_write_csv(index, file.path(paths$outputs, "editable_excel_figure_manifest_v3.csv"))
  message("Wrote Methodology v3 editable Excel workbook: ", normalizePath(output, winslash = "/", mustWork = FALSE))
  output
}
