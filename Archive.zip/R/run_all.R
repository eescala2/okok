
# Complete Iowa AI Workforce Atlas Methodology v3 runner
# Runs the preserved Methodology v2 workflow first, then adds the v3 evidence system.

.v3_runner_root <- function() {
  wd <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
  ofile <- tryCatch({
    f <- sys.frames(); z <- vapply(f, function(e) as.character(e$ofile %||% NA_character_), character(1));
    z <- stats::na.omit(z); if (length(z)) z[[length(z)]] else NA_character_
  }, error = function(e) NA_character_)
  candidates <- unique(stats::na.omit(c(
    wd, dirname(wd),
    if (!is.na(ofile)) dirname(normalizePath(ofile, winslash = "/", mustWork = FALSE)) else NA_character_,
    if (!is.na(ofile)) dirname(dirname(normalizePath(ofile, winslash = "/", mustWork = FALSE))) else NA_character_
  )))
  for (p in candidates) {
    if (dir.exists(file.path(p, "R")) && file.exists(file.path(p, "config", "methodology_v3.yml"))) return(p)
  }
  stop("Could not locate the Methodology v3 project root.", call. = FALSE)
}

`%||%` <- function(x, y) if (is.null(x) || length(x) == 0L || all(is.na(x))) y else x
.root_v3 <- .v3_runner_root()
.old_wd_v3 <- getwd(); on.exit(setwd(.old_wd_v3), add = TRUE); setwd(.root_v3)

# Preserve exact Methodology v2 functionality unless explicitly skipped.
.skip_v2 <- tolower(Sys.getenv("IA_ATLAS_V3_SKIP_V2", unset = "false")) %in% c("1", "true", "yes", "y")
.v2_runner <- file.path("R", "run_all_v2.R")
if (!.skip_v2) {
  if (!file.exists(.v2_runner)) {
    stop(
      "The Methodology v2 runner backup R/run_all_v2.R is missing. The maintained Methodology v2 runner R/run_all_v2.R is missing. Re-extract the clean distribution, or set IA_ATLAS_V3_SKIP_V2=true only when completed v2 outputs already exist.",
      call. = FALSE
    )
  }
  message("Stage A: running the preserved Methodology v2 workflow and deliverables.")
  sys.source(.v2_runner, envir = globalenv())
} else {
  message("Stage A: skipping the preserved v2 runner because IA_ATLAS_V3_SKIP_V2=true. Existing v2 outputs will be reused.")
}

.v3_scripts <- c(
  "20_methodology_v3_setup.R",
  "21_methodology_v3_public_data.R",
  "22_methodology_v3_adoption_nowcast.R",
  "23_methodology_v3_worker_outcomes.R",
  "24_methodology_v3_early_career.R",
  "25_methodology_v3_feasible_transitions.R",
  "26_methodology_v3_industrial_readiness.R",
  "27_methodology_v3_pilots_assurance.R",
  "28_methodology_v3_value_capture.R",
  "29_methodology_v3_visualizations.R",
  "30_methodology_v3_render.R",
  "31_methodology_v3_excel.R",
  "32_methodology_v3_validate.R",
  "33_methodology_v3_apply.R",
  "34_methodology_v3_provenance.R"
)
for (.s in .v3_scripts) {
  .path <- file.path("R", .s)
  if (!file.exists(.path)) stop("Missing Methodology v3 script: ", .path, call. = FALSE)
  source(.path)
}

v3_setup_packages(install_optional = FALSE)
.paths_v3 <- v3_paths(); v3_ensure_directories(.paths_v3)
.cfg_v3 <- v3_load_config(.paths_v3$root)
.refresh_setting <- tolower(trimws(Sys.getenv("IA_ATLAS_V3_REFRESH", unset = .cfg_v3$refresh_policy %||% "auto")))
.refresh_v3 <- switch(
  .refresh_setting,
  always = TRUE, true = TRUE, yes = TRUE,
  never = FALSE, false = FALSE, no = FALSE,
  auto = {
    status_file <- file.path(.paths_v3$outputs, "public_data_status_v3.csv")
    if (!file.exists(status_file)) TRUE else {
      age_days <- as.numeric(difftime(Sys.time(), file.info(status_file)$mtime, units = "days"))
      is.finite(age_days) && age_days > 14
    }
  },
  FALSE
)
message("Methodology v3 refresh policy resolved to refresh = ", .refresh_v3, ".")

# IA_ATLAS_V3_OUTPUT_QUALITY_V304_SOURCE
source(file.path("R", "37_methodology_v3_output_quality.R"))
# IA_ATLAS_V3_PDF_WATCHDOG_V306_SOURCE
source(file.path("R", "38_methodology_v3_pdf_watchdog.R"))
message("V3 Step 1/7: acquiring and normalizing public inputs, then applying all twelve evidence extensions.")
.run_v3 <- apply_methodology_v3(refresh = .refresh_v3, paths = .paths_v3, cfg = .cfg_v3)

message("V3 Step 2/7: writing source provenance, snapshots, evidence gaps, package versions, model card, and changelog.")
write_methodology_v3_provenance(.run_v3, .paths_v3)

message("V3 Step 3/7: creating 13 Methodology v3 public and policy figures.")
make_methodology_v3_figures(.run_v3$results, .run_v3$atlas, .paths_v3, return_plots = FALSE)

# IA_ATLAS_V3_OUTPUT_QUALITY_V304_FIGURES
v3_harden_methodology_v3_figures(paths = .paths_v3)
message("V3 Step 4/7: rendering Methodology v3 Quarto and R Markdown HTML reports.")
.html_v3 <- render_methodology_v3_reports(quiet = FALSE, paths = .paths_v3)

message("V3 Step 5/7: creating accessible-attempt Methodology v3 PDFs and the all-figures compendium.")
# IA_ATLAS_V3_PDF_WATCHDOG_V306_STAGE
v3_run_methodology_v3_pdf_stage(paths = .paths_v3, force = TRUE)
message("V3 Step 6/7: creating the editable Excel workbook for all Methodology v3 figures.")
make_methodology_v3_editable_excel(.run_v3, install_missing = TRUE, paths = .paths_v3)

message("V3 Step 7/7: validating the complete Methodology v3 output contract.")
validate_methodology_v3_outputs(.paths_v3, stop_on_missing = TRUE)

# IA_ATLAS_V3_OUTPUT_QUALITY_V304_VALIDATE
v3_validate_methodology_v3_output_quality(paths = .paths_v3)
message(
  "Methodology v3 completed. Existing Methodology v2 deliverables were retained. See outputs/methodology_v3/, figures/methodology_v3/, outputs/atlas_methodology_v3_*.html/.pdf, and outputs/iowa_ai_workforce_atlas_methodology_v3_editable_figures.xlsx."
)
