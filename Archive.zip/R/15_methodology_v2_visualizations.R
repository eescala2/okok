# 15_methodology_v2_visualizations.R --------------------------------------
# Ten public-facing diagnostics added by Methodology v2. These make the
# uncertainty, threshold sensitivity, actionable minority, data reliability,
# training capacity, physical-AI channel, adoption separation, skill pathways,
# and reconciliation results visible rather than burying them in code.

source(file.path(project_root(), 'R', '00_setup.R'))
source(file.path(project_root(), 'R', '10_iowa_report_style.R'))
source(file.path(project_root(), 'R', '07_public_visualizations.R'))
source(file.path(project_root(), 'R', '13_methodology_v2.R'))

safe_v2_csv <- function(name) {
  f <- file.path(paths()$processed, name)
  if (!file.exists(f)) return(tibble::tibble())
  readr::read_csv(f, show_col_types = FALSE, progress = FALSE)
}

get_methodology_v2_viz_data <- function(build_if_missing = TRUE, refresh = FALSE) {
  p <- paths()
  if ((!file.exists(file.path(p$processed, 'county_summary_v2.csv')) ||
       !compat_table_exists('county_industry_occupation_atlas_v2', p$processed)) && isTRUE(build_if_missing)) {
    apply_methodology_v2(refresh = refresh, overwrite_primary_outputs = TRUE)
  }
  public <- get_public_viz_data(build_if_missing = build_if_missing, refresh = refresh)
  list(
    public = public,
    county = safe_v2_csv('county_summary_v2.csv'),
    lwda = safe_v2_csv('lwda_summary_v2.csv'),
    sector = safe_v2_csv('sector_lwda_summary_v2.csv'),
    training = safe_v2_csv('training_priority_occupations_v2.csv'),
    capacity = safe_v2_csv('training_capacity_index_v2.csv'),
    sensitivity = safe_v2_csv('county_action_sensitivity_v2.csv'),
    thresholds = safe_v2_csv('action_threshold_values_v2.csv'),
    weight_sensitivity = safe_v2_csv('score_weight_sensitivity_v2.csv'),
    skill_paths = safe_v2_csv('occupation_skill_transition_paths_v2.csv'),
    adoption = safe_v2_csv('sector_observed_adoption_v2.csv'),
    adoption_sources = safe_v2_csv('sector_observed_adoption_sources_v2.csv'),
    adoption_status = safe_v2_csv('observed_adoption_status_v2.csv'),
    reconciliation = safe_read_csv(file.path(p$outputs, 'methodology_v2', 'reconciliation_tests.csv')),
    provenance = safe_read_csv(file.path(p$outputs, 'methodology_v2', 'source_provenance.csv')),
    configuration = safe_read_csv(file.path(p$outputs, 'methodology_v2', 'configuration_provenance.csv'))
  )
}

methodology_v2_reliability_palette <- c(A = atlas_brand()$blue, B = atlas_brand()$gold, C = atlas_brand()$red)

plot_m27_county_actionable_share <- function(data) {
  if (is.null(data$public$shapes) || !nrow(data$county)) return(NULL)
  map <- data$public$shapes |>
    dplyr::left_join(data$county |> dplyr::mutate(county_fips = as_fips5(county_fips)), by = 'county_fips')
  ggplot2::ggplot(map) +
    ggplot2::geom_sf(ggplot2::aes(fill = actionable_share), color = 'white', linewidth = 0.18) +
    ggplot2::scale_fill_gradientn(colours = c('#E9F1FB', atlas_brand()$green, atlas_brand()$blue), labels = atlas_axis_percent(accuracy = 1), na.value = 'grey90') +
    ggplot2::labs(title = 'Share of estimated jobs requiring an active AI-transition response', subtitle = 'Unlike the dominant-action map, this map preserves actionable minorities inside each county.', fill = 'Actionable share', caption = 'Actionable means Protect and redesign, Upgrade through AI-complementary training, or Scale pro-worker AI opportunity.') +
    atlas_void_theme(base_size = 10, strip_titles = FALSE) +
    ggplot2::theme(legend.position = 'right')
}

plot_m28_county_largest_nonmonitor <- function(data) {
  if (is.null(data$public$shapes) || !nrow(data$county)) return(NULL)
  map <- data$public$shapes |>
    dplyr::left_join(data$county |> dplyr::mutate(county_fips = as_fips5(county_fips)), by = 'county_fips')
  ggplot2::ggplot(map) +
    ggplot2::geom_sf(ggplot2::aes(fill = largest_non_monitor_action), color = 'white', linewidth = 0.18) +
    ggplot2::scale_fill_manual(values = atlas_transition_palette(), na.value = 'grey90') +
    ggplot2::labs(title = 'Largest non-Monitor AI workforce action by county', subtitle = 'The chart answers what leaders should prepare for even when Monitor remains the largest overall category.', fill = 'Largest active response', caption = 'Counties with no non-Monitor jobs are shown as Monitor.') +
    atlas_void_theme(base_size = 10, strip_titles = FALSE) +
    ggplot2::theme(legend.position = 'right')
}

plot_m29_lwda_uncertainty_intervals <- function(data) {
  if (!nrow(data$lwda)) return(NULL)
  specs <- tibble::tribble(
    ~metric, ~label,
    'automation_exposure', 'Automation exposure',
    'pro_worker_opportunity', 'Pro-worker opportunity',
    'transition_pressure', 'Transition pressure',
    'physical_ai_exposure', 'Physical-AI exposure'
  )
  x <- purrr::map_dfr(seq_len(nrow(specs)), function(i) {
    m <- specs$metric[[i]]
    tibble::tibble(
      lwda_combined = data$lwda$lwda_combined,
      metric = specs$label[[i]],
      estimate = data$lwda[[paste0(m, '_estimate')]] %||% data$lwda[[m]],
      lower = data$lwda[[paste0(m, '_lower')]],
      upper = data$lwda[[paste0(m, '_upper')]],
      reliability_class = data$lwda$reliability_class
    )
  }) |>
    dplyr::filter(is.finite(estimate), is.finite(lower), is.finite(upper))
  ggplot2::ggplot(x, ggplot2::aes(x = estimate, y = forcats::fct_reorder(lwda_combined, estimate), color = reliability_class)) +
    ggplot2::geom_errorbar(ggplot2::aes(xmin = lower, xmax = upper), orientation = 'y', width = 0.18, linewidth = 0.7) +
    ggplot2::geom_point(size = 2.8) +
    ggplot2::facet_wrap(~metric, scales = 'free_y', ncol = 2) +
    ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
    ggplot2::scale_color_manual(values = methodology_v2_reliability_palette) +
    ggplot2::labs(title = 'Combined-LWDA estimates with model-based uncertainty intervals', subtitle = 'Overlapping intervals reinforce that small regional differences should not be treated as categorical rankings.', x = 'Employment-weighted score', y = NULL, color = 'Reliability', caption = 'Intervals describe uncertainty in the synthetic allocation and pooling model; they are not causal forecast intervals.') +
    atlas_base_theme(base_size = 10, strip_titles = FALSE)
}

plot_m30_threshold_sensitivity <- function(data) {
  if (!nrow(data$sensitivity)) return(NULL)
  x <- data$sensitivity
  if (!'total_jobs' %in% names(x)) x$total_jobs <- 1
  x <- x |>
    dplyr::group_by(lwda_combined, scenario) |>
    dplyr::summarise(actionable_share = v2_weighted_mean(actionable_share, total_jobs), .groups = 'drop') |>
    dplyr::mutate(scenario = factor(scenario, levels = c('proactive', 'balanced', 'cautious')))
  ggplot2::ggplot(x, ggplot2::aes(x = scenario, y = lwda_combined, fill = actionable_share)) +
    ggplot2::geom_tile(color = 'white', linewidth = 0.5) +
    ggplot2::geom_text(ggplot2::aes(label = scales::percent(actionable_share, accuracy = 1)), family = atlas_font_family(), size = 3.2, color = atlas_brand()$black, na.rm = TRUE) +
    ggplot2::scale_fill_gradientn(colours = c('#E9F1FB', atlas_brand()$green, atlas_brand()$blue), labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::labs(title = 'Sensitivity of actionable job shares to alternative threshold scenarios', subtitle = 'The balanced scenario is the primary public view; proactive and cautious scenarios show how classification changes.', x = 'Threshold scenario', y = NULL, fill = 'Actionable share', caption = 'Thresholds are versioned in config/action_thresholds.csv and are based on employment-weighted percentiles, not hard-coded score levels.') +
    atlas_base_theme(base_size = 10, strip_titles = FALSE) +
    ggplot2::theme(panel.grid = ggplot2::element_blank())
}

plot_m31_county_reliability <- function(data) {
  if (is.null(data$public$shapes) || !nrow(data$county)) return(NULL)
  map <- data$public$shapes |>
    dplyr::left_join(data$county |> dplyr::mutate(county_fips = as_fips5(county_fips)), by = 'county_fips')
  ggplot2::ggplot(map) +
    ggplot2::geom_sf(ggplot2::aes(fill = reliability_class), color = 'white', linewidth = 0.18) +
    ggplot2::scale_fill_manual(values = methodology_v2_reliability_palette, na.value = 'grey90') +
    ggplot2::labs(title = 'Reliability class for county-level synthetic estimates', subtitle = 'A indicates strongest benchmarking/support; C indicates highly synthetic or sparse estimates requiring local validation.', fill = 'Reliability', caption = 'Reliability combines job scale, model interval width, and the share of employment supported by QWI rather than LODES fallback.') +
    atlas_void_theme(base_size = 10, strip_titles = FALSE) +
    ggplot2::theme(legend.position = 'right')
}

plot_m32_exposure_vs_adoption <- function(data) {
  x <- data$adoption
  if (nrow(x) && 'observed_ai_adoption' %in% names(x) && any(is.finite(x$observed_ai_adoption))) {
    y <- x |>
      dplyr::group_by(iowa_priority_sector) |>
      dplyr::summarise(
        technical_exposure = v2_weighted_mean(automation_exposure, estimated_jobs),
        observed_ai_adoption = mean(observed_ai_adoption, na.rm = TRUE),
        estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
        .groups = 'drop'
      ) |>
      dplyr::filter(is.finite(technical_exposure), is.finite(observed_ai_adoption))
    return(
      ggplot2::ggplot(y, ggplot2::aes(x = technical_exposure, y = observed_ai_adoption)) +
        ggplot2::geom_point(ggplot2::aes(size = estimated_jobs), color = atlas_brand()$blue, alpha = 0.85) +
        ggrepel::geom_text_repel(na.rm = TRUE, ggplot2::aes(label = iowa_priority_sector), family = atlas_font_family(), size = 3, color = atlas_brand()$black, seed = 32, max.overlaps = Inf) +
        ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
        ggplot2::scale_y_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
        ggplot2::scale_size_area(max_size = 12, labels = atlas_jobs_short()) +
        ggplot2::labs(title = 'Technical exposure and observed employer AI adoption are separate signals', subtitle = 'Observed adoption is never inferred from O*NET exposure; it enters only when BTOS or Iowa pulse data are supplied.', x = 'Technical automation exposure', y = 'Observed AI-use rate', size = 'Estimated jobs', caption = 'Observed rates use explicit 0-1 proportion units and are not silently converted from percentages.') +
        atlas_base_theme(base_size = 10, strip_titles = FALSE)
    )
  }
  status <- data$adoption_status
  if (!nrow(status)) status <- tibble::tibble(layer = c('Technical exposure', 'Observed employer adoption', 'Worker outcomes'), status = c('available', 'not loaded', 'not loaded'))
  status <- status |>
    dplyr::mutate(
      available = stringr::str_detect(stringr::str_to_lower(status), 'available|loaded'),
      layer = factor(layer, levels = rev(unique(layer)))
    )
  ggplot2::ggplot(status, ggplot2::aes(x = 1, y = layer, fill = available)) +
    ggplot2::geom_tile(width = 0.8, height = 0.7, color = 'white') +
    ggplot2::geom_text(ggplot2::aes(label = status), family = atlas_font_family(), size = 3.5, color = atlas_brand()$black, na.rm = TRUE) +
    ggplot2::scale_fill_manual(values = c(`TRUE` = atlas_brand()$blue, `FALSE` = atlas_brand()$gold), guide = 'none') +
    ggplot2::scale_x_continuous(breaks = NULL) +
    ggplot2::labs(title = 'Technical exposure, adoption, and realized outcomes are tracked separately', subtitle = 'Missing observed data remain explicitly missing rather than being imputed from technical capability.', x = NULL, y = NULL, caption = 'Add normalized BTOS, Iowa employer pulse, worker pulse, or employer-pilot files under inputs/ to activate the observed layers.') +
    atlas_base_theme(base_size = 10, strip_titles = FALSE) +
    ggplot2::theme(panel.grid = ggplot2::element_blank())
}

plot_m33_training_capacity_pressure <- function(data) {
  if (!nrow(data$county) || !'training_capacity_index' %in% names(data$county)) return(NULL)
  x <- data$county |>
    dplyr::filter(is.finite(training_capacity_index), is.finite(transition_pressure), estimated_jobs > 0) |>
    dplyr::mutate(label_score = actionable_jobs * pmax(transition_pressure - training_capacity_index, 0))
  lab <- x |> dplyr::slice_max(label_score, n = 14, with_ties = FALSE)
  ggplot2::ggplot(x, ggplot2::aes(x = training_capacity_index, y = transition_pressure)) +
    ggplot2::geom_abline(slope = 1, intercept = 0, linetype = 'dashed', color = atlas_brand()$grey) +
    ggplot2::geom_point(ggplot2::aes(size = actionable_jobs, fill = reliability_class), shape = 21, color = atlas_brand()$black, alpha = 0.85) +
    ggrepel::geom_text_repel(na.rm = TRUE, data = lab, ggplot2::aes(label = county_name), family = atlas_font_family(), size = 3, seed = 33, color = atlas_brand()$black, max.overlaps = Inf) +
    ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
    ggplot2::scale_y_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
    ggplot2::scale_fill_manual(values = methodology_v2_reliability_palette) +
    ggplot2::scale_size_area(max_size = 14, labels = atlas_jobs_short()) +
    ggplot2::labs(title = 'County transition pressure relative to training capacity', subtitle = 'Counties above the diagonal have greater modeled transition pressure than measured training-access capacity.', x = 'Training-capacity index', y = 'Transition-pressure index', size = 'Actionable jobs', fill = 'Reliability', caption = 'The capacity index combines ACS access indicators with optional community-college, apprenticeship, WIOA, release-time, child-care, and travel inputs; component coverage is published.') +
    atlas_base_theme(base_size = 10, strip_titles = FALSE)
}

plot_m34_physical_ai_sector_lens <- function(data) {
  if (!nrow(data$sector)) return(NULL)
  x <- data$sector |>
    dplyr::group_by(iowa_priority_sector) |>
    dplyr::summarise(
      physical_ai_exposure = v2_weighted_mean(physical_ai_exposure, estimated_jobs),
      pro_worker_opportunity = v2_weighted_mean(pro_worker_opportunity, estimated_jobs),
      actionable_share = v2_weighted_mean(actionable_share, estimated_jobs),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::filter(is.finite(physical_ai_exposure), is.finite(pro_worker_opportunity))
  ggplot2::ggplot(x, ggplot2::aes(x = physical_ai_exposure, y = pro_worker_opportunity)) +
    ggplot2::geom_point(ggplot2::aes(size = estimated_jobs, fill = actionable_share), shape = 21, color = atlas_brand()$black, alpha = 0.88) +
    ggrepel::geom_text_repel(na.rm = TRUE, ggplot2::aes(label = iowa_priority_sector), family = atlas_font_family(), size = 3, seed = 34, color = atlas_brand()$black, max.overlaps = Inf) +
    ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
    ggplot2::scale_y_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
    ggplot2::scale_fill_gradientn(colours = c('#E9F1FB', atlas_brand()$gold, atlas_brand()$red), labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::scale_size_area(max_size = 15, labels = atlas_jobs_short()) +
    ggplot2::labs(title = 'Physical AI and cyber-physical transition lens by sector', subtitle = 'This channel broadens the atlas beyond language-model exposure to robotics, sensors, machine vision, predictive maintenance, and digital operations.', x = 'Physical-AI exposure', y = 'Pro-worker opportunity', size = 'Estimated jobs', fill = 'Actionable share', caption = 'Configured sector modifiers are retained separately from raw occupation task scores and are identified as scenario adjustments.') +
    atlas_base_theme(base_size = 10, strip_titles = FALSE)
}

plot_m35_skill_transition_paths <- function(data) {
  if (!nrow(data$skill_paths)) return(NULL)
  x <- data$skill_paths |>
    dplyr::arrange(dplyr::desc(transition_score), skill_distance) |>
    dplyr::slice_head(n = 24) |>
    dplyr::mutate(path_label = paste0(stringr::str_trunc(origin_occupation, 32), '  →  ', stringr::str_trunc(destination_occupation, 32)),
                  path_label = forcats::fct_reorder(path_label, transition_score))
  ggplot2::ggplot(x, ggplot2::aes(x = transition_score, y = path_label)) +
    ggplot2::geom_point(ggplot2::aes(size = destination_state_employment, fill = wage_ratio), shape = 21, color = atlas_brand()$black, alpha = 0.88) +
    ggplot2::scale_fill_gradientn(colours = c(atlas_brand()$gold, atlas_brand()$green, atlas_brand()$blue), labels = scales::label_number(accuracy = 0.01, suffix = 'x')) +
    ggplot2::scale_size_area(max_size = 10, labels = atlas_jobs_short()) +
    ggplot2::labs(title = 'Feasible skill-transition pathways for exposed occupations', subtitle = 'Candidate destinations combine similar O*NET work-activity profiles, lower pressure or higher opportunity, acceptable Job Zone change, and wage preservation.', x = 'Transition score', y = NULL, size = 'Destination jobs', fill = 'Wage ratio', caption = 'These are planning candidates, not guaranteed individual career transitions; local program availability and worker preferences must be validated.') +
    atlas_base_theme(base_size = 9, strip_titles = FALSE)
}

plot_m36_reconciliation_scorecard <- function(data) {
  x <- data$reconciliation
  if (!nrow(x)) return(NULL)
  x <- x |>
    dplyr::mutate(
      result = ifelse(pass, 'PASS', 'FAIL'),
      test_label = paste0(test_id, ': ', stringr::str_wrap(test_description, 42)),
      test_label = forcats::fct_rev(factor(test_label, levels = unique(test_label)))
    )
  ggplot2::ggplot(x, ggplot2::aes(x = 1, y = test_label, fill = result)) +
    ggplot2::geom_tile(width = 0.75, height = 0.7, color = 'white') +
    ggplot2::geom_text(ggplot2::aes(label = paste0(result, '\n', scales::number(statistic, accuracy = 0.0001))), family = atlas_font_family(), size = 3.2, color = atlas_brand()$black, na.rm = TRUE) +
    ggplot2::scale_fill_manual(values = c(PASS = atlas_brand()$blue, FAIL = atlas_brand()$red), guide = 'none') +
    ggplot2::scale_x_continuous(breaks = NULL) +
    ggplot2::labs(title = 'Automated methodology and reconciliation scorecard', subtitle = 'The workflow does not declare success until typed score schemas, benchmark margins, key uniqueness, geography coverage, and finite employment tests pass.', x = NULL, y = NULL, caption = 'Detailed residuals, source hashes, package versions, build identifiers, and the model card are written under outputs/methodology_v2/.') +
    atlas_base_theme(base_size = 10, strip_titles = FALSE) +
    ggplot2::theme(panel.grid = ggplot2::element_blank())
}

methodology_v2_figure_specs <- function() {
  list(
    list(id = '27', filename = 'methodology_27_county_actionable_share.png', short = 'M2_Actionable', title = 'County actionable-job share', width = 11, height = 7, audience = 'County leaders and workforce boards', fun = plot_m27_county_actionable_share),
    list(id = '28', filename = 'methodology_28_largest_nonmonitor_action.png', short = 'M2_NonMonitor', title = 'Largest non-Monitor action by county', width = 11, height = 7, audience = 'County leaders and policymakers', fun = plot_m28_county_largest_nonmonitor),
    list(id = '29', filename = 'methodology_29_lwda_uncertainty_intervals.png', short = 'M2_Intervals', title = 'LWDA uncertainty intervals', width = 12, height = 8, audience = 'Analysts and policymakers', fun = plot_m29_lwda_uncertainty_intervals),
    list(id = '30', filename = 'methodology_30_threshold_sensitivity.png', short = 'M2_Sensitivity', title = 'Threshold sensitivity', width = 11, height = 7, audience = 'Policymakers and analysts', fun = plot_m30_threshold_sensitivity),
    list(id = '31', filename = 'methodology_31_county_reliability.png', short = 'M2_Reliability', title = 'County reliability classes', width = 11, height = 7, audience = 'Public and funding decision-makers', fun = plot_m31_county_reliability),
    list(id = '32', filename = 'methodology_32_exposure_vs_adoption.png', short = 'M2_Adoption', title = 'Exposure versus observed adoption', width = 11.5, height = 7.5, audience = 'Economic developers and employers', fun = plot_m32_exposure_vs_adoption),
    list(id = '33', filename = 'methodology_33_training_capacity_pressure.png', short = 'M2_Capacity', title = 'Training capacity versus transition pressure', width = 12, height = 8, audience = 'Community colleges and workforce boards', fun = plot_m33_training_capacity_pressure),
    list(id = '34', filename = 'methodology_34_physical_ai_sector_lens.png', short = 'M2_Physical_AI', title = 'Physical-AI sector lens', width = 12, height = 8, audience = 'Manufacturing and infrastructure economic developers', fun = plot_m34_physical_ai_sector_lens),
    list(id = '35', filename = 'methodology_35_skill_transition_paths.png', short = 'M2_Pathways', title = 'Skill-transition pathways', width = 13, height = 9, audience = 'Training providers and career-navigation staff', fun = plot_m35_skill_transition_paths),
    list(id = '36', filename = 'methodology_36_reconciliation_scorecard.png', short = 'M2_Validation', title = 'Reconciliation and validation scorecard', width = 12, height = 7.5, audience = 'Analysts, auditors, and public decision-makers', fun = plot_m36_reconciliation_scorecard)
  )
}

make_methodology_v2_visualizations <- function(build_if_missing = TRUE, refresh = FALSE, stop_on_error = TRUE) {
  p <- paths(); vp <- v2_methodology_paths()
  fs::dir_create(vp$figures); fs::dir_create(p$outputs)
  data <- get_methodology_v2_viz_data(build_if_missing = build_if_missing, refresh = refresh)
  specs <- methodology_v2_figure_specs()
  results <- purrr::map_dfr(specs, function(spec) {
    message('Creating methodology figure ', spec$id, ': ', spec$filename)
    tryCatch({
      plot <- spec$fun(data)
      if (is.null(plot)) stop('Required data are not available for this figure.')
      out <- file.path(vp$figures, spec$filename)
      atlas_save_transparent_png(plot, out, spec$width, spec$height, dpi = 320)
      tibble::tibble(id = spec$id, filename = spec$filename, status = 'created', path = normalizePath(out, winslash = '/', mustWork = FALSE), audience = spec$audience, question = spec$title, build_id = v2_build_id(), methodology_version = as.character(load_methodology_v2_config()$methodology_version))
    }, error = function(e) {
      if (isTRUE(stop_on_error)) stop('Methodology figure ', spec$id, ' failed: ', conditionMessage(e), call. = FALSE)
      tibble::tibble(id = spec$id, filename = spec$filename, status = paste0('failed: ', conditionMessage(e)), path = NA_character_, audience = spec$audience, question = spec$title, build_id = v2_build_id(), methodology_version = as.character(load_methodology_v2_config()$methodology_version))
    })
  })
  readr::write_csv(results, file.path(p$outputs, 'methodology_v2_visualization_manifest.csv'))
  message('Created ', sum(results$status == 'created'), ' methodology-v2 visualization files in ', vp$figures)
  invisible(results)
}

if (sys.nframe() == 0) make_methodology_v2_visualizations(build_if_missing = TRUE, refresh = FALSE)
