# R/run_all.R ---------------------------------------------------------------
# Complete Iowa AI Workforce Atlas Methodology v2 workflow.
# Compatible with Positron and R 4.4.0 ("Puppy Cup") or newer.

.local_project_root_runall <- function() {
  here <- normalizePath(getwd(), winslash = '/', mustWork = TRUE)
  script_dir <- tryCatch({
    frames <- sys.frames()
    ofiles <- vapply(frames, function(x) {
      val <- x$ofile
      if (is.null(val)) NA_character_ else as.character(val)
    }, character(1))
    ofiles <- stats::na.omit(ofiles)
    if (length(ofiles)) normalizePath(dirname(ofiles[[length(ofiles)]]), winslash = '/', mustWork = FALSE) else NA_character_
  }, error = function(e) NA_character_)
  candidates <- unique(stats::na.omit(c(
    here, dirname(here),
    normalizePath(file.path(here, '..'), winslash = '/', mustWork = FALSE),
    normalizePath(file.path(here, '../..'), winslash = '/', mustWork = FALSE),
    script_dir,
    normalizePath(file.path(script_dir, '..'), winslash = '/', mustWork = FALSE),
    normalizePath(file.path(script_dir, '../..'), winslash = '/', mustWork = FALSE)
  )))
  for (cand in candidates) {
    if (file.exists(file.path(cand, 'config.yml')) && dir.exists(file.path(cand, 'R'))) {
      return(normalizePath(cand, winslash = '/', mustWork = TRUE))
    }
  }
  stop('Could not locate the Iowa AI Workforce Atlas project root. Open the .Rproj in Positron or set the working directory to the project folder.', call. = FALSE)
}

.root <- .local_project_root_runall()
.old_wd <- getwd()
on.exit(setwd(.old_wd), add = TRUE)
setwd(.root)

# Explicitly source every analytical, provenance, visualization, report,
# editable-Excel, and validation component needed for the complete release.
source(file.path('R', '00_setup.R'))
message('Preparing required R packages and the editable-Excel DrawingML toolchain.')
setup_packages(install_optional = FALSE)

source(file.path('R', '01_lwda_crosswalk.R'))
source(file.path('R', '02_data_download.R'))
source(file.path('R', '03_ai_scores.R'))
source(file.path('R', '04_build_atlas.R'))
source(file.path('R', '13_methodology_v2.R'))
source(file.path('R', '14_provenance_validation.R'))
source(file.path('R', '10_iowa_report_style.R'))
source(file.path('R', '05_visualize.R'))
source(file.path('R', '07_public_visualizations.R'))
source(file.path('R', '15_methodology_v2_visualizations.R'))
source(file.path('R', '06_render.R'))
source(file.path('R', '08_pdf_reports.R'))
source(file.path('R', '12_excel_editable_figures.R'))
source(file.path('R', '11_validate_outputs.R'))

refresh_flag <- v2_resolve_refresh()
message('Methodology v2 refresh policy resolved to refresh = ', refresh_flag, '.')

message('Step 1/10: building and refreshing the public-data base atlas.')
build_atlas(refresh = refresh_flag, install_optional = FALSE)

message('Step 2/10: applying Methodology v2 scoring, partial pooling, uncertainty, actions, capacity, and pathways.')
apply_methodology_v2(refresh = FALSE, overwrite_primary_outputs = TRUE)

message('Step 3/10: writing provenance, immutable snapshots, model card, and reconciliation tests.')
run_methodology_v2_provenance(stop_on_failure = TRUE)

message('Step 4/10: creating core report figures from Methodology v2 outputs.')
make_figures(refresh = FALSE)

message('Step 5/10: creating 26 public visualization figures and gallery.')
make_public_visualizations(install_missing = TRUE, build_if_missing = FALSE, refresh = FALSE)

message('Step 6/10: creating 10 Methodology v2 uncertainty, sensitivity, adoption, capacity, and validation figures.')
make_methodology_v2_visualizations(build_if_missing = FALSE, refresh = FALSE, stop_on_error = TRUE)

message('Step 7/10: rendering Quarto and R Markdown HTML reports.')
render_reports(refresh = FALSE, stop_on_error = TRUE, quiet = FALSE, make_core_figures = FALSE)

message('Step 8/10: creating accessible PDF reports and all-figures PDF compendium.')
make_pdf_reports(install_missing = TRUE, build_if_missing = FALSE, use_chrome = TRUE)

message('Step 9/10: creating editable Excel figure workbook with all 40 figures.')
make_editable_excel_figures(install_missing = TRUE, build_if_missing = FALSE, refresh = FALSE)

message('Step 10/10: validating the complete Methodology v2 output set.')
validate_run_outputs(
  stop_on_missing = TRUE,
  expected_public_figures = 26L,
  expected_methodology_figures = 10L,
  expected_editable_figures = 40L
)

message('Done. See data_processed/, figures/, figures/public/, figures/methodology_v2/, outputs/, outputs/methodology_v2/, and outputs/iowa_ai_workforce_atlas_editable_figures.xlsx.')
