# Iowa AI Workforce Atlas: article visual profile
# Add this file as R/41_article_visual_profile.R and source it after 10_iowa_report_style.R.

atlas_article_packages <- c("ggplot2", "scales", "ragg", "svglite", "magick", "xml2", "base64enc", "fs")
missing <- atlas_article_packages[!vapply(atlas_article_packages, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) install.packages(missing, dependencies = TRUE)

IA_BLUE <- "#1C5DBA"
IA_TEAL <- "#00808D"
IA_GOLD <- "#E0A624"
IA_GREEN <- "#C6D667"
IA_RED <- "#B32A2D"
IA_BLACK <- "#000000"

atlas_article_theme <- function(base_size = 10, base_family = "Arial") {
  ggplot2::theme_minimal(base_size = base_size, base_family = base_family) +
    ggplot2::theme(
      plot.title = ggplot2::element_blank(),
      plot.subtitle = ggplot2::element_blank(),
      plot.caption = ggplot2::element_blank(),
      axis.title = ggplot2::element_text(size = 10, colour = IA_BLACK),
      axis.text = ggplot2::element_text(size = 9.5, colour = IA_BLACK),
      strip.text = ggplot2::element_text(size = 10.5, face = "bold", colour = IA_BLACK),
      legend.title = ggplot2::element_text(size = 10, face = "bold", colour = IA_BLACK),
      legend.text = ggplot2::element_text(size = 9.5, colour = IA_BLACK),
      panel.grid.minor = ggplot2::element_blank(),
      panel.grid.major = ggplot2::element_line(linewidth = 0.28, colour = "#D8D8D8"),
      plot.margin = ggplot2::margin(3, 7, 3, 3, unit = "pt"),
      plot.background = ggplot2::element_rect(fill = NA, colour = NA),
      panel.background = ggplot2::element_rect(fill = NA, colour = NA),
      legend.background = ggplot2::element_rect(fill = NA, colour = NA),
      legend.key = ggplot2::element_rect(fill = NA, colour = NA)
    )
}

atlas_percent_limits <- function(x, include_zero = TRUE, pad = 0.10, ceiling = 1) {
  x <- as.numeric(x)
  x <- x[is.finite(x)]
  if (!length(x)) return(c(0, 1))
  lo <- min(x); hi <- max(x)
  if (include_zero) lo <- min(0, lo)
  span <- max(hi - lo, 0.01)
  c(max(0, lo - span * 0.02), min(ceiling, hi + span * pad))
}

atlas_save_article_plot <- function(plot, filename, width, height, dpi = 320,
                                    make_svg = TRUE, make_white_preview = TRUE,
                                    trim = TRUE) {
  dir.create(dirname(filename), recursive = TRUE, showWarnings = FALSE)
  p <- plot + atlas_article_theme()
  ragg::agg_png(filename, width = width, height = height, units = "in",
                res = dpi, background = "transparent", scaling = 1)
  print(p)
  grDevices::dev.off()

  if (trim) {
    img <- magick::image_read(filename)
    img <- magick::image_trim(img, fuzz = 2)
    magick::image_write(img, filename, format = "png")
  }

  if (make_svg) {
    svg_file <- sub("\\.png$", ".svg", filename, ignore.case = TRUE)
    svglite::svglite(svg_file, width = width, height = height, bg = "transparent")
    print(p)
    grDevices::dev.off()
  }

  if (make_white_preview) {
    preview <- sub("\\.png$", "_white_preview.png", filename, ignore.case = TRUE)
    img <- magick::image_read(filename)
    img <- magick::image_background(img, "white", flatten = TRUE)
    magick::image_write(img, preview, format = "png")
  }

  invisible(filename)
}

atlas_make_lightweight_print_html <- function(input_html,
                                              output_html,
                                              asset_dir = file.path(dirname(output_html), "article_assets"),
                                              max_width_px = 3000,
                                              max_height_px = 2200) {
  stopifnot(file.exists(input_html))
  dir.create(asset_dir, recursive = TRUE, showWarnings = FALSE)
  doc <- xml2::read_html(input_html, options = c("RECOVER", "NOERROR", "NOWARNING"))

  # Remove source code and interactive navigation from the print copy.
  remove_xpath <- paste0(
    "//pre[contains(concat(' ', normalize-space(@class), ' '), ' r ')] | ",
    "//pre[contains(concat(' ', normalize-space(@class), ' '), ' sourceCode ')] | ",
    "//div[contains(concat(' ', normalize-space(@class), ' '), ' sourceCode ')] | ",
    "//div[contains(concat(' ', normalize-space(@class), ' '), ' cell-code ')] | ",
    "//details | //nav | //script"
  )
  xml2::xml_remove(xml2::xml_find_all(doc, remove_xpath))

  imgs <- xml2::xml_find_all(doc, "//img[starts-with(@src, 'data:image/png;base64,')]")
  for (i in seq_along(imgs)) {
    src <- xml2::xml_attr(imgs[[i]], "src")
    raw <- base64enc::base64decode(sub("^data:image/png;base64,", "", src))
    tmp <- tempfile(fileext = ".png")
    writeBin(raw, tmp)
    im <- magick::image_read(tmp)
    im <- magick::image_trim(im, fuzz = 2)
    info <- magick::image_info(im)
    if (info$width > max_width_px || info$height > max_height_px) {
      im <- magick::image_resize(im, sprintf("%dx%d>", max_width_px, max_height_px))
    }
    target <- file.path(asset_dir, sprintf("figure_%03d.png", i))
    magick::image_write(im, target, format = "png")
    rel <- fs::path_rel(target, start = dirname(output_html))
    xml2::xml_set_attr(imgs[[i]], "src", gsub("\\\\", "/", rel))
    xml2::xml_set_attr(imgs[[i]], "loading", "eager")
  }

  css <- paste0(
    "<style id='atlas-article-print'>",
    "@page{size:letter landscape;margin:.28in;}",
    "html,body{font-family:Arial,Helvetica,sans-serif!important;font-size:12pt;line-height:1.15;color:#000;background:#fff;}",
    "main,.container,.container-fluid,.content{max-width:none!important;width:100%!important;}",
    "pre,.sourceCode,.cell-code,details,summary,nav,.tocify{display:none!important;}",
    "h1{font-size:18pt;color:#1C5DBA;margin:0 0 6pt;}",
    "h2,h3,h4{font-size:16pt;color:#00808D;margin:8pt 0 5pt;}",
    ".figure-title{font-size:12pt;font-weight:700;text-align:center;margin:3pt 0 3pt;}",
    ".figure-note,figcaption{font-size:10pt;text-align:left;margin:2pt 0 5pt;}",
    "figure,.report-figure,.public-figure{margin:0 0 6pt!important;padding:0!important;break-inside: auto !important;}",
    "img{display:block;margin:0 auto;max-width:100%!important;max-height:6.8in!important;width:auto!important;height:auto!important;object-fit:contain;}",
    ".public-figure-page{break-before:page;break-inside: auto !important;margin:0!important;}",
    "table{width:100%;border-collapse:collapse;font-size:9.5pt;}",
    "th,td{padding:2px 4px;vertical-align:top;overflow-wrap:normal;word-break:normal;}",
    "</style>"
  )
  head <- xml2::xml_find_first(doc, "//head")
  xml2::xml_add_child(head, xml2::read_html(css) |> xml2::xml_find_first("//style"))
  xml2::write_html(doc, output_html, options = "format")
  message("Wrote lightweight article print HTML: ", normalizePath(output_html, winslash = "/", mustWork = FALSE))
  invisible(output_html)
}

# Recommended dimensions by visual family:
# maps: 10.5 x 6.2 in
# heatmaps/bubble matrices/alluvial: 11.0 x 6.4 in
# rankings/lollipops: 9.0 x 7.0 in
# compact status cards: 10.0 x 5.6 in
