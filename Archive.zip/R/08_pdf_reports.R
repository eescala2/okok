# 08_pdf_reports.R ----------------------------------------------------------
# Create readable PDF versions of the Quarto and R Markdown reports, with the
# public and Methodology v2 visualization appendices included. The preferred route uses a bounded,
# processx-managed Chrome or Edge subprocess. A robust R-only fallback
# also creates landscape figure compendium PDFs from the generated PNG figures.

.atlas_find_root_pdf <- function() {
  here <- normalizePath(getwd(), winslash = '/', mustWork = TRUE)
  candidates <- unique(c(
    here,
    dirname(here),
    normalizePath(file.path(here, '..'), winslash = '/', mustWork = FALSE),
    normalizePath(file.path(here, '../..'), winslash = '/', mustWork = FALSE)
  ))
  for (cand in candidates) {
    if (file.exists(file.path(cand, 'config.yml')) && dir.exists(file.path(cand, 'R'))) {
      return(normalizePath(cand, winslash = '/', mustWork = TRUE))
    }
  }
  here
}

root0 <- .atlas_find_root_pdf()
source(file.path(root0, 'R', '00_setup.R'))
source(file.path(root0, 'R', '10_iowa_report_style.R'))

.install_pdf_report_packages <- function(install_missing = TRUE) {
  needed <- c('png')
  # Direct Chromium/Edge printing is the primary route. Pagedown is disabled,
  # so there is no pagedown/xfun namespace or child-process dependency.
  optional <- character()
  repo <- Sys.getenv('IA_ATLAS_CRAN_REPO', unset = '')
  if (!nzchar(repo)) repo <- 'https://packagemanager.posit.co/cran/latest'
  repos <- getOption('repos')
  current <- tryCatch(repos[['CRAN']], error = function(e) NA_character_)
  if (is.null(repos) || is.na(current) || identical(current, '@CRAN@') || !nzchar(current)) {
    options(repos = c(CRAN = repo))
  }
  options(download.file.method = 'libcurl')
  cores <- parallel::detectCores(logical = TRUE)
  if (is.na(cores) || cores < 2L) cores <- 2L
  ncpus <- max(1L, cores - 1L)

  if (isTRUE(install_missing)) {
    missing_needed <- setdiff(needed, rownames(utils::installed.packages()))
    if (.Platform$OS.type == 'windows' || identical(Sys.info()[['sysname']], 'Darwin')) options(pkgType = 'binary')
  if (length(missing_needed)) utils::install.packages(missing_needed, dependencies = c('Depends', 'Imports', 'LinkingTo'), quiet = TRUE, Ncpus = ncpus, type = getOption('pkgType', 'binary'))
    missing_optional <- setdiff(optional, rownames(utils::installed.packages()))
    if (length(missing_optional)) {
      for (pkg in missing_optional) {
        tryCatch(
          utils::install.packages(pkg, dependencies = c('Depends', 'Imports', 'LinkingTo'), quiet = TRUE, Ncpus = ncpus, type = getOption('pkgType', 'binary')),
          error = function(e) warning('Could not install optional package ', pkg, ': ', conditionMessage(e), call. = FALSE)
        )
      }
    }
  }
  if (!requireNamespace('png', quietly = TRUE)) {
    stop('Package png is required for the PDF figure fallback. Install with install.packages("png").', call. = FALSE)
  }
  invisible(TRUE)
}

.clean_figure_title <- function(x) {
  x <- tools::file_path_sans_ext(basename(x))
  x <- gsub('^public_[0-9]+_', '', x)
  x <- gsub('_', ' ', x)
  x <- tools::toTitleCase(x)
  x
}

.wrap_grid_text <- function(text, x = 0.06, y = 0.9, width = 95,
                            gp = grid::gpar(fontsize = 10, fontfamily = 'Helvetica', col = atlas_brand()$black), lineheight = 1.15) {
  text <- paste(text, collapse = ' ')
  lines <- strwrap(text, width = width)
  if (!length(lines)) return(invisible(y))
  # grid::grid.text() does not accept a top-level lineheight argument;
  # line height belongs inside the graphical-parameters object. Passing it
  # directly caused `unused argument (lineheight = lineheight)` on newer R/grid
  # versions and stopped PDF report generation after the first title page.
  gp2 <- gp
  gp2$lineheight <- lineheight
  grid::grid.text(
    paste(lines, collapse = '\n'),
    x = grid::unit(x, 'npc'), y = grid::unit(y, 'npc'),
    just = c('left', 'top'), gp = gp2, default.units = 'npc'
  )
  invisible(y - length(lines) * 0.028 * lineheight)
}

.sync_pdf_report_assets <- function() {
  p <- paths()
  fs::dir_create(file.path(p$outputs, 'figures'))
  fs::dir_create(file.path(p$outputs, 'inputs'))

  # Keep copies beside the HTML files so browser-based printing can resolve
  # relative image paths even when Quarto/R Markdown do not copy every asset.
  standard_figs <- list.files(p$figures, pattern = '\\.(png|jpg|jpeg)$', full.names = TRUE, recursive = FALSE)
  if (length(standard_figs)) {
    file.copy(standard_figs, file.path(p$outputs, 'figures'), overwrite = TRUE)
  }

  public_dir <- file.path(p$figures, 'public')
  if (dir.exists(public_dir)) {
    out_public_dir <- file.path(p$outputs, 'figures', 'public')
    unlink(out_public_dir, recursive = TRUE, force = TRUE)
    fs::dir_create(dirname(out_public_dir))
    file.copy(public_dir, file.path(p$outputs, 'figures'), recursive = TRUE, overwrite = TRUE)
  }

  methodology_dir <- file.path(p$figures, 'methodology_v2')
  if (dir.exists(methodology_dir)) {
    out_methodology_dir <- file.path(p$outputs, 'figures', 'methodology_v2')
    unlink(out_methodology_dir, recursive = TRUE, force = TRUE)
    fs::dir_create(dirname(out_methodology_dir))
    file.copy(methodology_dir, file.path(p$outputs, 'figures'), recursive = TRUE, overwrite = TRUE)
  }

  input_figs <- list.files(p$inputs, pattern = '\\.(png|jpg|jpeg)$', full.names = TRUE, recursive = FALSE)
  if (length(input_figs)) {
    file.copy(input_figs, file.path(p$outputs, 'inputs'), overwrite = TRUE)
  }
  invisible(TRUE)
}


# METHODOLOGY_V2_PDF_CATALOG_ID_CONTRACT_V1
# Normalize every figure-catalog fragment before row binding. CSV readers may
# infer numeric IDs for Methodology figures (27-36), while core/discovered IDs
# are character (S01, P01, M27). A catalog identifier is metadata, not a number.
.atlas_pdf_catalog_contract_v2 <- function(x) {
  required <- c("id", "filename", "path", "status", "audience", "question", "section")
  if (is.null(x) || !is.data.frame(x)) x <- tibble::tibble()
  n <- nrow(x)
  for (nm in required) {
    if (!nm %in% names(x)) x[[nm]] <- rep(NA_character_, n)
  }
  x |>
    dplyr::mutate(dplyr::across(dplyr::all_of(required), as.character)) |>
    dplyr::select(dplyr::all_of(required), dplyr::everything())
}

get_pdf_figure_catalog <- function() {
  p <- paths()
  standard_paths <- list.files(p$figures, pattern = '\\.(png|jpg|jpeg)$', full.names = TRUE, recursive = FALSE)
  standard <- tibble::tibble(
    id = sprintf('S%02d', seq_along(standard_paths)),
    filename = basename(standard_paths),
    path = normalizePath(standard_paths, winslash = '/', mustWork = FALSE),
    status = 'created',
    audience = 'All audiences',
    question = vapply(standard_paths, .clean_figure_title, character(1)),
    section = 'Core atlas figures'
  )

  manifest_path <- file.path(p$outputs, 'public_visualization_manifest.csv')
  public <- tibble::tibble()
  if (file.exists(manifest_path)) {
    public <- readr::read_csv(manifest_path, show_col_types = FALSE)
    if (!all(c('id', 'filename', 'status', 'path', 'audience', 'question') %in% names(public))) {
      public <- tibble::tibble()
    } else {
      public <- public |>
        dplyr::mutate(
          path = as.character(path),
          fallback_path = file.path(p$figures, 'public', filename),
          path = ifelse(file.exists(path), path, fallback_path),
          path = normalizePath(path, winslash = '/', mustWork = FALSE),
          section = 'Public visualization appendix'
        ) |>
        dplyr::filter(status == 'created', file.exists(path)) |>
        dplyr::select(id, filename, path, status, audience, question, section)
    }
  }

  public_dir <- file.path(p$figures, 'public')
  discovered_public <- tibble::tibble()
  if (dir.exists(public_dir)) {
    public_paths <- list.files(public_dir, pattern = '\\.(png|jpg|jpeg)$', full.names = TRUE, recursive = FALSE)
    public_paths <- normalizePath(public_paths, winslash = '/', mustWork = FALSE)
    existing <- if (nrow(public)) normalizePath(public$path, winslash = '/', mustWork = FALSE) else character()
    extra <- setdiff(public_paths, existing)
    if (length(extra)) {
      discovered_public <- tibble::tibble(
        id = sprintf('P%02d', seq_along(extra)),
        filename = basename(extra),
        path = extra,
        status = 'created',
        audience = 'Public, policymakers, workforce boards, economic developers',
        question = vapply(extra, .clean_figure_title, character(1)),
        section = 'Public visualization appendix'
      )
    }
  }

  methodology_manifest_path <- file.path(p$outputs, 'methodology_v2_visualization_manifest.csv')
  methodology <- tibble::tibble()
  if (file.exists(methodology_manifest_path)) {
    methodology <- tryCatch(readr::read_csv(methodology_manifest_path, show_col_types = FALSE), error = function(e) tibble::tibble())
    if (nrow(methodology) && all(c('id', 'filename', 'status', 'path', 'audience', 'question') %in% names(methodology))) {
      methodology <- methodology |>
        dplyr::mutate(
          path = as.character(path),
          fallback_path = file.path(p$figures, 'methodology_v2', filename),
          path = ifelse(file.exists(path), path, fallback_path),
          path = normalizePath(path, winslash = '/', mustWork = FALSE),
          section = 'Methodology v2 diagnostics'
        ) |>
        dplyr::filter(status == 'created', file.exists(path)) |>
        dplyr::select(id, filename, path, status, audience, question, section)
    } else methodology <- tibble::tibble()
  }

  methodology_dir <- file.path(p$figures, 'methodology_v2')
  discovered_methodology <- tibble::tibble()
  if (dir.exists(methodology_dir)) {
    method_paths <- list.files(methodology_dir, pattern = '\\.(png|jpg|jpeg)$', full.names = TRUE, recursive = FALSE)
    method_paths <- normalizePath(method_paths, winslash = '/', mustWork = FALSE)
    existing <- if (nrow(methodology)) normalizePath(methodology$path, winslash = '/', mustWork = FALSE) else character()
    extra <- setdiff(method_paths, existing)
    if (length(extra)) {
      discovered_methodology <- tibble::tibble(
        id = sprintf('M%02d', seq_along(extra)),
        filename = basename(extra),
        path = extra,
        status = 'created',
        audience = 'Public, policymakers, workforce boards, analysts, and economic developers',
        question = vapply(extra, .clean_figure_title, character(1)),
        section = 'Methodology v2 diagnostics'
      )
    }
  }

  dplyr::bind_rows(
      .atlas_pdf_catalog_contract_v2(standard),
      .atlas_pdf_catalog_contract_v2(public),
      .atlas_pdf_catalog_contract_v2(discovered_public),
      .atlas_pdf_catalog_contract_v2(methodology),
      .atlas_pdf_catalog_contract_v2(discovered_methodology)
    ) |>
    dplyr::filter(file.exists(path)) |>
    dplyr::distinct(path, .keep_all = TRUE)
}

.make_print_html_copy <- function(input_html, output_html) {
  html <- paste(readLines(input_html, warn = FALSE, encoding = 'UTF-8'), collapse = '\n')
  css <- paste0(
    '\n<style id="iowa-atlas-branded-accessible-pdf-print-css">\n',
    '/* Iowa Workforce Atlas print styles: Arial typography, W3C/WCAG-oriented semantics, no code blocks, transparent chart backgrounds, and readable tables. */\n',
    '@page { size: letter landscape; margin: 0.45in; }\n',
    ':root { --ia-blue: rgb(28, 93, 186); --ia-teal: rgb(0, 128, 141); --ia-black: rgb(0, 0, 0); }\n',
    'html, body { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; background: transparent !important; color: var(--ia-black) !important; font-family: Arial, Helvetica, sans-serif !important; font-size: 12pt !important; line-height: 1.15 !important; text-align: justify !important; max-width: none !important; }\n',
    'main, .content, .container, .container-fluid, #quarto-content, #quarto-document-content { max-width: none !important; width: 100% !important; }\n',
    'p, li, dd { font-family: Arial, Helvetica, sans-serif !important; font-size: 12pt !important; color: var(--ia-black) !important; font-weight: 400 !important; margin-top: 0 !important; margin-bottom: 6pt !important; line-height: 1.15 !important; }\n',
    'h1, .title { font-family: Arial, Helvetica, sans-serif !important; font-size: 18pt !important; font-weight: 700 !important; color: var(--ia-blue) !important; text-align: left !important; margin: 0 0 6pt 0 !important; line-height: 1.15 !important; page-break-after: avoid; break-after: avoid; }\n',
    'h2, h3, h4, .subtitle { font-family: Arial, Helvetica, sans-serif !important; font-size: 16pt !important; font-weight: 400 !important; color: var(--ia-teal) !important; text-align: left !important; margin: 12pt 0 6pt 0 !important; line-height: 1.15 !important; page-break-after: avoid; break-after: avoid; }\n',
    '.figure-title, table.accessible-table caption { font-family: Arial, Helvetica, sans-serif !important; font-size: 12pt !important; font-weight: 700 !important; color: var(--ia-black) !important; text-align: center !important; margin: 10pt auto 6pt auto !important; line-height: 1.15 !important; }\n',
    '.figure-note, figcaption { font-family: Arial, Helvetica, sans-serif !important; font-size: 10pt !important; font-weight: 400 !important; color: var(--ia-black) !important; text-align: left !important; margin: 4pt 0 8pt 0 !important; line-height: 1.15 !important; }\n',
    'a { color: var(--ia-blue) !important; text-decoration: underline; }\n',
    'details, summary, .cell-code, .sourceCode, pre.sourceCode, div.sourceCode, .code-fold-btn-container { display: none !important; }\n',
    'table { width: 100% !important; border-collapse: collapse !important; table-layout: auto !important; background: transparent !important; page-break-inside: auto; break-inside: auto; }\n',
    'th { font-family: Arial, Helvetica, sans-serif !important; font-size: 12pt !important; font-weight: 700 !important; color: var(--ia-black) !important; text-align: center !important; vertical-align: bottom !important; white-space: normal !important; overflow-wrap: anywhere !important; border-color: #b8b8b8 !important; padding: 3.2px 5px !important; }\n',
    'td { font-family: Arial, Helvetica, sans-serif !important; font-size: 12pt !important; font-weight: 400 !important; color: var(--ia-black) !important; vertical-align: top !important; white-space: normal !important; overflow-wrap: anywhere !important; word-break: normal !important; hyphens: auto !important; border-color: #b8b8b8 !important; padding: 3.2px 5px !important; }\n',
    'thead { display: table-header-group; }\n',
    'tr { page-break-inside: auto !important; break-inside: auto !important; }\n',
    '.lwda-metric-table th, .lwda-metric-table td { font-size: 11pt !important; }\n',
    '.training-priority-table th, .training-priority-table td { font-size: 9.5pt !important; }\n',
    '.training-priority-table td:nth-child(3) { max-width: 1.9in !important; }\n',
    '.training-priority-table td:nth-child(4) { max-width: 2.1in !important; }\n',
    'img { max-width: 100% !important; height: auto !important; background: transparent !important; page-break-inside: auto !important; break-inside: auto !important; }\n',
    'figure, .figure, .report-figure, .public-figure { page-break-inside: auto !important; break-inside: auto !important; margin: 0 0 12pt 0 !important; background: transparent !important; }\n',
    '.report-figure img { max-height: 6.05in !important; object-fit: contain !important; }\n',
    '.public-appendix-intro { display: block !important; width: 100% !important; page-break-inside: auto !important; break-inside: auto !important; margin-bottom: 0.15in; }\n',
    '.public-figure-page { page-break-before: always; break-before: page; page-break-inside: auto !important; break-inside: auto !important; width: 100% !important; }\n',
    '.public-figure-page img { width: 100% !important; max-height: 5.95in !important; object-fit: contain !important; }\n',
    '@media print { a[href]:after { content: none !important; } }\n',
    '</style>\n'
  )
  if (grepl('</head>', html, fixed = TRUE)) {
    html <- sub('</head>', paste0(css, '</head>'), html, fixed = TRUE)
  } else {
    html <- paste0(css, html)
  }
  writeLines(html, output_html, useBytes = TRUE)
  output_html
}

.find_chromium_executable <- function() {
  env_candidates <- c(
    Sys.getenv('IA_ATLAS_CHROME', unset = ''),
    Sys.getenv('PAGEDOWN_CHROME', unset = ''),
    Sys.getenv('CHROME_PATH', unset = '')
  )

  candidates <- env_candidates[nzchar(env_candidates)]
  sysname <- Sys.info()[['sysname']]

  if (.Platform$OS.type == 'windows') {
    local_app <- Sys.getenv('LOCALAPPDATA', unset = '')
    program_files <- Sys.getenv('ProgramFiles', unset = 'C:/Program Files')
    program_files_x86 <- Sys.getenv('ProgramFiles(x86)', unset = 'C:/Program Files (x86)')
    candidates <- c(
      candidates,
      file.path(program_files, 'Google/Chrome/Application/chrome.exe'),
      file.path(program_files_x86, 'Google/Chrome/Application/chrome.exe'),
      if (nzchar(local_app)) file.path(local_app, 'Google/Chrome/Application/chrome.exe') else '',
      file.path(program_files, 'Microsoft/Edge/Application/msedge.exe'),
      file.path(program_files_x86, 'Microsoft/Edge/Application/msedge.exe'),
      if (nzchar(local_app)) file.path(local_app, 'Microsoft/Edge/Application/msedge.exe') else ''
    )
  } else if (identical(sysname, 'Darwin')) {
    candidates <- c(
      candidates,
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
      '/Applications/Chromium.app/Contents/MacOS/Chromium'
    )
  } else {
    bins <- Sys.which(c('google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser', 'microsoft-edge', 'microsoft-edge-stable'))
    candidates <- c(candidates, unname(bins[nzchar(bins)]))
  }

  candidates <- unique(candidates[nzchar(candidates)])
  existing <- candidates[file.exists(candidates)]
  if (!length(existing)) return(NA_character_)
  normalizePath(existing[[1L]], winslash = '/', mustWork = TRUE)
}

.as_file_uri <- function(path) {
  p <- normalizePath(path, winslash = '/', mustWork = TRUE)
  # Encode only characters that would terminate or alter a local file URL;
  # preserve drive-colon and slash characters.
  p <- gsub('%', '%25', p, fixed = TRUE)
  p <- gsub(' ', '%20', p, fixed = TRUE)
  p <- gsub('#', '%23', p, fixed = TRUE)
  p <- gsub('?', '%3F', p, fixed = TRUE)
  if (.Platform$OS.type == 'windows') paste0('file:///', p) else paste0('file://', p)
}

.run_browser_command <- function(browser, args, timeout_seconds = 180) {
  if (!requireNamespace('processx', quietly = TRUE)) {
    return(list(
      status = 127L,
      output = 'processx is required for bounded browser PDF execution; no unbounded system2 fallback was attempted.'
    ))
  }

  timeout_seconds <- suppressWarnings(as.numeric(timeout_seconds))
  if (!is.finite(timeout_seconds) || timeout_seconds < 10) timeout_seconds <- 180
  res <- tryCatch(
    processx::run(
      command = browser,
      args = args,
      echo = FALSE,
      error_on_status = FALSE,
      timeout = timeout_seconds * 1000,
      windows_hide_window = TRUE,
      cleanup_tree = TRUE
    ),
    error = function(e) list(
      status = 124L,
      stdout = '',
      stderr = paste0('Bounded browser process failed or timed out: ', conditionMessage(e))
    )
  )
  list(
    status = as.integer(res$status %||% 124L),
    output = paste(c(res$stdout %||% '', res$stderr %||% ''), collapse = '\n')
  )
}

.try_direct_chrome_print_pdf <- function(input_html, output_pdf, wait = 3) {
  browser <- .find_chromium_executable()
  if (is.na(browser) || !nzchar(browser)) return(FALSE)

  input_uri <- .as_file_uri(input_html)
  output_native <- normalizePath(output_pdf, winslash = '/', mustWork = FALSE)
  profile_dir <- tempfile('iowa-atlas-chrome-profile-')
  dir.create(profile_dir, recursive = TRUE, showWarnings = FALSE)
  on.exit(unlink(profile_dir, recursive = TRUE, force = TRUE), add = TRUE)

  timeout_seconds <- suppressWarnings(as.numeric(Sys.getenv(
    'IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS', unset = '240'
  )))
  if (!is.finite(timeout_seconds) || timeout_seconds < 30) timeout_seconds <- 240

  unlink(output_pdf, force = TRUE)
  common <- c(
    '--disable-gpu',
    '--disable-dev-shm-usage',
    '--disable-extensions',
    '--no-first-run',
    '--no-default-browser-check',
    '--no-sandbox',
    '--allow-file-access-from-files',
    '--run-all-compositor-stages-before-draw',
    '--no-pdf-header-footer',
    '--print-to-pdf-no-header',
    paste0('--virtual-time-budget=', max(5000L, as.integer(wait * 1000))),
    paste0('--user-data-dir=', normalizePath(profile_dir, winslash = '/', mustWork = TRUE)),
    paste0('--print-to-pdf=', output_native)
  )

  # At most three bounded attempts. Standard output is attempted before tagged
  # output because it is the most portable across Chrome and Edge releases.
  attempts <- list(
    c('--headless=new', common, input_uri),
    c('--headless=new', '--generate-tagged-pdf', '--generate-pdf-document-outline', common, input_uri),
    c('--headless', common, input_uri)
  )

  for (index in seq_along(attempts)) {
    message('  Browser PDF attempt ', index, '/', length(attempts),
            ' for ', basename(input_html), ' (timeout=', timeout_seconds, 's).')
    result <- .run_browser_command(
      browser,
      attempts[[index]],
      timeout_seconds = timeout_seconds
    )
    ok <- identical(result$status, 0L) && file.exists(output_pdf) &&
      isTRUE(file.info(output_pdf)$size > 10000)
    if (isTRUE(ok)) {
      attr(ok, 'browser') <- browser
      return(ok)
    }
    unlink(output_pdf, force = TRUE)
  }

  message('Direct Chromium/Edge PDF printing did not complete for ',
          basename(input_html), ' using ', browser, '.')
  FALSE
}

.try_pagedown_print_pdf <- function(input_html, output_pdf, wait = 3) {
  # Deliberately disabled. pagedown::chrome_print() controls its own browser
  # lifecycle and has caused indefinite waits on some macOS installations.
  # The maintained workflow uses processx-managed Chromium with a hard timeout,
  # followed by the portable base-PDF figure compendium when browser printing
  # is unavailable.
  FALSE
}

.try_chrome_print_pdf <- function(input_html, output_pdf, wait = 3) {
  # Direct processx-managed browser invocation is the default and is bounded.
  if (.try_direct_chrome_print_pdf(input_html, output_pdf, wait = wait)) {
    return('direct_chromium_bounded')
  }
  NA_character_
}

.open_atlas_pdf_device <- function(output_pdf, width = 11, height = 8.5) {
  # The figure panels are already high-resolution PNGs. Base pdf() is therefore
  # sufficient and avoids all Cairo/X11/XQuartz dynamic-library dependencies on
  # Apple Silicon while remaining portable to Windows 11.
  dir.create(dirname(output_pdf), recursive = TRUE, showWarnings = FALSE)
  if (file.exists(output_pdf)) unlink(output_pdf, force = TRUE)
  tryCatch({
    grDevices::pdf(
      output_pdf,
      width = width,
      height = height,
      onefile = TRUE,
      paper = 'special',
      family = 'Helvetica',
      useDingbats = FALSE
    )
    TRUE
  }, error = function(e) {
    warning(
      'Could not open the portable base PDF graphics device for ', output_pdf,
      ': ', conditionMessage(e),
      call. = FALSE
    )
    FALSE
  })
}

.pdf_gp <- function(fontsize = 10, fontface = 'plain', col = atlas_brand()$black, ...) {
  grid::gpar(fontsize = fontsize, fontface = fontface, fontfamily = 'Helvetica', col = col, ...)
}

make_figure_compendium_pdf <- function(output_pdf,
                                       title = 'Iowa AI Workforce Atlas - figure compendium',
                                       subtitle = 'Readable landscape PDF fallback with all generated figures.',
                                       figures = get_pdf_figure_catalog()) {
  p <- paths()
  fs::dir_create(dirname(output_pdf))
  if (!nrow(figures)) {
    warning('No generated figure files were found for the PDF compendium.', call. = FALSE)
    return(FALSE)
  }

  old <- grDevices::dev.cur()
  pdf_opened <- .open_atlas_pdf_device(output_pdf, width = 11, height = 8.5)
  if (!isTRUE(pdf_opened)) return(FALSE)
  on.exit({
    grDevices::dev.off()
    if (old > 1) try(grDevices::dev.set(old), silent = TRUE)
  }, add = TRUE)

  # Title page
  grid::grid.newpage()
  grid::grid.text(title, x = 0.06, y = 0.90, just = c('left', 'top'),
                  gp = .pdf_gp(fontsize = 18, fontface = 'bold', col = atlas_brand()$blue))
  .wrap_grid_text(subtitle, x = 0.06, y = 0.82, width = 105, gp = .pdf_gp(fontsize = 12, col = atlas_brand()$black))
  .wrap_grid_text(
    paste0('This PDF is generated from the project PNG outputs in figures/ and figures/public/. ',
           'Each figure gets its own landscape page so maps, labels, and dense policy graphics remain readable when printed or viewed full screen.'),
    x = 0.06, y = 0.72, width = 105, gp = .pdf_gp(fontsize = 12, col = atlas_brand()$black)
  )
  .wrap_grid_text(
    paste0('Generated: ', format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z'),
           ' | Project root: ', p$root),
    x = 0.06, y = 0.60, width = 105, gp = .pdf_gp(fontsize = 10, col = atlas_brand()$black)
  )
  grid::grid.text(paste0('Figures included: ', nrow(figures)), x = 0.06, y = 0.52,
                  just = c('left', 'top'), gp = .pdf_gp(fontsize = 12, fontface = 'bold', col = atlas_brand()$black))

  by_section <- split(figures, figures$section)
  y <- 0.45
  for (nm in names(by_section)) {
    grid::grid.text(paste0(nm, ': ', nrow(by_section[[nm]])), x = 0.08, y = y,
                    just = c('left', 'top'), gp = .pdf_gp(fontsize = 10, col = atlas_brand()$black))
    y <- y - 0.04
  }

  # Figure pages
  page_w <- 11
  page_h <- 8.5
  for (i in seq_len(nrow(figures))) {
    if (i == 1L || i %% 5L == 0L || i == nrow(figures)) {
      message('  Portable figure-compendium page ', i, '/', nrow(figures), '.')
    }
    row <- figures[i, ]
    grid::grid.newpage()
    fig_title <- paste0('Figure ', i, '. ', row$question)
    grid::grid.text(fig_title, x = 0.5, y = 0.965, just = c('center', 'top'),
                    gp = .pdf_gp(fontsize = 12, fontface = 'bold', col = atlas_brand()$black))
    .wrap_grid_text(paste0('Primary audience: ', row$audience), x = 0.04, y = 0.91, width = 118,
                    gp = .pdf_gp(fontsize = 10, col = atlas_brand()$black))

    img <- tryCatch(png::readPNG(row$path), error = function(e) NULL)
    if (is.null(img)) {
      .wrap_grid_text(paste0('Could not read image: ', row$path), x = 0.04, y = 0.80, width = 118,
                      gp = .pdf_gp(fontsize = 10, col = atlas_brand()$red))
      next
    }
    dims <- dim(img)
    img_h <- dims[1]
    img_w <- dims[2]
    aspect <- img_w / img_h

    max_w <- 0.94
    max_h <- 0.76
    draw_w <- max_w
    draw_h <- draw_w * page_w / (aspect * page_h)
    if (draw_h > max_h) {
      draw_h <- max_h
      draw_w <- draw_h * aspect * page_h / page_w
    }
    grid::grid.raster(
      img,
      x = grid::unit(0.5, 'npc'), y = grid::unit(0.48, 'npc'),
      width = grid::unit(draw_w, 'npc'), height = grid::unit(draw_h, 'npc'),
      interpolate = TRUE
    )
    grid::grid.text(paste0('Source: Iowa AI Workforce Atlas generated figure file - ', basename(row$path)), x = 0.04, y = 0.035,
                    just = c('left', 'bottom'), gp = .pdf_gp(fontsize = 10, col = atlas_brand()$black))
    grid::grid.text(sprintf('%s of %s', i, nrow(figures)), x = 0.96, y = 0.035,
                    just = c('right', 'bottom'), gp = .pdf_gp(fontsize = 10, col = atlas_brand()$black))
  }

  TRUE
}

write_pdf_accessibility_checklist <- function(manifest, output_file = file.path(paths()$outputs, 'pdf_accessibility_checklist.csv')) {
  checklist <- tibble::tibble(
    area = c(
      'Document title and language',
      'Logical headings',
      'Code hidden from print PDF',
      'Tables have centered Figure titles and header rows',
      'Wide tables avoid clipping',
      'Figures have alternative text and captions in HTML source',
      'Color and contrast',
      'Tagged PDF attempt',
      'Manual accessibility review'
    ),
    status = c(
      'implemented in Quarto/R Markdown YAML and HTML source',
      'implemented with ordered section headings',
      'implemented with global echo = FALSE and print CSS',
      'implemented with centered Figure titles above summary, training, and files-created tables',
      'implemented with landscape print CSS, shorter labels, and wrapped cells',
      'implemented for report figures and public visualization appendix images',
      'improved with dark text on white background and high-contrast print rules',
      'attempted when local Chromium supports generateTaggedPDF and document outline options',
      'recommended for formal WCAG/PDF-UA signoff using an accessibility checker such as PAC, Acrobat, or equivalent'
    ),
    notes = c(
      'The HTML-to-PDF route preserves more semantics than the R-only PNG fallback.',
      'Headings support navigation in HTML and in tagged PDFs when browser support is available.',
      'This removes the repeated Code disclosure labels visible in earlier PDFs.',
      'Tables are real HTML tables rather than screenshots.',
      'The LWDA summary is transposed; training priorities are split into one table per LWDA.',
      'Alt text is generated from figure captions and intended audience metadata.',
      'Most public visualizations still use color; captions and labels provide context.',
      'Older Chrome versions may silently fall back to untagged PDF output.',
      'Automated generation cannot guarantee complete PDF/UA conformance without a final remediation pass.'
    )
  )
  readr::write_csv(checklist, output_file)
  invisible(checklist)
}

make_pdf_reports <- function(install_missing = TRUE,
                             build_if_missing = TRUE,
                             use_chrome = TRUE,
                             wait = 3) {
  setup_packages(install_optional = FALSE)
  .install_pdf_report_packages(install_missing = install_missing)

  p <- paths()
  fs::dir_create(p$outputs)

  quarto_html <- file.path(p$outputs, 'atlas_quarto.html')
  rmarkdown_html <- file.path(p$outputs, 'atlas_rmarkdown.html')

  if (isTRUE(build_if_missing) && (!file.exists(quarto_html) || !file.exists(rmarkdown_html))) {
    message('One or both HTML reports are missing. Rendering reports before PDF creation.')
    source(file.path(p$R, '06_render.R'))
    render_reports(refresh = FALSE, stop_on_error = FALSE, quiet = FALSE)
  }

  .sync_pdf_report_assets()
  figures <- get_pdf_figure_catalog()

  compendium_pdf <- file.path(p$outputs, 'all_generated_figures_printable.pdf')
  make_figure_compendium_pdf(
    output_pdf = compendium_pdf,
    title = 'Iowa AI Workforce Atlas - all generated figures',
    subtitle = 'Landscape PDF with core atlas figures and all public visualization figures.',
    figures = figures
  )

  render_one <- function(html_file, pdf_file, print_html_file, label) {
    unlink(c(pdf_file, print_html_file), force = TRUE)
    if (file.exists(html_file)) {
      .make_print_html_copy(html_file, print_html_file)
      method <- if (isTRUE(use_chrome)) .try_chrome_print_pdf(print_html_file, pdf_file, wait = wait) else NA_character_
      if (!is.na(method) && file.exists(pdf_file) && file.info(pdf_file)$size > 10000) {
        return(list(status = paste0('created_from_html_', method), file = pdf_file))
      }
    } else {
      warning('HTML report not found for ', label, ': ', html_file, call. = FALSE)
    }

    # Guaranteed fallback: a readable landscape PDF containing all generated figures.
    # The manifest records this as a degraded result so final validation does not
    # mistake a figure packet for the complete Quarto/R Markdown article PDF.
    fallback_ok <- make_figure_compendium_pdf(
      output_pdf = pdf_file,
      title = paste0('Iowa AI Workforce Atlas - ', label, ' PDF figure packet'),
      subtitle = paste0('Fallback PDF generated from figure files because browser-based printing was unavailable. ',
                        'The HTML report should still be reviewed at ', basename(html_file), '.'),
      figures = figures
    )
    list(status = if (fallback_ok) 'created_figure_packet_fallback' else 'failed', file = pdf_file)
  }

  quarto_pdf <- file.path(p$outputs, 'atlas_quarto_with_all_figures.pdf')
  rmarkdown_pdf <- file.path(p$outputs, 'atlas_rmarkdown_with_all_figures.pdf')
  quarto_print_html <- file.path(p$outputs, 'atlas_quarto_print.html')
  rmarkdown_print_html <- file.path(p$outputs, 'atlas_rmarkdown_print.html')

  q <- render_one(quarto_html, quarto_pdf, quarto_print_html, 'Quarto')
  r <- render_one(rmarkdown_html, rmarkdown_pdf, rmarkdown_print_html, 'R Markdown')

  manifest <- tibble::tibble(
    output = c('Quarto PDF', 'R Markdown PDF', 'All generated figures PDF', 'Quarto print HTML', 'R Markdown print HTML'),
    file = c(q$file, r$file, compendium_pdf, quarto_print_html, rmarkdown_print_html),
    status = c(q$status, r$status, ifelse(file.exists(compendium_pdf), 'created', 'failed'),
               ifelse(file.exists(quarto_print_html), 'created', 'not_created'),
               ifelse(file.exists(rmarkdown_print_html), 'created', 'not_created')),
    build_id = if (exists('v2_build_id', mode = 'function')) v2_build_id() else NA_character_,
    methodology_version = if (exists('load_methodology_v2_config', mode = 'function')) as.character(load_methodology_v2_config()$methodology_version) else NA_character_,
    generated_at = format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z')
  )
  readr::write_csv(manifest, file.path(p$outputs, 'pdf_report_manifest.csv'))
  write_pdf_accessibility_checklist(manifest, file.path(p$outputs, 'pdf_accessibility_checklist.csv'))

  message('PDF report outputs:')
  purrr::walk(manifest$file[file.exists(manifest$file)], ~message(' - ', .x))

  invisible(manifest)
}

if (sys.nframe() == 0) {
  make_pdf_reports(install_missing = TRUE, build_if_missing = TRUE, use_chrome = TRUE)
}
