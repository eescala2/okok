# Methodology v3 public-data acquisition and normalization

v3_census_api_key <- function(required = FALSE) {
  key <- trimws(Sys.getenv("CENSUS_API_KEY", unset = ""))
  if (!nzchar(key)) key <- trimws(Sys.getenv("IA_ATLAS_CENSUS_API_KEY", unset = ""))
  if (required && !nzchar(key)) {
    stop(
      "CENSUS_API_KEY is required for current QWI API calls. Store it in the user-level ~/.Renviron file; do not place it in project code.",
      call. = FALSE
    )
  }
  key
}

v3_bea_api_key <- function(required = FALSE) {
  key <- trimws(Sys.getenv("BEA_API_KEY", unset = ""))
  if (!nzchar(key)) key <- trimws(Sys.getenv("IA_ATLAS_BEA_API_KEY", unset = ""))
  if (required && !nzchar(key)) {
    stop(
      "BEA_API_KEY is required for the BEA API. Store it in the user-level ~/.Renviron file; do not place it in project code.",
      call. = FALSE
    )
  }
  key
}

v3_request_json <- function(url, query = list(), timeout_seconds = 120, retries = 3L) {
  req <- httr2::request(url) |>
    httr2::req_user_agent("Iowa-AI-Workforce-Atlas-Methodology-v3/3.1.3 public-research") |>
    httr2::req_timeout(timeout_seconds) |>
    httr2::req_retry(max_tries = retries)
  if (length(query)) req <- rlang::inject(httr2::req_url_query(req, !!!query))
  resp <- httr2::req_perform(req)
  httr2::resp_check_status(resp)
  body <- httr2::resp_body_raw(resp)
  if (!length(body)) return(list())
  text <- rawToChar(body)
  if (!nzchar(trimws(text))) return(list())
  jsonlite::fromJSON(text, simplifyVector = TRUE)
}

v3_download_file <- function(url, dest, refresh = FALSE, timeout_seconds = 300) {
  if (!nzchar(url)) return(FALSE)
  dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
  if (file.exists(dest) && !refresh && file.info(dest)$size > 0) return(TRUE)
  tmp <- paste0(dest, ".partial")
  unlink(tmp, force = TRUE)
  ok <- tryCatch({
    req <- httr2::request(url) |>
      httr2::req_user_agent("Iowa-AI-Workforce-Atlas-Methodology-v3/3.0 public-research") |>
      httr2::req_timeout(timeout_seconds) |>
      httr2::req_retry(max_tries = 3)
    resp <- httr2::req_perform(req)
    httr2::resp_check_status(resp)
    writeBin(httr2::resp_body_raw(resp), tmp)
    file.rename(tmp, dest)
  }, error = function(e) {
    warning("Download failed for ", url, ": ", conditionMessage(e), call. = FALSE)
    FALSE
  })
  if (!isTRUE(ok)) unlink(tmp, force = TRUE)
  isTRUE(ok) && file.exists(dest) && file.info(dest)$size > 0
}

v3_source_registry <- function(root = v3_project_root()) {
  v3_read_csv(file.path(root, "config", "v3_data_sources.csv"), required = TRUE)
}

v3_discover_download_links <- function(page_url, extensions = c("xlsx", "csv", "zip")) {
  txt <- tryCatch({
    req <- httr2::request(page_url) |>
      httr2::req_user_agent("Iowa-AI-Workforce-Atlas-Methodology-v3/3.0 public-research") |>
      httr2::req_timeout(60) |>
      httr2::req_retry(max_tries = 2)
    resp <- httr2::req_perform(req)
    httr2::resp_check_status(resp)
    httr2::resp_body_string(resp)
  }, error = function(e) "")
  if (!nzchar(txt)) return(character())
  hrefs <- unlist(regmatches(txt, gregexpr("(?i)href=[\"'][^\"']+[\"']", txt, perl = TRUE)))
  hrefs <- gsub("(?i)^href=[\"']|[\"']$", "", hrefs, perl = TRUE)
  pattern <- paste0("\\.(", paste(extensions, collapse = "|"), ")(\\?|$)")
  hrefs <- hrefs[grepl(pattern, hrefs, ignore.case = TRUE)]
  hrefs <- ifelse(grepl("^https?://", hrefs), hrefs,
                  ifelse(startsWith(hrefs, "/"), paste0("https://www.census.gov", hrefs),
                         paste0(sub("/[^/]*$", "/", page_url), hrefs)))
  unique(hrefs)
}

v3_is_btos_data_file <- function(path) {
  if (!length(path)) return(logical())
  path <- as.character(path)
  base <- tolower(basename(path))
  ext_ok <- grepl("\\.(xlsx|xls|csv|zip)$", base, perl = TRUE)
  name_ok <- grepl("btos|business.*trends|ai.*supplement", base, perl = TRUE)
  helper_file <- grepl(
    "template|crosswalk|dictionary|lookup|inventory|schema|readme|manifest|config|example|hotfix|patch|atlas|installer",
    base,
    perl = TRUE
  )
  ext_ok & name_ok & !helper_file
}

v3_btos_local_files <- function(paths = v3_paths()) {
  dirs <- unique(c(
    paths$raw,
    file.path(paths$root, "data_raw", "btos"),
    paths$inputs,
    path.expand("~/Downloads")
  ))
  dirs <- dirs[dir.exists(dirs)]
  files <- unlist(lapply(dirs, function(d) {
    list.files(
      d,
      pattern = "(?i)\\.(xlsx|xls|csv|zip)$",
      full.names = TRUE,
      recursive = FALSE
    )
  }), use.names = FALSE)
  files <- unique(as.character(files[file.exists(files)]))
  files[v3_is_btos_data_file(files)]
}

v3_json_to_tibble <- function(x, preferred = c("data", "results", "records", "items", "periods"), depth = 0L) {
  if (is.null(x) || depth > 8L) return(tibble::tibble())
  if (is.data.frame(x)) return(tibble::as_tibble(x))
  if (is.matrix(x)) return(tibble::as_tibble(as.data.frame(x, stringsAsFactors = FALSE)))
  if (!is.list(x)) return(tibble::tibble())

  nms <- names(x)
  if (length(nms)) {
    for (nm in intersect(preferred, nms)) {
      out <- v3_json_to_tibble(x[[nm]], preferred, depth + 1L)
      if (nrow(out)) return(out)
    }
    scalar_record <- all(vapply(x, function(z) is.null(z) || length(z) <= 1L || is.atomic(z), logical(1)))
    if (scalar_record) {
      return(tibble::as_tibble(as.data.frame(x, stringsAsFactors = FALSE, optional = TRUE)))
    }
  }

  rows <- lapply(x, function(z) {
    if (is.data.frame(z)) return(tibble::as_tibble(z))
    if (is.list(z) && length(names(z))) {
      flat <- lapply(z, function(value) {
        if (is.null(value)) return(NA_character_)
        if (is.atomic(value) && length(value) <= 1L) return(value)
        jsonlite::toJSON(value, auto_unbox = TRUE, null = "null", na = "null")
      })
      return(tibble::as_tibble(as.data.frame(flat, stringsAsFactors = FALSE, optional = TRUE)))
    }
    tibble::tibble()
  })
  rows <- rows[vapply(rows, nrow, integer(1)) > 0L]
  if (!length(rows)) return(tibble::tibble())
  dplyr::bind_rows(rows)
}

v3_btos_period_metadata <- function(periods) {
  if (!nrow(periods)) return(tibble::tibble())
  periods <- v3_clean_names(periods)
  nms <- names(periods)
  id_col <- v3_first_existing(nms, c(
    "period_id", "periodid", "period", "id", "period_code", "periodcode",
    "period_number", "name"
  ))
  if (is.na(id_col)) return(tibble::tibble())
  start_col <- v3_first_existing(nms, c(
    "collection_period_start", "period_start", "start_date", "collection_start_date",
    "reference_period_start", "start"
  ))
  end_col <- v3_first_existing(nms, c(
    "collection_period_end", "period_end", "end_date", "collection_end_date",
    "reference_period_end", "end"
  ))
  out <- periods |>
    dplyr::mutate(
      btos_period_id = trimws(as.character(.data[[id_col]])),
      period_start = if (!is.na(start_col)) as.character(.data[[start_col]]) else NA_character_,
      period_end = if (!is.na(end_col)) as.character(.data[[end_col]]) else NA_character_
    ) |>
    dplyr::filter(nzchar(.data$btos_period_id)) |>
    dplyr::distinct(.data$btos_period_id, .keep_all = TRUE)
  out$period_sort_numeric <- suppressWarnings(v3_as_numeric(out$btos_period_id))
  out |>
    dplyr::arrange(dplyr::desc(.data$period_sort_numeric), dplyr::desc(.data$btos_period_id))
}

v3_btos_join_lookup <- function(data, lookup) {
  if (!nrow(data) || !nrow(lookup)) return(data)
  data <- v3_clean_names(data)
  lookup <- v3_clean_names(lookup)
  keys <- intersect(
    c("question_id", "question_code", "question_number", "answer_id", "answer_code", "response_id"),
    intersect(names(data), names(lookup))
  )
  if (!length(keys)) return(data)
  lookup <- lookup |> dplyr::distinct(dplyr::across(dplyr::all_of(keys)), .keep_all = TRUE)
  tryCatch(dplyr::left_join(data, lookup, by = keys, suffix = c("", "_lookup")), error = function(e) data)
}

v3_download_btos_api <- function(refresh = FALSE, paths = v3_paths()) {
  dir <- file.path(paths$raw, "btos")
  dir.create(dir, recursive = TRUE, showWarnings = FALSE)
  base <- sub("/+$", "", Sys.getenv(
    "IA_ATLAS_BTOS_API_BASE",
    unset = "https://www.census.gov/hfp/btos/api"
  ))

  periods_raw <- tryCatch(
    v3_request_json(paste0(base, "/periods"), timeout_seconds = 90, retries = 3L),
    error = function(e) {
      warning("BTOS periods API request failed: ", conditionMessage(e), call. = FALSE)
      list()
    }
  )
  periods <- v3_btos_period_metadata(v3_json_to_tibble(periods_raw))
  if (!nrow(periods)) return(character())
  max_periods <- suppressWarnings(as.integer(Sys.getenv("IA_ATLAS_BTOS_PERIODS", unset = "24")))
  if (!is.finite(max_periods) || max_periods < 1L) max_periods <- 24L
  periods <- utils::head(periods, max_periods)
  state_code <- toupper(trimws(Sys.getenv("IA_ATLAS_BTOS_STATE", unset = "IA")))
  if (!nzchar(state_code)) state_code <- "IA"

  lookup <- tryCatch(
    v3_json_to_tibble(v3_request_json(paste0(base, "/questions/answers"), timeout_seconds = 90, retries = 2L)),
    error = function(e) tibble::tibble()
  )
  if (nrow(lookup)) {
    lookup <- v3_clean_names(lookup)
    lookup[] <- lapply(lookup, function(z) {
      if (is.list(z)) vapply(z, function(v) jsonlite::toJSON(v, auto_unbox = TRUE, null = "null", na = "null"), character(1)) else z
    })
    v3_write_csv(lookup, file.path(dir, "btos_api_question_answer_lookup.csv"))
  }

  downloaded <- character()
  for (i in seq_len(nrow(periods))) {
    id <- periods$btos_period_id[[i]]
    safe_id <- gsub("[^A-Za-z0-9_-]+", "_", id)
    dest <- file.path(dir, paste0("btos_api_period_", safe_id, "_state_", state_code, ".csv"))
    if (file.exists(dest) && !refresh && file.info(dest)$size > 0L) {
      downloaded <- c(downloaded, dest)
      next
    }
    endpoints <- c(
      paste0(base, "/periods/", utils::URLencode(id, reserved = TRUE), "/data/state/", state_code),
      paste0(base, "/periods/", utils::URLencode(id, reserved = TRUE), "/data")
    )
    table <- tibble::tibble(); endpoint_used <- NA_character_
    for (endpoint in endpoints) {
      candidate <- tryCatch(v3_json_to_tibble(v3_request_json(endpoint, timeout_seconds = 120, retries = 2L)), error = function(e) tibble::tibble())
      if (nrow(candidate)) { table <- candidate; endpoint_used <- endpoint; break }
    }
    if (!nrow(table)) next
    table <- v3_clean_names(table)
    table <- v3_btos_join_lookup(table, lookup)
    if (!"btos_period_id" %in% names(table)) table$btos_period_id <- id
    if (!"period_end" %in% names(table)) table$period_end <- periods$period_end[[i]]
    if (!"period_start" %in% names(table)) table$period_start <- periods$period_start[[i]]
    table$btos_api_endpoint <- endpoint_used
    table[] <- lapply(table, function(z) {
      if (is.list(z)) vapply(z, function(v) jsonlite::toJSON(v, auto_unbox = TRUE, null = "null", na = "null"), character(1)) else z
    })
    v3_write_csv(table, dest)
    if (file.exists(dest) && file.info(dest)$size > 0L) downloaded <- c(downloaded, dest)
  }
  if (nrow(periods)) v3_write_csv(periods, file.path(dir, "btos_api_period_inventory.csv"))
  unique(downloaded)
}


v3_download_btos <- function(refresh = FALSE, paths = v3_paths()) {
  dir <- file.path(paths$raw, "btos")
  dir.create(dir, recursive = TRUE, showWarnings = FALSE)
  env_urls <- c(
    ai_supplement = Sys.getenv("IA_ATLAS_BTOS_AI_SUPPLEMENT_URL", unset = ""),
    state = Sys.getenv("IA_ATLAS_BTOS_STATE_URL", unset = ""),
    sector_size = Sys.getenv("IA_ATLAS_BTOS_SECTOR_SIZE_URL", unset = "")
  )
  downloaded <- character()
  for (nm in names(env_urls)) {
    url <- env_urls[[nm]]
    if (!nzchar(url)) next
    ext <- tools::file_ext(sub("\\?.*$", "", url)); if (!nzchar(ext)) ext <- "xlsx"
    dest <- file.path(dir, paste0("btos_", nm, ".", ext))
    if (v3_download_file(url, dest, refresh = refresh)) downloaded <- c(downloaded, dest)
  }

  # The public downloads application is JavaScript-rendered. Use the official
  # BTOS API first; static-link discovery is only a backwards-compatible fallback.
  api_files <- v3_download_btos_api(refresh = refresh, paths = paths)
  downloaded <- c(downloaded, api_files)
  if (!length(downloaded)) {
    links <- v3_discover_download_links("https://www.census.gov/hfp/btos/data_downloads")
    if (length(links)) {
      score <- function(x) {
        z <- tolower(x)
        100 * grepl("supplement|ai", z) + 20 * grepl("state", z) + 10 * grepl("size", z) + 5 * grepl("sector", z)
      }
      links <- head(links[order(vapply(links, score, numeric(1)), decreasing = TRUE)], 8L)
      for (i in seq_along(links)) {
        ext <- tools::file_ext(sub("\\?.*$", "", links[[i]])); if (!nzchar(ext)) ext <- "xlsx"
        dest <- file.path(dir, sprintf("btos_discovered_%02d.%s", i, ext))
        if (v3_download_file(links[[i]], dest, refresh = refresh)) downloaded <- c(downloaded, dest)
      }
    }
  }
  unique(c(downloaded, v3_btos_local_files(paths)))
}

v3_scan_excel_header <- function(path, sheet, max_skip = 20L) {
  best <- NULL; best_score <- -Inf
  for (skip in 0:max_skip) {
    x <- tryCatch(readxl::read_excel(path, sheet = sheet, skip = skip, n_max = 10000, .name_repair = "unique_quiet"), error = function(e) NULL)
    if (is.null(x) || ncol(x) < 2L) next
    x <- v3_clean_names(as.data.frame(x))
    nms <- names(x)
    score <- sum(grepl("date|period|state|sector|naics|size|estimate|percent|rate|artificial|ai|question|variable", nms, ignore.case = TRUE)) + log1p(nrow(x))
    if (score > best_score) { best <- x; best_score <- score }
  }
  best %||% data.frame()
}

v3_btos_tab_record <- function(data, sheet = NA_character_, source_file = NA_character_) {
  if (is.null(data)) return(NULL)
  if (!is.data.frame(data)) {
    data <- tryCatch(as.data.frame(data, stringsAsFactors = FALSE), error = function(e) NULL)
  }
  if (is.null(data)) return(NULL)

  sheet <- as.character(sheet %||% NA_character_)
  if (!length(sheet) || is.na(sheet[[1]]) || !nzchar(sheet[[1]])) sheet <- "table"
  source_file <- as.character(source_file %||% NA_character_)
  if (!length(source_file)) source_file <- NA_character_

  list(
    data = v3_clean_names(data),
    sheet = sheet[[1]],
    source_file = source_file[[1]]
  )
}

v3_read_tabular_file <- function(path) {
  path <- as.character(path)[[1]]
  ext <- tolower(tools::file_ext(path))

  if (ext == "csv") {
    x <- tryCatch(
      readr::read_csv(path, show_col_types = FALSE),
      error = function(e) NULL
    )
    rec <- v3_btos_tab_record(x, sheet = "csv", source_file = path)
    return(if (is.null(rec)) list() else list(rec))
  }

  if (ext %in% c("xlsx", "xls")) {
    sheets <- tryCatch(readxl::excel_sheets(path), error = function(e) character())
    out <- lapply(sheets, function(s) {
      v3_btos_tab_record(
        v3_scan_excel_header(path, s),
        sheet = s,
        source_file = path
      )
    })
    keep <- vapply(out, function(z) {
      is.list(z) && is.data.frame(z$data) && nrow(z$data) > 0L
    }, logical(1))
    return(out[keep])
  }

  if (ext == "zip") {
    exdir <- tempfile("btos_zip_")
    dir.create(exdir, recursive = TRUE, showWarnings = FALSE)
    on.exit(unlink(exdir, recursive = TRUE, force = TRUE), add = TRUE)
    ok <- tryCatch({
      utils::unzip(path, exdir = exdir)
      TRUE
    }, error = function(e) FALSE)
    if (!ok) return(list())
    nested <- list.files(
      exdir,
      pattern = "(?i)\\.(xlsx|xls|csv)$",
      full.names = TRUE,
      recursive = TRUE
    )
    return(unlist(lapply(nested, v3_read_tabular_file), recursive = FALSE))
  }

  list()
}

v3_first_existing <- function(nms, candidates) {
  hit <- intersect(candidates, nms)
  if (length(hit)) hit[[1]] else NA_character_
}

v3_btos_crosswalk <- function(root = v3_project_root()) {
  actual <- file.path(root, "inputs", "btos_variable_crosswalk.csv")
  template <- file.path(root, "inputs", "btos_variable_crosswalk_template.csv")
  x <- v3_read_csv(if (file.exists(actual)) actual else template)
  v3_drop_example_rows(x)
}

v3_normalize_btos_table <- function(x, source_file, sheet, root = v3_project_root()) {
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(as.data.frame(x))
  nms <- names(x)
  date_candidates <- c("collection_period_end", "collection_end_date", "reference_period_end", "reference_period", "period_end", "end_date", "survey_end_date", "reference_date", "date")
  metric_candidates <- c("question_text", "question_description", "question_label", "question_name", "question_lookup", "question", "variable", "series", "item", "metric", "question_code")
  response_candidates <- c("answer_text", "answer_description", "answer_label", "answer_lookup", "response", "response_category", "category", "answer")
  estimate_candidates <- c("estimate_value", "percentage_estimate", "percent_estimate", "proportion_estimate", "estimate", "pct", "est", "value", "rate", "percent", "percentage")
  se_candidates <- c("standard_error", "standard_error_estimate", "estimate_se", "se")
  moe_candidates <- c("margin_of_error", "margin_error", "estimate_moe", "moe")
  denominator_candidates <- c("denominator", "sample_size", "weighted_count", "unweighted_count", "n")
  id_candidates <- unique(na.omit(c(
    v3_first_existing(nms, date_candidates),
    v3_first_existing(nms, c("state_fips", "state", "state_code", "geography_code")),
    v3_first_existing(nms, c("state_name", "geography_name", "geography", "geo_name", "name")),
    v3_first_existing(nms, c("naics2", "naics", "sector", "industry", "industry_code")),
    v3_first_existing(nms, c("employment_size_class", "size_class", "firmsize", "employment_size")),
    v3_first_existing(nms, c("business_function", "function", "business_function_name")),
    v3_first_existing(nms, metric_candidates),
    v3_first_existing(nms, response_candidates),
    v3_first_existing(nms, estimate_candidates),
    v3_first_existing(nms, se_candidates),
    v3_first_existing(nms, moe_candidates),
    v3_first_existing(nms, denominator_candidates)
  )))

  metric_col <- v3_first_existing(nms, metric_candidates)
  estimate_col <- v3_first_existing(nms, estimate_candidates)
  if (!is.na(metric_col) && !is.na(estimate_col)) {
    long <- x
    long$raw_variable <- as.character(long[[metric_col]])
    long$raw_value <- long[[estimate_col]]
  } else {
    value_cols <- setdiff(nms, id_candidates)
    value_cols <- value_cols[vapply(x[value_cols], function(z) is.numeric(z) || any(is.finite(v3_as_numeric(z))), logical(1))]
    if (!length(value_cols)) return(tibble::tibble())
    long <- tidyr::pivot_longer(tibble::as_tibble(x), cols = dplyr::all_of(value_cols), names_to = "raw_variable", values_to = "raw_value")
  }

  date_col <- v3_first_existing(names(long), date_candidates)
  state_col <- v3_first_existing(names(long), c("state_fips", "state", "state_code", "geography_code"))
  geo_col <- v3_first_existing(names(long), c("state_name", "geography_name", "geography", "geo_name", "name"))
  naics_col <- v3_first_existing(names(long), c("naics2", "naics", "sector", "industry", "industry_code"))
  size_col <- v3_first_existing(names(long), c("employment_size_class", "size_class", "firmsize", "employment_size"))
  function_col <- v3_first_existing(names(long), c("business_function", "function", "business_function_name"))
  response_col <- v3_first_existing(names(long), response_candidates)
  se_col <- v3_first_existing(names(long), se_candidates)
  moe_col <- v3_first_existing(names(long), moe_candidates)
  n_col <- v3_first_existing(names(long), denominator_candidates)

  out <- tibble::tibble(
    period_end = if (!is.na(date_col)) as.character(long[[date_col]]) else NA_character_,
    state_fips = if (!is.na(state_col)) stringr::str_pad(gsub("\\D", "", as.character(long[[state_col]])), 2, pad = "0") else NA_character_,
    geography_name = if (!is.na(geo_col)) as.character(long[[geo_col]]) else NA_character_,
    naics2 = if (!is.na(naics_col)) v3_normalize_naics2(long[[naics_col]]) else NA_character_,
    employment_size_class = if (!is.na(size_col)) as.character(long[[size_col]]) else NA_character_,
    business_function = if (!is.na(function_col)) as.character(long[[function_col]]) else NA_character_,
    response_category = if (!is.na(response_col)) as.character(long[[response_col]]) else NA_character_,
    raw_variable = as.character(long$raw_variable),
    raw_value = v3_as_numeric(long$raw_value),
    supplied_se = if (!is.na(se_col)) v3_as_numeric(long[[se_col]]) else NA_real_,
    supplied_moe = if (!is.na(moe_col)) v3_as_numeric(long[[moe_col]]) else NA_real_,
    denominator = if (!is.na(n_col)) v3_as_numeric(long[[n_col]]) else NA_real_,
    source_file = basename(source_file),
    source_sheet = sheet
  )

  # For category-response API tables, only affirmative categories represent the
  # reported AI-use share. Retain unknown categories for audit, but invalidate
  # explicit negative/not-applicable categories for the canonical AI measures.
  response_key <- tolower(trimws(out$response_category))
  affirmative <- is.na(response_key) | response_key == "" | grepl("^(yes|currently using|expect.*use|used|1)$", response_key, perl = TRUE)

  crosswalk <- v3_btos_crosswalk(root)
  if (nrow(crosswalk)) {
    crosswalk <- crosswalk |>
      dplyr::mutate(raw_variable_key = tolower(trimws(.data$raw_variable))) |>
      dplyr::select(-.data$raw_variable)
    out <- out |>
      dplyr::mutate(raw_variable_key = tolower(trimws(.data$raw_variable))) |>
      dplyr::left_join(crosswalk, by = "raw_variable_key")
  } else {
    out$raw_variable_key <- tolower(trimws(out$raw_variable))
    out$canonical_metric <- NA_character_; out$declared_scale <- NA_real_
  }

  metric_defs <- v3_read_csv(file.path(root, "config", "v3_adoption_metrics.csv"), required = TRUE)
  for (i in seq_len(nrow(metric_defs))) {
    idx <- is.na(out$canonical_metric) & grepl(metric_defs$regex[[i]], out$raw_variable, perl = TRUE)
    out$canonical_metric[idx] <- metric_defs$canonical_metric[[i]]
    out$declared_scale[idx] <- metric_defs$declared_scale[[i]]
  }
  out$declared_scale <- v3_as_numeric(out$declared_scale)
  out$estimate <- ifelse(is.finite(out$declared_scale) & out$declared_scale > 0, out$raw_value / out$declared_scale, NA_real_)
  out$standard_error <- ifelse(
    is.finite(out$supplied_se),
    out$supplied_se / ifelse(is.finite(out$declared_scale), out$declared_scale, 1),
    ifelse(is.finite(out$supplied_moe), out$supplied_moe / 1.96 / ifelse(is.finite(out$declared_scale), out$declared_scale, 1), NA_real_)
  )
  out$schema_valid <- is.na(out$canonical_metric) | (
    affirmative & is.finite(out$estimate) & out$estimate >= 0 & out$estimate <= 1
  )
  out
}

v3_empty_btos_normalized <- function() {
  tibble::tibble(
    period_end = character(),
    state_fips = character(),
    geography_name = character(),
    naics2 = character(),
    employment_size_class = character(),
    business_function = character(),
    response_category = character(),
    raw_variable = character(),
    raw_value = double(),
    supplied_se = double(),
    supplied_moe = double(),
    denominator = double(),
    source_file = character(),
    source_sheet = character(),
    raw_variable_key = character(),
    canonical_metric = character(),
    declared_scale = double(),
    estimate = double(),
    standard_error = double(),
    schema_valid = logical()
  )
}

v3_as_btos_tab_record <- function(tab, index = 1L, source_file = NA_character_) {
  # Backward compatibility with the original CSV reader, which returned a
  # single named list rather than a list of table records.
  if (is.data.frame(tab)) {
    return(v3_btos_tab_record(
      tab,
      sheet = sprintf("table_%02d", as.integer(index)),
      source_file = source_file
    ))
  }
  if (!is.list(tab) || is.null(tab$data)) return(NULL)
  v3_btos_tab_record(
    tab$data,
    sheet = tab$sheet %||% sprintf("table_%02d", as.integer(index)),
    source_file = tab$source_file %||% source_file
  )
}

v3_normalize_btos <- function(files, paths = v3_paths()) {
  files <- unique(as.character(files))
  files <- files[nzchar(files) & file.exists(files)]
  files <- files[v3_is_btos_data_file(files)]

  inventory <- tibble::tibble(
    file = normalizePath(files, winslash = "/", mustWork = FALSE),
    filename = basename(files),
    eligible_btos_data = v3_is_btos_data_file(files)
  )
  v3_write_csv(inventory, file.path(paths$outputs, "btos_input_inventory_v3.csv"))

  pieces <- list()
  for (path in files) {
    tabs <- tryCatch(
      v3_read_tabular_file(path),
      error = function(e) {
        warning(
          "Could not read BTOS file ", basename(path), ": ",
          conditionMessage(e),
          call. = FALSE
        )
        list()
      }
    )

    # Normalize the old one-table named-list shape if encountered in an
    # already-loaded session or a locally customized reader.
    if (is.list(tabs) && all(c("data", "sheet") %in% names(tabs))) {
      tabs <- list(tabs)
    }
    if (!length(tabs)) next

    for (i in seq_along(tabs)) {
      tab <- v3_as_btos_tab_record(tabs[[i]], i, path)
      if (is.null(tab)) {
        warning(
          "Skipping malformed BTOS table record in ", basename(path),
          " at index ", i, ".",
          call. = FALSE
        )
        next
      }
      sheet_label <- as.character(tab$sheet %||% sprintf("table_%02d", i))[[1]]
      z <- tryCatch(
        v3_normalize_btos_table(tab$data, path, sheet_label, paths$root),
        error = function(e) {
          warning(
            "Could not normalize BTOS table ", basename(path), " / ",
            sheet_label, ": ", conditionMessage(e),
            call. = FALSE
          )
          v3_empty_btos_normalized()
        }
      )
      if (nrow(z)) pieces[[length(pieces) + 1L]] <- z
    }
  }

  out <- if (length(pieces)) {
    dplyr::bind_rows(pieces)
  } else {
    v3_empty_btos_normalized()
  }
  v3_write_csv(out, file.path(paths$processed, "btos_ai_normalized.csv"))
  out
}

v3_qwi_query <- function(year, quarter, agegrp, industry, key, state_fips = "19") {
  # Current Sex-by-Age endpoint contract. Firm age and firm size are omitted:
  # Census permits only one at a time and only with private ownership A05,
  # whereas this analysis requests all ownership A00.
  get_vars <- c(
    "Emp", "EmpS", "HirA", "HirN", "Sep", "EarnS", "EarnHirAS",
    "FrmJbGn", "FrmJbLs", "year", "quarter", "industry", "agegrp"
  )
  query <- list(
    get = paste(get_vars, collapse = ","),
    `for` = paste0("state:", state_fips),
    time = paste0(year, "-Q", quarter),
    industry = industry,
    agegrp = agegrp,
    sex = "0",
    ownercode = "A00",
    seasonadj = "U",
    periodicity = "Q",
    key = key
  )
  raw <- v3_request_json(
    "https://api.census.gov/data/timeseries/qwi/sa",
    query = query,
    timeout_seconds = 90,
    retries = 2L
  )
  if (length(raw) < 2L) return(tibble::tibble())
  hdr <- unlist(raw[[1]], use.names = FALSE)
  vals <- do.call(rbind, raw[-1])
  out <- as.data.frame(vals, stringsAsFactors = FALSE); names(out) <- hdr
  v3_clean_names(out)
}

v3_download_qwi_early_career <- function(refresh = FALSE, paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  out_path <- file.path(paths$processed, "qwi_early_career_iowa.csv")
  if (file.exists(out_path) && !refresh) return(v3_read_csv(out_path))
  key <- v3_census_api_key(required = FALSE)
  if (!nzchar(key)) {
    warning("CENSUS_API_KEY is absent; Methodology v3 cannot refresh QWI early-career data. A local normalized file may still be used.", call. = FALSE)
    local <- file.path(paths$inputs, "qwi_early_career_manual.csv")
    return(if (file.exists(local)) v3_read_csv(local) else tibble::tibble())
  }
  age_cfg <- v3_read_csv(file.path(paths$config, "v3_early_career_age_groups.csv"), required = TRUE)
  age_groups <- unique(age_cfg$agegrp)
  industries <- sprintf("%02d", c(11, 21, 22, 23, 31:33, 42, 44:45, 48:49, 51:56, 61:62, 71:72, 81, 92))
  start_idx <- v3_quarter_index(cfg$early_career$pre_start %||% "2019-Q1")
  now <- as.POSIXlt(Sys.Date())
  end_idx <- (now$year + 1900L) * 4L + max(1L, min(4L, ((now$mon + 1L) - 1L) %/% 3L + 1L)) - 2L
  quarters <- v3_quarter_label(seq.int(start_idx, end_idx))
  pieces <- list(); k <- 0L
  for (period in quarters) {
    yr <- as.integer(substr(period, 1, 4)); q <- as.integer(sub(".*Q", "", period))
    for (industry in industries) {
      for (agegrp in age_groups) {
        z <- tryCatch(v3_qwi_query(yr, q, agegrp, industry, key, cfg$state_fips %||% "19"), error = function(e) tibble::tibble())
        if (nrow(z)) { k <- k + 1L; pieces[[k]] <- z }
        Sys.sleep(0.03)
      }
    }
  }
  out <- if (length(pieces)) dplyr::bind_rows(pieces) else tibble::tibble()
  if (nrow(out)) {
    numeric_cols <- intersect(c("emp", "emp_s", "hir_a", "hir_n", "sep", "earn_s", "earn_hir_as", "frm_jb_gn", "frm_jb_ls"), names(out))
    out <- out |>
      dplyr::mutate(
        dplyr::across(dplyr::all_of(numeric_cols), v3_as_numeric),
        naics2 = v3_normalize_naics2(industry),
        period = paste0(year, "-Q", quarter),
        period_index = v3_quarter_index(period),
        source = "Census QWI Sex by Age API"
      )
    v3_write_csv(out, out_path)
  } else {
    warning("QWI early-career API queries returned no usable records. Methodology v3 will mark early-career results unavailable unless a local normalized file is supplied.", call. = FALSE)
  }
  out
}

v3_bea_api_call <- function(method = "GetData", dataset, params = list(), key = v3_bea_api_key(FALSE)) {
  if (!nzchar(key)) return(list())
  query <- c(list(UserID = key, method = method, DataSetName = dataset, ResultFormat = "JSON"), params)
  v3_request_json("https://apps.bea.gov/api/data", query = query, timeout_seconds = 180, retries = 3)
}

v3_bea_extract_data <- function(x) {
  if (!length(x)) return(tibble::tibble())
  candidates <- list(
    x$BEAAPI$Results$Data,
    x$BEAAPI$Results$ParamValue,
    x$BEAAPI$Results$Parameter,
    x$BEAAPI$Results$Dataset
  )
  for (z in candidates) {
    if (!is.null(z) && length(z)) return(v3_clean_names(as.data.frame(z, stringsAsFactors = FALSE)))
  }
  tibble::tibble()
}

v3_bea_parameter_values <- function(dataset, parameter_name, key = v3_bea_api_key(FALSE)) {
  v3_bea_extract_data(v3_bea_api_call("GetParameterValues", dataset, list(ParameterName = parameter_name), key))
}

v3_download_bea_inputs <- function(refresh = FALSE, paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  io_path <- file.path(paths$processed, "bea_input_output_raw.csv")
  regional_path <- file.path(paths$processed, "bea_iowa_regional_raw.csv")
  if (!refresh && file.exists(io_path) && file.exists(regional_path)) {
    return(list(io = v3_read_csv(io_path), regional = v3_read_csv(regional_path)))
  }
  key <- v3_bea_api_key(FALSE)
  if (!nzchar(key)) {
    warning("BEA_API_KEY is absent; regional value capture will use only local normalized multipliers and explicit scenario assumptions.", call. = FALSE)
    normalized <- file.path(paths$inputs, "bea_total_requirements_normalized.csv")
    template <- file.path(paths$inputs, "bea_total_requirements_normalized_template.csv")
    return(list(io = if (file.exists(normalized)) v3_read_csv(normalized) else v3_drop_example_rows(v3_read_csv(template)), regional = tibble::tibble()))
  }

  table_id <- as.character(cfg$value_capture$default_io_table_id %||% "56")
  years <- v3_bea_parameter_values("InputOutput", "Year", key)
  year_col <- intersect(c("key", "param_value", "year"), names(years))
  year <- if (length(year_col)) suppressWarnings(max(v3_as_numeric(years[[year_col[[1]]]]), na.rm = TRUE)) else NA_real_
  if (!is.finite(year)) year <- as.integer(format(Sys.Date(), "%Y")) - 2L
  io <- v3_bea_extract_data(v3_bea_api_call("GetData", "InputOutput", list(TableID = table_id, Year = as.character(year)), key))
  if (nrow(io)) v3_write_csv(io, io_path)

  # Regional tables are retrieved through published table names. Failures are nonfatal and visible.
  table_names <- c("CAGDP2", "CAINC1", "CAEMP25N")
  regional <- list()
  for (tab in table_names) {
    z <- tryCatch(v3_bea_extract_data(v3_bea_api_call("GetData", "Regional", list(TableName = tab, LineCode = "ALL", GeoFIPS = "STATE", Year = "LATEST"), key)), error = function(e) tibble::tibble())
    if (nrow(z)) { z$table_name_requested <- tab; regional[[length(regional) + 1L]] <- z }
  }
  regional <- if (length(regional)) dplyr::bind_rows(regional) else tibble::tibble()
  if (nrow(regional)) v3_write_csv(regional, regional_path)
  list(io = io, regional = regional)
}

v3_download_htops_benchmark <- function(refresh = FALSE, paths = v3_paths()) {
  url <- Sys.getenv("IA_ATLAS_HTOPS_TABLE_URL", unset = "")
  dest <- file.path(paths$raw, "htops", "htops_ai_work_table.xlsx")
  if (nzchar(url)) v3_download_file(url, dest, refresh = refresh)
  local <- c(dest, file.path(paths$inputs, "htops_ai_benchmark_normalized.csv"))
  local <- local[file.exists(local)]
  if (!length(local)) return(tibble::tibble())
  if (grepl("\\.csv$", local[[1]], ignore.case = TRUE)) return(v3_read_csv(local[[1]]))
  tabs <- v3_read_tabular_file(local[[1]])
  if (!length(tabs)) return(tibble::tibble())
  dplyr::bind_rows(lapply(tabs, function(z) {
    x <- z$data; x$source_sheet <- z$sheet; x
  }))
}

v3_refresh_public_inputs <- function(refresh = FALSE, paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  v3_ensure_directories(paths)
  btos_files <- v3_download_btos(refresh, paths)
  btos <- v3_normalize_btos(btos_files, paths)
  qwi <- v3_download_qwi_early_career(refresh, paths, cfg)
  bea <- v3_download_bea_inputs(refresh, paths, cfg)
  htops <- v3_download_htops_benchmark(refresh, paths)

  btos_usable <- if (nrow(btos) && all(c("canonical_metric", "schema_valid", "estimate") %in% names(btos))) {
    sum(
      btos$schema_valid %in% TRUE &
        btos$canonical_metric %in% c("current_ai_use", "expected_ai_use_6m") &
        is.finite(btos$estimate),
      na.rm = TRUE
    )
  } else 0L
  has_census_key <- nzchar(v3_census_api_key(FALSE))
  has_bea_key <- nzchar(v3_bea_api_key(FALSE))
  has_htops_config <- nzchar(Sys.getenv("IA_ATLAS_HTOPS_TABLE_URL", unset = "")) ||
    file.exists(file.path(paths$inputs, "htops_ai_benchmark_normalized.csv"))

  source <- c("BTOS", "QWI early career", "BEA Input-Output", "BEA Regional", "HTOPS benchmark")
  rows <- c(nrow(btos), nrow(qwi), nrow(bea$io), nrow(bea$regional), nrow(htops))
  usable_rows <- c(btos_usable, nrow(qwi), nrow(bea$io), nrow(bea$regional), nrow(htops))
  configured <- c(
    TRUE,
    has_census_key || file.exists(file.path(paths$inputs, "qwi_early_career_manual.csv")),
    has_bea_key || file.exists(file.path(paths$inputs, "bea_total_requirements_normalized.csv")),
    has_bea_key,
    has_htops_config
  )
  status_code <- c(
    if (btos_usable > 0L) "available" else if (length(btos_files)) "downloaded_but_no_usable_ai_rows" else "download_failed_or_not_cached",
    if (nrow(qwi)) "available" else if (!configured[[2]]) "not_configured" else "request_failed_or_no_usable_rows",
    if (nrow(bea$io)) "available" else if (!configured[[3]]) "not_configured" else "request_failed_or_no_usable_rows",
    if (nrow(bea$regional)) "available" else if (!configured[[4]]) "not_configured" else "request_failed_or_no_usable_rows",
    if (nrow(htops)) "available" else if (!configured[[5]]) "optional_not_configured" else "download_failed_or_no_usable_rows"
  )
  diagnostic <- c(
    if (btos_usable > 0L) "Official BTOS API/download records normalized to current or expected AI-use metrics."
    else if (length(btos_files)) "BTOS files were retrieved, but no schema-valid current/expected AI-use estimates were recognized; inspect btos_input_inventory_v3.csv and the crosswalk."
    else "No BTOS cache or API result was available. The JavaScript downloads page is not treated as proof that the public data are absent.",
    if (nrow(qwi)) "QWI sex-by-age records available."
    else if (!configured[[2]]) "CENSUS_API_KEY and qwi_early_career_manual.csv are both absent."
    else "The QWI source was configured but returned no usable records; inspect network/API diagnostics and quarter availability.",
    if (nrow(bea$io)) "BEA Input-Output rows available."
    else if (!configured[[3]]) "BEA_API_KEY and a normalized local multiplier table are both absent."
    else "BEA Input-Output was configured but produced no usable rows.",
    if (nrow(bea$regional)) "BEA Regional rows available."
    else if (!configured[[4]]) "BEA_API_KEY is absent."
    else "BEA Regional was configured but produced no usable rows; regional value-capture scenarios still require local project assumptions.",
    if (nrow(htops)) "HTOPS benchmark rows available."
    else if (!configured[[5]]) "HTOPS is an optional benchmark and no direct table URL or normalized local file was configured."
    else "HTOPS was configured but produced no usable rows."
  )
  status <- tibble::tibble(
    source = source,
    rows = as.integer(rows),
    usable_rows = as.integer(usable_rows),
    configured = configured,
    status = status_code,
    diagnostic = diagnostic,
    refreshed_at = as.character(Sys.time())
  )
  v3_write_csv(status, file.path(paths$outputs, "public_data_status_v3.csv"))
  list(btos = btos, qwi = qwi, bea = bea, htops = htops, status = status)
}
