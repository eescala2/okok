# 03_ai_scores.R -------------------------------------------------------------
# Public-data occupation AI channel scoring from O*NET tasks and optional AIOE.
# Robust to O*NET task column names across releases, including Task Statements.txt.

source(file.path(project_root(), 'R', '00_setup.R'))

count_regex <- function(text, pattern) {
  text <- stringr::str_to_lower(as.character(text))
  m <- stringr::str_count(text, pattern)
  tidyr::replace_na(m, 0)
}

weighted_mean2 <- function(x, w) {
  x <- suppressWarnings(as.numeric(x))
  w <- suppressWarnings(as.numeric(w))
  w <- tidyr::replace_na(w, 1)
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  stats::weighted.mean(x[ok], w = w[ok], na.rm = TRUE)
}

weighted_var2 <- function(x, w) {
  x <- suppressWarnings(as.numeric(x))
  w <- suppressWarnings(as.numeric(w))
  w <- tidyr::replace_na(w, 1)
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (sum(ok) < 2) return(0)
  mu <- stats::weighted.mean(x[ok], w[ok])
  sum(w[ok] * (x[ok] - mu)^2) / sum(w[ok])
}

first_non_missing <- function(x, default = NA_character_) {
  x <- as.character(x)
  x <- x[!is.na(x) & stringr::str_squish(x) != '']
  if (length(x)) x[[1]] else default
}

first_existing_name <- function(df, candidates) {
  nms <- names(df)
  hit <- intersect(candidates, nms)
  if (length(hit)) hit[[1]] else NA_character_
}

coalesce_existing_chr <- function(df, candidates, default = '') {
  hits <- intersect(candidates, names(df))
  if (!length(hits)) return(rep(default, nrow(df)))
  out <- as.character(df[[hits[[1]]]])
  if (length(hits) > 1) {
    for (h in hits[-1]) {
      y <- as.character(df[[h]])
      out <- dplyr::coalesce(out, y)
    }
  }
  out <- dplyr::coalesce(out, default)
  stringr::str_squish(out)
}

normalize_onet_tasks <- function(tasks) {
  if (!nrow(tasks)) stop('O*NET tasks table has zero rows.', call. = FALSE)

  # The O*NET all-files releases have used slightly different task columns.
  # Common names after janitor::clean_names() include: task, task_statement,
  # task_description, description, and task_text.
  task_text <- coalesce_existing_chr(
    tasks,
    c('task', 'task_statement', 'task_description', 'description', 'task_text'),
    default = ''
  )

  if (!any(nzchar(task_text))) {
    stop(
      'Could not find a usable O*NET task text column. Columns present: ',
      paste(names(tasks), collapse = ', '),
      call. = FALSE
    )
  }

  soc_col <- first_existing_name(tasks, c('soc_code', 'o_net_soc_code', 'onet_soc_code'))
  if (is.na(soc_col)) {
    stop(
      'Could not find an O*NET SOC code column in tasks table. Columns present: ',
      paste(names(tasks), collapse = ', '),
      call. = FALSE
    )
  }

  task_id_col <- first_existing_name(tasks, c('task_id', 'taskid', 'id'))
  title_col <- first_existing_name(tasks, c('onet_title', 'title', 'occupation_title'))

  out <- tasks |>
    dplyr::mutate(
      soc_code = clean_soc(.data[[soc_col]]),
      task_id = if (!is.na(task_id_col)) as.character(.data[[task_id_col]]) else paste0('row_', dplyr::row_number()),
      task_text = task_text,
      onet_title = if (!is.na(title_col)) as.character(.data[[title_col]]) else NA_character_
    ) |>
    dplyr::filter(stringr::str_detect(soc_code, '^\\d{2}-\\d{4}$'), nzchar(task_text))

  if (!nrow(out)) stop('O*NET task normalizer produced zero usable task rows.', call. = FALSE)
  out
}

normalize_task_ratings <- function(task_ratings) {
  if (!nrow(task_ratings)) return(tibble::tibble())
  needed_any <- c('soc_code', 'o_net_soc_code', 'onet_soc_code')
  soc_col <- first_existing_name(task_ratings, needed_any)
  task_id_col <- first_existing_name(task_ratings, c('task_id', 'taskid', 'id'))
  scale_col <- first_existing_name(task_ratings, c('scale_id', 'scale_name', 'scale'))
  value_col <- first_existing_name(task_ratings, c('data_value', 'value', 'rating'))
  if (any(is.na(c(soc_col, task_id_col, scale_col, value_col)))) return(tibble::tibble())

  task_ratings |>
    dplyr::transmute(
      soc_code = clean_soc(.data[[soc_col]]),
      task_id = as.character(.data[[task_id_col]]),
      scale_id = as.character(.data[[scale_col]]),
      data_value = suppressWarnings(readr::parse_number(as.character(.data[[value_col]])))
    ) |>
    dplyr::filter(stringr::str_detect(soc_code, '^\\d{2}-\\d{4}$'), !is.na(data_value))
}

score_task_text <- function(tasks, task_ratings = tibble::tibble()) {
  tasks <- normalize_onet_tasks(tasks)
  task_ratings <- normalize_task_ratings(task_ratings)

  im <- tibble::tibble()
  if (nrow(task_ratings)) {
    im <- task_ratings |>
      dplyr::filter(toupper(scale_id) %in% c('IM', 'IMPORTANCE')) |>
      dplyr::group_by(soc_code, task_id) |>
      dplyr::summarise(task_importance = mean(as.numeric(data_value), na.rm = TRUE), .groups = 'drop')
  }

  x <- tasks |>
    dplyr::left_join(im, by = c('soc_code', 'task_id')) |>
    dplyr::mutate(task_importance = dplyr::coalesce(task_importance, 3))

  automation_pat <- paste(c(
    'enter data','data entry','record','file','process','schedule','calculate','compile','verify',
    'transcribe','classify','sort','route','prepare reports','generate reports','maintain records',
    'billing','invoice','payroll','bookkeep','claim','audit','monitor','review documents','document',
    'routine','standard operating','reconcile','code data','collect data','analyze data','spreadsheet'
  ), collapse = '|')
  augmentation_pat <- paste(c(
    'diagnos','troubleshoot','advise','recommend','interpret','evaluate','assess','inspect','coordinate',
    'communicat','consult','plan','design','develop','teach','train','coach','care','treat','counsel',
    'negotiate','decide','judge','collaborate','lead','supervise','investigate','solve'
  ), collapse = '|')
  expertise_pat <- paste(c(
    'diagnos','technical','repair','install','maintain','calibrate','safety','regulation','compliance',
    'clinical','medical','electrical','mechanical','quality','inspect','blueprint','specification',
    'legal','certif','licensed','laboratory','troubleshoot','engineering'
  ), collapse = '|')
  newtask_pat <- paste(c(
    'design','develop','implement','integrate','workflow','automation','sensor','data','analytics',
    'customer','patient','student','precision','robot','drone','ai','machine learning','cyber',
    'compliance','supply chain','logistics','energy','environment','telehealth','remote','dashboard',
    'optimize','predict','forecast','process improvement','quality improvement'
  ), collapse = '|')
  manual_pat <- paste(c('operate','lift','carry','move','assemble','construct','repair','drive','clean','cook','install','machine','equipment','hand tool','physical','load','unload'), collapse = '|')
  cognitive_pat <- paste(c('analyze','calculate','design','develop','plan','evaluate','interpret','research','write','program','forecast','estimate','model','data'), collapse = '|')
  interpersonal_pat <- paste(c('communicat','teach','train','advise','counsel','care','serve','negotiate','sell','coordinate','supervise','manage','interview','collaborate'), collapse = '|')

  x |>
    dplyr::mutate(
      automation_hits = count_regex(task_text, automation_pat),
      augmentation_hits = count_regex(task_text, augmentation_pat),
      expertise_hits = count_regex(task_text, expertise_pat),
      newtask_hits = count_regex(task_text, newtask_pat),
      manual_hits = count_regex(task_text, manual_pat),
      cognitive_hits = count_regex(task_text, cognitive_pat),
      interpersonal_hits = count_regex(task_text, interpersonal_pat),
      routine_score = rescale01(automation_hits + 0.5 * count_regex(task_text, 'routine|standard|repeat|regular')),
      ai_capability_score = rescale01(automation_hits + cognitive_hits + newtask_hits + count_regex(task_text, 'data|text|report|image|voice|forecast|predict|classif|optimiz|language')),
      task_automation = rescale01(0.55 * ai_capability_score + 0.45 * routine_score + 0.10 * automation_hits),
      task_augmentation = rescale01(0.55 * ai_capability_score + 0.40 * augmentation_hits + 0.15 * interpersonal_hits - 0.20 * routine_score),
      task_expertise_leveling = rescale01(0.50 * ai_capability_score + 0.50 * expertise_hits + 0.15 * augmentation_hits),
      task_new_opportunity = rescale01(0.45 * ai_capability_score + 0.55 * newtask_hits + 0.20 * augmentation_hits),
      task_manual = rescale01(manual_hits),
      task_cognitive = rescale01(cognitive_hits),
      task_interpersonal = rescale01(interpersonal_hits)
    )
}

make_empty_aioe <- function() {
  tibble::tibble(soc_code = character(), aioe_score = numeric())
}

make_empty_oews <- function() {
  tibble::tibble(
    soc_code = character(), occupation_title = character(), state_emp = numeric(),
    hourly_mean = numeric(), annual_mean = numeric(), hourly_median = numeric(), annual_median = numeric()
  )
}

summarise_occupation_scores <- function(onet, aioe = tibble::tibble(), oews = tibble::tibble()) {
  scored <- score_task_text(onet$tasks, onet$task_ratings)

  occ <- scored |>
    dplyr::group_by(soc_code) |>
    dplyr::summarise(
      onet_title = first_non_missing(onet_title),
      task_count = dplyr::n(),
      mean_task_ai = weighted_mean2(ai_capability_score, task_importance),
      task_exposure_concentration = weighted_var2(ai_capability_score, task_importance),
      automation_raw = weighted_mean2(task_automation, task_importance),
      augmentation_raw = weighted_mean2(task_augmentation, task_importance),
      expertise_leveling_raw = weighted_mean2(task_expertise_leveling, task_importance),
      new_task_raw = weighted_mean2(task_new_opportunity, task_importance),
      manual_share_proxy = weighted_mean2(task_manual, task_importance),
      cognitive_share_proxy = weighted_mean2(task_cognitive, task_importance),
      interpersonal_share_proxy = weighted_mean2(task_interpersonal, task_importance),
      .groups = 'drop'
    )

  job_zones <- onet$job_zones
  if (nrow(job_zones)) {
    soc_col <- first_existing_name(job_zones, c('soc_code', 'o_net_soc_code', 'onet_soc_code'))
    zone_col <- first_existing_name(job_zones, c('job_zone', 'zone'))
    if (!is.na(soc_col) && !is.na(zone_col)) {
      jz <- job_zones |>
        dplyr::transmute(soc_code = clean_soc(.data[[soc_col]]), job_zone = .data[[zone_col]]) |>
        dplyr::distinct(soc_code, .keep_all = TRUE)
    } else {
      jz <- tibble::tibble(soc_code = character(), job_zone = numeric())
    }
  } else {
    jz <- tibble::tibble(soc_code = character(), job_zone = numeric())
  }

  aioe2 <- if (nrow(aioe) && all(c('soc_code', 'aioe_score') %in% names(aioe))) {
    aioe |> dplyr::transmute(soc_code = clean_soc(soc_code), aioe_score = suppressWarnings(as.numeric(aioe_score)))
  } else make_empty_aioe()

  oews2 <- if (nrow(oews) && 'soc_code' %in% names(oews)) {
    for (nm in names(make_empty_oews())) {
      if (!nm %in% names(oews)) oews[[nm]] <- NA
    }
    oews |>
      dplyr::transmute(
        soc_code = clean_soc(soc_code),
        occupation_title = as.character(occupation_title),
        state_emp = suppressWarnings(as.numeric(state_emp)),
        hourly_mean = suppressWarnings(as.numeric(hourly_mean)),
        annual_mean = suppressWarnings(as.numeric(annual_mean)),
        hourly_median = suppressWarnings(as.numeric(hourly_median)),
        annual_median = suppressWarnings(as.numeric(annual_median))
      ) |>
      dplyr::distinct(soc_code, .keep_all = TRUE)
  } else make_empty_oews()

  x <- occ |>
    dplyr::left_join(jz, by = 'soc_code') |>
    dplyr::left_join(aioe2, by = 'soc_code') |>
    dplyr::left_join(oews2, by = 'soc_code') |>
    dplyr::mutate(
      aioe_norm = ifelse(is.na(aioe_score), NA_real_, rescale01(aioe_score)),
      ai_exposure_base = ifelse(is.na(aioe_norm), mean_task_ai, 0.65 * mean_task_ai + 0.35 * aioe_norm),
      job_zone_norm = rescale01(readr::parse_number(as.character(job_zone))),
      automation_exposure = rescale01(0.55 * automation_raw + 0.30 * ai_exposure_base + 0.15 * cognitive_share_proxy),
      augmentation_potential = rescale01(0.55 * augmentation_raw + 0.30 * task_exposure_concentration + 0.15 * ai_exposure_base),
      expertise_leveling_potential = rescale01(0.50 * expertise_leveling_raw + 0.25 * job_zone_norm + 0.25 * ai_exposure_base),
      new_task_opportunity = rescale01(0.55 * new_task_raw + 0.25 * augmentation_potential + 0.20 * interpersonal_share_proxy),
      pro_worker_opportunity = rescale01(0.33 * augmentation_potential + 0.33 * new_task_opportunity +
                                           0.24 * expertise_leveling_potential - 0.20 * automation_exposure),
      risk_minus_opportunity = automation_exposure - pro_worker_opportunity,
      occupation_title = dplyr::coalesce(occupation_title, onet_title)
    ) |>
    dplyr::arrange(dplyr::desc(pro_worker_opportunity))
  x
}
