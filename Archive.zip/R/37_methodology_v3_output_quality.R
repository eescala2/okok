# Methodology v3.0.4 output-quality hardening
# - distinguishes true charts from evidence-unavailable placeholders
# - replaces tiny/black-on-transparent placeholders with readable status panels
# - rebuilds the evidence scorecard from module and public-source status files
# - validates and repairs HTML-to-PDF printing so Chrome cannot silently print New Tab

`%||%` <- function(x, y) {
  if (is.null(x) || length(x) == 0L || (length(x) == 1L && is.na(x))) y else x
}

v3_oq_font_family <- function() {
  if (requireNamespace("systemfonts", quietly = TRUE)) {
    exports <- getNamespaceExports("systemfonts")
    hit <- if ("match_fonts" %in% exports) {
      tryCatch(systemfonts::match_fonts("Arial"), error = function(e) NULL)
    } else {
      suppressWarnings(tryCatch(systemfonts::match_font("Arial"), error = function(e) NULL))
    }
    if (!is.null(hit) && is.character(hit$path) && nzchar(hit$path)) return("Arial")
  }
  "sans"
}

v3_oq_paths <- function(paths = NULL) {
  if (is.null(paths)) {
    provider <- get0("v3_paths", mode = "function", inherits = TRUE)
    if (is.function(provider)) paths <- provider()
  }
  if (!is.list(paths)) paths <- list(root = getwd())
  root <- normalizePath(paths$root %||% getwd(), winslash = "/", mustWork = FALSE)
  processed <- paths$processed %||% file.path(root, "data_processed", "methodology_v3")
  outputs_root <- file.path(root, "outputs")
  outputs_v3 <- file.path(outputs_root, "methodology_v3")
  figures_v3 <- file.path(root, "figures", "methodology_v3")
  dir.create(processed, recursive = TRUE, showWarnings = FALSE)
  dir.create(outputs_v3, recursive = TRUE, showWarnings = FALSE)
  dir.create(figures_v3, recursive = TRUE, showWarnings = FALSE)
  list(
    root = root,
    processed = processed,
    outputs_root = outputs_root,
    outputs_v3 = outputs_v3,
    figures_v3 = figures_v3
  )
}

v3_oq_read_csv <- function(path) {
  if (!file.exists(path) || is.na(file.info(path)$size) || file.info(path)$size == 0) return(tibble::tibble())
  tryCatch(readr::read_csv(path, show_col_types = FALSE, progress = FALSE), error = function(e) tibble::tibble())
}

v3_oq_figure_map <- function() {
  tibble::tribble(
    ~id, ~filename, ~title, ~module, ~dependency,
    "37", "methodology_v3_37_observed_adoption_nowcast.png", "Observed adoption nowcast", "observed_adoption_nowcast", "Census BTOS AI supplement and/or a normalized Iowa employer pulse",
    "38", "methodology_v3_38_exposure_vs_adoption.png", "Exposure versus observed adoption", "observed_adoption_nowcast", "Observed BTOS/Iowa adoption estimates joined to the exposure atlas",
    "39", "methodology_v3_39_worker_quality_adjusted_outcomes.png", "Worker task use and quality-adjusted outcomes", "quality_adjusted_worker_outcomes", "Iowa worker pulse or preregistered pilot task-outcome records",
    "40", "methodology_v3_40_early_career_fragility.png", "Early-career fragility", "early_career_fragility", "Usable Census QWI sex-by-age records or a normalized local early-career file",
    "41", "methodology_v3_41_apprenticeship_access.png", "Apprenticeship access", "apprenticeship_access", "Registered apprenticeship capacity, registrations, completions, wages, and waitlists",
    "42", "methodology_v3_42_credential_feasible_paths.png", "Credential-feasible transition pathways", "credential_feasible_transitions", "Credential, training-program, access, wage, opening, and employer-validation records",
    "43", "methodology_v3_43_transition_constraints.png", "Transition constraint audit", "credential_feasible_transitions", "Candidate occupation pairs plus credential, physical, schedule, commute, and training constraints",
    "44", "methodology_v3_44_industrial_ai_readiness.png", "Industrial AI readiness", "industrial_ai_readiness", "Employer/site readiness assessments covering capital, sensors, data, cyber, maintenance, management, and training",
    "45", "methodology_v3_45_productivity_j_curve.png", "Industrial AI productivity J-curve", "productivity_j_curve", "Readiness assessments plus implementation, operating-cost, ramp, plateau, and worker-gain assumptions",
    "46", "methodology_v3_46_pilot_decision_rules.png", "Pilot scale, redesign, suspend, or stop rules", "causal_pilot_registry", "Preregistered pilot registry, comparison design, incidents, appeals, and 30/90/180-day outcomes",
    "47", "methodology_v3_47_aria_assurance.png", "NIST ARIA assurance coverage", "nist_aria_system_assurance", "Pilot/system model testing, red teaming, field testing, and system-level evaluation records",
    "48", "methodology_v3_48_regional_value_capture.png", "Regional value capture", "regional_value_capture", "BEA regional data plus Iowa value-added, labor-income, supplier, leakage, and worker-share assumptions"
  )
}

v3_oq_status_inputs <- function(paths = NULL) {
  p <- v3_oq_paths(paths)
  modules <- v3_oq_read_csv(file.path(p$outputs_v3, "methodology_v3_module_status.csv"))
  gaps <- v3_oq_read_csv(file.path(p$outputs_v3, "evidence_gap_register_v3.csv"))
  public <- v3_oq_read_csv(file.path(p$outputs_v3, "public_data_status_v3.csv"))
  list(paths = p, modules = modules, gaps = gaps, public = public)
}

v3_oq_module_record <- function(module, status_inputs) {
  modules <- status_inputs$modules
  gaps <- status_inputs$gaps
  hit <- if (nrow(modules) && "module" %in% names(modules)) dplyr::filter(modules, .data$module == module) else tibble::tibble()
  gap <- if (nrow(gaps) && "module" %in% names(gaps)) dplyr::filter(gaps, .data$module == module) else tibble::tibble()
  list(
    rows = if (nrow(hit) && "rows" %in% names(hit)) suppressWarnings(as.numeric(hit$rows[[1L]])) else 0,
    status = if (nrow(hit) && "evidence_status" %in% names(hit)) as.character(hit$evidence_status[[1L]]) else "UNAVAILABLE",
    note = if (nrow(hit) && "note" %in% names(hit)) as.character(hit$note[[1L]]) else "No validated evidence rows were available.",
    required_action = if (nrow(gap) && "required_action" %in% names(gap)) as.character(gap$required_action[[1L]]) else "Connect a validated public or local source before publishing a substantive estimate."
  )
}

v3_evidence_placeholder_plot_v304 <- function(
  title = NULL,
  message = NULL,
  subtitle = NULL,
  note = NULL,
  detail = NULL,
  module = NULL,
  dependency = NULL,
  required_action = NULL,
  rows = 0,
  status = "UNAVAILABLE",
  ...
) {
  dots <- list(...)
  text_values <- unlist(c(list(message, subtitle, note, detail), dots[vapply(dots, is.character, logical(1L))]), use.names = FALSE)
  text_values <- text_values[!is.na(text_values) & nzchar(trimws(text_values))]
  if (is.null(title) || !nzchar(as.character(title))) title <- "Evidence status"
  if (is.null(detail) || !nzchar(as.character(detail))) detail <- if (length(text_values)) text_values[[1L]] else "No validated evidence rows were available."
  if (is.null(dependency) || !nzchar(as.character(dependency))) dependency <- "A validated public, administrative, employer, worker, or pilot input is required."
  if (is.null(required_action) || !nzchar(as.character(required_action))) required_action <- "Connect the required source, rerun the evidence layer, and retain UNAVAILABLE until validation passes."
  family <- v3_oq_font_family()
  blue <- "#1C5DBA"; teal <- "#00808D"; gold <- "#E0A624"; pale <- grDevices::adjustcolor("#C6D667", alpha.f = 0.20)
  status_label <- paste0(toupper(status), "  |  ", scales::comma(rows %||% 0), " validated rows")
  ggplot2::ggplot() +
    ggplot2::annotate("rect", xmin = 0.015, xmax = 0.985, ymin = 0.08, ymax = 0.92,
                      fill = pale, color = blue, linewidth = 0.8) +
    ggplot2::annotate("rect", xmin = 0.015, xmax = 0.038, ymin = 0.08, ymax = 0.92,
                      fill = blue, color = blue) +
    ggplot2::annotate("text", x = 0.065, y = 0.82, label = "EVIDENCE UNAVAILABLE",
                      hjust = 0, vjust = 1, family = family, fontface = "bold", size = 6.0, color = teal) +
    ggplot2::annotate("text", x = 0.065, y = 0.71, label = status_label,
                      hjust = 0, vjust = 1, family = family, fontface = "bold", size = 4.4, color = blue) +
    ggplot2::annotate("text", x = 0.065, y = 0.60,
                      label = stringr::str_wrap(paste0("Why no values are plotted: ", detail), width = 95),
                      hjust = 0, vjust = 1, family = family, size = 4.0, color = "black", lineheight = 1.12) +
    ggplot2::annotate("text", x = 0.065, y = 0.39,
                      label = stringr::str_wrap(paste0("Evidence needed: ", dependency), width = 95),
                      hjust = 0, vjust = 1, family = family, size = 4.0, color = "black", lineheight = 1.12) +
    ggplot2::annotate("text", x = 0.065, y = 0.20,
                      label = stringr::str_wrap(paste0("Next action: ", required_action), width = 95),
                      hjust = 0, vjust = 1, family = family, size = 3.9, color = "black", lineheight = 1.12) +
    ggplot2::annotate("text", x = 0.965, y = 0.11,
                      label = "No adoption, productivity, worker-benefit, readiness, causal, or value-capture estimate is inferred from exposure alone.",
                      hjust = 1, vjust = 0, family = family, size = 3.1, color = "black") +
    ggplot2::coord_cartesian(xlim = c(0, 1), ylim = c(0, 1), clip = "off") +
    ggplot2::theme_void(base_family = family) +
    ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = "transparent", color = NA),
      panel.background = ggplot2::element_rect(fill = "transparent", color = NA),
      plot.margin = ggplot2::margin(20, 24, 20, 24)
    )
}

v3_oq_save_plot <- function(plot, path, width = 16, height = 9.71, dpi = 128) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  device <- if (requireNamespace("ragg", quietly = TRUE)) ragg::agg_png else "png"
  ggplot2::ggsave(path, plot = plot, width = width, height = height, units = "in",
                  dpi = dpi, bg = "transparent", device = device, limitsize = FALSE)
  invisible(path)
}

v3_evidence_scorecard_plot_v304 <- function(paths = NULL) {
  si <- v3_oq_status_inputs(paths)
  modules <- si$modules
  public <- si$public
  if (!nrow(modules)) modules <- tibble::tibble(module = "Methodology v3 evidence modules", rows = 0, evidence_status = "UNAVAILABLE")
  module_df <- modules |>
    dplyr::transmute(
      section = "Evidence modules",
      item = stringr::str_to_sentence(gsub("_", " ", as.character(.data$module))),
      rows = suppressWarnings(as.numeric(.data$rows)),
      status = toupper(as.character(.data$evidence_status))
    )
  public_df <- if (nrow(public)) {
    public |>
      dplyr::transmute(
        section = "Public inputs",
        item = as.character(.data$source),
        rows = suppressWarnings(as.numeric(.data$rows)),
        status = toupper(as.character(.data$status))
      )
  } else tibble::tibble(section = "Public inputs", item = "No source-status file", rows = 0, status = "UNAVAILABLE")
  df <- dplyr::bind_rows(public_df, module_df) |>
    dplyr::mutate(
      status = dplyr::case_when(
        status %in% c("AVAILABLE", "OBSERVED", "COMPLETE") ~ "AVAILABLE",
        status %in% c("PROVISIONAL", "PARTIAL", "MODELED") ~ "PROVISIONAL",
        TRUE ~ "UNAVAILABLE"
      ),
      label = paste0(status, "  |  ", scales::comma(dplyr::coalesce(rows, 0)), " rows"),
      item = stringr::str_wrap(item, 34)
    )
  df$item_key <- factor(paste(df$section, df$item, sep = "___"), levels = rev(paste(df$section, df$item, sep = "___")))
  family <- v3_oq_font_family()
  fills <- c(AVAILABLE = "#C6D667", PROVISIONAL = "#E0A624", UNAVAILABLE = "#B32A2D")
  ggplot2::ggplot(df, ggplot2::aes(x = 1, y = item_key, fill = status)) +
    ggplot2::geom_tile(width = 0.96, height = 0.72, color = "white", linewidth = 0.5) +
    ggplot2::geom_text(ggplot2::aes(label = label), family = family, fontface = "bold",
                       size = 3.7, color = "white", na.rm = TRUE) +
    ggplot2::facet_grid(section ~ ., scales = "free_y", space = "free_y", switch = "y") +
    ggplot2::scale_fill_manual(values = fills, drop = FALSE) +
    ggplot2::scale_y_discrete(labels = function(x) sub("^.*___", "", x)) +
    ggplot2::scale_x_continuous(limits = c(0.44, 1.56), expand = c(0, 0)) +
    ggplot2::labs(x = NULL, y = NULL, fill = "Evidence status",
                  caption = "Rows are validated records available to the Methodology v3 evidence layer. UNAVAILABLE is retained rather than inferred from exposure.") +
    ggplot2::theme_minimal(base_family = family, base_size = 10) +
    ggplot2::theme(
      axis.text.x = ggplot2::element_blank(), axis.ticks.x = ggplot2::element_blank(),
      axis.text.y = ggplot2::element_text(color = "black", size = 9),
      panel.grid = ggplot2::element_blank(),
      strip.placement = "outside",
      strip.text.y.left = ggplot2::element_text(angle = 0, hjust = 1, color = "#00808D", size = 11),
      legend.position = "bottom", legend.text = ggplot2::element_text(color = "black"),
      plot.caption = ggplot2::element_text(hjust = 0, color = "black", size = 9),
      plot.background = ggplot2::element_rect(fill = "transparent", color = NA),
      panel.background = ggplot2::element_rect(fill = "transparent", color = NA),
      plot.margin = ggplot2::margin(12, 20, 12, 20)
    )
}

v3_oq_override_placeholder_helpers <- function(env = .GlobalEnv) {
  nms <- ls(env, all.names = TRUE)
  candidates <- nms[vapply(nms, function(nm) {
    obj <- get0(nm, envir = env, inherits = FALSE)
    if (!is.function(obj) || grepl("v304|v3_oq", nm)) return(FALSE)
    body_txt <- paste(deparse(body(obj), width.cutoff = 120L), collapse = "\n")
    name_hit <- grepl("placeholder|unavailable|empty.*plot|no.*data", nm, ignore.case = TRUE)
    body_hit <- grepl("theme_void|annotate\\s*\\(.*text|geom_text", body_txt) &&
      grepl("unavailable|not available|no .*records|not supplied", body_txt, ignore.case = TRUE)
    isTRUE(name_hit || body_hit)
  }, logical(1L))]
  for (nm in candidates) {
    assign(nm, function(title = NULL, message = NULL, subtitle = NULL, note = NULL, detail = NULL, ...) {
      v3_evidence_placeholder_plot_v304(title = title, message = message, subtitle = subtitle,
                                        note = note, detail = detail, ...)
    }, envir = env)
  }
  scorecard <- nms[vapply(nms, function(nm) {
    obj <- get0(nm, envir = env, inherits = FALSE)
    is.function(obj) && grepl("evidence.*scorecard|scorecard.*evidence", nm, ignore.case = TRUE) &&
      grepl("ggplot", paste(deparse(body(obj)), collapse = "\n"))
  }, logical(1L))]
  for (nm in scorecard) assign(nm, function(...) v3_evidence_scorecard_plot_v304(), envir = env)
  invisible(list(placeholders = candidates, scorecards = scorecard))
}

v3_harden_methodology_v3_figures <- function(paths = NULL) {
  si <- v3_oq_status_inputs(paths)
  p <- si$paths
  fmap <- v3_oq_figure_map()
  audit <- vector("list", nrow(fmap))
  for (i in seq_len(nrow(fmap))) {
    rec <- v3_oq_module_record(fmap$module[[i]], si)
    out <- file.path(p$figures_v3, fmap$filename[[i]])
    is_unavailable <- !is.finite(rec$rows) || rec$rows <= 0 || toupper(rec$status) == "UNAVAILABLE"
    if (is_unavailable) {
      plot <- v3_evidence_placeholder_plot_v304(
        title = fmap$title[[i]], module = fmap$module[[i]], dependency = fmap$dependency[[i]],
        required_action = rec$required_action, rows = rec$rows, status = rec$status, detail = rec$note
      )
      v3_oq_save_plot(plot, out)
    }
    audit[[i]] <- tibble::tibble(
      id = fmap$id[[i]], filename = fmap$filename[[i]], module = fmap$module[[i]],
      data_rows = rec$rows, evidence_status = rec$status,
      output_status = if (is_unavailable) "created_placeholder_unavailable" else "retained_data_chart",
      path = out
    )
  }
  scorecard_path <- file.path(p$figures_v3, "methodology_v3_49_evidence_scorecard.png")
  v3_oq_save_plot(v3_evidence_scorecard_plot_v304(paths), scorecard_path)
  audit_df <- dplyr::bind_rows(audit, tibble::tibble(
    id = "49", filename = basename(scorecard_path), module = "evidence_scorecard",
    data_rows = sum(suppressWarnings(as.numeric(si$modules$rows)), na.rm = TRUE),
    evidence_status = if (nrow(si$modules) && any(toupper(si$modules$evidence_status) == "AVAILABLE")) "MIXED" else "UNAVAILABLE",
    output_status = "created_status_scorecard", path = scorecard_path
  ))
  manifest_path <- file.path(p$outputs_v3, "methodology_v3_visualization_manifest.csv")
  manifest <- v3_oq_read_csv(manifest_path)
  if (nrow(manifest) && "id" %in% names(manifest)) {
    manifest <- manifest |>
      dplyr::mutate(id = as.character(.data$id)) |>
      dplyr::select(-dplyr::any_of(c("data_rows", "evidence_status", "is_placeholder"))) |>
      dplyr::left_join(
        audit_df |>
          dplyr::transmute(id, data_rows, evidence_status,
                           is_placeholder = .data$output_status == "created_placeholder_unavailable",
                           status_v304 = .data$output_status),
        by = "id"
      ) |>
      dplyr::mutate(status = dplyr::coalesce(.data$status_v304, as.character(.data$status))) |>
      dplyr::select(-dplyr::any_of("status_v304"))
    readr::write_csv(manifest, manifest_path, na = "")
  }
  readr::write_csv(audit_df, file.path(p$outputs_v3, "methodology_v3_figure_evidence_audit_v304.csv"), na = "")
  overrides <- v3_oq_override_placeholder_helpers()
  attr(audit_df, "overrides") <- overrides
  invisible(audit_df)
}

v3_oq_find_browser <- function() {
  envs <- c("IA_ATLAS_CHROME", "PAGEDOWN_CHROME", "CHROME_PATH")
  for (e in envs) {
    x <- Sys.getenv(e, unset = "")
    if (nzchar(x) && file.exists(x)) return(normalizePath(x, winslash = "/", mustWork = TRUE))
  }
  candidates <- c(
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "C:/Program Files/Google/Chrome/Application/chrome.exe",
    "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
    "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
    "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"
  )
  hit <- candidates[file.exists(candidates)]
  if (length(hit)) return(normalizePath(hit[[1L]], winslash = "/", mustWork = TRUE))
  for (cmd in c("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge", "chrome")) {
    x <- Sys.which(cmd)
    if (nzchar(x)) return(x)
  }
  ""
}

v3_oq_file_url <- function(path) {
  path <- normalizePath(path, winslash = "/", mustWork = TRUE)
  encode_parts <- function(x) paste(vapply(strsplit(x, "/", fixed = TRUE)[[1L]], utils::URLencode, character(1L), reserved = TRUE), collapse = "/")
  if (.Platform$OS.type == "windows" && grepl("^[A-Za-z]:/", path)) {
    drive <- substr(path, 1L, 2L)
    rest <- sub("^[A-Za-z]:", "", path)
    return(paste0("file:///", drive, encode_parts(rest)))
  }
  paste0("file://", encode_parts(path))
}

v3_oq_pdf_info <- function(path) {
  out <- list(exists = file.exists(path), bytes = if (file.exists(path)) unname(file.info(path)$size) else 0,
              pages = NA_integer_, title = NA_character_, first_text = "")
  if (!out$exists) return(out)
  if (requireNamespace("pdftools", quietly = TRUE)) {
    info <- tryCatch(pdftools::pdf_info(path), error = function(e) NULL)
    if (!is.null(info)) {
      out$pages <- as.integer(info$pages)
      keys <- info$keys
      key_title <- NULL
      if (is.list(keys)) key_title <- keys$Title
      if (!is.list(keys) && !is.null(names(keys)) && "Title" %in% names(keys)) key_title <- keys[["Title"]]
      out$title <- as.character(key_title %||% info$title %||% NA_character_)
    }
    txt <- tryCatch(pdftools::pdf_text(path), error = function(e) character())
    if (length(txt)) out$first_text <- txt[[1L]]
  } else {
    pdfinfo <- Sys.which("pdfinfo")
    if (nzchar(pdfinfo)) {
      z <- tryCatch(system2(pdfinfo, path, stdout = TRUE, stderr = TRUE), error = function(e) character())
      pg <- grep("^Pages:", z, value = TRUE); tt <- grep("^Title:", z, value = TRUE)
      if (length(pg)) out$pages <- suppressWarnings(as.integer(trimws(sub("^Pages:", "", pg[[1L]]))))
      if (length(tt)) out$title <- trimws(sub("^Title:", "", tt[[1L]]))
    }
  }
  out
}

v3_oq_pdf_valid <- function(pdf, html = NULL) {
  info <- v3_oq_pdf_info(pdf)
  html_bytes <- if (!is.null(html) && file.exists(html)) unname(file.info(html)$size) else 0
  min_bytes <- max(250000, min(1000000, html_bytes * 0.12))
  bad_text <- grepl("Search Google or type a URL|chrome://newtab", info$first_text, ignore.case = TRUE)
  bad_title <- !is.na(info$title) && grepl("^New Tab$|Google", info$title, ignore.case = TRUE)
  page_ok <- is.na(info$pages) || info$pages >= 3L
  valid <- isTRUE(info$exists) && is.finite(info$bytes) && info$bytes >= min_bytes && page_ok && !bad_text && !bad_title
  c(info, list(min_bytes = min_bytes, valid = valid))
}

v3_oq_print_html_once <- function(browser, html, pdf, tagged = TRUE) {
  if (file.exists(pdf)) unlink(pdf, force = TRUE)
  profile <- tempfile("iowa_atlas_chrome_profile_")
  dir.create(profile, recursive = TRUE, showWarnings = FALSE)
  on.exit(unlink(profile, recursive = TRUE, force = TRUE), add = TRUE)
  args <- c(
    "--headless=new", "--disable-gpu", "--disable-extensions", "--no-first-run",
    "--no-default-browser-check", "--allow-file-access-from-files",
    "--run-all-compositor-stages-before-draw", "--virtual-time-budget=20000",
    paste0("--user-data-dir=", profile),
    paste0("--print-to-pdf=", normalizePath(pdf, winslash = "/", mustWork = FALSE)),
    "--no-pdf-header-footer"
  )
  if (isTRUE(tagged)) args <- c(args, "--generate-tagged-pdf")
  args <- c(args, v3_oq_file_url(html))

  timeout_seconds <- suppressWarnings(as.numeric(Sys.getenv(
    "IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS", unset = "240"
  )))
  if (!is.finite(timeout_seconds) || timeout_seconds < 30) timeout_seconds <- 240

  if (!requireNamespace("processx", quietly = TRUE)) {
    return(list(
      status = 127L,
      log = "processx is required; no unbounded browser fallback was attempted.",
      tagged = tagged
    ))
  }
  z <- tryCatch(
    processx::run(
      browser,
      args,
      error_on_status = FALSE,
      echo = FALSE,
      windows_hide_window = TRUE,
      cleanup_tree = TRUE,
      timeout = timeout_seconds * 1000
    ),
    error = function(e) list(
      status = 124L,
      stdout = "",
      stderr = paste0("Browser process failed or timed out: ", conditionMessage(e))
    )
  )
  Sys.sleep(1.5)
  list(
    status = z$status %||% 124L,
    log = paste(c(z$stdout %||% "", z$stderr %||% ""), collapse = "\n"),
    tagged = tagged
  )
}

v3_oq_repair_one_pdf <- function(browser, html, pdf, force = FALSE) {
  current <- v3_oq_pdf_valid(pdf, html)
  if (!isTRUE(force) && isTRUE(current$valid)) return(c(current, list(status = "retained_valid_pdf", browser = browser, log = "")))
  attempts <- list()
  for (tagged in c(TRUE, FALSE)) {
    run <- v3_oq_print_html_once(browser, html, pdf, tagged = tagged)
    check <- v3_oq_pdf_valid(pdf, html)
    attempts[[length(attempts) + 1L]] <- list(run = run, check = check)
    if (isTRUE(check$valid)) {
      return(c(check, list(
        status = if (tagged) "created_from_html_direct_chromium_tagged_validated" else "created_from_html_direct_chromium_validated",
        browser = browser, log = run$log
      )))
    }
  }
  last <- attempts[[length(attempts)]]
  c(last$check, list(status = "failed_pdf_validation", browser = browser,
                     log = paste(vapply(attempts, function(x) x$run$log, character(1L)), collapse = "\n--- RETRY ---\n")))
}

v3_repair_methodology_v3_pdfs <- function(paths = NULL, force = FALSE) {
  p <- v3_oq_paths(paths)
  browser <- v3_oq_find_browser()
  if (!nzchar(browser)) stop("No supported Chrome, Chromium, or Edge executable was found. Set IA_ATLAS_CHROME to the full browser path.", call. = FALSE)
  jobs <- tibble::tribble(
    ~artifact, ~source_html, ~output_pdf,
    "Quarto Methodology v3 PDF", file.path(p$outputs_root, "atlas_methodology_v3_quarto.html"), file.path(p$outputs_root, "atlas_methodology_v3_quarto.pdf"),
    "R Markdown Methodology v3 PDF", file.path(p$outputs_root, "atlas_methodology_v3_rmarkdown.html"), file.path(p$outputs_root, "atlas_methodology_v3_rmarkdown.pdf")
  )
  results <- vector("list", nrow(jobs))
  for (i in seq_len(nrow(jobs))) {
    if (!file.exists(jobs$source_html[[i]])) stop("Missing source HTML: ", jobs$source_html[[i]], call. = FALSE)
    r <- v3_oq_repair_one_pdf(browser, jobs$source_html[[i]], jobs$output_pdf[[i]], force = force)
    results[[i]] <- tibble::tibble(
      artifact = jobs$artifact[[i]], source_html = jobs$source_html[[i]], output_pdf = jobs$output_pdf[[i]],
      exists = file.exists(jobs$output_pdf[[i]]), bytes = r$bytes %||% 0,
      pages = r$pages %||% NA_integer_, title = r$title %||% NA_character_, validated = isTRUE(r$valid),
      status = r$status %||% "unknown", browser = browser, log = r$log %||% ""
    )
  }
  out <- dplyr::bind_rows(results)
  manifest_path <- file.path(p$outputs_v3, "pdf_report_manifest_v3.csv")
  old <- v3_oq_read_csv(manifest_path)
  if (nrow(old)) {
    old <- old |>
      dplyr::mutate(artifact = as.character(.data$artifact)) |>
      dplyr::filter(!.data$artifact %in% out$artifact)
    out <- dplyr::bind_rows(out, old)
  }
  readr::write_csv(out, manifest_path, na = "")
  if (any(!out$validated[out$artifact %in% jobs$artifact])) {
    stop("Methodology v3 report PDF validation failed. See outputs/methodology_v3/pdf_report_manifest_v3.csv.", call. = FALSE)
  }
  invisible(out)
}

v3_validate_methodology_v3_output_quality <- function(paths = NULL) {
  p <- v3_oq_paths(paths)
  fmap <- v3_oq_figure_map()
  fig_paths <- file.path(p$figures_v3, fmap$filename)
  checks <- tibble::tibble(
    check = paste0("Figure ", fmap$id, " evidence-aware output"),
    path = fig_paths,
    exists = file.exists(fig_paths),
    bytes = ifelse(file.exists(fig_paths), file.info(fig_paths)$size, 0),
    passed = file.exists(fig_paths) & file.info(fig_paths)$size > 35000
  )
  pdf_jobs <- tibble::tribble(
    ~check, ~html, ~pdf,
    "Quarto Methodology v3 report PDF is not a browser New Tab", file.path(p$outputs_root, "atlas_methodology_v3_quarto.html"), file.path(p$outputs_root, "atlas_methodology_v3_quarto.pdf"),
    "R Markdown Methodology v3 report PDF is not a browser New Tab", file.path(p$outputs_root, "atlas_methodology_v3_rmarkdown.html"), file.path(p$outputs_root, "atlas_methodology_v3_rmarkdown.pdf")
  )
  pdf_checks <- purrr::pmap_dfr(pdf_jobs, function(check, html, pdf) {
    x <- v3_oq_pdf_valid(pdf, html)
    tibble::tibble(check = check, path = pdf, exists = x$exists, bytes = x$bytes, passed = isTRUE(x$valid))
  })
  out <- dplyr::bind_rows(checks, pdf_checks)
  readr::write_csv(out, file.path(p$outputs_v3, "output_quality_check_v304.csv"), na = "")
  if (any(!out$passed)) stop("Methodology v3 output-quality validation failed. See outputs/methodology_v3/output_quality_check_v304.csv.", call. = FALSE)
  invisible(out)
}

# BEGIN IA_ATLAS_V3_PUBLICATION_RELEASE_V308_SOURCE
.v3_pub_module_candidates <- unique(c(
  file.path(getwd(), "R", "39_methodology_v3_publication_release.R"),
  file.path("R", "39_methodology_v3_publication_release.R")
))
.v3_pub_module_hit <- .v3_pub_module_candidates[file.exists(.v3_pub_module_candidates)]
if (length(.v3_pub_module_hit)) {
  sys.source(.v3_pub_module_hit[[1L]], envir = .GlobalEnv, keep.source = FALSE)
}
rm(.v3_pub_module_candidates, .v3_pub_module_hit)
# END IA_ATLAS_V3_PUBLICATION_RELEASE_V308_SOURCE



# BEGIN IA_ATLAS_V3_PUBLICATION_COMPLETION_V309_SOURCE
.v3_v309_candidates <- unique(c(
  file.path(getwd(), "R", "40_methodology_v3_publication_completion_v309.R"),
  file.path("R", "40_methodology_v3_publication_completion_v309.R")
))
.v3_v309_hit <- .v3_v309_candidates[file.exists(.v3_v309_candidates)]
if (length(.v3_v309_hit)) sys.source(.v3_v309_hit[[1L]], envir = .GlobalEnv, keep.source = FALSE)
rm(.v3_v309_candidates, .v3_v309_hit)
# END IA_ATLAS_V3_PUBLICATION_COMPLETION_V309_SOURCE
