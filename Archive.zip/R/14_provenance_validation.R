# 14_provenance_validation.R ----------------------------------------------
# Reproducibility, immutable-input snapshots, source provenance, model card,
# typed-schema tests, and benchmark reconciliation for Methodology v2.

source(file.path(project_root(), 'R', '00_setup.R'))
source(file.path(project_root(), 'R', '13_methodology_v2.R'))

v2_sha256 <- function(path) {
  if (!file.exists(path)) return(NA_character_)
  digest::digest(file = path, algo = 'sha256', serialize = FALSE)
}

v2_count_rows <- function(path) {
  ext <- tolower(tools::file_ext(path))
  if (ext %in% c('csv', 'tsv', 'txt')) {
    return(tryCatch({
      con <- file(path, open = 'rb')
      on.exit(close(con), add = TRUE)
      n <- 0L
      repeat {
        z <- readLines(con, n = 100000L, warn = FALSE)
        if (!length(z)) break
        n <- n + length(z)
      }
      max(0L, n - 1L)
    }, error = function(e) NA_integer_))
  }
  NA_integer_
}

v2_source_candidates <- function(pattern) {
  p <- paths()
  roots <- c(p$raw, p$processed, p$inputs)
  files <- unlist(lapply(roots[dir.exists(roots)], function(root) {
    list.files(root, full.names = TRUE, recursive = TRUE, all.files = FALSE)
  }), use.names = FALSE)
  files <- files[!stringr::str_detect(normalizePath(files, winslash = '/', mustWork = FALSE), '/snapshots/') ]
  files[stringr::str_detect(basename(files), stringr::regex(pattern, ignore_case = TRUE))]
}

v2_snapshot_file <- function(path, source_id, cfg) {
  mode <- tolower(as.character(cfg$build$snapshot_mode %||% 'manifest_only'))
  if (mode %in% c('off', 'manifest_only') || !file.exists(path)) return(NA_character_)
  limit <- as.numeric(cfg$build$snapshot_max_file_mb %||% 250) * 1024^2
  if (file.info(path)$size > limit) return('manifest-only: file exceeds configured snapshot size')
  hash <- v2_sha256(path)
  dest_dir <- file.path(paths()$raw, 'snapshots', source_id)
  fs::dir_create(dest_dir)
  dest <- file.path(dest_dir, paste0(hash, '__', basename(path)))
  if (!file.exists(dest)) file.copy(path, dest, overwrite = FALSE, copy.date = TRUE)
  normalizePath(dest, winslash = '/', mustWork = FALSE)
}

v2_source_provenance <- function(cfg = load_methodology_v2_config()) {
  registry <- v2_read_config_csv('source_registry.csv')
  purrr::map_dfr(seq_len(nrow(registry)), function(i) {
    r <- registry[i, ]
    candidates <- v2_source_candidates(r$file_pattern)
    if (!length(candidates)) {
      return(tibble::tibble(
        source_id = r$source_id, source_name = r$source_name, source_url = r$source_url,
        vintage = r$vintage, required = r$required, role = r$role,
        local_file = NA_character_, file_size_bytes = NA_real_, modified_at = NA_character_, retrieved_at = NA_character_, build_seen_at = format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z'),
        sha256 = NA_character_, row_count = NA_integer_, snapshot_path = NA_character_,
        source_status = if (isTRUE(r$required)) 'required file not found' else 'optional file not loaded'
      ))
    }
    info <- file.info(candidates)
    candidates <- candidates[order(info$mtime, decreasing = TRUE)]
    purrr::map_dfr(candidates, function(f) {
      fi <- file.info(f)
      tibble::tibble(
        source_id = r$source_id, source_name = r$source_name, source_url = r$source_url,
        vintage = r$vintage, required = r$required, role = r$role,
        local_file = normalizePath(f, winslash = '/', mustWork = FALSE),
        file_size_bytes = as.numeric(fi$size), modified_at = format(fi$mtime, '%Y-%m-%d %H:%M:%S %Z'),
        retrieved_at = format(fi$mtime, '%Y-%m-%d %H:%M:%S %Z'), build_seen_at = format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z'),
        sha256 = v2_sha256(f), row_count = v2_count_rows(f),
        snapshot_path = v2_snapshot_file(f, r$source_id, cfg), source_status = 'available'
      )
    })
  })
}

v2_package_versions <- function() {
  pkgs <- unique(c(required_pkgs, editable_excel_pkgs, optional_pkgs, 'digest', 'targets'))
  tibble::tibble(
    package = pkgs,
    installed = vapply(pkgs, requireNamespace, logical(1), quietly = TRUE),
    version = vapply(pkgs, function(x) {
      if (!requireNamespace(x, quietly = TRUE)) return(NA_character_)
      as.character(utils::packageVersion(x))
    }, character(1))
  )
}

v2_configuration_provenance <- function() {
  vp <- v2_methodology_paths()
  files <- list.files(vp$config_dir, full.names = TRUE, recursive = FALSE)
  if (!length(files)) return(tibble::tibble())
  info <- file.info(files)
  tibble::tibble(
    configuration_file = normalizePath(files, winslash = '/', mustWork = FALSE),
    basename = basename(files),
    size_bytes = as.numeric(info$size),
    modified_at = format(info$mtime, '%Y-%m-%d %H:%M:%S %Z'),
    sha256 = vapply(files, v2_sha256, character(1)),
    methodology_version = as.character(load_methodology_v2_config()$methodology_version)
  ) |>
    dplyr::arrange(basename)
}

v2_reconciliation_tests <- function(atlas, cfg = load_methodology_v2_config()) {
  tol <- as.numeric(cfg$build$reconciliation_tolerance %||% 0.005)
  ci <- atlas |>
    dplyr::group_by(county_fips, naics2) |>
    dplyr::summarise(
      estimated = sum(estimated_jobs, na.rm = TRUE),
      target = max(county_industry_emp, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::mutate(
      target = dplyr::if_else(is.infinite(target), NA_real_, target),
      absolute_residual = estimated - target,
      relative_residual = abs(absolute_residual) / pmax(abs(target), 1)
    )
  soc_target_col <- if ('state_emp_benchmark' %in% names(atlas)) 'state_emp_benchmark' else 'state_emp'
  soc <- atlas |>
    dplyr::group_by(soc_code) |>
    dplyr::summarise(
      estimated = sum(estimated_jobs, na.rm = TRUE),
      target = max(.data[[soc_target_col]], na.rm = TRUE),
      target_definition = if ('state_emp_benchmark_definition' %in% names(atlas)) v2_mode_char(state_emp_benchmark_definition) else 'Iowa OEWS state employment',
      raw_oews_target = if ('state_emp_raw_oews' %in% names(atlas)) max(state_emp_raw_oews, na.rm = TRUE) else max(state_emp, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::mutate(
      target = dplyr::if_else(is.infinite(target), NA_real_, target),
      absolute_residual = estimated - target,
      relative_residual = abs(absolute_residual) / pmax(abs(target), 1)
    )
  p <- v2_methodology_paths()
  readr::write_csv(ci, file.path(p$outputs, 'county_industry_reconciliation_detail.csv'))
  readr::write_csv(soc, file.path(p$outputs, 'state_occupation_reconciliation_detail.csv'))

  key_cols <- intersect(c('county_fips', 'naics2', 'soc_code'), names(atlas))
  duplicate_cells <- if (length(key_cols) == 3L) {
    atlas |>
      dplyr::count(dplyr::across(dplyr::all_of(key_cols))) |>
      dplyr::filter(n > 1) |>
      nrow()
  } else NA_integer_
  schema_issues <- tryCatch(nrow(v2_assert_score_schema(atlas, 'reconciliation score schema', stop_on_error = FALSE)), error = function(e) 1L)
  unmapped_lwda <- sum(is.na(atlas$lwda_combined) | !nzchar(atlas$lwda_combined))

  tibble::tribble(
    ~test_id, ~test_description, ~statistic, ~tolerance, ~pass,
    'CI_MARGIN', 'Maximum relative residual against county-industry employment controls', if (nrow(ci)) max(ci$relative_residual, na.rm = TRUE) else Inf, tol, nrow(ci) > 0 && max(ci$relative_residual, na.rm = TRUE) <= tol,
    'SOC_MARGIN', 'Maximum relative residual against Iowa state occupation controls', if (nrow(soc)) max(soc$relative_residual, na.rm = TRUE) else Inf, tol, nrow(soc) > 0 && max(soc$relative_residual, na.rm = TRUE) <= tol,
    'DUPLICATE_CELL', 'Duplicate county-industry-occupation keys', as.numeric(duplicate_cells), 0, identical(as.integer(duplicate_cells), 0L),
    'SCORE_SCHEMA', 'Typed score-schema issues', as.numeric(schema_issues), 0, identical(as.integer(schema_issues), 0L),
    'LWDA_COVERAGE', 'Atlas rows without a combined LWDA', as.numeric(unmapped_lwda), 0, identical(as.integer(unmapped_lwda), 0L),
    'FINITE_JOBS', 'Rows with non-finite or negative employment', sum(!is.finite(atlas$estimated_jobs) | atlas$estimated_jobs < 0), 0, all(is.finite(atlas$estimated_jobs) & atlas$estimated_jobs >= 0)
  )
}

v2_model_card <- function(cfg, source_provenance, reconciliation) {
  source_coverage <- source_provenance |>
    dplyr::group_by(source_id, required) |>
    dplyr::summarise(available = any(source_status == 'available'), .groups = 'drop')
  tibble::tribble(
    ~field, ~value,
    'Model name', 'Iowa AI Exposure and Pro-Worker AI Opportunity Atlas Methodology v2',
    'Version', as.character(cfg$methodology_version),
    'Intended use', 'Strategic prioritization, scenario analysis, employer validation, training planning, and pilot selection',
    'Prohibited interpretation', 'Not a job-loss forecast, not an official county-SOC count, and not proof that small score differences are statistically meaningful',
    'Core unit', 'Synthetic county x industry x detailed-SOC cell constrained to public margins',
    'Task framework', 'O*NET task-importance-weighted mean exposure, exposure concentration, reallocation potential, automation, augmentation, expertise leveling, new-task opportunity, and physical AI',
    'Small-area method', 'Conjugate empirical-Bayes Dirichlet/Beta-style partial pooling toward combined-LWDA sector priors followed by iterative benchmark reconciliation; production approximation rather than full MCMC',
    'Benchmark universe', 'OEWS detailed-SOC shares are scaled to the QWI/LODES county-industry employment universe before simultaneous reconciliation; raw and scaled targets are retained',
    'Uncertainty', 'Model-based 95% intervals and A/B/C reliability classes; intervals describe synthetic allocation uncertainty, not causal forecast uncertainty',
    'Observed adoption', 'Maintained separately; Census BTOS and Iowa employer-pulse estimates are retained by source and combined only through a published precision-weighted nowcast; missing observations are not imputed from technical exposure',
    'External benchmark', 'AIOE is retained as an external benchmark and is not used to silently rescale the primary score',
    'Training capacity', 'Multi-component ACS/local-input index with explicit component coverage and reliability',
    'Sensitivity', 'Proactive/balanced/cautious action thresholds plus worker-capability, balanced, substitution-stress, and physical-AI score-weight scenarios',
    'Publication and suppression', 'Modeled cells remain available for reproducibility, while public interpretation relies on aggregated outputs, reliability classes, interval widths, and explicit warnings rather than presenting sparse cells as observed counts',
    'Validation', paste0(sum(reconciliation$pass), ' of ', nrow(reconciliation), ' automated reconciliation/schema tests passed'),
    'Required source coverage', paste0(sum(source_coverage$required & source_coverage$available), ' of ', sum(source_coverage$required), ' required registry entries available'),
    'Governance', 'NIST AI RMF-oriented Govern, Map, Measure, and Manage profile template',
    'Known limitations', 'No direct county-SOC observations for all counties; limited local workflow/adoption/outcome data; task dictionaries and sector modifiers require employer validation; no causal claims from exposure maps'
  )
}


v2_git_commit_if_available <- function(root = getwd()) {
  git_exe <- Sys.which("git")
  if (!nzchar(git_exe) || !dir.exists(file.path(root, ".git"))) {
    return(NA_character_)
  }
  output <- tryCatch(
    suppressWarnings(system2(
      git_exe,
      c("-C", root, "rev-parse", "HEAD"),
      stdout = TRUE,
      stderr = TRUE
    )),
    error = function(e) character()
  )
  status <- attr(output, "status")
  candidate <- if (length(output)) trimws(output[[1L]]) else ""
  if (!is.null(status) || !grepl("^[0-9A-Fa-f]{7,40}$", candidate)) {
    return(NA_character_)
  }
  candidate
}

run_methodology_v2_provenance <- function(stop_on_failure = TRUE) {
  setup_packages(install_optional = FALSE)
  cfg <- load_methodology_v2_config()
  p <- paths(); vp <- v2_methodology_paths()
  fs::dir_create(vp$outputs)
  if (!compat_table_exists('county_industry_occupation_atlas', p$processed)) stop('Methodology-v2 atlas is missing. Run apply_methodology_v2() first.', call. = FALSE)
  atlas <- read_compat_table('county_industry_occupation_atlas', p$processed) |> dplyr::as_tibble()
  provenance <- v2_source_provenance(cfg)
  packages <- v2_package_versions()
  configuration <- v2_configuration_provenance()
  reconciliation <- v2_reconciliation_tests(atlas, cfg)
  model_card <- v2_model_card(cfg, provenance, reconciliation)
  build_id <- v2_build_id()
  cfg_files <- list.files(vp$config_dir, full.names = TRUE, recursive = FALSE)
  config_hashes <- paste(sort(vapply(cfg_files, v2_sha256, character(1))), collapse = '|')
  build_manifest <- tibble::tibble(
    build_id = build_id,
    methodology_version = as.character(cfg$methodology_version),
    built_at = format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z'),
    r_version = R.version.string,
    platform = R.version$platform,
    config_bundle_sha256 = digest::digest(config_hashes, algo = 'sha256', serialize = FALSE),
    source_bundle_sha256 = digest::digest(paste(sort(stats::na.omit(provenance$sha256)), collapse = '|'), algo = 'sha256', serialize = FALSE),
    reconciliation_pass = all(reconciliation$pass),
    git_commit = v2_git_commit_if_available(vp$root)
  )
  readr::write_csv(provenance, file.path(vp$outputs, 'source_provenance.csv'))
  readr::write_csv(packages, file.path(vp$outputs, 'package_versions.csv'))
  readr::write_csv(configuration, file.path(vp$outputs, 'configuration_provenance.csv'))
  readr::write_csv(reconciliation, file.path(vp$outputs, 'reconciliation_tests.csv'))
  readr::write_csv(model_card, file.path(vp$outputs, 'model_card.csv'))
  readr::write_csv(build_manifest, file.path(vp$outputs, 'build_manifest.csv'))

  md <- c(
    '# Iowa AI Workforce Atlas Methodology v2 model card', '',
    paste0('**Build ID:** `', build_id, '`  '),
    paste0('**Methodology version:** `', cfg$methodology_version, '`  '), '',
    paste0('- **', model_card$field, ':** ', model_card$value), '',
    '## Automated reconciliation tests', '',
    paste0('- ', reconciliation$test_id, ': ', ifelse(reconciliation$pass, 'PASS', 'FAIL'), ' — ', reconciliation$test_description, ' (statistic=', signif(reconciliation$statistic, 5), ', tolerance=', reconciliation$tolerance, ')')
  )
  writeLines(md, file.path(p$root, 'MODEL_CARD.md'), useBytes = TRUE)

  failed <- reconciliation |> dplyr::filter(!pass)
  if (nrow(failed)) {
    msg <- paste0('Methodology-v2 validation failed: ', paste(failed$test_id, collapse = ', '), '. See outputs/methodology_v2/reconciliation_tests.csv.')
    if (isTRUE(stop_on_failure)) stop(msg, call. = FALSE) else warning(msg, call. = FALSE)
  }
  message('Wrote source provenance, model card, package versions, snapshots, build manifest, and reconciliation tests.')
  invisible(list(provenance = provenance, packages = packages, configuration = configuration, reconciliation = reconciliation, model_card = model_card, build_manifest = build_manifest))
}

if (sys.nframe() == 0) run_methodology_v2_provenance(stop_on_failure = TRUE)
