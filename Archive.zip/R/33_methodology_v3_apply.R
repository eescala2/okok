# Methodology v3 evidence-system orchestration
# Version 3.1.3: distinguish missing local evidence, failed public requests,
# optional unconfigured sources, and genuinely available modules.

v3_result_column <- function(x, name, default = NULL) {
  if (is.data.frame(x) && name %in% names(x)) return(x[[name]])
  if (!is.null(default)) return(default)
  NULL
}

v3_safe_nrow <- function(x) {
  if (is.data.frame(x) || is.matrix(x)) return(nrow(x))
  0L
}

v3_public_source_diagnostic <- function(results, source_name) {
  status <- if (is.list(results$public_inputs) && "status" %in% names(results$public_inputs)) results$public_inputs$status else tibble::tibble()
  if (!is.data.frame(status) || !nrow(status) || !"source" %in% names(status)) {
    return(list(code = "status_not_recorded", explanation = "No public-source status record was written."))
  }
  hit <- status[as.character(status$source) == source_name, , drop = FALSE]
  if (!nrow(hit)) return(list(code = "status_not_recorded", explanation = paste0("No status row was found for ", source_name, ".")))
  list(
    code = as.character(v3_result_column(hit, "status", "status_not_recorded")[[1]]),
    explanation = as.character(v3_result_column(hit, "diagnostic", "No diagnostic was recorded.")[[1]])
  )
}

v3_local_input_diagnostic <- function(paths, filenames, available_rows) {
  full <- file.path(paths$inputs, filenames)
  present <- file.exists(full)
  existing <- filenames[present]
  missing <- filenames[!present]
  if (available_rows > 0L) {
    source_text <- if (length(existing)) paste(existing, collapse = ", ") else "the configured local-input path"
    return(list(code = "available", explanation = paste0("Usable rows were read from ", source_text, ".")))
  }
  if (length(missing)) {
    partial <- if (length(existing)) paste0(" Present: ", paste(existing, collapse = ", "), ".") else ""
    return(list(code = "missing_local_input", explanation = paste0("Required local evidence file(s) are absent: ", paste(missing, collapse = ", "), ".", partial)))
  }
  list(code = "configured_but_no_usable_rows", explanation = paste0("Input file(s) exist but produced no usable rows: ", paste(existing, collapse = ", "), ". Check schema, coding, and filters."))
}

v3_methodology_v3_extension_status <- function(results, paths = v3_paths()) {
  btos <- v3_public_source_diagnostic(results, "BTOS")
  qwi <- v3_public_source_diagnostic(results, "QWI early career")
  pulse_rows <- v3_safe_nrow(results$adoption$pulse)
  worker_raw_rows <- v3_safe_nrow(results$worker$raw)
  worker_summary_rows <- v3_safe_nrow(results$worker$summary)
  apprenticeship_rows <- v3_safe_nrow(results$early_career$apprenticeship)
  transition_public_rows <- v3_safe_nrow(results$transitions$public)
  transition_eval_rows <- v3_safe_nrow(results$transitions$evaluated)
  readiness_rows <- v3_safe_nrow(results$industrial$readiness)
  jcurve_rows <- dplyr::n_distinct(v3_result_column(results$industrial$jcurve, "assessment_id", character()))
  pilot_rows <- v3_safe_nrow(results$pilots$registry)
  aria_rows <- v3_safe_nrow(results$pilots$aria)
  value_rows <- v3_safe_nrow(results$value_capture$summary)

  pulse_diag <- v3_local_input_diagnostic(paths, "iowa_employer_pulse.csv", pulse_rows)
  worker_diag <- v3_local_input_diagnostic(paths, "worker_task_outcomes.csv", worker_raw_rows)
  apprentice_diag <- v3_local_input_diagnostic(paths, "apprenticeship_access.csv", apprenticeship_rows)
  transition_files <- c("credential_requirements.csv", "training_programs.csv", "local_openings.csv", "employer_transition_validation.csv")
  transition_diag <- v3_local_input_diagnostic(paths, transition_files, transition_eval_rows)
  industrial_diag <- v3_local_input_diagnostic(paths, "industrial_readiness_assessment.csv", readiness_rows)
  pilot_diag <- v3_local_input_diagnostic(paths, c("ai_pilot_registry_v3.csv", "pilot_measurements_v3.csv"), pilot_rows)
  aria_diag <- v3_local_input_diagnostic(paths, "aria_test_results.csv", aria_rows)
  value_diag <- v3_local_input_diagnostic(paths, "regional_project_scenarios.csv", value_rows)

  row <- function(extension_id, module, rows, evidence_status, availability_code, required_input, availability_explanation, note) {
    tibble::tibble(
      extension_id = extension_id, module = module, rows = as.numeric(rows), evidence_status = evidence_status,
      availability_code = availability_code, required_input = required_input,
      availability_explanation = availability_explanation, note = note
    )
  }

  dplyr::bind_rows(
    row(1, "observed_adoption_nowcast", v3_safe_nrow(results$adoption$integrated), if (v3_safe_nrow(results$adoption$integrated)) "BENCHMARKED" else "UNAVAILABLE", if (v3_safe_nrow(results$adoption$integrated)) "available" else btos$code, "Official Census BTOS API; inputs/iowa_employer_pulse.csv is optional", if (v3_safe_nrow(results$adoption$integrated)) "BTOS observations were normalized into the adoption nowcast." else btos$explanation, "Quarterly BTOS layer benchmarked with an optional Iowa employer pulse."),
    row(2, "iowa_employer_pulse", pulse_rows, if (pulse_rows) "OBSERVED" else "UNAVAILABLE", pulse_diag$code, "inputs/iowa_employer_pulse.csv", pulse_diag$explanation, "Firm size, sector, function, current use, and expected six-month deployment."),
    row(3, "worker_task_use", worker_raw_rows, if (worker_raw_rows) "OBSERVED" else "UNAVAILABLE", worker_diag$code, "inputs/worker_task_outcomes.csv", worker_diag$explanation, "Task frequency, review, correction, rework, surveillance, scheduling, and time reallocation."),
    row(4, "quality_adjusted_worker_outcomes", worker_summary_rows, if (worker_summary_rows) "OBSERVED" else "UNAVAILABLE", worker_diag$code, "inputs/worker_task_outcomes.csv", worker_diag$explanation, "Good output per total active, review, correction, and rework time plus quality and job-quality safeguards."),
    row(5, "early_career_fragility", v3_safe_nrow(results$early_career$industry), if (v3_safe_nrow(results$early_career$industry)) "BENCHMARKED" else "UNAVAILABLE", if (v3_safe_nrow(results$early_career$industry)) "available" else qwi$code, "Census QWI Sex-by-Age API (CENSUS_API_KEY) or inputs/qwi_early_career_manual.csv", if (v3_safe_nrow(results$early_career$industry)) "QWI age-by-industry records were available." else qwi$explanation, "QWI age-specific employment, hiring, separations, earnings, gains, and losses; no causal claim."),
    row(6, "apprenticeship_access", apprenticeship_rows, if (apprenticeship_rows) "OBSERVED" else "UNAVAILABLE", apprentice_diag$code, "inputs/apprenticeship_access.csv", apprentice_diag$explanation, "Registered apprenticeship capacity, registrations, completions, wages, and waitlists."),
    row(7, "credential_feasible_transitions", transition_public_rows, if (transition_public_rows) "BENCHMARKED" else if (transition_eval_rows) "PROVISIONAL" else "UNAVAILABLE", transition_diag$code, paste0("inputs/", paste(transition_files, collapse = "; inputs/")), transition_diag$explanation, "Licenses, education, experience, Job Zone, physical and schedule demands, openings, wages, training, commute, and employer validation."),
    row(8, "industrial_ai_readiness", readiness_rows, if (readiness_rows) "OBSERVED" else "UNAVAILABLE", industrial_diag$code, "inputs/industrial_readiness_assessment.csv", industrial_diag$explanation, "Capital, sensors, data, maintenance, management, cybersecurity, training, change, and financing readiness."),
    row(9, "productivity_j_curve", jcurve_rows, if (jcurve_rows) "SCENARIO" else "UNAVAILABLE", industrial_diag$code, "inputs/industrial_readiness_assessment.csv", industrial_diag$explanation, "Implementation dip, ramp, plateau, operating cost, worker gain, and break-even scenarios."),
    row(10, "causal_pilot_registry", pilot_rows, if (pilot_rows) "OBSERVED" else "UNAVAILABLE", pilot_diag$code, "inputs/ai_pilot_registry_v3.csv; inputs/pilot_measurements_v3.csv", pilot_diag$explanation, "Preregistration, comparison design, baseline, incidents, appeals, and 30/90/180-day outcome reporting."),
    row(11, "nist_aria_system_assurance", aria_rows, if (aria_rows) "OBSERVED" else "UNAVAILABLE", aria_diag$code, "inputs/aria_test_results.csv", aria_diag$explanation, "Model testing, red teaming, field testing, and system-level evaluation."),
    row(12, "regional_value_capture", value_rows, if (value_rows) "SCENARIO" else "UNAVAILABLE", value_diag$code, "inputs/regional_project_scenarios.csv plus BEA/local multiplier inputs", value_diag$explanation, "Iowa value added, labor income, supplier purchases, tax-base effects, leakage, and worker income.")
  )
}

apply_methodology_v3 <- function(refresh = FALSE, paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  v3_ensure_directories(paths)
  build_id <- v3_build_id(paths$root)
  message("Applying Methodology v3: observed diffusion, worker outcomes, early-career fragility, feasible pathways, industrial readiness, causal pilots, assurance, and value capture.")

  atlas <- v3_read_v2_atlas(paths$root)
  public_inputs <- v3_refresh_public_inputs(refresh = refresh, paths = paths, cfg = cfg)
  adoption <- apply_methodology_v3_adoption(public_inputs, atlas, paths, cfg)
  worker <- apply_methodology_v3_worker_outcomes(paths, cfg)
  early_career <- apply_methodology_v3_early_career(public_inputs, atlas, paths, cfg)
  transitions <- apply_methodology_v3_transitions(atlas, paths, cfg)
  industrial <- apply_methodology_v3_industrial_readiness(paths, cfg)
  pilots <- apply_methodology_v3_pilots(paths, cfg)
  value_capture <- apply_methodology_v3_value_capture(public_inputs, paths, cfg)

  results <- list(
    public_inputs = public_inputs,
    adoption = adoption,
    worker = worker,
    early_career = early_career,
    transitions = transitions,
    industrial = industrial,
    pilots = pilots,
    value_capture = value_capture
  )

  module_status <- v3_methodology_v3_extension_status(results, paths)
  roadmap <- v3_read_csv(file.path(paths$config, "v3_36_month_roadmap.csv"), required = TRUE)
  principle <- tibble::tibble(
    methodology_version = as.character(cfg$methodology_version %||% "3.0.3"),
    governing_principle = "Exposure is not adoption; adoption is not productivity; and productivity is not automatically pro-worker.",
    interpretation = "The evidence system separates technical capability, observed use, measured productivity, worker outcomes, system assurance, feasible transitions, and regional value capture."
  )
  v3_write_csv(module_status, file.path(paths$outputs, "methodology_v3_module_status.csv"))
  v3_write_csv(roadmap, file.path(paths$outputs, "methodology_v3_36_month_roadmap.csv"))
  v3_write_csv(principle, file.path(paths$outputs, "methodology_v3_governing_principle.csv"))
  v3_write_build_metadata(build_id, paths, extra = list(
    v2_atlas_source = attr(atlas, "source_path") %||% NA_character_,
    refresh = refresh,
    module_count = nrow(module_status)
  ))

  saveRDS(results, file.path(paths$processed, "methodology_v3_results.rds"))
  message("Methodology v3 evidence outputs written to ", paths$processed, " and ", paths$outputs, ".")
  list(build_id = build_id, atlas = atlas, results = results, module_status = module_status, roadmap = roadmap, principle = principle)
}

v3_load_results <- function(paths = v3_paths()) {
  path <- file.path(paths$processed, "methodology_v3_results.rds")
  if (!file.exists(path)) stop("Methodology v3 results do not exist. Run apply_methodology_v3() first.", call. = FALSE)
  readRDS(path)
}
