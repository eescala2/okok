# Iowa AI Workforce Atlas one-click release: article plot overrides
# Version 3.1.2
#
# These functions change presentation only. They do not change the underlying
# Methodology v2 or Methodology v3 analytical values.

`%||%` <- function(x, y) {
  if (is.null(x) || !length(x) || (length(x) == 1L && is.na(x))) y else x
}

atlas_v312_pick_col <- function(data, candidates, required = TRUE, label = NULL) {
  hit <- candidates[candidates %in% names(data)]
  if (length(hit)) return(hit[[1L]])
  if (isTRUE(required)) {
    stop(
      "Could not find ",
      label %||% paste(candidates, collapse = "/"),
      ". Available columns: ",
      paste(names(data), collapse = ", "),
      call. = FALSE
    )
  }
  NA_character_
}

atlas_v312_read_first <- function(paths, required = FALSE) {
  hit <- paths[file.exists(paths)]
  if (!length(hit)) {
    if (isTRUE(required)) {
      stop(
        "None of the required files exists: ",
        paste(paths, collapse = ", "),
        call. = FALSE
      )
    }
    return(NULL)
  }

  path <- hit[[1L]]
  extension <- tolower(tools::file_ext(path))

  if (extension == "rds") {
    return(readRDS(path))
  }

  if (extension == "parquet") {
    if (!requireNamespace("arrow", quietly = TRUE)) {
      stop("A Parquet input exists but arrow is unavailable: ", path, call. = FALSE)
    }
    return(as.data.frame(arrow::read_parquet(path)))
  }

  if (grepl("\\.csv\\.gz$", path, ignore.case = TRUE) || extension == "csv") {
    return(readr::read_csv(path, show_col_types = FALSE))
  }

  stop("Unsupported input type: ", path, call. = FALSE)
}

atlas_v312_load_visual_data <- function(root = getwd()) {
  root <- normalizePath(root, winslash = "/", mustWork = TRUE)
  processed <- file.path(root, "data_processed")

  main <- atlas_v312_read_first(
    c(
      file.path(processed, "county_industry_occupation_atlas.rds"),
      file.path(processed, "county_industry_occupation_atlas.parquet"),
      file.path(processed, "county_industry_occupation_atlas.csv.gz")
    ),
    required = TRUE
  )

  county <- atlas_v312_read_first(
    c(
      file.path(processed, "county_summary_v2.csv"),
      file.path(processed, "county_summary.csv")
    )
  )

  lwda <- atlas_v312_read_first(
    c(
      file.path(processed, "lwda_summary_v2.csv"),
      file.path(processed, "lwda_summary.csv")
    )
  )

  sector <- atlas_v312_read_first(
    c(
      file.path(processed, "sector_lwda_summary_v2.csv"),
      file.path(processed, "sector_lwda_summary.csv")
    )
  )

  training <- atlas_v312_read_first(
    c(
      file.path(processed, "training_priority_occupations_v2.csv"),
      file.path(processed, "training_priority_occupations.csv")
    )
  )

  commuting_candidates <- list.files(
    processed,
    pattern = "commut|flow",
    full.names = TRUE,
    ignore.case = TRUE
  )
  commuting_candidates <- commuting_candidates[
    grepl("\\.csv(\\.gz)?$", commuting_candidates, ignore.case = TRUE)
  ]
  commuting <- if (length(commuting_candidates)) {
    tryCatch(
      readr::read_csv(commuting_candidates[[1L]], show_col_types = FALSE),
      error = function(e) NULL
    )
  } else {
    NULL
  }

  list(
    atlas = as.data.frame(main),
    county = county,
    lwda = lwda,
    sector = sector,
    training = training,
    commuting = commuting
  )
}

atlas_v312_article_font <- function() {
  if (exists("atlas_article_font", mode = "function", inherits = TRUE)) {
    return(atlas_article_font())
  }
  "Arial"
}

atlas_v312_theme <- function(base_size = 11) {
  if (exists("atlas_article_theme", mode = "function", inherits = TRUE)) {
    return(atlas_article_theme(base_size = base_size))
  }

  ggplot2::theme_minimal(
    base_size = base_size,
    base_family = atlas_v312_article_font()
  ) +
    ggplot2::theme(
      plot.title = ggplot2::element_blank(),
      plot.subtitle = ggplot2::element_blank(),
      plot.caption = ggplot2::element_blank(),
      panel.grid.minor = ggplot2::element_blank(),
      plot.background = ggplot2::element_rect(fill = "transparent", colour = NA),
      panel.background = ggplot2::element_rect(fill = "transparent", colour = NA),
      legend.position = "bottom"
    )
}

atlas_v312_save_plot <- function(
    plot,
    path,
    width,
    height,
    dpi = 320,
    svg = TRUE,
    white_preview = TRUE) {

  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)

  device <- if (requireNamespace("ragg", quietly = TRUE)) {
    ragg::agg_png
  } else {
    "png"
  }

  ggplot2::ggsave(
    filename = path,
    plot = plot,
    device = device,
    width = width,
    height = height,
    units = "in",
    dpi = dpi,
    bg = "transparent",
    limitsize = FALSE
  )

  if (
    exists("atlas_article_trim_png", mode = "function", inherits = TRUE)
  ) {
    try(atlas_article_trim_png(path, fuzz = 2, border_px = 12L), silent = TRUE)
  } else if (requireNamespace("magick", quietly = TRUE)) {
    image <- magick::image_read(path)
    image <- magick::image_trim(image, fuzz = 2)
    image <- magick::image_border(image, "none", "12x12")
    magick::image_write(image, path, format = "png")
  }

  if (isTRUE(svg) && requireNamespace("svglite", quietly = TRUE)) {
    svg_path <- sub("\\.png$", ".svg", path, ignore.case = TRUE)
    svglite::svglite(
      svg_path,
      width = width,
      height = height,
      bg = "transparent"
    )
    print(plot)
    grDevices::dev.off()
  }

  if (
    isTRUE(white_preview) &&
    requireNamespace("magick", quietly = TRUE)
  ) {
    preview <- sub(
      "\\.png$",
      "_white_preview.png",
      path,
      ignore.case = TRUE
    )
    image <- magick::image_read(path)
    image <- magick::image_background(image, "white", flatten = TRUE)
    magick::image_write(image, preview, format = "png")
  }

  invisible(path)
}

atlas_v312_weighted_mean <- function(x, w) {
  x <- suppressWarnings(as.numeric(x))
  w <- suppressWarnings(as.numeric(w))
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  sum(x[ok] * w[ok]) / sum(w[ok])
}

atlas_v312_observed_limits <- function(x, include_zero = TRUE, pad = 0.14) {
  x <- suppressWarnings(as.numeric(x))
  x <- x[is.finite(x)]
  if (!length(x)) return(c(0, 1))
  limits <- range(x)
  if (isTRUE(include_zero)) limits[[1L]] <- min(0, limits[[1L]])
  span <- diff(limits)
  if (!is.finite(span) || span <= 0) span <- max(abs(limits), 0.01)
  c(
    max(0, limits[[1L]] - span * 0.02),
    limits[[2L]] + span * pad
  )
}

atlas_v312_lwda_heatmap_plot <- function(lwda) {
  metric_columns <- c(
    automation_exposure = "Automation\nexposure",
    augmentation_potential = "Augmentation\npotential",
    expertise_leveling_potential = "Expertise-leveling\npotential",
    new_task_opportunity = "New-task\nopportunity",
    pro_worker_opportunity = "Pro-worker\nopportunity"
  )
  required <- c("lwda_combined", "estimated_jobs", names(metric_columns))
  missing <- setdiff(required, names(lwda))
  if (length(missing)) {
    stop(
      "LWDA heatmap is missing columns: ",
      paste(missing, collapse = ", "),
      call. = FALSE
    )
  }

  long <- lwda |>
    dplyr::select(dplyr::all_of(required)) |>
    tidyr::pivot_longer(
      cols = dplyr::all_of(names(metric_columns)),
      names_to = "metric",
      values_to = "score"
    ) |>
    dplyr::mutate(
      score = suppressWarnings(as.numeric(.data$score)),
      metric = factor(
        .data$metric,
        levels = names(metric_columns),
        labels = unname(metric_columns)
      ),
      lwda_label = paste0(
        .data$lwda_combined,
        "  |  ",
        scales::comma(round(.data$estimated_jobs)),
        " jobs"
      ),
      value_label = scales::percent(.data$score, accuracy = 0.1)
    ) |>
    dplyr::filter(is.finite(.data$score))

  order_values <- long |>
    dplyr::distinct(.data$lwda_label, .data$estimated_jobs) |>
    dplyr::arrange(.data$estimated_jobs) |>
    dplyr::pull(.data$lwda_label)

  long$lwda_label <- factor(long$lwda_label, levels = order_values)
  cut <- stats::quantile(long$score, 0.72, na.rm = TRUE)
  long$text_tone <- ifelse(long$score >= cut, "light_text", "dark_text")
  long$text_tone <- factor(
    long$text_tone,
    levels = c("light_text", "dark_text")
  )

  ggplot2::ggplot(
    long,
    ggplot2::aes(
      x = .data$metric,
      y = .data$lwda_label,
      fill = .data$score
    )
  ) +
    ggplot2::geom_tile(
      colour = "white",
      linewidth = 0.8,
      width = 0.98,
      height = 0.92
    ) +
    ggplot2::geom_text(
      ggplot2::aes(
        label = .data$value_label,
        colour = .data$text_tone
      ),
      family = atlas_v312_article_font(),
      size = 3.6,
      fontface = "bold", na.rm = TRUE
    ) +
    ggplot2::scale_colour_manual(
      values = c(light_text = "white", dark_text = "#000000"),
      limits = c("light_text", "dark_text"),
      guide = "none"
    ) +
    ggplot2::scale_fill_gradientn(
      colours = c("#C6D667", "#E0A624", "#1C5DBA"),
      labels = scales::label_percent(accuracy = 1),
      guide = ggplot2::guide_colourbar(
        title = "Employment-weighted score",
        title.position = "top",
        barwidth = grid::unit(3.1, "in"),
        barheight = grid::unit(0.16, "in")
      )
    ) +
    ggplot2::labs(x = NULL, y = NULL) +
    atlas_v312_theme() +
    ggplot2::theme(
      panel.grid = ggplot2::element_blank(),
      axis.text.x = ggplot2::element_text(
        size = 10,
        lineheight = 0.95,
        margin = ggplot2::margin(t = 4)
      ),
      axis.text.y = ggplot2::element_text(size = 10),
      legend.position = "bottom",
      plot.margin = ggplot2::margin(3, 3, 3, 3, unit = "pt")
    )
}

atlas_v312_training_pipeline_plot <- function(atlas) {
  lwda_col <- atlas_v312_pick_col(
    atlas,
    c("lwda_combined", "lwda"),
    label = "LWDA"
  )
  sector_col <- atlas_v312_pick_col(
    atlas,
    c("iowa_priority_sector", "priority_sector", "sector"),
    label = "priority sector"
  )
  action_col <- atlas_v312_pick_col(
    atlas,
    c("transition_priority", "transition_action", "action"),
    label = "transition action"
  )
  jobs_col <- atlas_v312_pick_col(
    atlas,
    c("estimated_jobs", "jobs", "employment"),
    label = "estimated jobs"
  )

  flows <- atlas |>
    dplyr::transmute(
      lwda = as.character(.data[[lwda_col]]),
      sector = as.character(.data[[sector_col]]),
      action = as.character(.data[[action_col]]),
      jobs = suppressWarnings(as.numeric(.data[[jobs_col]]))
    ) |>
    dplyr::filter(
      !is.na(.data$lwda),
      !is.na(.data$sector),
      !is.na(.data$action),
      is.finite(.data$jobs),
      .data$jobs > 0
    ) |>
    dplyr::group_by(.data$lwda, .data$sector, .data$action) |>
    dplyr::summarise(jobs = sum(.data$jobs), .groups = "drop")

  top_sectors <- flows |>
    dplyr::group_by(.data$sector) |>
    dplyr::summarise(jobs = sum(.data$jobs), .groups = "drop") |>
    dplyr::slice_max(.data$jobs, n = 7, with_ties = FALSE) |>
    dplyr::pull(.data$sector)

  flows <- flows |>
    dplyr::mutate(
      sector = dplyr::if_else(
        .data$sector %in% top_sectors,
        .data$sector,
        "Other sectors"
      )
    ) |>
    dplyr::group_by(.data$lwda, .data$sector, .data$action) |>
    dplyr::summarise(jobs = sum(.data$jobs), .groups = "drop")

  action_palette <- c(
    "Monitor" = "#7F7F7F",
    "Protect and redesign" = "#B32A2D",
    "Scale pro-worker AI opportunity" = "#1C5DBA",
    "Upgrade through AI-complementary training" = "#E0A624"
  )
  missing_actions <- setdiff(unique(flows$action), names(action_palette))
  if (length(missing_actions)) {
    action_palette <- c(
      action_palette,
      stats::setNames(
        grDevices::hcl.colors(length(missing_actions), "Dark 3"),
        missing_actions
      )
    )
  }

  if (requireNamespace("ggalluvial", quietly = TRUE)) {
    ggplot2::ggplot(
      flows,
      ggplot2::aes(
        axis1 = .data$lwda,
        axis2 = .data$sector,
        axis3 = .data$action,
        y = .data$jobs
      )
    ) +
      ggalluvial::geom_alluvium(
        ggplot2::aes(fill = .data$action),
        width = 0.16,
        alpha = 0.84,
        knot.pos = 0.45
      ) +
      ggalluvial::geom_stratum(
        width = 0.17,
        fill = "white",
        colour = "#505050",
        linewidth = 0.45
      ) +
      ggalluvial::stat_stratum(
        mapping = ggplot2::aes(
          label = ggplot2::after_stat(stratum)
        ),
        geom = "text",
        family = atlas_v312_article_font(),
        size = 3.0,
        lineheight = 0.92,
        na.rm = TRUE
      ) +
      ggplot2::scale_x_discrete(
        limits = c("LWDA", "Priority sector", "Transition action"),
        expand = c(0.08, 0.08)
      ) +
      ggplot2::scale_fill_manual(
        values = action_palette,
        name = "Transition action"
      ) +
      ggplot2::scale_y_continuous(
        labels = scales::label_number(
          scale_cut = scales::cut_short_scale(),
          accuracy = 1
        ),
        expand = ggplot2::expansion(mult = c(0, 0.04))
      ) +
      ggplot2::labs(x = NULL, y = "Estimated jobs") +
      atlas_v312_theme() +
      ggplot2::theme(
        panel.grid.major.x = ggplot2::element_blank(),
        legend.position = "bottom",
        plot.margin = ggplot2::margin(3, 18, 3, 18, unit = "pt")
      ) +
      ggplot2::coord_cartesian(clip = "off")
  } else {
    ggplot2::ggplot(
      flows,
      ggplot2::aes(
        x = .data$sector,
        y = .data$lwda,
        fill = .data$jobs
      )
    ) +
      ggplot2::geom_tile(colour = "white") +
      ggplot2::scale_fill_gradientn(
        colours = c("#C6D667", "#E0A624", "#1C5DBA"),
        labels = scales::label_comma()
      ) +
      ggplot2::labs(x = NULL, y = NULL, fill = "Estimated jobs") +
      atlas_v312_theme() +
      ggplot2::theme(
        axis.text.x = ggplot2::element_text(
          angle = 25,
          hjust = 1
        ),
        panel.grid = ggplot2::element_blank()
      )
  }
}

atlas_v312_commuting_heatmap_plot <- function(commuting) {
  if (is.null(commuting) || !nrow(commuting)) return(NULL)

  origin <- atlas_v312_pick_col(
    commuting,
    c(
      "home_lwda", "origin_lwda", "residence_lwda",
      "home_lwda_combined", "origin"
    ),
    required = FALSE
  )
  destination <- atlas_v312_pick_col(
    commuting,
    c(
      "work_lwda", "destination_lwda", "workplace_lwda",
      "work_lwda_combined", "destination"
    ),
    required = FALSE
  )
  count <- atlas_v312_pick_col(
    commuting,
    c("commuters", "estimated_jobs", "jobs", "count", "flow"),
    required = FALSE
  )

  if (any(is.na(c(origin, destination, count)))) return(NULL)

  matrix <- commuting |>
    dplyr::transmute(
      origin = as.character(.data[[origin]]),
      destination = as.character(.data[[destination]]),
      commuters = suppressWarnings(as.numeric(.data[[count]]))
    ) |>
    dplyr::filter(
      !is.na(.data$origin),
      !is.na(.data$destination),
      is.finite(.data$commuters),
      .data$commuters > 0
    ) |>
    dplyr::group_by(.data$origin, .data$destination) |>
    dplyr::summarise(
      commuters = sum(.data$commuters),
      .groups = "drop"
    ) |>
    dplyr::group_by(.data$origin) |>
    dplyr::mutate(
      origin_share = .data$commuters / sum(.data$commuters)
    ) |>
    dplyr::ungroup()

  ggplot2::ggplot(
    matrix,
    ggplot2::aes(
      x = .data$destination,
      y = .data$origin,
      fill = .data$origin_share
    )
  ) +
    ggplot2::geom_tile(
      colour = "white",
      linewidth = 0.7
    ) +
    ggplot2::geom_text(
      ggplot2::aes(
        label = paste0(
          scales::comma(round(.data$commuters)),
          "\n",
          scales::percent(.data$origin_share, accuracy = 1)
        )
      ),
      family = atlas_v312_article_font(),
      size = 3.1,
      lineheight = 0.92, na.rm = TRUE
    ) +
    ggplot2::scale_fill_gradientn(
      colours = c("#F4F6F8", "#C6D667", "#1C5DBA"),
      labels = scales::label_percent(accuracy = 1),
      name = "Share of origin commuters"
    ) +
    ggplot2::labs(
      x = "Work LWDA",
      y = "Home LWDA"
    ) +
    atlas_v312_theme() +
    ggplot2::theme(
      panel.grid = ggplot2::element_blank(),
      axis.text.x = ggplot2::element_text(
        angle = 20,
        hjust = 1
      ),
      legend.position = "bottom"
    )
}

atlas_v312_lollipop_plot <- function(atlas) {
  lwda_col <- atlas_v312_pick_col(
    atlas,
    c("lwda_combined", "lwda"),
    label = "LWDA"
  )
  occ_col <- atlas_v312_pick_col(
    atlas,
    c("occupation_title", "occ_title", "onet_title"),
    label = "occupation title"
  )
  soc_col <- atlas_v312_pick_col(
    atlas,
    c("soc_code", "occ_code", "occupation_code"),
    label = "SOC code"
  )
  jobs_col <- atlas_v312_pick_col(
    atlas,
    c("estimated_jobs", "jobs", "employment"),
    label = "estimated jobs"
  )
  auto_col <- atlas_v312_pick_col(
    atlas,
    c("automation_exposure"),
    label = "automation exposure"
  )
  pro_col <- atlas_v312_pick_col(
    atlas,
    c("pro_worker_opportunity"),
    label = "pro-worker opportunity"
  )

  summary <- atlas |>
    dplyr::transmute(
      lwda = as.character(.data[[lwda_col]]),
      occupation = as.character(.data[[occ_col]]),
      soc = as.character(.data[[soc_col]]),
      jobs = suppressWarnings(as.numeric(.data[[jobs_col]])),
      automation = suppressWarnings(as.numeric(.data[[auto_col]])),
      pro_worker = suppressWarnings(as.numeric(.data[[pro_col]]))
    ) |>
    dplyr::filter(
      !is.na(.data$lwda),
      !is.na(.data$occupation),
      is.finite(.data$jobs),
      .data$jobs > 0,
      is.finite(.data$automation),
      is.finite(.data$pro_worker)
    ) |>
    dplyr::group_by(.data$lwda, .data$soc, .data$occupation) |>
    dplyr::summarise(
      estimated_jobs = sum(.data$jobs),
      automation = atlas_v312_weighted_mean(
        .data$automation,
        .data$jobs
      ),
      pro_worker = atlas_v312_weighted_mean(
        .data$pro_worker,
        .data$jobs
      ),
      .groups = "drop"
    ) |>
    dplyr::group_by(.data$lwda) |>
    dplyr::slice_max(.data$estimated_jobs, n = 6, with_ties = FALSE) |>
    dplyr::ungroup() |>
    dplyr::mutate(
      occupation_label = stringr::str_wrap(
        paste0(.data$occupation, " (", .data$soc, ")"),
        width = 34
      )
    )

  max_score <- max(
    c(summary$automation, summary$pro_worker),
    na.rm = TRUE
  )
  x_limit <- max_score * 1.18

  ggplot2::ggplot(summary) +
    ggplot2::geom_segment(
      ggplot2::aes(
        x = .data$automation,
        xend = .data$pro_worker,
        y = .data$occupation_label,
        yend = .data$occupation_label
      ),
      colour = "#777777",
      linewidth = 0.8
    ) +
    ggplot2::geom_point(
      ggplot2::aes(
        x = .data$automation,
        y = .data$occupation_label
      ),
      colour = "#B32A2D",
      size = 3.0
    ) +
    ggplot2::geom_point(
      ggplot2::aes(
        x = .data$pro_worker,
        y = .data$occupation_label,
        size = .data$estimated_jobs
      ),
      colour = "#1C5DBA",
      alpha = 0.9
    ) +
    ggplot2::facet_grid(
      rows = ggplot2::vars(lwda),
      scales = "free_y",
      space = "free_y",
      switch = "y"
    ) +
    ggplot2::scale_x_continuous(
      limits = c(0, x_limit),
      labels = scales::label_percent(accuracy = 1),
      expand = ggplot2::expansion(mult = c(0, 0.03))
    ) +
    ggplot2::scale_size_area(
      max_size = 8,
      labels = scales::label_number(
        scale_cut = scales::cut_short_scale(),
        accuracy = 1
      ),
      name = "Estimated jobs"
    ) +
    ggplot2::labs(
      x = "Score",
      y = NULL
    ) +
    atlas_v312_theme(base_size = 10.5) +
    ggplot2::theme(
      strip.placement = "outside",
      strip.background = ggplot2::element_blank(),
      strip.text.y.left = ggplot2::element_text(
        angle = 0,
        face = "bold",
        colour = "#1C5DBA",
        hjust = 1
      ),
      panel.spacing.y = grid::unit(0.25, "lines"),
      legend.position = "bottom"
    )
}

atlas_v312_funnel_plot <- function(atlas) {
  jobs_col <- atlas_v312_pick_col(
    atlas,
    c("estimated_jobs", "jobs", "employment"),
    label = "estimated jobs"
  )
  auto_col <- atlas_v312_pick_col(
    atlas,
    c("automation_exposure"),
    label = "automation exposure"
  )
  pro_col <- atlas_v312_pick_col(
    atlas,
    c("pro_worker_opportunity"),
    label = "pro-worker opportunity"
  )
  action_col <- atlas_v312_pick_col(
    atlas,
    c("transition_priority", "transition_action", "action"),
    required = FALSE
  )

  data <- atlas |>
    dplyr::transmute(
      jobs = suppressWarnings(as.numeric(.data[[jobs_col]])),
      automation = suppressWarnings(as.numeric(.data[[auto_col]])),
      pro_worker = suppressWarnings(as.numeric(.data[[pro_col]])),
      action = if (!is.na(action_col)) {
        as.character(.data[[action_col]])
      } else {
        NA_character_
      }
    ) |>
    dplyr::filter(
      is.finite(.data$jobs),
      .data$jobs > 0,
      is.finite(.data$automation),
      is.finite(.data$pro_worker)
    )

  threshold <- stats::weighted.mean(
    data$automation,
    data$jobs,
    na.rm = TRUE
  ) + stats::sd(data$automation, na.rm = TRUE)

  if (!is.finite(threshold)) {
    threshold <- stats::quantile(
      data$automation,
      0.75,
      na.rm = TRUE
    )
  }

  high <- data$automation >= threshold
  convertible <- high & data$pro_worker >= data$automation
  actionable <- if (!all(is.na(data$action))) {
    convertible &
      !is.na(data$action) &
      !(tolower(data$action) %in% c("monitor", "na", ""))
  } else {
    convertible
  }

  funnel <- tibble::tibble(
    stage = c(
      "All estimated jobs",
      paste0(
        "Above high-exposure threshold\n(",
        scales::percent(threshold, accuracy = 0.1),
        ")"
      ),
      "High exposure with opportunity\nat least as strong",
      "Actionable upgrade or scale"
    ),
    jobs = c(
      sum(data$jobs),
      sum(data$jobs[high]),
      sum(data$jobs[convertible]),
      sum(data$jobs[actionable])
    )
  ) |>
    dplyr::mutate(
      stage = factor(.data$stage, levels = rev(.data$stage)),
      label = scales::comma(round(.data$jobs))
    )

  ggplot2::ggplot(
    funnel,
    ggplot2::aes(
      x = .data$jobs,
      y = .data$stage
    )
  ) +
    ggplot2::geom_col(
      fill = "#1C5DBA",
      width = 0.66
    ) +
    ggplot2::geom_text(
      ggplot2::aes(label = .data$label),
      hjust = -0.12,
      family = atlas_v312_article_font(),
      size = 3.6,
      fontface = "bold", na.rm = TRUE
    ) +
    ggplot2::scale_x_continuous(
      labels = scales::label_number(
        scale_cut = scales::cut_short_scale(),
        accuracy = 1
      ),
      expand = ggplot2::expansion(mult = c(0, 0.16))
    ) +
    ggplot2::labs(
      x = "Estimated jobs",
      y = NULL
    ) +
    atlas_v312_theme() +
    ggplot2::theme(
      panel.grid.major.y = ggplot2::element_blank()
    ) +
    ggplot2::coord_cartesian(clip = "off")
}

atlas_v312_county_leaderboard_plot <- function(county) {
  if (is.null(county) || !nrow(county)) return(NULL)

  name_col <- atlas_v312_pick_col(
    county,
    c("county_name", "name"),
    label = "county name"
  )
  jobs_col <- atlas_v312_pick_col(
    county,
    c(
      "actionable_jobs", "actionable_estimated_jobs",
      "estimated_jobs", "jobs"
    ),
    label = "actionable jobs"
  )
  share_col <- atlas_v312_pick_col(
    county,
    c("actionable_job_share", "actionable_share"),
    required = FALSE
  )

  leaders <- county |>
    dplyr::transmute(
      county = as.character(.data[[name_col]]),
      jobs = suppressWarnings(as.numeric(.data[[jobs_col]])),
      share = if (!is.na(share_col)) {
        suppressWarnings(as.numeric(.data[[share_col]]))
      } else {
        NA_real_
      }
    ) |>
    dplyr::filter(
      !is.na(.data$county),
      is.finite(.data$jobs),
      .data$jobs > 0
    ) |>
    dplyr::slice_max(.data$jobs, n = 20, with_ties = FALSE) |>
    dplyr::arrange(.data$jobs) |>
    dplyr::mutate(
      county = factor(.data$county, levels = .data$county),
      label = ifelse(
        is.finite(.data$share),
        paste0(
          scales::comma(round(.data$jobs)),
          "  |  ",
          scales::percent(.data$share, accuracy = 0.1)
        ),
        scales::comma(round(.data$jobs))
      )
    )

  ggplot2::ggplot(
    leaders,
    ggplot2::aes(
      x = .data$jobs,
      y = .data$county
    )
  ) +
    ggplot2::geom_col(
      fill = "#1C5DBA",
      width = 0.7
    ) +
    ggplot2::geom_text(
      ggplot2::aes(label = .data$label),
      hjust = -0.08,
      family = atlas_v312_article_font(),
      size = 3.25, na.rm = TRUE
    ) +
    ggplot2::scale_x_continuous(
      labels = scales::label_number(
        scale_cut = scales::cut_short_scale(),
        accuracy = 1
      ),
      expand = ggplot2::expansion(mult = c(0, 0.22))
    ) +
    ggplot2::labs(
      x = "Estimated actionable jobs",
      y = NULL
    ) +
    atlas_v312_theme() +
    ggplot2::theme(
      panel.grid.major.y = ggplot2::element_blank()
    ) +
    ggplot2::coord_cartesian(clip = "off")
}

atlas_v312_build_article_overrides <- function(
    root = getwd(),
    save = TRUE) {

  root <- normalizePath(root, winslash = "/", mustWork = TRUE)
  data <- atlas_v312_load_visual_data(root)
  public_dir <- file.path(root, "figures", "public")
  dir.create(public_dir, recursive = TRUE, showWarnings = FALSE)

  plots <- list()

  if (!is.null(data$lwda) && nrow(data$lwda)) {
    plots$public_03 <- atlas_v312_lwda_heatmap_plot(data$lwda)
    if (isTRUE(save)) {
      atlas_v312_save_plot(
        plots$public_03,
        file.path(
          public_dir,
          "public_03_lwda_ai_compass.png"
        ),
        width = 9.4,
        height = 4.7
      )
    }
  }

  plots$public_07 <- atlas_v312_training_pipeline_plot(data$atlas)
  if (isTRUE(save)) {
    atlas_v312_save_plot(
      plots$public_07,
      file.path(
        public_dir,
        "public_07_training_pipeline_alluvial.png"
      ),
      width = 11,
      height = 6.4
    )
  }

  commute_plot <- atlas_v312_commuting_heatmap_plot(data$commuting)
  if (!is.null(commute_plot)) {
    plots$public_10 <- commute_plot
    if (isTRUE(save)) {
      atlas_v312_save_plot(
        plots$public_10,
        file.path(
          public_dir,
          "public_10_lwda_commuting_alluvial.png"
        ),
        width = 9.2,
        height = 5.6
      )
    }
  }

  plots$public_12 <- atlas_v312_lollipop_plot(data$atlas)
  if (isTRUE(save)) {
    atlas_v312_save_plot(
      plots$public_12,
      file.path(
        public_dir,
        "public_12_lwda_top_occupation_lollipops.png"
      ),
      width = 10.5,
      height = 10.5
    )
  }

  plots$public_20 <- atlas_v312_funnel_plot(data$atlas)
  if (isTRUE(save)) {
    atlas_v312_save_plot(
      plots$public_20,
      file.path(
        public_dir,
        "public_20_training_funnel.png"
      ),
      width = 9.2,
      height = 5.4
    )
  }

  county_plot <- atlas_v312_county_leaderboard_plot(data$county)
  if (!is.null(county_plot)) {
    plots$public_26 <- county_plot
    if (isTRUE(save)) {
      atlas_v312_save_plot(
        plots$public_26,
        file.path(
          public_dir,
          "public_26_county_action_leaderboard.png"
        ),
        width = 9.4,
        height = 7.3
      )
    }
  }

  attr(plots, "data") <- data
  plots
}
