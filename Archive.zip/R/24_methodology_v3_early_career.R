# Methodology v3 early-career fragility, entry hiring, separations, and apprenticeship access

v3_industry_exposure <- function(atlas) {
  if (!nrow(atlas)) return(tibble::tibble())
  exposure_col <- intersect(c("automation_exposure", "mean_exposure", "ai_exposure"), names(atlas))
  if (!length(exposure_col)) return(tibble::tibble())
  emp_col <- intersect(c("estimated_jobs", "employment", "emp"), names(atlas))
  if (!length(emp_col)) return(tibble::tibble())
  atlas |>
    dplyr::mutate(
      naics2 = v3_normalize_naics2(naics2),
      exposure = v3_validate_unit_interval(.data[[exposure_col[[1]]]], exposure_col[[1]]),
      jobs = pmax(v3_as_numeric(.data[[emp_col[[1]]]]), 0)
    ) |>
    dplyr::filter(!is.na(naics2)) |>
    dplyr::group_by(naics2) |>
    dplyr::summarise(
      automation_exposure = v3_weighted_mean(exposure, jobs),
      estimated_jobs = sum(jobs, na.rm = TRUE),
      .groups = "drop"
    )
}

v3_prepare_qwi_early_career <- function(qwi) {
  if (!nrow(qwi)) return(tibble::tibble())
  qwi <- v3_clean_names(qwi)
  required <- c("agegrp", "naics2", "period")
  v3_require_columns(qwi, required, "QWI early-career data")
  aliases <- list(
    emp = c("emp", "emp_total", "employment"),
    emp_s = c("emp_s", "emps", "stable_employment"),
    hir_a = c("hir_a", "hira", "all_hires"),
    hir_n = c("hir_n", "hirn", "new_hires"),
    sep = c("sep", "separations"),
    earn_s = c("earn_s", "earns", "average_monthly_earnings"),
    frm_jb_gn = c("frm_jb_gn", "frmjbgn", "job_gains"),
    frm_jb_ls = c("frm_jb_ls", "frmjbls", "job_losses")
  )
  for (target in names(aliases)) {
    hit <- intersect(aliases[[target]], names(qwi))
    qwi[[target]] <- if (length(hit)) v3_as_numeric(qwi[[hit[[1]]]]) else NA_real_
  }
  qwi |>
    dplyr::mutate(
      naics2 = v3_normalize_naics2(naics2),
      period_index = dplyr::coalesce(v3_as_numeric(period_index), v3_quarter_index(period)),
      employment = dplyr::coalesce(emp, emp_s),
      hires = dplyr::coalesce(hir_a, hir_n),
      hire_rate = dplyr::if_else(employment > 0, hires / employment, NA_real_),
      separation_rate = dplyr::if_else(employment > 0, sep / employment, NA_real_),
      job_gain_rate = dplyr::if_else(employment > 0, frm_jb_gn / employment, NA_real_),
      job_loss_rate = dplyr::if_else(employment > 0, frm_jb_ls / employment, NA_real_)
    ) |>
    dplyr::filter(!is.na(naics2), !is.na(period_index))
}

v3_pre_post_change <- function(x, event_idx, minimum_pre = 8, minimum_post = 4) {
  # Use deterministic, adjacent windows. The pre-period is the last configured
  # number of quarters before the event; the post-period is the first equally
  # long window after the event (or all available quarters when shorter).
  x <- x |> dplyr::arrange(period_index)
  pre <- x |>
    dplyr::filter(period_index <= event_idx) |>
    dplyr::slice_tail(n = minimum_pre)
  post_all <- x |>
    dplyr::filter(period_index > event_idx) |>
    dplyr::arrange(period_index)
  post_window <- max(as.integer(minimum_pre), as.integer(minimum_post))
  post <- post_all |>
    dplyr::slice_head(n = min(post_window, nrow(post_all)))
  metrics <- c("employment", "hires", "hire_rate", "separation_rate", "earn_s", "job_gain_rate", "job_loss_rate")
  out <- list()
  for (m in metrics) {
    pv <- mean(v3_as_numeric(pre[[m]]), na.rm = TRUE)
    qv <- mean(v3_as_numeric(post[[m]]), na.rm = TRUE)
    if (!is.finite(pv)) pv <- NA_real_
    if (!is.finite(qv)) qv <- NA_real_
    out[[paste0(m, "_pre")]] <- pv
    out[[paste0(m, "_post")]] <- qv
    out[[paste0(m, "_change")]] <- if (is.finite(pv) && pv != 0 && is.finite(qv)) qv / pv - 1 else qv - pv
  }
  out$quarters_pre <- nrow(pre)
  out$quarters_post <- nrow(post)
  tibble::as_tibble(out)
}

v3_early_career_changes <- function(qwi, exposure, cfg) {
  if (!nrow(qwi)) return(tibble::tibble())
  event_idx <- v3_quarter_index(cfg$early_career$event_quarter %||% "2022-Q4")
  min_pre <- cfg$early_career$minimum_quarters_pre %||% 8
  min_post <- cfg$early_career$minimum_quarters_post %||% 4
  changes <- qwi |>
    dplyr::group_by(naics2, agegrp) |>
    dplyr::group_modify(~v3_pre_post_change(.x, event_idx, min_pre, min_post)) |>
    dplyr::ungroup()
  focal <- changes |>
    dplyr::filter(agegrp == (cfg$early_career$focal_age_group %||% "A03")) |>
    dplyr::rename_with(~paste0("early_", .x), -naics2)
  comparison <- changes |>
    dplyr::filter(agegrp == "A04") |>
    dplyr::rename_with(~paste0("comparison_", .x), -naics2)
  out <- focal |>
    dplyr::left_join(comparison, by = "naics2") |>
    dplyr::left_join(exposure, by = "naics2") |>
    dplyr::mutate(
      employment_change_gap = early_employment_change - comparison_employment_change,
      hire_change_gap = early_hires_change - comparison_hires_change,
      hire_rate_change_gap = early_hire_rate_change - comparison_hire_rate_change,
      earnings_change_gap = early_earn_s_change - comparison_earn_s_change,
      separation_change_gap = early_separation_rate_change - comparison_separation_rate_change,
      fragility_raw = rowMeans(cbind(
        -v3_zscore(employment_change_gap),
        -v3_zscore(hire_change_gap),
        -v3_zscore(hire_rate_change_gap),
        -v3_zscore(earnings_change_gap),
        v3_zscore(separation_change_gap),
        v3_zscore(automation_exposure)
      ), na.rm = TRUE),
      early_career_fragility_index = v3_percentile(fragility_raw),
      evidence_status = "OBSERVED",
      reliability_class = dplyr::case_when(
        early_quarters_pre >= min_pre & early_quarters_post >= min_post & early_employment_pre >= 500 ~ "A",
        early_quarters_pre >= min_pre & early_quarters_post >= min_post & early_employment_pre >= 100 ~ "B",
        TRUE ~ "C"
      ),
      causal_claim_allowed = FALSE,
      interpretation = "Descriptive pre/post and age-gap indicator; not a causal estimate of AI effects."
    ) |>
    dplyr::arrange(dplyr::desc(early_career_fragility_index), naics2)
  out
}



# IA_ATLAS_V312_HOTFIX4_EARLY_CAREER_JOIN_CONTRACT_BEGIN
# Keep occupation-industry exposure and employment as the canonical cell-level
# fields. The industry-level QWI benchmark carries fields with the same names;
# rename those before joining so dplyr does not create .x/.y suffixes and remove
# the canonical columns expected by the cell-fragility calculation.
v3_prepare_occupation_industry_early_career_join <- function(
    cells,
    industry_results) {

  industry_join <- tibble::as_tibble(industry_results)

  collision_map <- c(
    automation_exposure = "industry_automation_exposure",
    estimated_jobs = "industry_estimated_jobs"
  )

  for (source_name in names(collision_map)) {
    if (!source_name %in% names(industry_join)) next
    target_name <- unname(collision_map[[source_name]])

    if (target_name %in% names(industry_join)) {
      # A locally extended input may already carry the explicit audit column.
      # Keep that explicit field and remove only the duplicate ambiguous alias.
      industry_join[[source_name]] <- NULL
    } else {
      names(industry_join)[names(industry_join) == source_name] <- target_name
    }
  }

  joined <- dplyr::left_join(cells, industry_join, by = "naics2")

  forbidden_suffixes <- intersect(
    c(
      "automation_exposure.x", "automation_exposure.y",
      "estimated_jobs.x", "estimated_jobs.y"
    ),
    names(joined)
  )

  if (length(forbidden_suffixes)) {
    stop(
      "The Methodology v3 early-career join produced ambiguous duplicate ",
      "columns: ", paste(forbidden_suffixes, collapse = ", "), ".",
      call. = FALSE
    )
  }

  required <- c("automation_exposure", "estimated_jobs")
  missing_required <- setdiff(required, names(joined))
  if (length(missing_required)) {
    stop(
      "The Methodology v3 early-career join is missing canonical cell fields: ",
      paste(missing_required, collapse = ", "), ".",
      call. = FALSE
    )
  }

  joined
}
# IA_ATLAS_V312_HOTFIX4_EARLY_CAREER_JOIN_CONTRACT_END

v3_occupation_industry_early_career <- function(industry_results, atlas, cfg) {
  if (!nrow(industry_results) || !nrow(atlas) || !all(c("naics2", "soc_code", "estimated_jobs") %in% names(atlas))) {
    return(tibble::tibble())
  }
  needed <- intersect(c(
    "automation_exposure", "pro_worker_opportunity", "augmentation_potential",
    "expertise_leveling_potential", "new_task_opportunity"
  ), names(atlas))
  if (!"automation_exposure" %in% needed) return(tibble::tibble())
  cells <- atlas |>
    dplyr::mutate(
      naics2 = v3_normalize_naics2(naics2),
      soc_code = v3_normalize_soc(soc_code),
      jobs_weight = pmax(v3_as_numeric(estimated_jobs), 0),
      automation_exposure = v3_validate_unit_interval(automation_exposure, "automation_exposure"),
      pro_worker_opportunity = if ("pro_worker_opportunity" %in% names(atlas))
        v3_validate_unit_interval(pro_worker_opportunity, "pro_worker_opportunity") else NA_real_
    ) |>
    dplyr::filter(!is.na(naics2), !is.na(soc_code)) |>
    dplyr::group_by(naics2, soc_code, dplyr::across(dplyr::any_of("occupation_title"))) |>
    dplyr::summarise(
      estimated_jobs = sum(jobs_weight, na.rm = TRUE),
      automation_exposure = v3_weighted_mean(automation_exposure, jobs_weight),
      pro_worker_opportunity = v3_weighted_mean(pro_worker_opportunity, jobs_weight),
      .groups = "drop"
    ) |>
    v3_prepare_occupation_industry_early_career_join(industry_results)

  weights <- cfg$early_career$cell_fragility_weights %||% list(
    observed_industry_fragility = 0.55,
    occupation_automation_exposure = 0.30,
    occupation_pro_worker_offset = 0.15
  )
  w_ind <- as.numeric(weights$observed_industry_fragility %||% 0.55)
  w_auto <- as.numeric(weights$occupation_automation_exposure %||% 0.30)
  w_offset <- as.numeric(weights$occupation_pro_worker_offset %||% 0.15)
  denom <- w_ind + w_auto + w_offset
  if (!is.finite(denom) || denom <= 0) stop("Early-career cell-fragility weights must sum to a positive value.", call. = FALSE)

  cells |>
    dplyr::mutate(
      fragility_component = v3_percentile(early_career_fragility_index),
      exposure_component = v3_percentile(automation_exposure),
      opportunity_offset = v3_percentile(pro_worker_opportunity),
      cell_fragility_raw = (
        w_ind * dplyr::coalesce(fragility_component, 0.5) +
          w_auto * dplyr::coalesce(exposure_component, 0.5) +
          w_offset * (1 - dplyr::coalesce(opportunity_offset, 0.5))
      ) / denom,
      early_career_cell_fragility_index = v3_percentile(cell_fragility_raw),
      early_career_risk_tier = dplyr::case_when(
        early_career_cell_fragility_index >= 0.80 ~ "High",
        early_career_cell_fragility_index >= 0.50 ~ "Elevated",
        TRUE ~ "Monitor"
      ),
      evidence_status = "BENCHMARKED",
      reliability_class = "C",
      causal_claim_allowed = FALSE,
      note = "Occupation-industry cell combines observed state-industry age dynamics with modeled occupation exposure and opportunity; it is a benchmarked planning indicator, not a causal estimate or local age-specific count."
    ) |>
    dplyr::arrange(dplyr::desc(early_career_cell_fragility_index), dplyr::desc(estimated_jobs), naics2, soc_code)
}

v3_read_apprenticeship_access <- function(paths = v3_paths()) {
  path <- file.path(paths$inputs, "apprenticeship_access.csv")
  if (!file.exists(path)) path <- file.path(paths$inputs, "apprenticeship_access_template.csv")
  x <- v3_drop_example_rows(v3_read_csv(path))
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(x)
  x |>
    dplyr::mutate(
      county_fips = v3_normalize_fips5(county_fips),
      naics2 = v3_normalize_naics2(naics2),
      soc_code = v3_normalize_soc(soc_code),
      dplyr::across(dplyr::any_of(c("active_apprentices", "new_registrations", "completions", "capacity", "waitlist", "entry_wage", "completion_wage")), v3_as_numeric)
    )
}

v3_apprenticeship_summary <- function(apprenticeship, atlas) {
  if (!nrow(apprenticeship)) return(tibble::tibble())
  x <- apprenticeship |>
    dplyr::group_by(lwda_combined, naics2) |>
    dplyr::summarise(
      apprenticeship_capacity = sum(capacity, na.rm = TRUE),
      active_apprentices = sum(active_apprentices, na.rm = TRUE),
      new_registrations = sum(new_registrations, na.rm = TRUE),
      completions = sum(completions, na.rm = TRUE),
      waitlist = sum(waitlist, na.rm = TRUE),
      programs = dplyr::n_distinct(program_id),
      .groups = "drop"
    )
  if (nrow(atlas) && all(c("lwda_combined", "naics2", "estimated_jobs") %in% names(atlas))) {
    jobs <- atlas |>
      dplyr::group_by(lwda_combined, naics2) |>
      dplyr::summarise(estimated_jobs = sum(v3_as_numeric(estimated_jobs), na.rm = TRUE), .groups = "drop")
    x <- x |>
      dplyr::left_join(jobs, by = c("lwda_combined", "naics2")) |>
      dplyr::mutate(
        capacity_per_1000_jobs = 1000 * apprenticeship_capacity / pmax(estimated_jobs, 1),
        completion_rate = completions / pmax(active_apprentices, 1),
        access_gap_index = 1 - v3_percentile(capacity_per_1000_jobs)
      )
  }
  x
}

v3_lwda_early_career_scenario <- function(industry_results, atlas) {
  if (!nrow(industry_results) || !nrow(atlas) || !all(c("lwda_combined", "naics2", "estimated_jobs") %in% names(atlas))) return(tibble::tibble())
  weights <- atlas |>
    dplyr::group_by(lwda_combined, naics2) |>
    dplyr::summarise(estimated_jobs = sum(v3_as_numeric(estimated_jobs), na.rm = TRUE), .groups = "drop")
  weights |>
    dplyr::left_join(industry_results |>
      dplyr::select(naics2, early_career_fragility_index, employment_change_gap, hire_change_gap, earnings_change_gap, reliability_class),
      by = "naics2") |>
    dplyr::group_by(lwda_combined) |>
    dplyr::summarise(
      weighted_fragility_index = v3_weighted_mean(early_career_fragility_index, estimated_jobs),
      employment_change_gap = v3_weighted_mean(employment_change_gap, estimated_jobs),
      hire_change_gap = v3_weighted_mean(hire_change_gap, estimated_jobs),
      earnings_change_gap = v3_weighted_mean(earnings_change_gap, estimated_jobs),
      industries_covered = sum(is.finite(v3_as_numeric(early_career_fragility_index))),
      reliability_class = "C",
      evidence_status = "SCENARIO",
      note = "LWDA values are industry-composition scenarios based on Iowa state-industry QWI; they are not locally observed early-career counts.",
      .groups = "drop"
    ) |>
    dplyr::rename(early_career_fragility_index = weighted_fragility_index)
}

apply_methodology_v3_early_career <- function(public_inputs, atlas, paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  qwi <- v3_prepare_qwi_early_career(public_inputs$qwi)
  exposure <- v3_industry_exposure(atlas)
  industry <- v3_early_career_changes(qwi, exposure, cfg)
  occupation_industry <- v3_occupation_industry_early_career(industry, atlas, cfg)
  apprenticeship <- v3_read_apprenticeship_access(paths)
  apprenticeship_summary <- v3_apprenticeship_summary(apprenticeship, atlas)
  lwda <- v3_lwda_early_career_scenario(industry, atlas)
  status <- tibble::tibble(
    module = "early_career_fragility",
    qwi_rows = nrow(qwi),
    industries = nrow(industry),
    apprenticeship_records = nrow(apprenticeship),
    evidence_status = if (nrow(industry)) "OBSERVED" else "UNAVAILABLE",
    note = if (nrow(industry))
      "Industry-state indicators use QWI age group A03 (ages 22-24) and comparison groups. LWDA results are composition scenarios."
    else
      "No age-specific QWI data were available; early-career fragility is not inferred from aggregate exposure alone."
  )
  v3_write_csv(industry, file.path(paths$processed, "early_career_fragility_by_industry.csv"))
  v3_write_csv(occupation_industry, file.path(paths$processed, "early_career_fragility_occupation_industry.csv"))
  v3_write_csv(lwda, file.path(paths$processed, "early_career_fragility_lwda_scenario.csv"))
  v3_write_csv(apprenticeship_summary, file.path(paths$processed, "apprenticeship_access_summary.csv"))
  v3_write_csv(status, file.path(paths$outputs, "early_career_status_v3.csv"))
  list(qwi = qwi, industry = industry, occupation_industry = occupation_industry, lwda = lwda, apprenticeship = apprenticeship_summary, status = status)
}
