# Methodology v3 industrial-AI readiness and productivity J-curve
# Version 3.0.3: typed empty contracts keep missing local assessments explicit
# without producing uninitialised-column warnings or downstream join failures.

v3_industrial_component_names <- function(paths = v3_paths()) {
  weight_path <- file.path(paths$config, "v3_industrial_readiness_weights.csv")
  weights <- v3_read_csv(weight_path)
  if (nrow(weights) && "component" %in% names(weights)) {
    out <- trimws(as.character(weights[["component"]]))
    out <- out[nzchar(out) & !is.na(out)]
    if (length(out)) return(unique(out))
  }
  c(
    "complementary_capital", "sensor_coverage", "usable_data_infrastructure",
    "maintenance_capacity", "production_management", "cybersecurity",
    "workforce_training", "organizational_change", "financing_capacity"
  )
}

v3_empty_industrial_assessments <- function(paths = v3_paths()) {
  x <- tibble::tibble(
    assessment_id = character(),
    assessment_date = as.Date(character()),
    employer_or_site = character(),
    county_fips = character(),
    lwda_combined = character(),
    naics2 = character(),
    employees = numeric(),
    implementation_cost = numeric(),
    monthly_value_added_baseline = numeric(),
    productivity_dip_percent = numeric(),
    productivity_dip_months = numeric(),
    ramp_months = numeric(),
    plateau_productivity_gain_percent = numeric(),
    annual_operating_cost = numeric(),
    worker_gain_share = numeric(),
    confidence_level = character(),
    assessor = character(),
    notes = character()
  )
  for (nm in v3_industrial_component_names(paths)) x[[nm]] <- numeric()
  x
}

v3_empty_industrial_readiness <- function(paths = v3_paths()) {
  x <- v3_empty_industrial_assessments(paths)
  for (nm in v3_industrial_component_names(paths)) x[[paste0(nm, "_score")]] <- numeric()
  x$component_coverage <- numeric()
  x$industrial_ai_readiness_index <- numeric()
  x$readiness_bottleneck <- character()
  x$evidence_status <- character()
  x$reliability_class <- character()
  x
}

v3_empty_industrial_jcurve <- function() {
  tibble::tibble(
    assessment_id = character(),
    employer_or_site = character(),
    county_fips = character(),
    lwda_combined = character(),
    naics2 = character(),
    month = integer(),
    productivity_effect = numeric(),
    monthly_benefit = numeric(),
    monthly_cost = numeric(),
    net_cash_flow = numeric(),
    discounted_net_cash_flow = numeric(),
    cumulative_npv = numeric(),
    worker_gain = numeric(),
    break_even_month = integer(),
    evidence_status = character()
  )
}

v3_empty_industrial_jcurve_summary <- function() {
  tibble::tibble(
    assessment_id = character(),
    break_even_month = integer(),
    npv_36_months = numeric(),
    max_productivity_dip = numeric(),
    plateau_productivity_effect = numeric(),
    worker_gain_36_months = numeric()
  )
}

v3_empty_industrial_summary <- function(paths = v3_paths()) {
  x <- v3_empty_industrial_readiness(paths)
  extras <- v3_empty_industrial_jcurve_summary()
  for (nm in setdiff(names(extras), names(x))) x[[nm]] <- extras[[nm]]
  x$readiness_action <- character()
  x$financing_risk <- character()
  x
}

v3_column_or <- function(x, name, default = NULL) {
  if (is.data.frame(x) && name %in% names(x)) return(x[[name]])
  if (!is.null(default)) return(default)
  NULL
}

v3_read_industrial_assessments <- function(paths = v3_paths()) {
  path <- file.path(paths$inputs, "industrial_readiness_assessment.csv")
  if (!file.exists(path)) path <- file.path(paths$inputs, "industrial_readiness_assessment_template.csv")
  x <- v3_drop_example_rows(v3_read_csv(path))
  if (!nrow(x)) return(v3_empty_industrial_assessments(paths))

  x <- v3_clean_names(x)
  components <- v3_industrial_component_names(paths)
  v3_require_columns(x, c("assessment_id", "naics2", components), "Industrial readiness assessment")

  character_optional <- c(
    "employer_or_site", "county_fips", "lwda_combined", "confidence_level",
    "assessor", "notes"
  )
  numeric_optional <- c(
    "employees", "implementation_cost", "monthly_value_added_baseline",
    "productivity_dip_percent", "productivity_dip_months", "ramp_months",
    "plateau_productivity_gain_percent", "annual_operating_cost", "worker_gain_share"
  )
  if (!"assessment_date" %in% names(x)) x$assessment_date <- as.Date(NA)
  for (nm in character_optional) if (!nm %in% names(x)) x[[nm]] <- NA_character_
  for (nm in numeric_optional) if (!nm %in% names(x)) x[[nm]] <- NA_real_

  x |>
    dplyr::mutate(
      assessment_id = as.character(assessment_id),
      assessment_date = v3_parse_date(assessment_date),
      employer_or_site = as.character(employer_or_site),
      county_fips = v3_normalize_fips5(county_fips),
      lwda_combined = as.character(lwda_combined),
      naics2 = v3_normalize_naics2(naics2),
      dplyr::across(dplyr::all_of(components), v3_as_numeric),
      dplyr::across(dplyr::all_of(numeric_optional), v3_as_numeric),
      dplyr::across(dplyr::all_of(c("confidence_level", "assessor", "notes")), as.character)
    )
}

v3_component_score <- function(x) {
  # Assessment inputs are declared on a 0-4 maturity scale.
  z <- v3_as_numeric(x)
  bad <- is.finite(z) & (z < 0 | z > 4)
  if (any(bad)) stop("Industrial readiness components must use the declared 0-4 maturity scale.", call. = FALSE)
  z / 4
}

v3_calculate_industrial_readiness <- function(x, paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  if (!nrow(x)) return(v3_empty_industrial_readiness(paths))
  weights <- v3_read_csv(file.path(paths$config, "v3_industrial_readiness_weights.csv"), required = TRUE)
  components <- as.character(weights$component)
  weight_map <- stats::setNames(v3_as_numeric(weights$weight), components)
  for (nm in components) x[[paste0(nm, "_score")]] <- v3_component_score(x[[nm]])
  score_cols <- paste0(components, "_score")
  score_matrix <- as.matrix(x[, score_cols, drop = FALSE])
  storage.mode(score_matrix) <- "double"
  weight_matrix <- matrix(weight_map[components], nrow = nrow(x), ncol = length(components), byrow = TRUE)
  observed <- is.finite(score_matrix)
  weighted_sum <- rowSums(ifelse(observed, score_matrix * weight_matrix, 0), na.rm = TRUE)
  observed_weight <- rowSums(ifelse(observed, weight_matrix, 0), na.rm = TRUE)
  x$component_coverage <- observed_weight / sum(weight_map)
  x$industrial_ai_readiness_index <- ifelse(
    x$component_coverage >= (cfg$industrial_readiness$minimum_component_coverage %||% 0.60),
    weighted_sum / pmax(observed_weight, 1e-9),
    NA_real_
  )
  x$readiness_bottleneck <- apply(score_matrix, 1, function(z) {
    if (!any(is.finite(z))) return(NA_character_)
    components[which.min(replace(z, !is.finite(z), Inf))]
  })
  x$evidence_status <- ifelse(is.finite(x$industrial_ai_readiness_index), "OBSERVED", "UNAVAILABLE")
  x$reliability_class <- dplyr::case_when(
    x$component_coverage >= 0.90 ~ "A",
    x$component_coverage >= (cfg$industrial_readiness$minimum_component_coverage %||% 0.60) ~ "B",
    TRUE ~ "C"
  )
  x
}

v3_j_curve_profile <- function(row, cfg) {
  horizon <- as.integer(cfg$industrial_readiness$j_curve_horizon_months %||% 36)
  months <- 0:horizon
  implementation_cost <- v3_as_numeric(row$implementation_cost %||% NA_real_)
  baseline <- v3_as_numeric(row$monthly_value_added_baseline %||% NA_real_)
  dip_pct <- v3_as_numeric(row$productivity_dip_percent %||% NA_real_) / 100
  dip_months <- as.integer(v3_as_numeric(row$productivity_dip_months %||% cfg$industrial_readiness$default_productivity_dip_months %||% 3))
  ramp_months <- as.integer(v3_as_numeric(row$ramp_months %||% cfg$industrial_readiness$default_ramp_months %||% 12))
  plateau <- v3_as_numeric(row$plateau_productivity_gain_percent %||% NA_real_) / 100
  annual_op <- v3_as_numeric(row$annual_operating_cost %||% 0)
  worker_share <- v3_as_numeric(row$worker_gain_share %||% NA_real_)
  readiness <- v3_as_numeric(row$industrial_ai_readiness_index %||% NA_real_)
  if (!all(is.finite(c(implementation_cost, baseline, dip_pct, plateau, readiness)))) return(v3_empty_industrial_jcurve())
  readiness <- v3_clamp(readiness)
  # Lower readiness deepens and lengthens the implementation dip and delays benefits.
  effective_dip <- dip_pct * (1 + (1 - readiness))
  effective_ramp <- max(1L, round(ramp_months * (1 + 0.75 * (1 - readiness))))
  productivity_effect <- numeric(length(months))
  for (i in seq_along(months)) {
    m <- months[[i]]
    if (m <= dip_months) {
      productivity_effect[[i]] <- effective_dip
    } else {
      progress <- v3_clamp((m - dip_months) / effective_ramp)
      productivity_effect[[i]] <- effective_dip * (1 - progress) + plateau * readiness * progress
    }
  }
  monthly_benefit <- baseline * productivity_effect
  monthly_cost <- rep(annual_op / 12, length(months))
  monthly_cost[1] <- monthly_cost[1] + implementation_cost
  net_cash_flow <- monthly_benefit - monthly_cost
  discount <- (1 + (cfg$industrial_readiness$discount_rate_annual %||% 0.05))^(months / 12)
  discounted_net <- net_cash_flow / discount
  cumulative <- cumsum(discounted_net)
  break_even <- which(cumulative >= 0)
  tibble::tibble(
    assessment_id = as.character(row$assessment_id),
    employer_or_site = as.character(row$employer_or_site %||% NA_character_),
    county_fips = as.character(row$county_fips %||% NA_character_),
    lwda_combined = as.character(row$lwda_combined %||% NA_character_),
    naics2 = as.character(row$naics2 %||% NA_character_),
    month = months,
    productivity_effect = productivity_effect,
    monthly_benefit = monthly_benefit,
    monthly_cost = monthly_cost,
    net_cash_flow = net_cash_flow,
    discounted_net_cash_flow = discounted_net,
    cumulative_npv = cumulative,
    worker_gain = if (is.finite(worker_share)) pmax(monthly_benefit, 0) * v3_clamp(worker_share) else NA_real_,
    break_even_month = if (length(break_even)) months[min(break_even)] else NA_integer_,
    evidence_status = "SCENARIO"
  )
}

v3_run_j_curve <- function(readiness, cfg) {
  if (!nrow(readiness)) return(v3_empty_industrial_jcurve())
  pieces <- lapply(seq_len(nrow(readiness)), function(i) {
    v3_j_curve_profile(as.list(readiness[i, , drop = FALSE]), cfg)
  })
  out <- dplyr::bind_rows(pieces)
  if (!nrow(out)) v3_empty_industrial_jcurve() else out
}

v3_industrial_summary <- function(readiness, jcurve, paths = v3_paths()) {
  if (!nrow(readiness)) return(v3_empty_industrial_summary(paths))
  jc <- if (nrow(jcurve)) {
    jcurve |>
      dplyr::group_by(assessment_id) |>
      dplyr::summarise(
        break_even_month = {
          z <- break_even_month[is.finite(break_even_month)]
          if (length(z)) as.integer(z[[1]]) else NA_integer_
        },
        npv_36_months = {
          z <- cumulative_npv[is.finite(cumulative_npv)]
          if (length(z)) dplyr::last(z) else NA_real_
        },
        max_productivity_dip = {
          z <- productivity_effect[is.finite(productivity_effect)]
          if (length(z)) min(z) else NA_real_
        },
        plateau_productivity_effect = {
          z <- productivity_effect[is.finite(productivity_effect)]
          if (length(z)) dplyr::last(z) else NA_real_
        },
        worker_gain_36_months = {
          z <- worker_gain[is.finite(worker_gain)]
          if (length(z)) sum(z) else NA_real_
        },
        .groups = "drop"
      )
  } else {
    v3_empty_industrial_jcurve_summary()
  }

  readiness |>
    dplyr::left_join(jc, by = "assessment_id") |>
    dplyr::mutate(
      readiness_action = dplyr::case_when(
        !is.finite(industrial_ai_readiness_index) ~ "Complete readiness assessment before procurement",
        industrial_ai_readiness_index < 0.40 ~ "Build foundations before pilot",
        industrial_ai_readiness_index < 0.65 ~ "Limited pilot with explicit remediation plan",
        TRUE ~ "Eligible for measured pilot; do not assume immediate gains"
      ),
      financing_risk = dplyr::case_when(
        !is.finite(break_even_month) ~ "No break-even within modeled horizon",
        break_even_month > 24 ~ "High J-curve financing burden",
        break_even_month > 12 ~ "Moderate J-curve financing burden",
        TRUE ~ "Lower modeled financing burden"
      )
    )
}

apply_methodology_v3_industrial_readiness <- function(paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  raw <- v3_read_industrial_assessments(paths)
  readiness <- v3_calculate_industrial_readiness(raw, paths, cfg)
  jcurve <- v3_run_j_curve(readiness, cfg)
  summary <- v3_industrial_summary(readiness, jcurve, paths)

  readiness_index <- v3_column_or(readiness, "industrial_ai_readiness_index", numeric())
  jcurve_ids <- v3_column_or(jcurve, "assessment_id", character())
  status <- tibble::tibble(
    module = "industrial_ai_readiness_and_productivity_j_curve",
    assessments = nrow(raw),
    readiness_scores = sum(is.finite(readiness_index), na.rm = TRUE),
    j_curve_scenarios = dplyr::n_distinct(jcurve_ids),
    evidence_status = if (nrow(raw)) "OBSERVED" else "UNAVAILABLE",
    note = if (nrow(raw))
      "Readiness is observed from structured assessments; J-curve outputs are scenarios and explicitly allow short-run productivity losses."
    else
      "No employer/site readiness assessments were supplied; the system does not infer industrial readiness from exposure alone."
  )
  v3_write_csv(readiness, file.path(paths$processed, "industrial_ai_readiness_scores.csv"))
  v3_write_csv(jcurve, file.path(paths$processed, "industrial_ai_productivity_j_curve.csv"))
  v3_write_csv(summary, file.path(paths$processed, "industrial_ai_readiness_summary.csv"))
  v3_write_csv(status, file.path(paths$outputs, "industrial_readiness_status_v3.csv"))
  list(raw = raw, readiness = readiness, jcurve = jcurve, summary = summary, status = status)
}
