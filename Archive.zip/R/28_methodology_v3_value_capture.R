# Methodology v3 regional value capture using BEA I-O/regional inputs and explicit Iowa assumptions

v3_read_project_scenarios <- function(paths = v3_paths()) {
  path <- file.path(paths$inputs, "regional_project_scenarios.csv")
  if (!file.exists(path)) path <- file.path(paths$inputs, "regional_project_scenarios_template.csv")
  x <- v3_drop_example_rows(v3_read_csv(path))
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(x)
  v3_require_columns(x, c(
    "project_id", "naics2", "bea_industry_code", "direct_capital_spend",
    "direct_annual_operating_spend", "direct_jobs_supported", "average_annual_wage",
    "local_purchase_share", "out_of_state_vendor_share", "worker_gain_share"
  ), "Regional project scenarios")
  num <- intersect(c(
    "analysis_year", "direct_capital_spend", "direct_annual_operating_spend",
    "direct_jobs_supported", "average_annual_wage", "local_purchase_share",
    "out_of_state_vendor_share", "worker_gain_share", "state_local_effective_tax_rate",
    "analysis_horizon_years", "discount_rate", "scenario_low_multiplier", "scenario_high_multiplier",
    "output_multiplier_override", "value_added_ratio_override", "labor_income_ratio_override",
    "supplier_purchase_ratio_override"
  ), names(x))
  x <- x |>
    dplyr::mutate(
      dplyr::across(dplyr::all_of(num), v3_as_numeric),
      county_fips = v3_normalize_fips5(county_fips),
      naics2 = v3_normalize_naics2(naics2),
      local_purchase_share = v3_validate_unit_interval(local_purchase_share, "local_purchase_share"),
      out_of_state_vendor_share = v3_validate_unit_interval(out_of_state_vendor_share, "out_of_state_vendor_share"),
      worker_gain_share = v3_validate_unit_interval(worker_gain_share, "worker_gain_share"),
      state_local_effective_tax_rate = v3_validate_unit_interval(state_local_effective_tax_rate, "state_local_effective_tax_rate")
    )
  x
}

v3_normalize_bea_io <- function(bea_io, paths = v3_paths()) {
  manual <- file.path(paths$inputs, "bea_total_requirements_normalized.csv")
  template <- file.path(paths$inputs, "bea_total_requirements_normalized_template.csv")
  if (file.exists(manual)) {
    x <- v3_read_csv(manual)
  } else if (nrow(bea_io) && all(c("bea_industry_code", "output_multiplier") %in% names(bea_io))) {
    x <- bea_io
  } else if (nrow(bea_io)) {
    raw <- v3_clean_names(bea_io)
    row_col <- v3_first_existing(names(raw), c("rowcode", "row_code", "row"))
    col_col <- v3_first_existing(names(raw), c("colcode", "col_code", "column_code", "column"))
    value_col <- v3_first_existing(names(raw), c("data_value", "datavalue", "value"))
    col_desc <- v3_first_existing(names(raw), c("coldescr", "col_descr", "column_description", "description"))
    if (!is.na(col_col) && !is.na(value_col)) {
      raw$data_value_v3 <- v3_as_numeric(raw[[value_col]])
      raw$bea_industry_code_v3 <- as.character(raw[[col_col]])
      raw$bea_industry_name_v3 <- if (!is.na(col_desc)) as.character(raw[[col_desc]]) else raw$bea_industry_code_v3
      x <- raw |>
        dplyr::filter(!is.na(bea_industry_code_v3), is.finite(data_value_v3)) |>
        dplyr::group_by(bea_industry_code = bea_industry_code_v3) |>
        dplyr::summarise(
          bea_industry_name = dplyr::first(stats::na.omit(bea_industry_name_v3), default = dplyr::first(bea_industry_code)),
          output_multiplier = sum(data_value_v3, na.rm = TRUE),
          value_added_ratio = NA_real_,
          labor_income_ratio = NA_real_,
          supplier_purchase_ratio = NA_real_,
          source = "BEA Input-Output total-requirements API; ratios require normalized table or project override",
          .groups = "drop"
        )
    } else {
      x <- v3_drop_example_rows(v3_read_csv(template))
    }
  } else {
    x <- v3_drop_example_rows(v3_read_csv(template))
  }
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(x)
  required <- c("bea_industry_code", "output_multiplier")
  if (!all(required %in% names(x))) return(tibble::tibble())
  for (nm in c("value_added_ratio", "labor_income_ratio", "supplier_purchase_ratio")) {
    if (!nm %in% names(x)) x[[nm]] <- NA_real_
  }
  if (!"source" %in% names(x)) x$source <- "BEA API or normalized input"
  x |>
    dplyr::mutate(
      dplyr::across(dplyr::all_of(c("output_multiplier", "value_added_ratio", "labor_income_ratio", "supplier_purchase_ratio")), v3_as_numeric),
      bea_industry_code = as.character(bea_industry_code),
      source = dplyr::coalesce(as.character(source), "BEA API or normalized input")
    ) |>
    dplyr::filter(is.finite(output_multiplier), output_multiplier > 0)
}

v3_value_capture_one <- function(row, multiplier, cfg) {
  horizon <- as.integer(row$analysis_horizon_years %||% cfg$value_capture$horizon_years %||% 5)
  rate <- v3_as_numeric(row$discount_rate %||% cfg$value_capture$discount_rate_annual %||% 0.05)
  capex <- v3_as_numeric(row$direct_capital_spend)
  opex <- v3_as_numeric(row$direct_annual_operating_spend)
  jobs <- v3_as_numeric(row$direct_jobs_supported)
  wage <- v3_as_numeric(row$average_annual_wage)
  local_share <- v3_as_numeric(row$local_purchase_share)
  vendor_leakage <- v3_as_numeric(row$out_of_state_vendor_share)
  worker_share <- v3_as_numeric(row$worker_gain_share)
  tax_rate <- v3_as_numeric(row$state_local_effective_tax_rate)
  output_mult <- dplyr::coalesce(v3_as_numeric(row$output_multiplier_override), v3_as_numeric(multiplier$output_multiplier))
  va_ratio <- dplyr::coalesce(v3_as_numeric(row$value_added_ratio_override), v3_as_numeric(multiplier$value_added_ratio))
  labor_ratio <- dplyr::coalesce(v3_as_numeric(row$labor_income_ratio_override), v3_as_numeric(multiplier$labor_income_ratio))
  supplier_ratio <- dplyr::coalesce(v3_as_numeric(row$supplier_purchase_ratio_override), v3_as_numeric(multiplier$supplier_purchase_ratio))
  if (!all(is.finite(c(capex, opex, jobs, wage, local_share, vendor_leakage, worker_share, tax_rate, output_mult, va_ratio, labor_ratio, supplier_ratio)))) {
    return(tibble::tibble())
  }
  local_share <- v3_clamp(local_share)
  vendor_leakage <- v3_clamp(vendor_leakage)
  worker_share <- v3_clamp(worker_share)
  tax_rate <- v3_clamp(tax_rate)
  years <- 0:horizon
  direct_spend <- c(capex, rep(opex, horizon))
  local_retention_rate <- v3_clamp(local_share * (1 - vendor_leakage))
  potential_output <- direct_spend * output_mult
  iowa_output <- potential_output * local_retention_rate
  leakage <- pmax(potential_output - iowa_output, 0)
  value_added <- iowa_output * va_ratio
  local_supplier_purchases <- iowa_output * supplier_ratio * local_share
  payroll_direct <- c(0, rep(jobs * wage, horizon))
  modeled_labor_income <- iowa_output * labor_ratio
  labor_income <- pmin(value_added, pmax(modeled_labor_income, payroll_direct))
  worker_income_gain <- pmax(labor_income - payroll_direct, 0) * worker_share
  tax_base_effect <- value_added * tax_rate
  discount <- (1 + rate)^years
  tibble::tibble(
    project_id = as.character(row$project_id),
    project_name = as.character(row$project_name %||% row$project_id),
    county_fips = as.character(row$county_fips %||% NA_character_),
    lwda_combined = as.character(row$lwda_combined %||% NA_character_),
    naics2 = as.character(row$naics2),
    bea_industry_code = as.character(row$bea_industry_code),
    year_index = years,
    direct_spend = direct_spend,
    local_retention_rate = local_retention_rate,
    potential_output = potential_output,
    iowa_output = iowa_output,
    value_added = value_added,
    local_supplier_purchases = local_supplier_purchases,
    labor_income = labor_income,
    direct_payroll = payroll_direct,
    worker_income_gain = worker_income_gain,
    tax_base_effect = tax_base_effect,
    leakage = leakage,
    regional_value_capture = value_added,
    discounted_regional_value_capture = value_added / discount,
    evidence_status = "SCENARIO"
  )
}

v3_value_capture_scenarios <- function(projects, multipliers, cfg) {
  if (!nrow(projects) || !nrow(multipliers)) return(tibble::tibble())
  joined <- projects |>
    dplyr::left_join(multipliers, by = "bea_industry_code", suffix = c("", "_bea"))
  pieces <- lapply(seq_len(nrow(joined)), function(i) {
    row <- as.list(joined[i, , drop = FALSE])
    mult <- list(
      output_multiplier = row$output_multiplier,
      value_added_ratio = row$value_added_ratio,
      labor_income_ratio = row$labor_income_ratio,
      supplier_purchase_ratio = row$supplier_purchase_ratio
    )
    v3_value_capture_one(row, mult, cfg)
  })
  dplyr::bind_rows(pieces)
}

v3_value_capture_rank <- function(summary, paths = v3_paths()) {
  if (!nrow(summary)) return(summary)
  weights <- v3_read_csv(file.path(paths$config, "v3_value_capture_weights.csv"), required = TRUE)
  metrics <- intersect(weights$metric, names(summary))
  score <- rep(0, nrow(summary)); weight_used <- rep(0, nrow(summary))
  for (metric in metrics) {
    w <- weights$weight[match(metric, weights$metric)] |> v3_as_numeric()
    direction <- weights$direction[match(metric, weights$metric)]
    z <- v3_percentile(summary[[metric]])
    if (identical(direction, "negative")) z <- 1 - z
    ok <- is.finite(z)
    score[ok] <- score[ok] + w * z[ok]
    weight_used[ok] <- weight_used[ok] + w
  }
  summary$regional_value_capture_rank_score <- ifelse(weight_used > 0, score / weight_used, NA_real_)
  summary$regional_value_capture_rank <- rank(-summary$regional_value_capture_rank_score, na.last = "keep", ties.method = "min")
  summary
}

v3_value_capture_summary <- function(detail, projects, paths = v3_paths()) {
  if (!nrow(detail)) return(tibble::tibble())
  summary <- detail |>
    dplyr::group_by(project_id, project_name, county_fips, lwda_combined, naics2, bea_industry_code) |>
    dplyr::summarise(
      direct_spend = sum(direct_spend, na.rm = TRUE),
      potential_output = sum(potential_output, na.rm = TRUE),
      iowa_output = sum(iowa_output, na.rm = TRUE),
      value_added = sum(value_added, na.rm = TRUE),
      discounted_value_added = sum(discounted_regional_value_capture, na.rm = TRUE),
      local_supplier_purchases = sum(local_supplier_purchases, na.rm = TRUE),
      labor_income = sum(labor_income, na.rm = TRUE),
      direct_payroll = sum(direct_payroll, na.rm = TRUE),
      worker_income_gain = sum(worker_income_gain, na.rm = TRUE),
      tax_base_effect = sum(tax_base_effect, na.rm = TRUE),
      leakage = sum(leakage, na.rm = TRUE),
      regional_value_capture = sum(regional_value_capture, na.rm = TRUE),
      .groups = "drop"
    ) |>
    dplyr::left_join(projects |>
      dplyr::select(project_id, scenario_low_multiplier, scenario_high_multiplier), by = "project_id") |>
    dplyr::mutate(
      scenario_low = discounted_value_added * dplyr::coalesce(scenario_low_multiplier, 0.75),
      scenario_high = discounted_value_added * dplyr::coalesce(scenario_high_multiplier, 1.25),
      worker_share_of_value_added = worker_income_gain / pmax(value_added, 1),
      leakage_share = leakage / pmax(potential_output, 1),
      evidence_status = "SCENARIO",
      reliability_class = "C",
      publication_note = "Scenario estimate using national BEA I-O relationships, explicit Iowa retention assumptions, and user-supplied project inputs. Value added is the non-overlapping headline measure; labor income, supplier purchases, worker gain, tax effects, and leakage are reported separately."
    )
  v3_value_capture_rank(summary, paths)
}

apply_methodology_v3_value_capture <- function(public_inputs, paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  projects <- v3_read_project_scenarios(paths)
  multipliers <- v3_normalize_bea_io(public_inputs$bea$io, paths)
  detail <- v3_value_capture_scenarios(projects, multipliers, cfg)
  summary <- v3_value_capture_summary(detail, projects, paths)
  status <- tibble::tibble(
    module = "regional_value_capture",
    projects = nrow(projects),
    multiplier_rows = nrow(multipliers),
    completed_scenarios = nrow(summary),
    bea_api_key_detected = nzchar(v3_bea_api_key(FALSE)),
    evidence_status = if (nrow(summary)) "SCENARIO" else "UNAVAILABLE",
    note = if (nrow(summary))
      "Results distinguish Iowa value added, labor income, supplier purchases, tax-base scenario effects, leakage, and worker income. They are scenario estimates, not official RIMS II outputs."
    else
      "Project assumptions or normalized BEA multipliers were not supplied; regional value capture is unavailable rather than inferred from jobs touched or vendor savings."
  )
  v3_write_csv(detail, file.path(paths$processed, "regional_value_capture_detail.csv"))
  v3_write_csv(summary, file.path(paths$processed, "regional_value_capture_summary.csv"))
  v3_write_csv(status, file.path(paths$outputs, "regional_value_capture_status_v3.csv"))
  list(projects = projects, multipliers = multipliers, detail = detail, summary = summary, status = status)
}
