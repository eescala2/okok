# Methodology v3 public and policy visualizations

v3_theme <- function(base_size = 10) {
  ggplot2::theme_minimal(base_family = "Arial", base_size = base_size) +
    ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = "transparent", color = NA),
      panel.background = ggplot2::element_rect(fill = "transparent", color = NA),
      legend.background = ggplot2::element_rect(fill = "transparent", color = NA),
      legend.key = ggplot2::element_rect(fill = "transparent", color = NA),
      text = ggplot2::element_text(color = "black"),
      axis.text = ggplot2::element_text(size = 10, color = "black"),
      axis.title = ggplot2::element_text(size = 10, color = "black"),
      legend.text = ggplot2::element_text(size = 10, color = "black"),
      legend.title = ggplot2::element_text(size = 10, face = "bold", color = "black"),
      plot.margin = ggplot2::margin(10, 20, 10, 10)
    )
}

v3_palette <- function() c(blue = "#1C5DBA", gold = "#E0A624", green = "#C6D667", red = "#B32A2D", teal = "#00808D", gray = "#808080")

v3_placeholder_plot <- function(title, message) {
  ggplot2::ggplot() +
    ggplot2::annotate("text", x = 0.5, y = 0.58, label = title, family = "Arial", fontface = "bold", size = 12 / ggplot2::.pt) +
    ggplot2::annotate("text", x = 0.5, y = 0.42, label = stringr::str_wrap(message, 80), family = "Arial", size = 10 / ggplot2::.pt) +
    ggplot2::xlim(0, 1) + ggplot2::ylim(0, 1) +
    ggplot2::theme_void(base_family = "Arial") +
    ggplot2::theme(plot.background = ggplot2::element_rect(fill = "transparent", color = NA))
}

v3_save_plot <- function(plot, path, width = 13, height = 8, dpi = 300) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  device <- if (requireNamespace("ragg", quietly = TRUE)) ragg::agg_png else "png"
  ggplot2::ggsave(path, plot = plot, width = width, height = height, dpi = dpi, bg = "transparent", device = device)
  invisible(path)
}

v3_plot_adoption_nowcast <- function(adoption) {
  x <- adoption$integrated
  if (!nrow(x)) return(v3_placeholder_plot("Observed adoption nowcast", "BTOS AI data or an Iowa employer pulse was not available. Exposure is not substituted for adoption."))
  x <- x |>
    dplyr::filter(canonical_metric %in% c("current_ai_use", "expected_ai_use_6m")) |>
    dplyr::mutate(
      metric = dplyr::recode(canonical_metric, current_ai_use = "Current AI use", expected_ai_use_6m = "Expected use in six months"),
      cell = dplyr::coalesce(naics2, geography_name, "All businesses")
    ) |>
    dplyr::group_by(metric, cell) |>
    dplyr::slice_max(forecast_date, n = 1, with_ties = FALSE) |>
    dplyr::ungroup() |>
    dplyr::slice_max(adoption_mean, n = 20, with_ties = FALSE)
  ggplot2::ggplot(x, ggplot2::aes(x = stats::reorder(cell, adoption_mean), y = adoption_mean, color = metric)) +
    ggplot2::geom_errorbar(ggplot2::aes(ymin = adoption_lower, ymax = adoption_upper), width = 0.15, linewidth = 0.5, position = ggplot2::position_dodge(width = 0.5)) +
    ggplot2::geom_point(size = 3, position = ggplot2::position_dodge(width = 0.5)) +
    ggplot2::coord_flip() +
    ggplot2::scale_y_continuous(labels = scales::label_percent(accuracy = 1), limits = c(0, 1)) +
    ggplot2::scale_color_manual(values = c("Current AI use" = v3_palette()[["blue"]], "Expected use in six months" = v3_palette()[["gold"]])) +
    ggplot2::labs(x = NULL, y = "Observed/nowcast adoption rate", color = NULL) + v3_theme()
}

v3_plot_exposure_adoption_gap <- function(adoption, atlas) {
  county <- adoption$county
  if (!nrow(county) || !nrow(atlas) || !"automation_exposure" %in% names(atlas)) return(v3_placeholder_plot("Exposure versus adoption", "Both a benchmarked adoption nowcast and technical exposure estimates are required. The two constructs are never treated as interchangeable."))
  exp <- atlas |>
    dplyr::mutate(jobs_weight = pmax(v3_as_numeric(estimated_jobs), 0)) |>
    dplyr::group_by(county_fips, dplyr::across(dplyr::any_of(c("county_name", "lwda_combined")))) |>
    dplyr::summarise(
      estimated_jobs = sum(jobs_weight, na.rm = TRUE),
      automation_exposure = v3_weighted_mean(v3_validate_unit_interval(automation_exposure, "automation_exposure"), jobs_weight),
      .groups = "drop"
    )
  x <- exp |>
    dplyr::left_join(county, by = intersect(c("county_fips", "county_name", "lwda_combined"), names(exp))) |>
    dplyr::filter(is.finite(automation_exposure), is.finite(adoption_nowcast))
  if (!nrow(x)) return(v3_placeholder_plot("Exposure versus adoption", "No matched county exposure and adoption estimates were available."))
  ggplot2::ggplot(x, ggplot2::aes(automation_exposure, adoption_nowcast, size = estimated_jobs, label = county_name)) +
    ggplot2::geom_abline(slope = 1, intercept = 0, linetype = 2, color = "gray50") +
    ggplot2::geom_point(fill = v3_palette()[["blue"]], color = "black", shape = 21, alpha = 0.75) +
    ggrepel::geom_text_repel(na.rm = TRUE, family = "Arial", size = 10 / ggplot2::.pt, max.overlaps = Inf, seed = 3002) +
    ggplot2::scale_x_continuous(labels = scales::label_percent(), limits = c(0, 1)) +
    ggplot2::scale_y_continuous(labels = scales::label_percent(), limits = c(0, 1)) +
    ggplot2::scale_size_area(labels = scales::label_number(scale_cut = scales::cut_short_scale()), max_size = 12) +
    ggplot2::labs(x = "Technical automation exposure", y = "Observed/benchmarked AI adoption nowcast", size = "Estimated jobs") + v3_theme()
}

v3_plot_worker_outcomes <- function(worker) {
  x <- worker$summary
  if (!nrow(x)) return(v3_placeholder_plot("Worker task use and quality-adjusted outcomes", "No Iowa worker-pulse or pilot task-outcome records were supplied. Gross time savings are not used as a substitute for quality-adjusted productivity."))
  x <- x |>
    dplyr::mutate(label = dplyr::coalesce(task_name, occupation_title, soc_code, pilot_id)) |>
    dplyr::slice_max(weighted_respondents, n = 25, with_ties = FALSE)
  ggplot2::ggplot(x, ggplot2::aes(quality_adjusted_productivity_ratio - 1, worker_benefit_index, size = weighted_respondents, color = pro_worker_pass_share)) +
    ggplot2::geom_hline(yintercept = 0, linetype = 2) + ggplot2::geom_vline(xintercept = 0, linetype = 2) +
    ggplot2::geom_point(alpha = 0.8) +
    ggrepel::geom_text_repel(na.rm = TRUE, ggplot2::aes(label = label), family = "Arial", size = 10 / ggplot2::.pt, max.overlaps = Inf, seed = 3003) +
    ggplot2::scale_x_continuous(labels = scales::label_percent()) +
    ggplot2::scale_color_gradient(low = v3_palette()[["red"]], high = v3_palette()[["blue"]], labels = scales::label_percent()) +
    ggplot2::scale_size_area(max_size = 12) +
    ggplot2::labs(x = "Quality-adjusted productivity change", y = "Worker benefit index", color = "Pro-worker pass share", size = "Weighted respondents") + v3_theme()
}

v3_plot_early_career <- function(early) {
  x <- early$industry
  if (!nrow(x)) return(v3_placeholder_plot("Early-career fragility", "Age-specific QWI records were unavailable. The system does not infer early-career hiring fragility from aggregate occupation exposure alone."))
  ggplot2::ggplot(x, ggplot2::aes(automation_exposure, early_career_fragility_index, size = early_employment_pre, label = naics2, color = reliability_class)) +
    ggplot2::geom_point(alpha = 0.8) +
    ggrepel::geom_text_repel(na.rm = TRUE, family = "Arial", size = 10 / ggplot2::.pt, max.overlaps = Inf, seed = 3004) +
    ggplot2::scale_x_continuous(labels = scales::label_percent(), limits = c(0, 1)) +
    ggplot2::scale_y_continuous(labels = scales::label_percent(), limits = c(0, 1)) +
    ggplot2::scale_size_area(labels = scales::label_number(scale_cut = scales::cut_short_scale()), max_size = 12) +
    ggplot2::scale_color_manual(values = c(A = v3_palette()[["blue"]], B = v3_palette()[["gold"]], C = v3_palette()[["red"]])) +
    ggplot2::labs(x = "Industry automation exposure", y = "Early-career fragility index", size = "Ages 22-24 pre-period employment", color = "Reliability") + v3_theme()
}

v3_plot_apprenticeship_access <- function(early) {
  x <- early$apprenticeship
  if (!nrow(x)) return(v3_placeholder_plot("Apprenticeship access", "Registered apprenticeship and local training-access records were not supplied. Pipeline safeguards remain an explicit evidence gap."))
  ggplot2::ggplot(x, ggplot2::aes(stats::reorder(paste(lwda_combined, naics2), capacity_per_1000_jobs), capacity_per_1000_jobs, fill = completion_rate)) +
    ggplot2::geom_col() + ggplot2::coord_flip() +
    ggplot2::scale_y_continuous(labels = scales::label_number(accuracy = 0.1)) +
    ggplot2::scale_fill_gradient(low = v3_palette()[["gold"]], high = v3_palette()[["blue"]], labels = scales::label_percent()) +
    ggplot2::labs(x = NULL, y = "Apprenticeship capacity per 1,000 jobs", fill = "Completion rate") + v3_theme()
}

v3_plot_feasible_paths <- function(transitions) {
  x <- transitions$public
  if (!nrow(x)) return(v3_placeholder_plot("Credential-feasible transition pathways", "No pathway passed all public-recommendation constraints. Supply licenses, bridge programs, local openings, physical/schedule demands, and employer validation."))
  x <- x |>
    dplyr::slice_max(feasibility_score, n = 30, with_ties = FALSE) |>
    dplyr::mutate(path = paste0(origin_title, "  →  ", destination_title))
  ggplot2::ggplot(x, ggplot2::aes(feasibility_score, stats::reorder(path, feasibility_score), size = annual_openings, color = wage_ratio)) +
    ggplot2::geom_point(alpha = 0.85) +
    ggplot2::scale_x_continuous(labels = scales::label_percent(), limits = c(0, 1)) +
    ggplot2::scale_color_gradient(low = v3_palette()[["red"]], high = v3_palette()[["blue"]]) +
    ggplot2::scale_size_area(max_size = 10, labels = scales::label_number()) +
    ggplot2::labs(x = "Feasibility score", y = NULL, color = "Destination/origin wage ratio", size = "Annual openings") + v3_theme()
}

v3_plot_transition_constraints <- function(transitions) {
  x <- transitions$rejection
  if (!nrow(x)) return(v3_placeholder_plot("Transition constraint audit", "No transition candidates were evaluated."))
  ggplot2::ggplot(x, ggplot2::aes(candidate_pairs, stats::reorder(reason, candidate_pairs))) +
    ggplot2::geom_col(fill = v3_palette()[["red"]]) +
    ggplot2::scale_x_continuous(labels = scales::label_comma()) +
    ggplot2::labs(x = "Candidate pathways affected", y = NULL) + v3_theme()
}

v3_plot_readiness <- function(industrial) {
  x <- industrial$summary
  if (!nrow(x)) return(v3_placeholder_plot("Industrial-AI readiness", "No employer/site industrial-readiness assessments were supplied. Exposure is not treated as implementation readiness."))
  ggplot2::ggplot(x, ggplot2::aes(industrial_ai_readiness_index, plateau_productivity_effect, size = employees, color = financing_risk, label = employer_or_site)) +
    ggplot2::geom_point(alpha = 0.85) +
    ggrepel::geom_text_repel(na.rm = TRUE, family = "Arial", size = 10 / ggplot2::.pt, max.overlaps = Inf, seed = 3008) +
    ggplot2::scale_x_continuous(labels = scales::label_percent(), limits = c(0, 1)) +
    ggplot2::scale_y_continuous(labels = scales::label_percent()) +
    ggplot2::scale_size_area(max_size = 12, labels = scales::label_number(scale_cut = scales::cut_short_scale())) +
    ggplot2::labs(x = "Industrial-AI readiness", y = "Modeled plateau productivity effect", color = "J-curve financing risk", size = "Employees") + v3_theme()
}

v3_plot_jcurve <- function(industrial) {
  x <- industrial$jcurve
  if (!nrow(x)) return(v3_placeholder_plot("Productivity J-curve", "No assessment had sufficient implementation-cost, baseline-value, readiness, dip, ramp, and plateau assumptions for a J-curve scenario."))
  ggplot2::ggplot(x, ggplot2::aes(month, productivity_effect, group = assessment_id, color = employer_or_site)) +
    ggplot2::geom_hline(yintercept = 0, linetype = 2) +
    ggplot2::geom_line(linewidth = 1) +
    ggplot2::scale_y_continuous(labels = scales::label_percent()) +
    ggplot2::scale_x_continuous(breaks = seq(0, max(x$month, na.rm = TRUE), by = 6)) +
    ggplot2::labs(x = "Months after implementation", y = "Modeled productivity effect", color = "Site") + v3_theme()
}

v3_plot_pilot_decisions <- function(pilots) {
  x <- pilots$decisions
  if (!nrow(x)) return(v3_placeholder_plot("Pilot decision rules", "No preregistered pilot registry and measurement data were supplied. No scale, redesign, suspend, or stop decision is inferred."))
  x <- x |>
    dplyr::count(decision, reliability_class, name = "pilots")
  ggplot2::ggplot(x, ggplot2::aes(decision, pilots, fill = reliability_class)) +
    ggplot2::geom_col() +
    ggplot2::scale_y_continuous(labels = scales::label_comma()) +
    ggplot2::scale_fill_manual(values = c(A = v3_palette()[["blue"]], B = v3_palette()[["gold"]], C = v3_palette()[["red"]])) +
    ggplot2::labs(x = NULL, y = "Pilots", fill = "Reliability") + v3_theme()
}

v3_plot_aria <- function(pilots) {
  x <- pilots$aria
  if (!nrow(x)) return(v3_placeholder_plot("NIST/ARIA assurance coverage", "No model-testing, red-team, field-testing, or system-level test results were supplied."))
  ggplot2::ggplot(x, ggplot2::aes(evaluation_level, pilot_id, fill = pass_rate)) +
    ggplot2::geom_tile(color = "white") +
    ggplot2::geom_text(ggplot2::aes(label = scales::percent(pass_rate, accuracy = 1)), family = "Arial", size = 10 / ggplot2::.pt, na.rm = TRUE) +
    ggplot2::scale_fill_gradient2(low = v3_palette()[["red"]], mid = v3_palette()[["gold"]], high = v3_palette()[["blue"]], midpoint = 0.75, labels = scales::label_percent()) +
    ggplot2::labs(x = NULL, y = "Pilot", fill = "Pass rate") + v3_theme() +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 30, hjust = 1))
}

v3_plot_value_capture <- function(value_capture) {
  x <- value_capture$summary
  if (!nrow(x)) return(v3_placeholder_plot("Regional value capture", "No project scenario with normalized BEA multipliers and approved Iowa retention assumptions was supplied. Vendor savings are not treated as regional value creation."))
  long <- x |>
    dplyr::select(project_id, project_name, value_added, labor_income, local_supplier_purchases, worker_income_gain, tax_base_effect, leakage) |>
    tidyr::pivot_longer(-c(project_id, project_name), names_to = "component", values_to = "value") |>
    dplyr::mutate(value = ifelse(component == "leakage", -abs(value), value))
  ggplot2::ggplot(long, ggplot2::aes(component, value, fill = component)) +
    ggplot2::geom_col() +
    ggplot2::facet_wrap(~project_name, scales = "free_y") +
    ggplot2::scale_y_continuous(labels = scales::label_dollar(scale_cut = scales::cut_short_scale())) +
    ggplot2::scale_fill_manual(values = c(
      value_added = v3_palette()[["blue"]], labor_income = v3_palette()[["teal"]],
      local_supplier_purchases = v3_palette()[["green"]], worker_income_gain = v3_palette()[["gold"]],
      tax_base_effect = "#6A51A3", leakage = v3_palette()[["red"]]
    )) +
    ggplot2::labs(x = NULL, y = "Five-year scenario value", fill = NULL) + v3_theme() +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 35, hjust = 1))
}

v3_plot_evidence_scorecard <- function(results) {
  x <- if (exists("v3_methodology_v3_extension_status", mode = "function")) {
    v3_methodology_v3_extension_status(results)
  } else {
    status_tables <- lapply(results, function(z) if (is.list(z) && "status" %in% names(z)) z$status else tibble::tibble())
    dplyr::bind_rows(status_tables)
  }
  if (!nrow(x)) return(v3_placeholder_plot("Methodology v3 evidence scorecard", "No module status records were available."))
  x <- x |>
    dplyr::mutate(
      evidence_status = factor(evidence_status, levels = c("UNAVAILABLE", "PROVISIONAL", "SCENARIO", "BENCHMARKED", "OBSERVED")),
      score = as.numeric(evidence_status)
    )
  ggplot2::ggplot(x, ggplot2::aes(score, stats::reorder(module, score), color = evidence_status)) +
    ggplot2::geom_point(size = 5) +
    ggplot2::scale_x_continuous(breaks = 1:5, labels = levels(x$evidence_status), limits = c(0.5, 5.5)) +
    ggplot2::scale_color_manual(values = c(UNAVAILABLE = "gray70", PROVISIONAL = v3_palette()[["red"]], SCENARIO = v3_palette()[["gold"]], BENCHMARKED = v3_palette()[["teal"]], OBSERVED = v3_palette()[["blue"]])) +
    ggplot2::labs(x = "Evidence status", y = NULL, color = NULL) + v3_theme() +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 25, hjust = 1))
}

make_methodology_v3_figures <- function(results, atlas, paths = v3_paths(), return_plots = FALSE) {
  v3_ensure_directories(paths)
  specs <- list(
    list(id = 37, filename = "methodology_v3_37_observed_adoption_nowcast.png", title = "Observed adoption nowcast", plot = v3_plot_adoption_nowcast(results$adoption), audience = "State leaders, economic developers, employers"),
    list(id = 38, filename = "methodology_v3_38_exposure_vs_adoption.png", title = "Exposure versus observed adoption", plot = v3_plot_exposure_adoption_gap(results$adoption, atlas), audience = "Policymakers and analysts"),
    list(id = 39, filename = "methodology_v3_39_worker_quality_adjusted_outcomes.png", title = "Worker task use and quality-adjusted outcomes", plot = v3_plot_worker_outcomes(results$worker), audience = "Employers, workers, evaluators"),
    list(id = 40, filename = "methodology_v3_40_early_career_fragility.png", title = "Early-career fragility", plot = v3_plot_early_career(results$early_career), audience = "Workforce boards, colleges, apprenticeships"),
    list(id = 41, filename = "methodology_v3_41_apprenticeship_access.png", title = "Apprenticeship access", plot = v3_plot_apprenticeship_access(results$early_career), audience = "Workforce boards and training providers"),
    list(id = 42, filename = "methodology_v3_42_credential_feasible_paths.png", title = "Credential-feasible transition pathways", plot = v3_plot_feasible_paths(results$transitions), audience = "Workers, colleges, employers"),
    list(id = 43, filename = "methodology_v3_43_transition_constraints.png", title = "Transition constraint audit", plot = v3_plot_transition_constraints(results$transitions), audience = "Program designers and policymakers"),
    list(id = 44, filename = "methodology_v3_44_industrial_ai_readiness.png", title = "Industrial-AI readiness", plot = v3_plot_readiness(results$industrial), audience = "Manufacturers, economic developers, lenders"),
    list(id = 45, filename = "methodology_v3_45_productivity_j_curve.png", title = "Industrial-AI productivity J-curve", plot = v3_plot_jcurve(results$industrial), audience = "Employers, funders, policymakers"),
    list(id = 46, filename = "methodology_v3_46_pilot_decision_rules.png", title = "Pilot scale, redesign, suspend, or stop decisions", plot = v3_plot_pilot_decisions(results$pilots), audience = "Steering group and independent evaluators"),
    list(id = 47, filename = "methodology_v3_47_aria_assurance.png", title = "NIST/ARIA assurance coverage", plot = v3_plot_aria(results$pilots), audience = "Procurement, risk, legal, workers"),
    list(id = 48, filename = "methodology_v3_48_regional_value_capture.png", title = "Regional value capture", plot = v3_plot_value_capture(results$value_capture), audience = "Economic developers and budget officials"),
    list(id = 49, filename = "methodology_v3_49_evidence_scorecard.png", title = "Methodology v3 evidence scorecard", plot = v3_plot_evidence_scorecard(results), audience = "Public and policymakers")
  )
  manifest <- purrr::map_dfr(specs, function(s) {
    path <- file.path(paths$figures, s$filename)
    v3_save_plot(s$plot, path, width = 14, height = 8.5)
    tibble::tibble(
      id = as.character(s$id),
      filename = s$filename,
      path = normalizePath(path, winslash = "/", mustWork = FALSE),
      title = s$title,
      audience = s$audience,
      status = if (file.exists(path)) "created" else "failed"
    )
  })
  v3_write_csv(manifest, file.path(paths$outputs, "methodology_v3_visualization_manifest.csv"))
  if (return_plots) list(manifest = manifest, plots = stats::setNames(lapply(specs, `[[`, "plot"), vapply(specs, `[[`, character(1), "filename"))) else manifest
}
