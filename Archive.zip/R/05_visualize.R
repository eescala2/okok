# 05_visualize.R -------------------------------------------------------------
# Figures for the atlas report.

source(file.path(project_root(), 'R', '00_setup.R'))
source(file.path(project_root(), 'R', '01_lwda_crosswalk.R'))
source(file.path(project_root(), 'R', '02_data_download.R'))
source(file.path(project_root(), 'R', '10_iowa_report_style.R'))

score01 <- function(x, label = 'score') {
  x <- suppressWarnings(as.numeric(x))
  bad <- is.finite(x) & (x < -1e-9 | x > 1 + 1e-9)
  if (any(bad)) stop(label, ' must be stored explicitly as a proportion in [0,1]; the figure layer does not guess score units.', call. = FALSE)
  x
}

range_pad <- function(x, pad = 0.06, fallback = c(0, 1)) {
  x <- x[is.finite(x)]
  if (!length(x)) return(fallback)
  rng <- range(x, na.rm = TRUE)
  if (abs(diff(rng)) < 1e-6) rng <- rng + c(-0.02, 0.02)
  d <- diff(rng) * pad
  c(max(0, rng[1] - d), min(1, rng[2] + d))
}

make_figures <- function(refresh = FALSE) {
  p <- paths(); cfg <- load_config(); brand <- atlas_brand()
  atlas_ok <- compat_table_exists('county_industry_occupation_atlas', p$processed)
  county_path <- file.path(p$processed, 'county_summary.csv')
  lwda_path <- file.path(p$processed, 'lwda_summary.csv')
  sector_path <- file.path(p$processed, 'sector_lwda_summary.csv')
  if (!atlas_ok || !file.exists(county_path)) {
    source(file.path(p$R, '04_build_atlas.R'))
    build_atlas(refresh = refresh, install_optional = FALSE)
  }
  county <- readr::read_csv(county_path, show_col_types = FALSE)
  lwda <- readr::read_csv(lwda_path, show_col_types = FALSE)
  sector <- readr::read_csv(sector_path, show_col_types = FALSE)
  shapes <- tryCatch(get_county_shapes(cfg, refresh = FALSE), error = function(e) NULL)

  metric_cols <- c('automation_exposure', 'augmentation_potential', 'expertise_leveling_potential',
                   'new_task_opportunity', 'pro_worker_opportunity', 'transition_pressure', 'physical_ai_exposure')
  county <- county |> dplyr::mutate(county_fips = clean_fips(county_fips, 5))
  for (nm in intersect(metric_cols, names(county))) county[[nm]] <- score01(county[[nm]], nm)
  for (nm in intersect(metric_cols, names(lwda))) lwda[[nm]] <- score01(lwda[[nm]], nm)
  for (nm in intersect(metric_cols, names(sector))) sector[[nm]] <- score01(sector[[nm]], nm)
  for (nm in intersect(c('risk_opportunity_gap', 'risk_minus_opportunity'), names(county))) county[[nm]] <- suppressWarnings(as.numeric(county[[nm]]))
  for (nm in intersect(c('risk_opportunity_gap', 'risk_minus_opportunity'), names(lwda))) lwda[[nm]] <- suppressWarnings(as.numeric(lwda[[nm]]))
  for (nm in intersect(c('risk_opportunity_gap', 'risk_minus_opportunity'), names(sector))) sector[[nm]] <- suppressWarnings(as.numeric(sector[[nm]]))
  if (!is.null(shapes)) shapes <- shapes |> dplyr::mutate(county_fips = clean_fips(county_fips, 5))

  if (!is.null(shapes) && nrow(county)) {
    mapdat <- shapes |> dplyr::left_join(county, by = 'county_fips')
    g1 <- ggplot2::ggplot(mapdat) +
      ggplot2::geom_sf(ggplot2::aes(fill = automation_exposure), color = 'white', linewidth = 0.15) +
      atlas_color_scale_continuous(labels = atlas_axis_percent(accuracy = 1), limits = range_pad(mapdat$automation_exposure)) +
      ggplot2::labs(title = NULL, subtitle = NULL, caption = NULL, fill = 'Exposure') +
      atlas_void_theme() +
      ggplot2::theme(legend.position = 'right')
    atlas_save_transparent_png(g1, file.path(p$figures, 'county_automation_exposure.png'), width = 9, height = 6, dpi = 180, force_alpha_repair = TRUE)

    g2 <- ggplot2::ggplot(mapdat) +
      ggplot2::geom_sf(ggplot2::aes(fill = pro_worker_opportunity), color = 'white', linewidth = 0.15) +
      atlas_color_scale_continuous(labels = atlas_axis_percent(accuracy = 1), limits = range_pad(mapdat$pro_worker_opportunity)) +
      ggplot2::labs(title = NULL, subtitle = NULL, caption = NULL, fill = 'Opportunity') +
      atlas_void_theme() +
      ggplot2::theme(legend.position = 'right')
    atlas_save_transparent_png(g2, file.path(p$figures, 'county_pro_worker_opportunity.png'), width = 9, height = 6, dpi = 180, force_alpha_repair = TRUE)
  }

  if (nrow(lwda)) {
    g3 <- lwda |>
      tidyr::pivot_longer(c(automation_exposure, augmentation_potential, expertise_leveling_potential, new_task_opportunity, pro_worker_opportunity),
                          names_to = 'metric', values_to = 'score') |>
      dplyr::filter(is.finite(score)) |>
      dplyr::mutate(metric = stringr::str_replace_all(metric, '_', ' ') |> stringr::str_to_title()) |>
      ggplot2::ggplot(ggplot2::aes(x = score, y = stats::reorder(lwda_combined, score))) +
      ggplot2::geom_col(fill = brand$blue) +
      ggplot2::facet_wrap(~metric, ncol = 2) +
      ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
      ggplot2::labs(title = NULL, subtitle = NULL, caption = NULL, x = 'Employment-weighted score', y = NULL) +
      atlas_base_theme()
    atlas_save_transparent_png(g3, file.path(p$figures, 'lwda_ai_metrics.png'), width = 10, height = 8, dpi = 180, force_alpha_repair = TRUE)
  }

  if (nrow(sector)) {
    top_sector <- sector |>
      dplyr::group_by(iowa_priority_sector) |>
      dplyr::summarise(jobs = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop') |>
      dplyr::slice_max(jobs, n = 12)
    g4 <- sector |>
      dplyr::semi_join(top_sector, by = 'iowa_priority_sector') |>
      dplyr::group_by(iowa_priority_sector) |>
      dplyr::summarise(
        automation_exposure = stats::weighted.mean(automation_exposure, estimated_jobs, na.rm = TRUE),
        pro_worker_opportunity = stats::weighted.mean(pro_worker_opportunity, estimated_jobs, na.rm = TRUE),
        estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
        .groups = 'drop'
      ) |>
      dplyr::filter(is.finite(automation_exposure), is.finite(pro_worker_opportunity), estimated_jobs > 0) |>
      ggplot2::ggplot(ggplot2::aes(x = automation_exposure, y = pro_worker_opportunity, size = estimated_jobs, label = iowa_priority_sector)) +
      ggplot2::geom_point(alpha = 0.78, color = brand$blue) +
      ggrepel::geom_text_repel(na.rm = TRUE, max.overlaps = Inf, seed = 1, size = 3.2, family = atlas_font_family(), color = brand$black, box.padding = 0.4, point.padding = 0.35) +
      ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
      ggplot2::scale_y_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
      ggplot2::scale_size_area(
        max_size = 11,
        labels = atlas_jobs_number(accuracy = 1)
      ) +
      ggplot2::labs(title = NULL, subtitle = NULL, caption = NULL, x = 'Automation exposure', y = 'Pro-worker opportunity', size = 'Estimated jobs') +
      atlas_base_theme()
    atlas_save_transparent_png(g4, file.path(p$figures, 'sector_risk_opportunity_quadrant.png'), width = 10, height = 7, dpi = 180, force_alpha_repair = TRUE)
  }
  core_files <- c(
    file.path(p$figures, 'county_automation_exposure.png'),
    file.path(p$figures, 'county_pro_worker_opportunity.png'),
    file.path(p$figures, 'lwda_ai_metrics.png'),
    file.path(p$figures, 'sector_risk_opportunity_quadrant.png')
  )
  core_manifest <- tibble::tibble(
    figure = basename(core_files),
    path = normalizePath(core_files, winslash = '/', mustWork = FALSE),
    exists = file.exists(core_files),
    build_id = if (exists('v2_build_id', mode = 'function')) v2_build_id() else NA_character_,
    methodology_version = if (exists('load_methodology_v2_config', mode = 'function')) as.character(load_methodology_v2_config()$methodology_version) else NA_character_,
    generated_at = format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z')
  )
  fs::dir_create(p$outputs)
  readr::write_csv(core_manifest, file.path(p$outputs, 'core_figure_manifest.csv'))
  invisible(core_manifest)
}
