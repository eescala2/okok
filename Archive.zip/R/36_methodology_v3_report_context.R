# Auto-generated Methodology v3 atomic report context.
# This file is report-session infrastructure, not an analytical model.

v3_report_context_find_root <- function(start = getwd()) {
  starts <- c(start)
  if (requireNamespace("knitr", quietly = TRUE)) {
    input <- tryCatch(knitr::current_input(dir = TRUE), error = function(e) "")
    if (nzchar(input)) starts <- c(starts, dirname(input))
  }
  starts <- unique(normalizePath(starts, winslash = "/", mustWork = FALSE))
  for (candidate in starts) {
    current <- candidate
    for (i in seq_len(15L)) {
      if (dir.exists(file.path(current, "R")) &&
          (file.exists(file.path(current, "atlas_v3.qmd")) ||
           file.exists(file.path(current, "atlas_v3.Rmd")))) {
        return(normalizePath(current, winslash = "/", mustWork = TRUE))
      }
      parent <- dirname(current)
      if (identical(parent, current)) break
      current <- parent
    }
  }
  stop("Methodology v3 report context could not locate the project root.", call. = FALSE)
}

v3_report_context_source_bootstrap <- function(root, report_env) {
  has_loader <- exists("v3_load_results", envir = report_env, mode = "function", inherits = TRUE)
  has_paths <- exists("v3_paths", envir = report_env, inherits = TRUE)
  if (has_loader && has_paths) return(invisible(TRUE))

  bootstrap <- file.path(root, "R", "35_methodology_v3_report_bootstrap.R")
  if (!file.exists(bootstrap)) {
    stop(sprintf("Missing Methodology v3 report bootstrap: %s", bootstrap), call. = FALSE)
  }

  old_opt <- getOption("ia_atlas_v3_bootstrap_no_autorun")
  options(ia_atlas_v3_bootstrap_no_autorun = TRUE)
  on.exit(options(ia_atlas_v3_bootstrap_no_autorun = old_opt), add = TRUE)
  sys.source(bootstrap, envir = report_env, keep.source = FALSE)

  if (exists("v3_bootstrap_methodology_v3_report", envir = report_env, mode = "function", inherits = TRUE)) {
    get("v3_bootstrap_methodology_v3_report", envir = report_env, inherits = TRUE)(
      root = root, envir = report_env, verbose = FALSE
    )
  }

  if (!exists("v3_load_results", envir = report_env, mode = "function", inherits = TRUE)) {
    stop("Report bootstrap did not install v3_load_results().", call. = FALSE)
  }
  if (!exists("v3_paths", envir = report_env, inherits = TRUE)) {
    stop("Report bootstrap did not install v3_paths.", call. = FALSE)
  }
  invisible(TRUE)
}

v3_report_context_resolve_paths <- function(root, report_env) {
  provider <- get("v3_paths", envir = report_env, inherits = TRUE)
  attempts <- list()

  if (is.function(provider)) {
    attempts <- list(
      function() provider(root = root),
      function() provider(root),
      function() provider()
    )
    resolved <- NULL
    errors <- character()
    for (attempt in attempts) {
      value <- tryCatch(attempt(), error = function(e) e)
      if (!inherits(value, "error")) {
        resolved <- value
        break
      }
      errors <- c(errors, conditionMessage(value))
    }
    if (is.null(resolved)) {
      stop(
        paste0("Could not evaluate v3_paths(): ", paste(unique(errors), collapse = " | ")),
        call. = FALSE
      )
    }
  } else {
    resolved <- provider
  }

  if (is.function(resolved)) {
    stop("Methodology v3 paths resolved to a function rather than a list.", call. = FALSE)
  }
  if (!is.list(resolved)) {
    stop(sprintf("Methodology v3 paths must be a list; found <%s>.", paste(class(resolved), collapse = "/")), call. = FALSE)
  }

  required <- c("root", "processed", "outputs")
  missing <- setdiff(required, names(resolved))
  if (length(missing)) {
    stop(sprintf("Methodology v3 paths are missing: %s", paste(missing, collapse = ", ")), call. = FALSE)
  }

  for (field in required) {
    value <- resolved[[field]]
    if (is.function(value) || length(value) != 1L || is.na(value) || !nzchar(as.character(value))) {
      stop(sprintf("Invalid Methodology v3 path field `%s`.", field), call. = FALSE)
    }
    resolved[[field]] <- normalizePath(as.character(value), winslash = "/", mustWork = FALSE)
  }
  resolved
}

v3_report_context_initialize <- function(root = NULL, report_env = NULL) {
  if (is.null(report_env)) {
    report_env <- if (requireNamespace("knitr", quietly = TRUE)) knitr::knit_global() else globalenv()
  }
  if (is.null(root)) root <- v3_report_context_find_root()

  v3_report_context_source_bootstrap(root, report_env)
  paths <- v3_report_context_resolve_paths(root, report_env)
  loader <- get("v3_load_results", envir = report_env, mode = "function", inherits = TRUE)
  results <- loader(paths = paths)

  assign("paths", paths, envir = report_env)
  assign(".v3_report_paths", paths, envir = report_env)
  assign("results", results, envir = report_env)
  assign(".v3_report_results", results, envir = report_env)

  list(root = root, paths = paths, results = results)
}
