# Methodology v3.0.9 publication completion layer
#
# Corrects four output-only issues without changing the analytical model:
# 1. module lookup uses .env$module, preventing every unavailable panel from
#    inheriting the first module's BTOS note;
# 2. macOS compendium PDF generation falls back to the base PDF device and
#    therefore does not require XQuartz/Cairo;
# 3. rendered Quarto/R Markdown HTML receives a narrow publication cleanup;
# 4. the all-figures compendium uses publication titles and source notes.

v3_v309_is_scalar_text <- function(x) {
  is.character(x) && length(x) == 1L && !is.na(x) && nzchar(trimws(x))
}

v3_v309_font_family <- function() {
  if (requireNamespace("systemfonts", quietly = TRUE)) {
    exports <- getNamespaceExports("systemfonts")
    hit <- NULL
    if ("match_fonts" %in% exports) {
      hit <- tryCatch(systemfonts::match_fonts("Arial"), error = function(e) NULL)
    } else if ("match_font" %in% exports) {
      hit <- suppressWarnings(tryCatch(systemfonts::match_font("Arial"), error = function(e) NULL))
    }
    paths <- if (is.data.frame(hit) && "path" %in% names(hit)) hit$path else if (is.list(hit)) hit$path else character()
    if (length(paths) && any(!is.na(paths) & nzchar(paths))) return("Arial")
  }
  "sans"
}

# Replace the deprecated match_font()-based helper when the publication module
# has already installed it.
v3_pub_font_family <- v3_v309_font_family

v3_v309_module_record <- function(module, status_inputs) {
  modules <- status_inputs$modules
  gaps <- status_inputs$gaps
  hit <- if (nrow(modules) && "module" %in% names(modules)) {
    dplyr::filter(modules, .data$module == .env$module)
  } else {
    tibble::tibble()
  }
  gap <- if (nrow(gaps) && "module" %in% names(gaps)) {
    dplyr::filter(gaps, .data$module == .env$module)
  } else {
    tibble::tibble()
  }
  list(
    rows = if (nrow(hit) && "rows" %in% names(hit)) suppressWarnings(as.numeric(hit$rows[[1L]])) else 0,
    status = if (nrow(hit) && "evidence_status" %in% names(hit)) as.character(hit$evidence_status[[1L]]) else "UNAVAILABLE",
    note = if (nrow(hit) && "note" %in% names(hit)) as.character(hit$note[[1L]]) else "No validated evidence rows were available.",
    required_action = if (nrow(gap) && "required_action" %in% names(gap)) as.character(gap$required_action[[1L]]) else "Connect a validated public or local source before publishing a substantive estimate."
  )
}

# Both v3.0.4 and v3.0.8 used the same data-mask expression. Override both
# contracts so the function argument is never mistaken for the data column.
v3_oq_module_record <- v3_v309_module_record
v3_pub_module_record <- v3_v309_module_record

v3_v309_figure_meaning <- function(id, fallback = NULL) {
  values <- c(
    `37` = "No validated Iowa employer-adoption observations were available. Technical exposure is not used as a substitute for observed adoption.",
    `38` = "Observed adoption data were unavailable, so the atlas cannot compare technical exposure with actual employer use.",
    `39` = "No validated worker task-use or pilot outcome records were available, so quality-adjusted productivity and job-quality effects are not estimated.",
    `40` = "The age-specific QWI query returned no usable Iowa records. Early-career hiring fragility is not inferred from aggregate exposure.",
    `41` = "No registered-apprenticeship capacity or administrative records were connected. Missing evidence is not interpreted as zero capacity.",
    `42` = "No pathway passed the complete credential, training, openings, access, wage, and employer-validation contract, so no transition is recommended.",
    `43` = "No validated candidate-pathway records were available for a constraint audit; rejection reasons cannot be counted until the pathway inputs are populated.",
    `44` = "No employer or site readiness assessments were available. Industrial readiness is not inferred from technical exposure.",
    `45` = "No approved implementation assumptions and readiness observations were available, so the productivity J-curve remains a scenario template rather than a forecast.",
    `46` = "No preregistered pilot registry and 30/90/180-day outcome records were available, so no scale, redesign, suspend, or stop decision is assigned.",
    `47` = "No ARIA-style model, red-team, field-test, or system-assurance records were available, so assurance coverage cannot be claimed.",
    `48` = "BEA input-output data alone are insufficient. Regional value capture requires Iowa regional data and explicit local-purchase, leakage, worker-share, and tax assumptions."
  )
  hit <- unname(values[as.character(id)])
  if (length(hit) && !is.na(hit) && nzchar(hit)) return(hit)
  if (v3_v309_is_scalar_text(fallback)) fallback else "No validated evidence rows were available."
}

# Rebuild the evidence panels with figure-specific explanations. This retains
# the original data/status/source contracts and changes only output wording.
v3_harden_methodology_v3_figures <- function(paths = NULL) {
  si <- v3_oq_status_inputs(paths)
  p <- si$paths
  fmap <- v3_oq_figure_map()
  audit <- vector("list", nrow(fmap))

  for (i in seq_len(nrow(fmap))) {
    rec <- v3_v309_module_record(fmap$module[[i]], si)
    out <- file.path(p$figures_v3, fmap$filename[[i]])
    is_unavailable <- !is.finite(rec$rows) || rec$rows <= 0 || toupper(rec$status) == "UNAVAILABLE"

    if (is_unavailable) {
      plot <- v3_evidence_placeholder_plot_v304(
        title = fmap$title[[i]],
        module = fmap$module[[i]],
        dependency = fmap$dependency[[i]],
        required_action = rec$required_action,
        rows = rec$rows,
        status = rec$status,
        detail = v3_v309_figure_meaning(fmap$id[[i]], rec$note)
      )
      v3_oq_save_plot(plot, out)
    }

    audit[[i]] <- tibble::tibble(
      id = fmap$id[[i]],
      filename = fmap$filename[[i]],
      module = fmap$module[[i]],
      data_rows = rec$rows,
      evidence_status = rec$status,
      output_status = if (is_unavailable) "created_placeholder_unavailable" else "retained_data_chart",
      path = out
    )
  }

  scorecard_path <- file.path(p$figures_v3, "methodology_v3_49_evidence_scorecard.png")
  v3_oq_save_plot(v3_evidence_scorecard_plot_v304(paths), scorecard_path)

  module_rows <- if (nrow(si$modules) && "rows" %in% names(si$modules)) suppressWarnings(as.numeric(si$modules$rows)) else numeric()
  module_status <- if (nrow(si$modules) && "evidence_status" %in% names(si$modules)) toupper(as.character(si$modules$evidence_status)) else character()

  audit_df <- dplyr::bind_rows(
    audit,
    tibble::tibble(
      id = "49",
      filename = basename(scorecard_path),
      module = "evidence_scorecard",
      data_rows = sum(module_rows, na.rm = TRUE),
      evidence_status = if (any(module_status == "AVAILABLE", na.rm = TRUE)) "MIXED" else "UNAVAILABLE",
      output_status = "created_status_scorecard",
      path = scorecard_path
    )
  )

  manifest_path <- file.path(p$outputs_v3, "methodology_v3_visualization_manifest.csv")
  manifest <- v3_oq_read_csv(manifest_path)
  if (nrow(manifest) && "id" %in% names(manifest)) {
    manifest <- manifest |>
      dplyr::mutate(id = as.character(.data$id)) |>
      dplyr::select(-dplyr::any_of(c("data_rows", "evidence_status", "is_placeholder"))) |>
      dplyr::left_join(
        audit_df |>
          dplyr::transmute(
            id,
            data_rows,
            evidence_status,
            is_placeholder = .data$output_status == "created_placeholder_unavailable",
            status_v309 = .data$output_status
          ),
        by = "id"
      ) |>
      dplyr::mutate(status = dplyr::coalesce(.data$status_v309, as.character(.data$status))) |>
      dplyr::select(-dplyr::any_of("status_v309"))
    readr::write_csv(manifest, manifest_path, na = "")
  }

  readr::write_csv(
    audit_df,
    file.path(p$outputs_v3, "methodology_v3_figure_evidence_audit_v309.csv"),
    na = ""
  )
  invisible(audit_df)
}

# Open a PDF device without requiring XQuartz. Base grDevices::pdf() is fully
# adequate for this compendium because the chart panels are already rendered
# as high-resolution PNGs and only the page title/source note remain vector text.
v3_pub_open_pdf_device <- function(path, width = 11, height = 8.5) {
  # Always use the portable base device. Do not probe Cairo capability: Apple
  # Silicon R can report it even when the XQuartz-linked dylibs are absent.
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  if (file.exists(path)) unlink(path, force = TRUE)
  grDevices::pdf(
    path,
    width = width,
    height = height,
    onefile = TRUE,
    useDingbats = FALSE,
    family = "Helvetica",
    paper = "special"
  )
  invisible("pdf")
}

v3_v309_source_note <- function(id) {
  notes <- c(
    `37` = "Source: Census BTOS public estimates and Iowa employer pulse when supplied. Unavailable cells remain unavailable.",
    `38` = "Source: Methodology v2 technical exposure estimates and Methodology v3 observed or benchmarked adoption nowcast. The comparison is descriptive, not causal.",
    `39` = "Source: Iowa worker pulse or preregistered pilot task-outcome records. Cells below the configured sample threshold are not publicly reported.",
    `40` = "Source: Census QWI Sex-by-Age API and Methodology v2 industry exposure. The index is descriptive and requires a reliability class.",
    `41` = "Source: Registered apprenticeship or local administrative records. Missing records are not interpreted as zero capacity.",
    `42` = "Source: O*NET candidate graph plus verified credential, training, openings, access, wage, and employer-validation inputs.",
    `43` = "Source: Methodology v3 pathway-constraint engine. Counts explain why candidate pathways were not eligible for recommendation.",
    `44` = "Source: Employer or site readiness assessments. Readiness is observed and is not inferred from exposure.",
    `45` = "Source: User-approved implementation-cost, ramp, dip, plateau, operating-cost, and worker-gain assumptions. Scenarios are not forecasts.",
    `46` = "Source: Preregistered pilot registry, comparison evidence, outcomes, incidents, appeals, and configured decision rules.",
    `47` = "Source: Model testing, red-team, field-testing, and system-level evidence recorded in the assurance registry.",
    `48` = "Source: BEA Input-Output and Regional data where available, plus explicit Iowa retention, leakage, worker-share, and tax assumptions.",
    `49` = "Source: Module-level and public-input evidence status. Unavailable and provisional evidence is shown rather than silently imputed."
  )
  out <- unname(notes[as.character(id)])
  if (length(out) && !is.na(out)) out else "Source: Iowa AI Workforce Atlas Methodology v3 evidence system."
}

# Publication compendium: cross-platform, XQuartz-free, one landscape page per
# figure, with titles and source notes in the requested body typography.
v3_pdf_watchdog_create_compendium <- function(paths = NULL, force = TRUE) {
  p <- v3_pub_paths(paths)
  output <- file.path(p$outputs_root, "all_generated_figures_methodology_v3_printable.pdf")
  files <- v3_pub_compendium_files(paths)

  if (!nrow(files)) stop("No Methodology v3 PNG figures were found for the publication compendium.", call. = FALSE)
  if (!requireNamespace("png", quietly = TRUE)) utils::install.packages("png", dependencies = NA, quiet = TRUE)
  if (!requireNamespace("png", quietly = TRUE)) stop("The png package is required for the publication figure compendium.", call. = FALSE)
  if (file.exists(output) && isTRUE(force)) unlink(output, force = TRUE)

  v3_pub_open_pdf_device(output, width = 11, height = 8.5)
  device_open <- TRUE
  on.exit({
    if (isTRUE(device_open)) try(grDevices::dev.off(), silent = TRUE)
  }, add = TRUE)

  pages_written <- 0L
  for (i in seq_len(nrow(files))) {
    img <- tryCatch(png::readPNG(files$path[[i]]), error = function(e) NULL)
    if (is.null(img)) next

    dims <- dim(img)
    aspect <- if (length(dims) >= 2L && dims[[1L]] > 0) dims[[2L]] / dims[[1L]] else 16 / 9
    max_w <- 10.55
    max_h <- 6.95
    w <- min(max_w, max_h * aspect)
    h <- w / aspect

    grid::grid.newpage()
    grid::grid.rect(gp = grid::gpar(fill = "white", col = NA))
    grid::grid.text(
      paste0("Figure ", files$id[[i]], ". ", files$title[[i]]),
      x = grid::unit(0.5, "npc"),
      y = grid::unit(0.968, "npc"),
      gp = grid::gpar(fontfamily = "Helvetica", fontsize = 12, fontface = "bold", col = "black")
    )
    grid::grid.raster(
      img,
      x = grid::unit(0.5, "npc"),
      y = grid::unit(0.51, "npc"),
      width = grid::unit(w, "in"),
      height = grid::unit(h, "in"),
      interpolate = TRUE
    )
    grid::grid.text(
      v3_v309_source_note(files$id[[i]]),
      x = grid::unit(0.025, "npc"),
      y = grid::unit(0.022, "npc"),
      just = c("left", "bottom"),
      gp = grid::gpar(fontfamily = "Helvetica", fontsize = 10, col = "black")
    )
    pages_written <- pages_written + 1L
  }

  grDevices::dev.off()
  device_open <- FALSE
  if (pages_written < 13L || !file.exists(output) || is.na(file.info(output)$size) || file.info(output)$size <= 250000) {
    stop("The Methodology v3 compendium did not produce all 13 validated pages.", call. = FALSE)
  }
  output
}

v3_v309_clean_report_html <- function(path, compact_figures = TRUE) {
  if (!file.exists(path)) return(invisible(FALSE))
  lines <- readLines(path, warn = FALSE, encoding = "UTF-8")
  trimmed <- trimws(lines)

  # Remove only the known Quarto raw-block artifacts produced by the previous
  # double-asis contract. Embedded scripts and base64 image data are untouched.
  lines <- sub("^([[:space:]]*)`````(?=<div class=\"source-note\">)", "\\1", lines, perl = TRUE)
  trimmed <- trimws(lines)
  remove <- trimmed %in% c(
    ":::",
    "::: {.cell layout-align=&quot;center&quot;}",
    "`````{=html}"
  )
  lines[remove] <- ""

  heading <- grepl("^# [^#]", trimws(lines))
  if (any(heading)) {
    label <- sub("^# ", "", trimws(lines[heading]))
    lines[heading] <- paste0("<h1>", label, "</h1>")
  }

  style_id <- "ia-methodology-v3-publication-v309"
  style <- c(
    paste0('<style id="', style_id, '">'),
    "@media print {",
    "  .methodology-v3-figure { break-before: auto !important; page-break-before: auto !important; break-inside: auto !important; page-break-inside: auto !important; margin-bottom: 8pt !important; }",
    if (isTRUE(compact_figures)) "  .methodology-v3-figure-img { max-height: 5.15in !important; }" else "",
    "  p { orphans: 3; widows: 3; }",
    "  table th, table td { font-size: 9.5pt !important; word-break: normal !important; overflow-wrap: break-word !important; hyphens: none !important; }",
    "  thead { display: table-header-group; }",
    "  tr { break-inside: auto !important; page-break-inside: auto !important; }",
    "}",
    "</style>"
  )

  # Replace an earlier v3.0.9 style if this function is called repeatedly.
  begin <- which(grepl(paste0('<style id="', style_id, '">'), lines, fixed = TRUE))
  if (length(begin)) {
    end <- which(seq_along(lines) >= begin[[1L]] & trimws(lines) == "</style>")
    if (length(end)) lines <- lines[-seq.int(begin[[1L]], end[[1L]])]
  }

  head_end <- which(grepl("</head>", lines, fixed = TRUE))
  if (length(head_end)) lines <- append(lines, style, after = head_end[[1L]] - 1L)

  writeLines(lines, path, useBytes = TRUE)
  invisible(TRUE)
}

# Wrap the existing renderer once, then clean only its final HTML artifacts.
if (
  exists("render_methodology_v3_reports", mode = "function", inherits = TRUE) &&
  !exists(".v3_v309_render_methodology_v3_reports_original", inherits = FALSE)
) {
  .v3_v309_render_methodology_v3_reports_original <- get("render_methodology_v3_reports", mode = "function", inherits = TRUE)
}

if (exists(".v3_v309_render_methodology_v3_reports_original", inherits = FALSE)) {
  render_methodology_v3_reports <- function(quiet = FALSE, paths = v3_paths()) {
    out <- .v3_v309_render_methodology_v3_reports_original(quiet = quiet, paths = paths)
    p <- v3_pub_paths(paths)
    v3_v309_clean_report_html(file.path(p$outputs_root, "atlas_methodology_v3_quarto.html"), compact_figures = TRUE)
    v3_v309_clean_report_html(file.path(p$outputs_root, "atlas_methodology_v3_rmarkdown.html"), compact_figures = TRUE)
    invisible(out)
  }
}


# Strengthen the publication validators so raw Quarto double-asis markers cannot
# be accepted as a successful article report.
if (
  exists("v3_pub_html_quality", mode = "function", inherits = TRUE) &&
  !exists(".v3_v309_html_quality_original", inherits = FALSE)
) {
  .v3_v309_html_quality_original <- get("v3_pub_html_quality", mode = "function", inherits = TRUE)
}
if (exists(".v3_v309_html_quality_original", inherits = FALSE)) {
  v3_pub_html_quality <- function(path) {
    out <- .v3_v309_html_quality_original(path)
    text <- if (file.exists(path)) paste(readLines(path, warn = FALSE, encoding = "UTF-8"), collapse = "\n") else ""
    bad_v309 <- grepl("`````|::: \\{\\.cell|^# (Observed adoption nowcasting|Publication and governance rules|Files created)$", text, perl = TRUE)
    out$valid <- isTRUE(out$valid) && !bad_v309
    out$detail <- paste0(out$detail, "; raw_quarto_markers=", bad_v309)
    out
  }
}

if (
  exists("v3_pub_pdf_quality", mode = "function", inherits = TRUE) &&
  !exists(".v3_v309_pdf_quality_original", inherits = FALSE)
) {
  .v3_v309_pdf_quality_original <- get("v3_pub_pdf_quality", mode = "function", inherits = TRUE)
}
if (exists(".v3_v309_pdf_quality_original", inherits = FALSE)) {
  v3_pub_pdf_quality <- function(path, html = NULL) {
    out <- .v3_v309_pdf_quality_original(path, html)
    text <- ""
    if (file.exists(path) && requireNamespace("pdftools", quietly = TRUE)) {
      text <- paste(tryCatch(pdftools::pdf_text(path), error = function(e) character()), collapse = "\n")
    }
    bad_v309 <- grepl("`````|::: \\{\\.cell|^# (Observed adoption nowcasting|Publication and governance rules|Files created)$", text, perl = TRUE)
    out$valid <- isTRUE(out$valid) && !bad_v309
    out$detail <- paste0(out$detail, "; raw_quarto_markers=", bad_v309)
    out
  }
}

# Record the installed output-layer version for validators and reports.
options(ia_atlas_methodology_v3_publication_completion = "3.0.9")
