# Iowa AI Workforce Atlas v3.1.3 public-source and Excel repair layer
# Narrow public-source and Stage 6 compatibility repairs.
#
# This module does not change Methodology v2/v3 scoring. It:
#   * uses the live Census BTOS /api contract and Iowa FIPS 19;
#   * sorts BTOS periods by collection date rather than numeric ID alone;
#   * supplies a valid BEA Regional Iowa control fallback;
#   * aliases the maintained v3 editable-Excel builder to historical names;
#   * records explicit diagnostics instead of equating adapter failure with
#     source unavailability.

if (!exists("%||%", mode = "function", inherits = TRUE)) {
  `%||%` <- function(x, y) {
    if (is.null(x) || !length(x) || (length(x) == 1L && is.na(x))) y else x
  }
}

atlas_v313_has_rows <- function(x) {
  if (is.data.frame(x) || is.matrix(x)) return(NROW(x) > 0L)
  if (is.list(x)) {
    for (nm in c("data", "rows", "result", "results", "Data", "Results")) {
      if (!is.null(x[[nm]]) && atlas_v313_has_rows(x[[nm]])) return(TRUE)
    }
  }
  FALSE
}

atlas_v313_clean_names <- function(x) {
  if (!is.data.frame(x)) x <- as.data.frame(x, stringsAsFactors = FALSE)
  if (requireNamespace("janitor", quietly = TRUE)) {
    return(janitor::clean_names(x))
  }
  names(x) <- tolower(gsub("[^A-Za-z0-9]+", "_", names(x)))
  names(x) <- gsub("^_+|_+$", "", names(x))
  x
}

atlas_v313_parse_json_rows <- function(text) {
  if (!length(text) || !nzchar(text[[1L]])) return(data.frame())
  prefix <- trimws(substr(text[[1L]], 1L, 32L))
  if (identical(prefix, "null") || grepl('^\\[\\s*"bad request"', prefix, ignore.case = TRUE)) {
    return(data.frame())
  }
  value <- tryCatch(
    jsonlite::fromJSON(text[[1L]], simplifyDataFrame = TRUE, flatten = TRUE),
    error = function(e) NULL
  )
  if (is.null(value)) return(data.frame())
  if (is.matrix(value)) {
    # Standard Census APIs encode a table as an array whose first row contains
    # column names. Promote that row before returning observations.
    if (NROW(value) >= 2L) {
      header <- make.unique(as.character(value[1L, , drop = TRUE]))
      out <- as.data.frame(value[-1L, , drop = FALSE], stringsAsFactors = FALSE)
      names(out) <- header
      return(out)
    }
    return(as.data.frame(value, stringsAsFactors = FALSE))
  }
  if (is.data.frame(value)) {
    # jsonlite can occasionally simplify an array-of-arrays to a data frame
    # with generic names. Promote the first row only in that representation.
    generic <- all(grepl("^(V|X)?[0-9]+$", names(value)))
    if (generic && NROW(value) >= 2L) {
      header <- make.unique(as.character(value[1L, , drop = TRUE]))
      out <- value[-1L, , drop = FALSE]
      names(out) <- header
      rownames(out) <- NULL
      return(out)
    }
    return(value)
  }
  if (is.list(value)) {
    # Common nested API containers.
    for (nm in c("data", "Data", "rows", "Rows", "results", "Results", "BEAAPI")) {
      if (!is.null(value[[nm]])) {
        candidate <- value[[nm]]
        if (identical(nm, "BEAAPI") && is.list(candidate)) {
          candidate <- candidate$Results$Data %||% candidate$Results$data %||% candidate
        }
        if (is.data.frame(candidate)) return(candidate)
        if (is.matrix(candidate)) return(as.data.frame(candidate, stringsAsFactors = FALSE))
        if (is.list(candidate) && length(candidate)) {
          out <- tryCatch(
            dplyr::bind_rows(candidate),
            error = function(e) tryCatch(
              as.data.frame(candidate, stringsAsFactors = FALSE),
              error = function(e2) data.frame()
            )
          )
          if (NROW(out)) return(out)
        }
      }
    }
    out <- tryCatch(
      dplyr::bind_rows(value),
      error = function(e) tryCatch(
        as.data.frame(value, stringsAsFactors = FALSE),
        error = function(e2) data.frame()
      )
    )
    if (NROW(out)) return(out)
  }
  data.frame()
}

atlas_v313_http_text <- function(url, query = list(), timeout = 90) {
  if (!requireNamespace("httr2", quietly = TRUE)) {
    return(list(ok = FALSE, status = NA_integer_, text = "", error = "httr2 unavailable"))
  }
  req <- httr2::request(url) |>
    httr2::req_user_agent("Iowa-AI-Workforce-Atlas/3.1.3-clean-r6 public-research") |>
    httr2::req_timeout(timeout)
  if (length(query)) req <- do.call(httr2::req_url_query, c(list(req), query))
  resp <- tryCatch(
    httr2::req_perform(req),
    error = function(e) e
  )
  if (inherits(resp, "error")) {
    return(list(ok = FALSE, status = NA_integer_, text = "", error = conditionMessage(resp)))
  }
  status <- httr2::resp_status(resp)
  text <- tryCatch(httr2::resp_body_string(resp), error = function(e) "")
  list(
    ok = isTRUE(status >= 200L && status < 300L),
    status = status,
    text = text,
    error = ""
  )
}

atlas_v313_btos_periods <- function() {
  got <- atlas_v313_http_text("https://www.census.gov/hfp/btos/api/periods")
  rows <- atlas_v313_parse_json_rows(got$text)
  if (!NROW(rows)) return(rows)
  rows <- atlas_v313_clean_names(rows)
  # The API inventory is not guaranteed to arrive in chronological order.
  parse_btos_date <- function(x) {
    x <- sub("\\.[0-9]{6}(?=\\s+[AP]M$)", "", as.character(x), perl = TRUE)
    suppressWarnings(as.POSIXct(
      x,
      format = "%d-%b-%y %I.%M.%S %p",
      tz = "UTC"
    ))
  }
  if ("collection_end" %in% names(rows)) {
    rows$collection_end_parsed <- parse_btos_date(rows$collection_end)
  } else {
    rows$collection_end_parsed <- as.POSIXct(NA)
  }
  if (!"period_id" %in% names(rows)) {
    candidate <- intersect(c("period", "id"), names(rows))
    if (length(candidate)) rows$period_id <- rows[[candidate[[1L]]]]
  }
  rows$period_id <- suppressWarnings(as.integer(as.character(rows$period_id)))
  rows[order(rows$collection_end_parsed, rows$period_id, decreasing = TRUE, na.last = TRUE), , drop = FALSE]
}

atlas_v313_filter_iowa_rows <- function(rows) {
  if (!NROW(rows)) return(rows)
  rows <- atlas_v313_clean_names(rows)
  state_columns <- intersect(
    c("state", "state_fips", "state_code", "st", "geo_id", "geoid", "geofips"),
    names(rows)
  )
  if (!length(state_columns)) return(rows)
  keep <- rep(FALSE, NROW(rows))
  for (column in state_columns) {
    value <- toupper(trimws(as.character(rows[[column]])))
    keep <- keep | value %in% c("19", "IA", "IOWA", "19000")
  }
  rows[keep, , drop = FALSE]
}

atlas_v313_btos_state_period <- function(
    period_id,
    state_candidates = c("19", "IA", "ia")) {
  period_id <- as.integer(period_id[[1L]])
  diagnostics <- list()

  requests <- list()
  for (state_id in unique(state_candidates)) {
    requests[[length(requests) + 1L]] <- list(
      state_id = state_id,
      url = sprintf(
        "https://www.census.gov/hfp/btos/api/periods/%s/data/state/%s",
        period_id,
        state_id
      ),
      query = list(),
      filter_iowa = FALSE
    )
  }
  # Contract fallbacks for deployments that expose all-state data or accept
  # the state selector as a query parameter rather than a path segment.
  requests[[length(requests) + 1L]] <- list(
    state_id = "all_state_filter",
    url = sprintf(
      "https://www.census.gov/hfp/btos/api/periods/%s/data/state",
      period_id
    ),
    query = list(),
    filter_iowa = TRUE
  )
  requests[[length(requests) + 1L]] <- list(
    state_id = "query_19",
    url = sprintf(
      "https://www.census.gov/hfp/btos/api/periods/%s/data/state",
      period_id
    ),
    query = list(state = "19"),
    filter_iowa = TRUE
  )

  for (request_spec in requests) {
    got <- atlas_v313_http_text(
      request_spec$url,
      query = request_spec$query
    )
    rows <- atlas_v313_parse_json_rows(got$text)
    if (isTRUE(request_spec$filter_iowa) && NROW(rows)) {
      rows <- atlas_v313_filter_iowa_rows(rows)
    }
    diagnostics[[length(diagnostics) + 1L]] <- data.frame(
      period_id = period_id,
      state_id = request_spec$state_id,
      request_url = request_spec$url,
      status = got$status,
      body_bytes = nchar(got$text, type = "bytes"),
      rows = NROW(rows),
      error = got$error,
      stringsAsFactors = FALSE
    )
    if (NROW(rows)) {
      rows <- atlas_v313_clean_names(rows)
      rows$period_id <- period_id
      rows$atlas_state_request_id <- request_spec$state_id
      attr(rows, "atlas_v313_diagnostics") <- dplyr::bind_rows(diagnostics)
      return(rows)
    }
  }
  out <- data.frame()
  attr(out, "atlas_v313_diagnostics") <- dplyr::bind_rows(diagnostics)
  out
}

atlas_v313_btos_latest_iowa <- function(max_periods = 20L, max_successes = 8L) {
  periods <- atlas_v313_btos_periods()
  if (!NROW(periods) || !"period_id" %in% names(periods)) return(data.frame())
  ids <- unique(stats::na.omit(periods$period_id))
  ids <- head(ids, max(1L, as.integer(max_periods)))
  records <- list()
  diagnostics <- list()
  successes <- 0L
  for (period_id in ids) {
    rows <- atlas_v313_btos_state_period(period_id)
    diag <- attr(rows, "atlas_v313_diagnostics")
    if (NROW(diag)) diagnostics[[length(diagnostics) + 1L]] <- diag
    if (NROW(rows)) {
      meta <- periods[match(period_id, periods$period_id), , drop = FALSE]
      for (nm in setdiff(names(meta), names(rows))) {
        rows[[nm]] <- meta[[nm]][[1L]]
      }
      records[[length(records) + 1L]] <- rows
      successes <- successes + 1L
      if (successes >= max_successes) break
    }
  }
  out <- dplyr::bind_rows(records)
  attr(out, "atlas_v313_diagnostics") <- dplyr::bind_rows(diagnostics)
  out
}

atlas_v313_bea_regional_iowa_control <- function(
    api_key = Sys.getenv("BEA_API_KEY"),
    table_name = "SAINC1",
    line_code = "3",
    geo_fips = "19000",
    year = "LAST5") {
  if (!nzchar(api_key)) return(data.frame())
  got <- atlas_v313_http_text(
    "https://apps.bea.gov/api/data",
    query = list(
      UserID = api_key,
      method = "GetData",
      DatasetName = "Regional",
      TableName = table_name,
      LineCode = line_code,
      GeoFIPS = geo_fips,
      Year = year,
      ResultFormat = "JSON"
    )
  )
  if (!got$ok || !nzchar(got$text)) return(data.frame())
  parsed <- tryCatch(
    jsonlite::fromJSON(got$text, simplifyDataFrame = TRUE, flatten = TRUE),
    error = function(e) NULL
  )
  rows <- tryCatch(
    parsed$BEAAPI$Results$Data,
    error = function(e) NULL
  )
  if (is.null(rows)) return(data.frame())
  if (!is.data.frame(rows)) {
    rows <- tryCatch(dplyr::bind_rows(rows), error = function(e) data.frame())
  }
  if (!NROW(rows)) return(rows)
  rows <- atlas_v313_clean_names(rows)
  # Supply stable normalized aliases while retaining every source field.
  if ("time_period" %in% names(rows)) {
    rows$year <- suppressWarnings(as.integer(rows$time_period))
  }
  if ("data_value" %in% names(rows)) {
    rows$value <- suppressWarnings(readr::parse_number(as.character(rows$data_value)))
  }
  if ("geo_fips" %in% names(rows)) rows$geofips <- as.character(rows$geo_fips)
  rows$dataset_name <- "Regional"
  rows$table_name <- table_name
  rows$line_code <- line_code
  rows
}

atlas_v313_fallback_like <- function(original, fallback) {
  if (!NROW(fallback)) return(original)
  if (is.data.frame(original) || is.matrix(original) || is.null(original)) {
    return(fallback)
  }
  if (is.list(original)) {
    for (nm in c("data", "rows", "result", "results", "Data", "Results")) {
      if (nm %in% names(original)) {
        original[[nm]] <- fallback
        return(original)
      }
    }
  }
  fallback
}

atlas_v313_wrap_empty_source <- function(
    function_name,
    fallback,
    marker_prefix = ".atlas_v313_original_") {
  if (!exists(function_name, mode = "function", inherits = TRUE)) return(FALSE)
  marker <- paste0(marker_prefix, function_name)
  if (exists(marker, envir = .GlobalEnv, inherits = FALSE)) return(TRUE)
  original <- get(function_name, mode = "function", inherits = TRUE)
  assign(marker, original, envir = .GlobalEnv)
  wrapper <- local({
    original_fn <- original
    fallback_fn <- fallback
    function(...) {
      original_result <- tryCatch(
        original_fn(...),
        error = function(e) structure(list(error = e), class = "atlas_v313_source_error")
      )
      if (!inherits(original_result, "atlas_v313_source_error") &&
          atlas_v313_has_rows(original_result)) {
        return(original_result)
      }
      replacement <- tryCatch(fallback_fn(list(...)), error = function(e) data.frame())
      if (NROW(replacement)) {
        base <- if (inherits(original_result, "atlas_v313_source_error")) NULL else original_result
        return(atlas_v313_fallback_like(base, replacement))
      }
      if (inherits(original_result, "atlas_v313_source_error")) {
        stop(original_result$error)
      }
      original_result
    }
  })
  # Keep the closure environment created by local(); it stores both the
  # original function and the source-specific fallback. Its parent remains the
  # project environment, so shared helpers are still resolved normally.
  assign(function_name, wrapper, envir = .GlobalEnv)
  TRUE
}

atlas_v313_install_repairs <- function() {
  # Excel aliases fix the Stage 6 lookup without altering either workbook.
  if (exists("make_methodology_v3_editable_excel", mode = "function", inherits = TRUE)) {
    builder <- get("make_methodology_v3_editable_excel", mode = "function", inherits = TRUE)
    for (alias in c(
      "v3_make_methodology_v3_editable_excel",
      "make_methodology_v3_editable_excel_workbook"
    )) {
      if (!exists(alias, mode = "function", inherits = TRUE)) {
        assign(alias, builder, envir = .GlobalEnv)
      }
    }
  }

  # Wrappers are generated only for acquisition functions identified in the
  # maintained source. Original results always win; fallbacks run only after
  # a genuine zero-row result or request error.
  btos_period_functions <- c()
  btos_state_functions <- c("v3_download_btos_api")
  btos_general_functions <- c("v3_download_btos")
  bea_regional_functions <- c()

  for (nm in btos_period_functions) {
    atlas_v313_wrap_empty_source(
      nm,
      fallback = function(args) atlas_v313_btos_periods()
    )
  }
  for (nm in btos_state_functions) {
    atlas_v313_wrap_empty_source(
      nm,
      fallback = function(args) {
        period_id <- args$period_id %||% args$period %||% args$id
        if (is.null(period_id)) {
          periods <- atlas_v313_btos_periods()
          if (!NROW(periods)) return(data.frame())
          period_id <- periods$period_id[[1L]]
        }
        atlas_v313_btos_state_period(period_id)
      }
    )
  }
  for (nm in btos_general_functions) {
    atlas_v313_wrap_empty_source(
      nm,
      fallback = function(args) atlas_v313_btos_latest_iowa()
    )
  }
  for (nm in bea_regional_functions) {
    atlas_v313_wrap_empty_source(
      nm,
      fallback = function(args) atlas_v313_bea_regional_iowa_control()
    )
  }

  invisible(TRUE)
}

atlas_v313_write_source_diagnostics <- function(root = getwd()) {
  out_dir <- file.path(root, "outputs", "methodology_v3")
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

  btos <- tryCatch(atlas_v313_btos_latest_iowa(), error = function(e) data.frame())
  btos_diag <- attr(btos, "atlas_v313_diagnostics")
  if (NROW(btos_diag)) {
    readr::write_csv(
      btos_diag,
      file.path(out_dir, "btos_request_diagnostics_v313.csv")
    )
  }
  if (NROW(btos)) {
    raw_dir <- file.path(root, "data_raw", "methodology_v3")
    dir.create(raw_dir, recursive = TRUE, showWarnings = FALSE)
    readr::write_csv(
      btos,
      file.path(raw_dir, "btos_iowa_api_v313.csv")
    )
  }

  bea <- tryCatch(atlas_v313_bea_regional_iowa_control(), error = function(e) data.frame())
  if (NROW(bea)) {
    raw_dir <- file.path(root, "data_raw", "methodology_v3")
    dir.create(raw_dir, recursive = TRUE, showWarnings = FALSE)
    readr::write_csv(
      bea,
      file.path(raw_dir, "bea_regional_iowa_control_v313.csv")
    )
  }
  invisible(list(btos = btos, bea_regional = bea))
}

atlas_v313_reconcile_public_status <- function(root = getwd()) {
  status_path <- file.path(
    root, "outputs", "methodology_v3", "public_data_status_v3.csv"
  )
  if (!file.exists(status_path)) return(invisible(FALSE))
  status <- tryCatch(
    readr::read_csv(status_path, show_col_types = FALSE),
    error = function(e) NULL
  )
  if (is.null(status) || !NROW(status) || !"source" %in% names(status)) {
    return(invisible(FALSE))
  }

  fallback <- atlas_v313_write_source_diagnostics(root)
  btos_rows <- NROW(fallback$btos)
  bea_rows <- NROW(fallback$bea_regional)

  btos_hit <- which(tolower(status$source) == "btos")
  if (length(btos_hit) && btos_rows > 0L) {
    status$rows[btos_hit] <- btos_rows
    status$usable_rows[btos_hit] <- btos_rows
    status$configured[btos_hit] <- TRUE
    status$status[btos_hit] <- "available_via_live_api_contract"
    status$diagnostic[btos_hit] <- paste0(
      "Census BTOS Iowa rows retrieved through /hfp/btos/api using state FIPS 19; ",
      "period inventory sorted by collection_end."
    )
  }

  bea_hit <- which(tolower(status$source) == "bea regional")
  if (length(bea_hit) && bea_rows > 0L) {
    status$rows[bea_hit] <- bea_rows
    status$usable_rows[bea_hit] <- bea_rows
    status$configured[bea_hit] <- TRUE
    status$status[bea_hit] <- "available_via_valid_control_series"
    status$diagnostic[bea_hit] <- paste0(
      "BEA Regional control succeeded: SAINC1 line 3, GeoFIPS 19000, LAST5. ",
      "Regional value-capture estimates still require explicit local assumptions."
    )
  }

  readr::write_csv(status, status_path)
  invisible(TRUE)
}

atlas_v313_install_repairs()
