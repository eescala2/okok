# Iowa AI Workforce Atlas one-click release: bounded cross-platform PDF
# Version 3.1.2

`%||%` <- function(x, y) {
  if (is.null(x) || !length(x) || (length(x) == 1L && is.na(x))) y else x
}

atlas_v312_find_browser <- function() {
  explicit <- Sys.getenv("IA_ATLAS_CHROME", unset = "")
  candidates <- unique(c(
    explicit,
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
    "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
    "C:/Program Files/Google/Chrome/Application/chrome.exe",
    "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe"
  ))
  candidates <- candidates[nzchar(candidates) & file.exists(candidates)]
  if (!length(candidates)) {
    stop(
      "No supported Chrome or Edge executable was found. Set IA_ATLAS_CHROME.",
      call. = FALSE
    )
  }
  normalizePath(candidates[[1L]], winslash = "/", mustWork = TRUE)
}

atlas_v312_file_uri <- function(path) {
  path <- normalizePath(path, winslash = "/", mustWork = TRUE)
  path <- gsub("%", "%25", path, fixed = TRUE)
  path <- gsub(" ", "%20", path, fixed = TRUE)
  path <- gsub("#", "%23", path, fixed = TRUE)
  path <- gsub("?", "%3F", path, fixed = TRUE)
  if (.Platform$OS.type == "windows") {
    paste0("file:///", path)
  } else {
    paste0("file://", path)
  }
}

atlas_v312_validate_pdf <- function(
    path,
    min_pages = 10L,
    min_bytes = 500000L) {

  result <- list(
    valid = FALSE,
    pages = NA_integer_,
    bytes = if (file.exists(path)) file.info(path)$size else 0,
    reason = ""
  )

  if (!file.exists(path)) {
    result$reason <- "file was not created"
    return(result)
  }

  if (!is.finite(result$bytes) || result$bytes < min_bytes) {
    result$reason <- paste0("PDF too small: ", result$bytes, " bytes")
    return(result)
  }

  if (requireNamespace("pdftools", quietly = TRUE)) {
    info <- tryCatch(pdftools::pdf_info(path), error = function(e) NULL)
    if (is.null(info)) {
      result$reason <- "pdftools could not parse the PDF"
      return(result)
    }

    result$pages <- as.integer(info$pages)
    if (!is.finite(result$pages) || result$pages < min_pages) {
      result$reason <- paste0("implausible page count: ", result$pages)
      return(result)
    }

    text <- tryCatch(
      paste(pdftools::pdf_text(path), collapse = "\n"),
      error = function(e) ""
    )
    bad <- c(
      "Search Google or type a URL",
      "knit_image_paths",
      "object is read-only"
    )
    found <- bad[
      vapply(bad, grepl, logical(1), x = text, fixed = TRUE)
    ]
    if (length(found)) {
      result$reason <- paste("invalid PDF content:", paste(found, collapse = "; "))
      return(result)
    }
  }

  result$valid <- TRUE
  result$reason <- "validated"
  result
}

atlas_v312_print_html_pdf <- function(
    browser,
    html,
    pdf,
    artifact,
    timeout_sec,
    heartbeat_sec,
    tagged = FALSE,
    min_pages = 10L) {

  if (!requireNamespace("processx", quietly = TRUE)) {
    stop("processx is required for bounded PDF generation.", call. = FALSE)
  }

  html <- normalizePath(html, winslash = "/", mustWork = TRUE)
  pdf <- normalizePath(pdf, winslash = "/", mustWork = FALSE)
  dir.create(dirname(pdf), recursive = TRUE, showWarnings = FALSE)
  if (file.exists(pdf)) unlink(pdf)

  profile <- tempfile("iowa-atlas-v312-browser-profile-")
  dir.create(profile, recursive = TRUE, showWarnings = FALSE)
  on.exit(unlink(profile, recursive = TRUE, force = TRUE), add = TRUE)

  is_windows <- .Platform$OS.type == "windows"
  headless_argument <- if (is_windows) "--headless=new" else "--headless"

  arguments <- c(
    headless_argument,
    "--disable-gpu",
    "--disable-dev-shm-usage",
    "--disable-extensions",
    "--no-first-run",
    "--no-default-browser-check",
    "--no-sandbox",
    "--allow-file-access-from-files",
    "--run-all-compositor-stages-before-draw",
    "--no-pdf-header-footer",
    "--print-to-pdf-no-header",
    "--virtual-time-budget=12000",
    paste0("--user-data-dir=", profile),
    paste0("--print-to-pdf=", pdf)
  )

  if (isTRUE(tagged)) {
    arguments <- c(
      arguments,
      "--generate-tagged-pdf",
      "--generate-pdf-document-outline"
    )
  }

  arguments <- c(arguments, atlas_v312_file_uri(html))

  message(
    "Starting ", artifact,
    " [timeout=", timeout_sec,
    "s; tagged=", tagged, "]."
  )

  process <- processx::process$new(
    command = browser,
    args = arguments,
    stdout = "|",
    stderr = "|",
    cleanup_tree = TRUE
  )

  started <- Sys.time()
  next_heartbeat <- heartbeat_sec
  last_size <- -1
  stable <- 0L
  validation <- list(valid = FALSE, pages = NA_integer_, bytes = 0, reason = "")

  repeat {
    Sys.sleep(1)
    elapsed <- as.numeric(difftime(Sys.time(), started, units = "secs"))
    size <- if (file.exists(pdf)) file.info(pdf)$size else 0

    if (is.finite(size) && size > 500000 && identical(as.numeric(size), as.numeric(last_size))) {
      stable <- stable + 1L
    } else {
      stable <- 0L
    }
    last_size <- size

    if (elapsed >= next_heartbeat) {
      message(
        "  PDF watchdog: ",
        round(elapsed),
        "s elapsed; ",
        if (file.exists(pdf)) {
          paste0(round(size / 1024^2, 1), " MB")
        } else {
          "not written yet"
        },
        "; browser alive=", process$is_alive()
      )
      next_heartbeat <- next_heartbeat + heartbeat_sec
    }

    if (stable >= 5L) {
      validation <- atlas_v312_validate_pdf(
        pdf,
        min_pages = min_pages
      )
      if (isTRUE(validation$valid)) {
        if (process$is_alive()) {
          try(process$kill_tree(), silent = TRUE)
        }
        break
      }
    }

    if (!process$is_alive()) {
      validation <- atlas_v312_validate_pdf(
        pdf,
        min_pages = min_pages
      )
      break
    }

    if (elapsed >= timeout_sec) {
      try(process$kill_tree(), silent = TRUE)
      validation <- atlas_v312_validate_pdf(
        pdf,
        min_pages = min_pages
      )
      if (!isTRUE(validation$valid)) {
        stop(
          artifact,
          " timed out after ",
          timeout_sec,
          " seconds. ",
          validation$reason,
          call. = FALSE
        )
      }
      break
    }
  }

  if (!isTRUE(validation$valid)) {
    stop(
      artifact,
      " failed validation: ",
      validation$reason,
      call. = FALSE
    )
  }

  message(
    "Completed ", artifact,
    ": ", validation$pages,
    " pages, ",
    round(validation$bytes / 1024^2, 1),
    " MB."
  )

  validation
}


atlas_v312_print_html_pdf_with_fallback <- function(
    browser,
    html,
    pdf,
    artifact,
    timeout_sec,
    heartbeat_sec,
    tagged,
    min_pages = 10L) {

  tagged_sequence <- if (isTRUE(tagged)) c(TRUE, FALSE) else FALSE
  errors <- character()

  for (attempt in seq_along(tagged_sequence)) {
    attempt_tagged <- tagged_sequence[[attempt]]
    message(
      "  Attempt ", attempt, "/", length(tagged_sequence),
      " for ", artifact,
      " [tagged=", attempt_tagged, "]."
    )

    result <- tryCatch(
      atlas_v312_print_html_pdf(
        browser = browser,
        html = html,
        pdf = pdf,
        artifact = artifact,
        timeout_sec = timeout_sec,
        heartbeat_sec = heartbeat_sec,
        tagged = attempt_tagged,
        min_pages = min_pages
      ),
      error = function(e) e
    )

    if (!inherits(result, "error")) {
      result$attempt <- attempt
      result$tagged <- attempt_tagged
      return(result)
    }

    errors <- c(
      errors,
      paste0(
        "attempt ", attempt,
        " tagged=", attempt_tagged,
        ": ", conditionMessage(result)
      )
    )
  }

  stop(
    artifact,
    " failed every bounded PDF attempt. ",
    paste(errors, collapse = " | "),
    call. = FALSE
  )
}


atlas_v312_externalize_print_html <- function(
    input_html,
    output_html,
    asset_dir,
    max_width = 3000L,
    max_height = 2200L) {

  if (!requireNamespace("xml2", quietly = TRUE)) {
    stop("xml2 is required to create lightweight print HTML.", call. = FALSE)
  }
  if (!requireNamespace("base64enc", quietly = TRUE)) {
    stop("base64enc is required to create lightweight print HTML.", call. = FALSE)
  }
  if (!requireNamespace("magick", quietly = TRUE)) {
    stop("magick is required to create lightweight print HTML.", call. = FALSE)
  }

  input_html <- normalizePath(input_html, winslash = "/", mustWork = TRUE)
  output_html <- normalizePath(output_html, winslash = "/", mustWork = FALSE)
  dir.create(dirname(output_html), recursive = TRUE, showWarnings = FALSE)
  dir.create(asset_dir, recursive = TRUE, showWarnings = FALSE)

  document <- xml2::read_html(
    input_html,
    options = c("RECOVER", "NOERROR", "NOWARNING")
  )

  remove_xpath <- paste0(
    "//pre[contains(concat(' ', normalize-space(@class), ' '), ' r ')] | ",
    "//pre[contains(concat(' ', normalize-space(@class), ' '), ' sourceCode ')] | ",
    "//div[contains(concat(' ', normalize-space(@class), ' '), ' sourceCode ')] | ",
    "//div[contains(concat(' ', normalize-space(@class), ' '), ' cell-code ')] | ",
    "//details | //nav | //script"
  )
  xml2::xml_remove(xml2::xml_find_all(document, remove_xpath))

  images <- xml2::xml_find_all(
    document,
    "//img[starts-with(@src, 'data:image/png;base64,')]"
  )

  for (index in seq_along(images)) {
    source <- xml2::xml_attr(images[[index]], "src")
    raw <- base64enc::base64decode(
      sub("^data:image/png;base64,", "", source)
    )
    temporary <- tempfile(fileext = ".png")
    writeBin(raw, temporary)

    image <- magick::image_read(temporary)
    image <- tryCatch(
      magick::image_trim(image, fuzz = 2),
      error = function(e) image
    )
    information <- magick::image_info(image)

    if (
      information$width > max_width ||
      information$height > max_height
    ) {
      image <- magick::image_resize(
        image,
        sprintf("%dx%d>", max_width, max_height)
      )
    }

    target <- file.path(
      asset_dir,
      sprintf("figure_%03d.png", index)
    )
    magick::image_write(image, target, format = "png")

    relative <- fs::path_rel(
      target,
      start = dirname(output_html)
    )
    xml2::xml_set_attr(
      images[[index]],
      "src",
      gsub("\\\\", "/", relative)
    )
    xml2::xml_set_attr(images[[index]], "loading", "eager")
  }

  css <- paste0(
    "<style id='ia-atlas-v312-print'>",
    "@page{size:letter landscape;margin:.28in;}",
    "html,body{font-family:Arial,Helvetica,sans-serif!important;",
    "font-size:12pt;line-height:1.15;color:#000;background:#fff;}",
    "main,.container,.container-fluid,.content,#quarto-document-content",
    "{max-width:none!important;width:100%!important;margin:0!important;}",
    "pre,.sourceCode,.cell-code,details,summary,nav,.tocify,",
    ".sidebar,.margin-sidebar{display:none!important;}",
    "h1{font-size:18pt;color:#1C5DBA;margin:0 0 6pt;}",
    "h2,h3,h4{font-size:16pt;color:#00808D;margin:8pt 0 5pt;}",
    ".figure-title{font-size:12pt;font-weight:700;text-align:center;",
    "margin:2pt 0 3pt;line-height:1.05;}",
    ".figure-note,figcaption{font-size:10pt;text-align:left;",
    "margin:2pt 0 4pt;line-height:1.08;}",
    "figure,.report-figure,.public-figure{margin:0 0 5pt!important;",
    "padding:0!important;break-inside: auto !important;}",
    "img{display:block;margin:0 auto;max-width:100%!important;",
    "max-height:6.82in!important;width:auto!important;height:auto!important;",
    "object-fit:contain;}",
    ".public-figure-page{break-before:page;break-inside: auto !important;",
    "margin:0!important;padding:0!important;}",
    "table{width:100%;border-collapse:collapse;font-size:9.5pt;}",
    "th,td{padding:2px 4px;vertical-align:top;",
    "overflow-wrap:normal;word-break:normal;hyphens:none;}",
    "p,li{orphans:3;widows:3;}",
    "</style>"
  )

  head <- xml2::xml_find_first(document, "//head")
  style_node <- xml2::read_html(css) |>
    xml2::xml_find_first("//style")
  xml2::xml_add_child(head, style_node)

  xml2::write_html(document, output_html, options = "format")
  invisible(output_html)
}

atlas_v312_create_compendium <- function(
    figures,
    output_pdf,
    title = "Iowa AI Workforce Atlas figures") {

  if (!requireNamespace("png", quietly = TRUE)) {
    stop("png is required to create figure compendia.", call. = FALSE)
  }

  figures <- figures[file.exists(figures)]
  if (!length(figures)) {
    stop("No figure files were supplied for the compendium.", call. = FALSE)
  }

  grDevices::pdf(
    output_pdf,
    width = 11,
    height = 8.5,
    onefile = TRUE,
    family = "Helvetica",
    useDingbats = FALSE,
    paper = "special"
  )
  on.exit(grDevices::dev.off(), add = TRUE)

  for (index in seq_along(figures)) {
    image <- png::readPNG(figures[[index]], native = FALSE)
    dimensions <- dim(image)
    aspect <- dimensions[[2L]] / dimensions[[1L]]

    page_width <- 11
    page_height <- 8.5
    available_width <- 0.95
    available_height <- 0.82
    available_aspect <- (
      available_width * page_width
    ) / (
      available_height * page_height
    )

    if (aspect >= available_aspect) {
      width_npc <- available_width
      height_npc <- width_npc * page_width / (page_height * aspect)
    } else {
      height_npc <- available_height
      width_npc <- height_npc * page_height * aspect / page_width
    }

    figure_title <- tools::toTitleCase(
      gsub(
        "_",
        " ",
        tools::file_path_sans_ext(
          basename(figures[[index]])
        )
      )
    )

    grid::grid.newpage()
    grid::grid.text(
      figure_title,
      x = 0.5,
      y = 0.965,
      gp = grid::gpar(
        fontfamily = "Helvetica",
        fontsize = 12,
        fontface = "bold"
      )
    )
    grid::grid.raster(
      image,
      x = 0.5,
      y = 0.50,
      width = grid::unit(width_npc, "npc"),
      height = grid::unit(height_npc, "npc"),
      interpolate = TRUE
    )
  }

  grDevices::dev.off()
  on.exit(NULL, add = FALSE)
  invisible(output_pdf)
}
