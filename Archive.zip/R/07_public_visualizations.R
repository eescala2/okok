# 07_public_visualizations.R --------------------------------------------------
# Intricate, public-facing R-only visualizations for the Iowa AI Workforce Atlas.
#
# Usage from the project root after running Rscript run_all.R:
#   source('R/07_public_visualizations.R')
#   make_public_visualizations(install_missing = TRUE)
#
# Outputs are written to figures/public/ and a manifest is written to
# outputs/public_visualization_manifest.csv.

# ---- Local project-root discovery -----------------------------------------
.local_project_root <- function() {
  here <- normalizePath(getwd(), winslash = '/', mustWork = TRUE)
  script_dir <- tryCatch({
    frames <- sys.frames()
    ofiles <- vapply(frames, function(x) {
      val <- x$ofile
      if (is.null(val)) NA_character_ else as.character(val)
    }, character(1))
    ofiles <- stats::na.omit(ofiles)
    if (length(ofiles)) normalizePath(dirname(ofiles[[length(ofiles)]]), winslash = '/', mustWork = FALSE) else NA_character_
  }, error = function(e) NA_character_)
  candidates <- unique(stats::na.omit(c(
    here,
    dirname(here),
    normalizePath(file.path(here, '..'), winslash = '/', mustWork = FALSE),
    script_dir,
    normalizePath(file.path(script_dir, '..'), winslash = '/', mustWork = FALSE)
  )))
  for (cand in candidates) {
    if (file.exists(file.path(cand, 'config.yml')) && dir.exists(file.path(cand, 'R'))) {
      return(cand)
    }
  }
  stop('Could not locate project root. Run from the Iowa AI Workforce Atlas project root.', call. = FALSE)
}

.public_viz_pkgs <- c(
  'dplyr', 'tidyr', 'readr', 'sf', 'ggplot2', 'scales', 'stringr',
  'forcats', 'ggrepel', 'patchwork', 'ggforce', 'ggridges', 'ggalluvial',
  'treemapify', 'ggtext', 'viridis', 'fs', 'glue', 'janitor', 'tigris', 'purrr', 'htmltools', 'png'
)

.public_viz_optional_pkgs <- c('ragg')

install_public_viz_packages <- function(install_missing = TRUE) {
  repo <- Sys.getenv('IA_ATLAS_CRAN_REPO', unset = '')
  if (!nzchar(repo)) repo <- 'https://packagemanager.posit.co/cran/latest'
  repos <- getOption('repos')
  current <- tryCatch(repos[['CRAN']], error = function(e) NA_character_)
  if (is.null(repos) || is.na(current) || identical(current, '@CRAN@') || !nzchar(current)) {
    options(repos = c(CRAN = repo))
  }
  options(download.file.method = 'libcurl')
  if (.Platform$OS.type == 'windows' || identical(Sys.info()[['sysname']], 'Darwin')) options(pkgType = 'binary')

  installed <- rownames(utils::installed.packages())
  missing <- setdiff(.public_viz_pkgs, installed)
  if (length(missing) && isTRUE(install_missing)) {
    message('Installing missing visualization packages: ', paste(missing, collapse = ', '))
    cores <- parallel::detectCores(logical = TRUE)
    if (is.na(cores) || cores < 2L) cores <- 2L
    utils::install.packages(missing, dependencies = c('Depends', 'Imports', 'LinkingTo'), quiet = TRUE, Ncpus = max(1L, cores - 1L), type = getOption('pkgType', 'binary'))
  }
  still_missing <- setdiff(.public_viz_pkgs, rownames(utils::installed.packages()))
  if (length(still_missing)) {
    stop('Missing required visualization packages: ', paste(still_missing, collapse = ', '),
         '. Re-run with install_missing = TRUE.', call. = FALSE)
  }

  # ragg is preferred because it reliably writes an RGBA PNG with a true alpha
  # channel on Windows/Positron. It remains optional because the shared save
  # helper also supports the platform PNG device and a targeted alpha repair.
  optional_missing <- setdiff(.public_viz_optional_pkgs, rownames(utils::installed.packages()))
  if (length(optional_missing) && isTRUE(install_missing)) {
    for (pkg in optional_missing) {
      tryCatch(
        utils::install.packages(pkg, dependencies = c('Depends', 'Imports', 'LinkingTo'), quiet = TRUE,
                                type = getOption('pkgType', 'binary')),
        error = function(e) warning('Could not install optional visualization package ', pkg, ': ', conditionMessage(e), call. = FALSE)
      )
    }
  }

  invisible(lapply(.public_viz_pkgs, function(pkg) suppressWarnings(suppressPackageStartupMessages(require(pkg, character.only = TRUE)))))
}

# Source project utilities after packages are available.
.project_root <- .local_project_root()
source(file.path(.project_root, 'R', '00_setup.R'))
source(file.path(project_root(), 'R', '01_lwda_crosswalk.R'))
source(file.path(project_root(), 'R', '02_data_download.R'))
source(file.path(project_root(), 'R', '10_iowa_report_style.R'))

# ---- Helpers ---------------------------------------------------------------
w_mean <- function(x, w) {
  x <- suppressWarnings(as.numeric(x))
  w <- suppressWarnings(as.numeric(w))
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  stats::weighted.mean(x[ok], w[ok])
}


as_fips5 <- function(x) {
  x <- as.character(x)
  x <- readr::parse_number(x)
  stringr::str_pad(as.integer(x), 5, pad = '0')
}

score01 <- function(x, label = 'score') {
  x <- suppressWarnings(as.numeric(x))
  bad <- is.finite(x) & (x < -1e-9 | x > 1 + 1e-9)
  if (any(bad)) {
    stop(label, ' must be stored explicitly as a proportion in [0,1]; found ', sum(bad),
         ' out-of-range values. The visualization layer no longer guesses score units.', call. = FALSE)
  }
  x
}

range_pad01 <- function(x, pad = 0.08, fallback = c(0, 1)) {
  x <- x[is.finite(x)]
  if (!length(x)) return(fallback)
  rng <- range(x, na.rm = TRUE)
  if (!is.finite(rng[1]) || !is.finite(rng[2])) return(fallback)
  if (abs(diff(rng)) < 1e-6) rng <- rng + c(-0.02, 0.02)
  d <- diff(rng) * pad
  c(max(0, rng[1] - d), min(1, rng[2] + d))
}

repair_occ_titles <- function(df, onet_tasks = tibble::tibble()) {
  if (!nrow(df) || !'soc_code' %in% names(df)) return(df)
  if (!'occupation_title' %in% names(df)) df$occupation_title <- NA_character_
  bad <- is.na(df$occupation_title) | stringr::str_squish(stringr::str_to_lower(df$occupation_title)) %in% c('', 'iowa', 'united states', 'na')
  if (any(bad) && nrow(onet_tasks) && all(c('soc_code', 'onet_title') %in% names(onet_tasks))) {
    lookup <- onet_tasks |>
      dplyr::filter(!is.na(onet_title), onet_title != '') |>
      dplyr::distinct(soc_code, occupation_title_onet = onet_title)
    df <- df |>
      dplyr::left_join(lookup, by = 'soc_code') |>
      dplyr::mutate(
        occupation_title = dplyr::if_else(
          is.na(occupation_title) | stringr::str_squish(stringr::str_to_lower(occupation_title)) %in% c('', 'iowa', 'united states', 'na'),
          occupation_title_onet,
          occupation_title
        )
      ) |>
      dplyr::select(-occupation_title_onet)
  }
  df |>
    dplyr::mutate(occupation_title = dplyr::coalesce(occupation_title, soc_code))
}

standardize_viz_table <- function(df, onet_tasks = tibble::tibble()) {
  if (!nrow(df)) return(df)
  score_cols <- c('automation_exposure', 'augmentation_potential', 'expertise_leveling_potential',
                  'new_task_opportunity', 'new_task_opportunity_local', 'pro_worker_opportunity',
                  'pro_worker_opportunity_local', 'transition_pressure', 'physical_ai_exposure',
                  'task_reallocation_potential', 'actionable_share',
                  'protective_redesign_share', 'upgrade_training_share', 'scale_opportunity_share')
  if ('county_fips' %in% names(df)) df <- df |> dplyr::mutate(county_fips = as_fips5(county_fips))
  if ('soc_code' %in% names(df)) df <- df |> dplyr::mutate(soc_code = clean_soc(soc_code))
  for (nm in intersect(score_cols, names(df))) df[[nm]] <- score01(df[[nm]], nm)
  for (nm in intersect(c('risk_opportunity_gap', 'risk_minus_opportunity'), names(df))) df[[nm]] <- suppressWarnings(as.numeric(df[[nm]]))
  df <- repair_occ_titles(df, onet_tasks)
  if ('hourly_mean' %in% names(df) && 'annual_mean' %in% names(df)) {
    df <- df |> dplyr::mutate(hourly_mean = dplyr::if_else(is.na(hourly_mean) & !is.na(annual_mean), annual_mean / 2080, hourly_mean))
  }
  df
}

palette_for_actions <- function(vals) {
  vals <- unique(stats::na.omit(as.character(vals)))
  extra <- setdiff(vals, names(transition_palette))
  if (length(extra)) {
    add <- setNames(rep('#7f7f7f', length(extra)), extra)
    c(transition_palette, add)
  } else transition_palette
}

weighted_mode <- function(x, w) {
  ok <- !is.na(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_character_)
  tab <- tapply(w[ok], as.character(x[ok]), sum, na.rm = TRUE)
  names(tab)[which.max(tab)]
}

fmt_jobs <- function(x) {
  dplyr::case_when(
    is.na(x) ~ '',
    abs(x) >= 1e6 ~ paste0(scales::number(x / 1e6, accuracy = 0.1), 'M'),
    abs(x) >= 1e3 ~ paste0(scales::number(x / 1e3, accuracy = 0.1), 'K'),
    TRUE ~ scales::number(x, accuracy = 1)
  )
}

wrap_label <- function(x, width = 22) stringr::str_wrap(as.character(x), width = width)

safe_read_csv <- function(path) {
  if (!file.exists(path)) return(tibble::tibble())
  readr::read_csv(path, show_col_types = FALSE)
}

safe_read_parquet2 <- function(path) {
  if (is.null(path) || !nzchar(path)) return(tibble::tibble())
  base_name <- tools::file_path_sans_ext(basename(path))
  dir <- dirname(path)
  if (!compat_table_exists(base_name, dir)) return(tibble::tibble())
  read_compat_table(base_name, dir) |> dplyr::as_tibble()
}

metric_label <- function(x) {
  dplyr::recode(
    x,
    automation_exposure = 'Automation exposure',
    augmentation_potential = 'Augmentation potential',
    expertise_leveling_potential = 'Expertise-leveling potential',
    new_task_opportunity = 'New-task opportunity',
    pro_worker_opportunity = 'Pro-worker opportunity',
    risk_opportunity_gap = 'Risk minus opportunity',
    .default = stringr::str_to_title(stringr::str_replace_all(x, '_', ' '))
  )
}

transition_palette <- atlas_transition_palette()

channel_palette <- atlas_channel_palette()

plot_theme_public <- function(base_size = 10) {
  atlas_base_theme(base_size = base_size, strip_titles = TRUE)
}

save_public_plot <- function(plot, filename, width = 12, height = 8, dpi = 320) {
  p <- paths()
  out_dir <- file.path(p$figures, 'public')
  fs::dir_create(out_dir)
  out <- file.path(out_dir, filename)

  # Figure 01 previously rendered as a three-channel RGB PNG with a white
  # canvas even though ggsave(bg = 'transparent') was requested. The shared
  # device helper now prefers ragg/the platform PNG device and performs a targeted alpha repair
  # plus validation for Figure 01, so the saved file is verifiably transparent.
  force_alpha <- identical(filename, 'public_01_county_bivariate_risk_opportunity.png')
  atlas_save_transparent_png(
    plot = plot,
    filename = out,
    width = width,
    height = height,
    dpi = dpi,
    force_alpha_repair = force_alpha
  )
  out
}

write_public_visualization_gallery <- function(results) {
  p <- paths()
  fs::dir_create(p$outputs)
  created <- results |> dplyr::filter(status == 'created', !is.na(filename))
  cards <- purrr::pmap_chr(created, function(id, filename, status, path, audience, question, ...) {
    rel <- file.path('..', 'figures', 'public', filename)
    id_num <- suppressWarnings(as.integer(id))
    id_label <- ifelse(is.na(id_num), as.character(id), as.character(id_num))
    paste0(
      '<section class="card">',
      '<div class="figure-title">Figure ', id_label, '. ', htmltools::htmlEscape(question), '</div>',
      '<p class="figure-note"><strong>Primary audience:</strong> ', htmltools::htmlEscape(audience), '</p>',
      '<img src="', rel, '" alt="', htmltools::htmlEscape(question), '">', '<p class="figure-note">Source: Iowa AI Workforce Atlas public visualization output.</p>',
      '</section>'
    )
  })
  html <- c(
    '<!doctype html><html><head><meta charset="utf-8">',
    '<title>Iowa AI Workforce Atlas public visualization gallery</title>',
    '<style>body{font-family:Arial,Helvetica,sans-serif;margin:28px;line-height:1.15;color:#000;font-size:12pt;text-align:justify}h1{font-family:Arial,Helvetica,sans-serif;font-size:18pt;font-weight:700;color:rgb(28,93,186);text-align:left;margin:0 0 6pt}h2{font-family:Arial,Helvetica,sans-serif;font-size:16pt;font-weight:400;color:rgb(0,128,141);text-align:left}.lead{font-size:12pt;margin:0 0 6pt;max-width:980px}.grid{display:grid;grid-template-columns:1fr;gap:26px}.card{border:1px solid #ddd;border-radius:12px;padding:18px;background:transparent}.figure-title{font-family:Arial,Helvetica,sans-serif;font-size:12pt;font-weight:700;color:#000;text-align:center;margin:10pt auto 6pt}.figure-note{font-family:Arial,Helvetica,sans-serif;font-size:10pt;font-weight:400;color:#000;text-align:left;margin:4pt 0 8pt}.card img{max-width:100%;height:auto;border:1px solid #eee;background:transparent}code{background:#f5f5f5;padding:2px 4px;border-radius:4px}</style>',
    '</head><body>',
    '<h1>Iowa AI Workforce Atlas: public visualization gallery</h1>',
    '<p class="lead">Static R-generated graphics for public briefings, workforce boards, community colleges, policymakers, and economic developers. Each figure is also saved as a standalone PNG under <code>figures/public/</code>.</p>',
    '<div class="grid">', cards, '</div>',
    '</body></html>'
  )
  out <- file.path(p$outputs, 'public_visualization_gallery.html')
  writeLines(html, out, useBytes = TRUE)
  out
}

get_public_viz_data <- function(build_if_missing = TRUE, refresh = FALSE) {
  p <- paths()
  atlas_path <- file.path(p$processed, 'county_industry_occupation_atlas.parquet')
  if (!compat_table_exists('county_industry_occupation_atlas', p$processed) && isTRUE(build_if_missing)) {
    message('Processed atlas not found; building atlas first.')
    source(file.path(p$R, '04_build_atlas.R'))
    build_atlas(refresh = refresh, install_optional = FALSE)
  }
  atlas <- read_compat_table('county_industry_occupation_atlas', p$processed)
  if (!nrow(atlas)) stop('Missing county_industry_occupation_atlas in Parquet/RDS/CSV.GZ form. Run Rscript run_all.R first.', call. = FALSE)

  county <- safe_read_csv(file.path(p$processed, 'county_summary.csv'))
  lwda <- safe_read_csv(file.path(p$processed, 'lwda_summary.csv'))
  sector <- safe_read_csv(file.path(p$processed, 'sector_lwda_summary.csv'))
  training <- safe_read_csv(file.path(p$processed, 'training_priority_occupations.csv'))
  flows <- safe_read_csv(file.path(p$processed, 'lwda_commuting_flows.csv'))
  occ_scores <- safe_read_csv(file.path(p$processed, 'occupation_ai_scores.csv'))
  acs <- safe_read_csv(file.path(p$processed, 'acs_county_demographics.csv'))
  training_capacity <- safe_read_csv(file.path(p$processed, 'training_capacity_index_v2.csv'))

  if (nrow(training_capacity) && nrow(county) && 'county_fips' %in% names(training_capacity) && 'county_fips' %in% names(county)) {
    training_capacity <- training_capacity |>
      dplyr::mutate(county_fips = as_fips5(county_fips)) |>
      dplyr::distinct(county_fips, .keep_all = TRUE)
    county <- county |> dplyr::mutate(county_fips = as_fips5(county_fips))
    add_cols <- setdiff(names(training_capacity), names(county))
    if (length(add_cols)) county <- county |> dplyr::left_join(training_capacity |> dplyr::select(county_fips, dplyr::all_of(add_cols)), by = 'county_fips')
  }

  # Bring ACS county training-capacity and income context into the public
  # visualization layer when the ACS step succeeded. Older county_summary.csv
  # files did not include these columns, which caused figure 11 to skip.
  if (nrow(acs) && nrow(county) && 'county_fips' %in% names(acs) && 'county_fips' %in% names(county)) {
    acs <- acs |>
      dplyr::mutate(county_fips = as_fips5(county_fips)) |>
      dplyr::select(county_fips, dplyr::any_of(c('population', 'median_household_income', 'share_bachelors_plus'))) |>
      dplyr::distinct(county_fips, .keep_all = TRUE)
    county <- county |> dplyr::mutate(county_fips = as_fips5(county_fips))
    acs_join_cols <- setdiff(names(acs), names(county))
    if (length(acs_join_cols)) {
      county <- county |>
        dplyr::left_join(acs |> dplyr::select(county_fips, dplyr::all_of(acs_join_cols)), by = 'county_fips')
    }
  }

  if (!nrow(training)) {
    training <- atlas |>
      dplyr::filter(transition_priority %in% c('Upgrade through AI-complementary training', 'Scale pro-worker AI opportunity')) |>
      dplyr::group_by(lwda_combined, iowa_priority_sector, soc_code, occupation_title, transition_priority) |>
      dplyr::summarise(
        automation_exposure = w_mean(automation_exposure, estimated_jobs),
        augmentation_potential = w_mean(augmentation_potential, estimated_jobs),
        expertise_leveling_potential = w_mean(expertise_leveling_potential, estimated_jobs),
        new_task_opportunity = w_mean(new_task_opportunity_local, estimated_jobs),
        pro_worker_opportunity = w_mean(pro_worker_opportunity_local, estimated_jobs),
        estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
        .groups = 'drop'
      )
  }

  cfg <- load_config()
  gpkg <- file.path(p$processed, 'iowa_county_shapes.gpkg')
  shapes <- tryCatch({
    if (file.exists(gpkg)) sf::read_sf(gpkg, quiet = TRUE) else get_county_shapes(cfg, refresh = FALSE)
  }, error = function(e) NULL)
  if (!is.null(shapes) && 'county_fips' %in% names(shapes)) {
    shapes <- shapes |> dplyr::mutate(county_fips = as_fips5(county_fips))
  }

  onet_tasks <- safe_read_csv(file.path(p$processed, 'onet_tasks.csv'))
  atlas <- standardize_viz_table(atlas, onet_tasks)
  county <- standardize_viz_table(county, onet_tasks)
  lwda <- standardize_viz_table(lwda, onet_tasks)
  sector <- standardize_viz_table(sector, onet_tasks)
  training <- standardize_viz_table(training, onet_tasks)
  flows <- standardize_viz_table(flows, onet_tasks)
  occ_scores <- standardize_viz_table(occ_scores, onet_tasks)

  # Repair local opportunity columns if the atlas predates those names.
  if (nrow(atlas) && !'pro_worker_opportunity_local' %in% names(atlas) && 'pro_worker_opportunity' %in% names(atlas)) atlas$pro_worker_opportunity_local <- atlas$pro_worker_opportunity
  if (nrow(atlas) && !'new_task_opportunity_local' %in% names(atlas) && 'new_task_opportunity' %in% names(atlas)) atlas$new_task_opportunity_local <- atlas$new_task_opportunity

  # Remove summary SOC rows and unscored rows. This lets the public visualizations
  # work even if they are run against outputs created before the detailed-SOC NEM fix.
  if (nrow(atlas)) {
    atlas <- atlas |>
      dplyr::filter(
        estimated_jobs > 0,
        stringr::str_detect(soc_code, '^\\d{2}-\\d{4}$'),
        is.finite(automation_exposure),
        is.finite(pro_worker_opportunity_local)
      ) |>
      dplyr::mutate(transition_priority = dplyr::coalesce(transition_priority, 'Monitor'))
  }
  if (nrow(training)) {
    training <- training |>
      dplyr::filter(
        estimated_jobs > 0,
        stringr::str_detect(soc_code, '^\\d{2}-\\d{4}$'),
        is.finite(pro_worker_opportunity)
      )
  }

  list(atlas = atlas, county = county, lwda = lwda, sector = sector, training = training, flows = flows, shapes = shapes, occ_scores = occ_scores)
}

# ---- Bivariate map utilities ----------------------------------------------
bi_class <- function(x, y, dim = 3) {
  x_class <- dplyr::ntile(x, dim)
  y_class <- dplyr::ntile(y, dim)
  out <- paste(x_class, y_class, sep = '-')
  out[is.na(x) | is.na(y)] <- NA_character_
  out
}

bi_palette_3x3 <- c(
  '1-1' = '#F2F2F2', '2-1' = '#D7E6FA', '3-1' = atlas_brand()$blue,
  '1-2' = '#F4E7B8', '2-2' = atlas_brand()$green, '3-2' = atlas_brand()$teal,
  '1-3' = atlas_brand()$gold, '2-3' = '#C16A38', '3-3' = atlas_brand()$red
)

make_bi_legend <- function(xlab = 'Higher automation exposure', ylab = 'Higher pro-worker opportunity') {
  legend_df <- tidyr::expand_grid(x = 1:3, y = 1:3) |>
    dplyr::mutate(bi_class = paste(x, y, sep = '-'))
  ggplot2::ggplot(legend_df, ggplot2::aes(x = x, y = y, fill = bi_class)) +
    ggplot2::geom_tile(color = 'white', linewidth = 0.25) +
    ggplot2::scale_fill_manual(values = bi_palette_3x3, guide = 'none') +
    ggplot2::scale_x_continuous(breaks = NULL, expand = c(0, 0)) +
    ggplot2::scale_y_continuous(breaks = NULL, expand = c(0, 0)) +
    ggplot2::labs(x = xlab, y = ylab, title = NULL, subtitle = NULL, caption = NULL) +
    ggplot2::coord_equal() +
    atlas_void_theme(base_size = 9, strip_titles = TRUE) +
    ggplot2::theme(
      axis.title.x = ggplot2::element_text(size = 8, margin = ggplot2::margin(t = 4), family = atlas_font_family(), color = atlas_brand()$black),
      axis.title.y = ggplot2::element_text(size = 8, angle = 90, margin = ggplot2::margin(r = 4), family = atlas_font_family(), color = atlas_brand()$black),
      plot.background = ggplot2::element_rect(fill = 'transparent', colour = NA),
      panel.background = ggplot2::element_rect(fill = 'transparent', colour = NA)
    )
}

# ---- Individual visualization functions -----------------------------------
plot_01_county_bivariate_risk_opportunity <- function(data) {
  if (is.null(data$shapes) || !nrow(data$county)) return(NULL)
  mapdat <- data$shapes |>
    dplyr::left_join(data$county, by = 'county_fips') |>
    dplyr::mutate(bi_class = bi_class(automation_exposure, pro_worker_opportunity, dim = 3))

  # Build LWDA outlines using sf's own grouped summarise. Do not refer to a
  # literal column named geometry here: depending on sf/read_sf versions the
  # active geometry column may not be available in dplyr's data mask.
  lwda_outline <- tryCatch({
    mapdat |>
      dplyr::filter(!is.na(lwda_combined)) |>
      dplyr::select(lwda_combined) |>
      dplyr::group_by(lwda_combined) |>
      dplyr::summarise(.groups = 'drop')
  }, error = function(e) NULL)

  p_map <- ggplot2::ggplot() +
    ggplot2::geom_sf(data = mapdat, ggplot2::aes(fill = bi_class), color = 'white', linewidth = 0.18) +
    (if (!is.null(lwda_outline) && nrow(lwda_outline)) ggplot2::geom_sf(data = lwda_outline, fill = NA, color = 'grey15', linewidth = 0.55) else NULL) +
    ggplot2::scale_fill_manual(values = bi_palette_3x3, na.value = 'grey90', guide = 'none') +
    ggplot2::labs(title = NULL, subtitle = NULL, caption = NULL) +
    atlas_void_theme(base_size = 11, strip_titles = TRUE) +
    ggplot2::theme(
      plot.margin = ggplot2::margin(8, 8, 8, 8),
      plot.background = ggplot2::element_rect(fill = 'transparent', colour = NA),
      panel.background = ggplot2::element_rect(fill = 'transparent', colour = NA)
    )

  # Both component plots already use transparent plot and panel backgrounds.
  # Returning the patchwork directly avoids an incompatibility in older Windows/
  # R 4.4 patchwork builds that warns that `annotation$theme` is not a valid
  # theme. The PNG export helper still verifies and, if necessary, repairs the
  # alpha channel for Figure 01.
  p_map + make_bi_legend() + patchwork::plot_layout(widths = c(5.5, 1.1))
}

plot_02_county_dominant_transition_action <- function(data) {
  if (is.null(data$shapes) || !nrow(data$county)) return(NULL)
  if ('largest_non_monitor_action' %in% names(data$county)) {
    county_action <- data$county |>
      dplyr::transmute(
        county_fips,
        county_name,
        transition_priority = dplyr::coalesce(largest_non_monitor_action, 'Monitor'),
        action_share = dplyr::coalesce(largest_non_monitor_share, actionable_share, 0)
      )
    title <- 'Largest non-Monitor AI workforce action by county'
    subtitle <- 'This view preserves actionable minorities even when Monitor remains the largest overall category.'
    legend_title <- 'Largest active response'
    caption <- 'The action is selected after excluding Monitor; counties with no active category remain Monitor.'
  } else {
    county_action <- data$county |>
      dplyr::mutate(
        Monitor = pmax(0, 1 - dplyr::coalesce(protective_redesign_share, 0) -
                         dplyr::coalesce(upgrade_training_share, 0) - dplyr::coalesce(scale_opportunity_share, 0))
      ) |>
      tidyr::pivot_longer(
        c(protective_redesign_share, upgrade_training_share, scale_opportunity_share, Monitor),
        names_to = 'action_raw', values_to = 'share'
      ) |>
      dplyr::mutate(
        transition_priority = dplyr::recode(
          action_raw,
          protective_redesign_share = 'Protect and redesign',
          upgrade_training_share = 'Upgrade through AI-complementary training',
          scale_opportunity_share = 'Scale pro-worker AI opportunity',
          Monitor = 'Monitor'
        )
      ) |>
      dplyr::group_by(county_fips, county_name) |>
      dplyr::slice_max(share, n = 1, with_ties = FALSE) |>
      dplyr::ungroup()
    title <- 'Dominant AI workforce action by county'
    subtitle <- 'Legacy fallback used because methodology-v2 county profiles were not found.'
    legend_title <- 'Dominant action'
    caption <- 'Run apply_methodology_v2() to publish the largest non-Monitor action and threshold sensitivity.'
  }

  mapdat <- data$shapes |> dplyr::left_join(county_action, by = 'county_fips')
  ggplot2::ggplot(mapdat) +
    ggplot2::geom_sf(ggplot2::aes(fill = transition_priority), color = 'white', linewidth = 0.18) +
    ggplot2::scale_fill_manual(values = transition_palette, na.value = 'grey90') +
    ggplot2::labs(title = title, subtitle = subtitle, fill = legend_title, caption = caption) +
    atlas_void_theme(base_size = 11, strip_titles = FALSE) +
    ggplot2::theme(legend.position = 'right')
}

plot_03_lwda_ai_compass <- function(data) {
  if (!nrow(data$lwda)) return(NULL)
  metrics <- c('automation_exposure', 'augmentation_potential', 'expertise_leveling_potential', 'new_task_opportunity', 'pro_worker_opportunity')
  lwda_long <- data$lwda |>
    tidyr::pivot_longer(dplyr::all_of(metrics), names_to = 'metric', values_to = 'score') |>
    dplyr::mutate(metric_label = factor(metric_label(metric), levels = metric_label(metrics)))

  ggplot2::ggplot(lwda_long, ggplot2::aes(x = metric_label, y = score, fill = metric_label)) +
    ggplot2::geom_col(width = 0.92, color = 'white', linewidth = 0.25, alpha = 0.95) +
    ggplot2::coord_polar(start = -pi / 5) +
    ggplot2::facet_wrap(~lwda_combined, ncol = 3) +
    ggplot2::scale_fill_manual(values = channel_palette, guide = 'none') +
    ggplot2::scale_y_continuous(limits = c(0, 1), labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::labs(
      title = 'AI transition compass by combined LWDA',
      subtitle = 'Each petal shows an employment-weighted channel score. Higher pro-worker petals indicate better opportunity for AI-complementary training and new-task creation.',
      x = NULL, y = NULL,
      caption = 'Use this as the public-facing “at a glance” dashboard for workforce boards and local leaders.'
    ) +
    plot_theme_public(base_size = 10) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(size = 7), panel.grid.minor = ggplot2::element_blank())
}

plot_04_lwda_sector_bubble_heatmap <- function(data) {
  if (!nrow(data$sector)) return(NULL)
  x <- data$sector |>
    dplyr::group_by(lwda_combined, iowa_priority_sector) |>
    dplyr::summarise(
      automation_exposure = w_mean(automation_exposure, estimated_jobs),
      pro_worker_opportunity = w_mean(pro_worker_opportunity, estimated_jobs),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::mutate(risk_opportunity_gap = automation_exposure - pro_worker_opportunity) |>
    dplyr::mutate(
      sector_wrapped = forcats::fct_reorder(wrap_label(iowa_priority_sector, 18), estimated_jobs, .fun = sum, .desc = TRUE),
      lwda_combined = forcats::fct_reorder(lwda_combined, risk_opportunity_gap, .fun = w_mean, w = estimated_jobs)
    )

  ggplot2::ggplot(x, ggplot2::aes(x = sector_wrapped, y = lwda_combined)) +
    ggplot2::geom_tile(fill = 'grey96', color = 'white') +
    ggplot2::geom_point(ggplot2::aes(size = estimated_jobs, fill = risk_opportunity_gap), shape = 21, color = 'grey25', alpha = 0.92) +
    ggplot2::scale_size_area(max_size = 15, labels = fmt_jobs) +
    ggplot2::scale_fill_gradient2(
      low = atlas_brand()$blue, mid = 'white', high = atlas_brand()$red, midpoint = 0,
      labels = atlas_axis_percent(accuracy = 1)
    ) +
    ggplot2::labs(
      title = 'Where jobs are concentrated and where AI transition risk is highest',
      subtitle = 'Bubble area shows estimated jobs. Fill shows automation exposure minus pro-worker opportunity.',
      x = NULL, y = NULL, size = 'Estimated jobs', fill = 'Risk gap',
      caption = 'Economic developers can use this to target sector partnerships within each LWDA.'
    ) +
    plot_theme_public(base_size = 11) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 40, hjust = 1))
}

plot_05_sector_policy_quadrant <- function(data) {
  if (!nrow(data$sector)) return(NULL)
  x <- data$sector |>
    dplyr::group_by(iowa_priority_sector) |>
    dplyr::summarise(
      automation_exposure = w_mean(automation_exposure, estimated_jobs),
      pro_worker_opportunity = w_mean(pro_worker_opportunity, estimated_jobs),
      new_task_opportunity = w_mean(new_task_opportunity, estimated_jobs),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::filter(estimated_jobs > 0, is.finite(automation_exposure), is.finite(pro_worker_opportunity))
  if (!nrow(x)) return(NULL)
  vline <- w_mean(x$automation_exposure, x$estimated_jobs)
  hline <- w_mean(x$pro_worker_opportunity, x$estimated_jobs)
  if (!is.finite(vline)) vline <- stats::median(x$automation_exposure, na.rm = TRUE)
  if (!is.finite(hline)) hline <- stats::median(x$pro_worker_opportunity, na.rm = TRUE)

  # Place quadrant annotations at the geometric center of each relevant
  # quadrant. Fixed +/- offsets can exceed the [0, 1] score scales when the
  # statewide threshold is near an edge, causing geom_text() rows to be dropped.
  x_left <- pmin(0.94, pmax(0.06, vline / 2))
  x_right <- pmin(0.94, pmax(0.06, vline + (1 - vline) / 2))
  y_low <- pmin(0.94, pmax(0.06, hline / 2))
  y_high <- pmin(0.94, pmax(0.06, hline + (1 - hline) / 2))

  ggplot2::ggplot(x, ggplot2::aes(x = automation_exposure, y = pro_worker_opportunity)) +
    ggplot2::annotate('rect', xmin = -Inf, xmax = vline, ymin = hline, ymax = Inf, alpha = 0.08, fill = atlas_brand()$blue) +
    ggplot2::annotate('rect', xmin = vline, xmax = Inf, ymin = hline, ymax = Inf, alpha = 0.08, fill = atlas_brand()$gold) +
    ggplot2::annotate('rect', xmin = vline, xmax = Inf, ymin = -Inf, ymax = hline, alpha = 0.08, fill = atlas_brand()$red) +
    ggplot2::annotate('rect', xmin = -Inf, xmax = vline, ymin = -Inf, ymax = hline, alpha = 0.05, fill = 'grey50') +
    ggplot2::geom_vline(xintercept = vline, linetype = 'dashed', color = 'grey35') +
    ggplot2::geom_hline(yintercept = hline, linetype = 'dashed', color = 'grey35') +
    ggplot2::geom_point(ggplot2::aes(size = estimated_jobs, fill = new_task_opportunity), shape = 21, color = 'grey20', alpha = 0.9) +
    ggrepel::geom_text_repel(na.rm = TRUE, ggplot2::aes(label = iowa_priority_sector), size = 3.3, seed = 7, max.overlaps = Inf, family = atlas_font_family(), color = atlas_brand()$black) +
    ggplot2::annotate('text', x = x_right, y = y_low, label = 'Protect and redesign', color = atlas_brand()$black, family = atlas_font_family(), fontface = 'plain', size = 3.5, na.rm = TRUE) +
    ggplot2::annotate('text', x = x_right, y = y_high, label = 'Upgrade with AI training', color = atlas_brand()$black, family = atlas_font_family(), fontface = 'plain', size = 3.5, na.rm = TRUE) +
    ggplot2::annotate('text', x = x_left, y = y_high, label = 'Scale pro-worker AI', color = atlas_brand()$black, family = atlas_font_family(), fontface = 'plain', size = 3.5, na.rm = TRUE) +
    ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
    ggplot2::scale_y_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
    ggplot2::scale_size_area(max_size = 18, labels = fmt_jobs) +
    atlas_color_scale_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::labs(
      title = 'Iowa sector AI policy quadrant',
      subtitle = 'The most actionable view for economic development: where exposure is high, where opportunity is high, and how many jobs are in play.',
      x = 'Automation exposure', y = 'Pro-worker opportunity', size = 'Estimated jobs', fill = 'New-task opportunity',
      caption = 'Dashed lines are employment-weighted statewide averages.'
    ) +
    plot_theme_public(base_size = 11)
}

plot_06_occupation_wage_risk_bubble <- function(data, top_n = 60) {
  x <- data$atlas |>
    dplyr::group_by(soc_code, occupation_title) |>
    dplyr::summarise(
      hourly_mean = w_mean(hourly_mean, estimated_jobs),
      automation_exposure = w_mean(automation_exposure, estimated_jobs),
      pro_worker_opportunity = w_mean(pro_worker_opportunity_local, estimated_jobs),
      transition_priority = weighted_mode(transition_priority, estimated_jobs),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::mutate(risk_opportunity_gap = automation_exposure - pro_worker_opportunity) |>
    dplyr::filter(is.finite(hourly_mean), is.finite(risk_opportunity_gap), estimated_jobs > 0) |>
    dplyr::slice_max(estimated_jobs, n = top_n, with_ties = FALSE)

  lab <- x |>
    dplyr::mutate(label_score = estimated_jobs * abs(risk_opportunity_gap)) |>
    dplyr::slice_max(label_score, n = 18, with_ties = FALSE)

  ggplot2::ggplot(x, ggplot2::aes(x = hourly_mean, y = risk_opportunity_gap)) +
    ggplot2::geom_hline(yintercept = 0, color = 'grey35') +
    ggplot2::geom_point(ggplot2::aes(size = estimated_jobs, fill = transition_priority), shape = 21, color = 'grey20', alpha = 0.9) +
    ggrepel::geom_text_repel(na.rm = TRUE, data = lab, ggplot2::aes(label = occupation_title), size = 3, seed = 9, max.overlaps = Inf, family = atlas_font_family(), color = atlas_brand()$black) +
    ggplot2::scale_x_continuous(labels = scales::dollar_format(accuracy = 1)) +
    ggplot2::scale_y_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::scale_size_area(max_size = 17, labels = fmt_jobs) +
    ggplot2::scale_fill_manual(values = palette_for_actions(x$transition_priority), na.value = 'grey70') +
    ggplot2::labs(
      title = 'Which large occupations combine wage value, AI risk, and training opportunity?',
      subtitle = 'Above zero: automation exposure exceeds pro-worker opportunity. Below zero: opportunity is stronger than exposure.',
      x = 'Mean hourly wage', y = 'Risk minus opportunity', size = 'Estimated jobs', fill = 'Dominant transition action',
      caption = 'This view helps identify occupations where training dollars protect household income and employer competitiveness.'
    ) +
    plot_theme_public(base_size = 11)
}

plot_07_training_pipeline_alluvial <- function(data) {
  if (!nrow(data$atlas)) return(NULL)
  x <- data$atlas |>
    dplyr::mutate(
      sector_lumped = forcats::fct_lump_n(iowa_priority_sector, n = 8, w = estimated_jobs, other_level = 'Other sectors') |>
        as.character(),
      lwda_label = stringr::str_replace(lwda_combined, ' Iowa LWDA', '')
    ) |>
    dplyr::group_by(lwda_label, sector_lumped, transition_priority) |>
    dplyr::summarise(estimated_jobs = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop') |>
    dplyr::filter(estimated_jobs > 0) |>
    dplyr::group_by(lwda_label) |>
    dplyr::mutate(lwda_jobs = sum(estimated_jobs, na.rm = TRUE)) |>
    dplyr::ungroup() |>
    dplyr::filter(lwda_jobs > 0)

  ggplot2::ggplot(x, ggplot2::aes(y = estimated_jobs, axis1 = lwda_label, axis2 = sector_lumped, axis3 = transition_priority)) +
    ggalluvial::geom_alluvium(ggplot2::aes(fill = transition_priority), alpha = 0.75, width = 0.12) +
    ggalluvial::geom_stratum(width = 0.16, fill = 'grey94', color = 'grey35') +
    ggalluvial::stat_stratum(
      mapping = ggplot2::aes(label = ggplot2::after_stat(stratum)),
      geom = 'text', size = 2.6, color = atlas_brand()$black,
      family = atlas_font_family(), na.rm = TRUE
    ) +
    ggplot2::scale_x_discrete(limits = c('Combined LWDA', 'Priority sector', 'Transition action'), expand = c(0.08, 0.08)) +
    ggplot2::scale_y_continuous(labels = fmt_jobs) +
    ggplot2::scale_fill_manual(values = palette_for_actions(x$transition_priority), na.value = 'grey70') +
    ggplot2::labs(
      title = 'Training and transition pipeline: from place to sector to action',
      subtitle = 'Widths represent estimated jobs. This is a static R alluvial graphic that works well in public reports and slide decks.',
      x = NULL, y = 'Estimated jobs', fill = 'Transition action',
      caption = 'Use this with community college partners to discuss sector-specific training capacity by region.'
    ) +
    plot_theme_public(base_size = 11) +
    ggplot2::theme(panel.grid = ggplot2::element_blank())
}

plot_08_training_priority_treemap <- function(data) {
  if (!nrow(data$training)) return(NULL)
  x <- data$training |>
    dplyr::mutate(priority_score = estimated_jobs * dplyr::coalesce(pro_worker_opportunity, 0)) |>
    dplyr::group_by(lwda_combined) |>
    dplyr::slice_max(priority_score, n = 8, with_ties = FALSE) |>
    dplyr::ungroup() |>
    dplyr::mutate(
      occ_label = paste0(wrap_label(occupation_title, 24), '\n', fmt_jobs(estimated_jobs), ' jobs'),
      lwda_short = stringr::str_replace(lwda_combined, ' Iowa LWDA', '')
    )

  ggplot2::ggplot(x, ggplot2::aes(area = pmax(priority_score, 1), fill = transition_priority, label = occ_label, subgroup = lwda_short)) +
    treemapify::geom_treemap(colour = 'white', size = 0.7) +
    treemapify::geom_treemap_subgroup_border(colour = 'grey20', size = 1.0) +
    treemapify::geom_treemap_subgroup_text(place = 'centre', grow = FALSE, alpha = 0.85, color = atlas_brand()$black, fontface = 'plain', family = atlas_font_family()) +
    treemapify::geom_treemap_text(color = 'white', place = 'centre', grow = FALSE, reflow = TRUE, min.size = 2.5) +
    ggplot2::scale_fill_manual(values = palette_for_actions(x$transition_priority), na.value = 'grey70') +
    ggplot2::labs(
      title = 'Regional training portfolio: highest-value occupations to upgrade or scale',
      subtitle = 'Tile area = estimated jobs × pro-worker opportunity. The plot highlights where training can turn exposure into local advantage.',
      fill = 'Transition action',
      caption = 'This is best used as a one-page handout for workforce boards, community colleges, chambers, and sector partnerships.'
    ) +
    plot_theme_public(base_size = 11) +
    ggplot2::theme(axis.text = ggplot2::element_blank(), axis.title = ggplot2::element_blank(), panel.grid = ggplot2::element_blank())
}

plot_09_risk_distribution_ridges <- function(data) {
  if (!nrow(data$atlas)) return(NULL)
  x <- data$atlas |>
    dplyr::mutate(
      risk_gap = automation_exposure - pro_worker_opportunity_local,
      lwda_short = stringr::str_replace(lwda_combined, ' Iowa LWDA', '')
    ) |>
    dplyr::filter(is.finite(risk_gap), estimated_jobs > 0) |>
    dplyr::group_by(lwda_short) |>
    dplyr::mutate(lwda_gap = w_mean(risk_gap, estimated_jobs)) |>
    dplyr::ungroup() |>
    dplyr::mutate(lwda_short = forcats::fct_reorder(lwda_short, lwda_gap))

  ggplot2::ggplot(x, ggplot2::aes(x = risk_gap, y = lwda_short, weight = estimated_jobs, fill = ggplot2::after_stat(x))) +
    ggridges::geom_density_ridges_gradient(scale = 2.2, rel_min_height = 0.01, color = 'white', linewidth = 0.25) +
    ggplot2::geom_vline(xintercept = 0, linetype = 'dashed', color = 'grey25') +
    ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::scale_fill_gradient2(low = atlas_brand()$blue, mid = 'white', high = atlas_brand()$red, midpoint = 0, guide = 'none') +
    ggplot2::labs(
      title = 'Distribution of occupation-level AI transition pressure within each LWDA',
      subtitle = 'The tail matters: two regions with similar averages can have very different concentrations of high-risk jobs.',
      x = 'Automation exposure minus pro-worker opportunity', y = NULL,
      caption = 'Density is weighted by estimated jobs across county × industry × occupation cells.'
    ) +
    plot_theme_public(base_size = 11)
}

plot_10_lwda_commuting_alluvial <- function(data) {
  if (!nrow(data$flows)) return(NULL)
  x <- data$flows |>
    dplyr::filter(!is.na(home_lwda), !is.na(work_lwda), commuters > 0) |>
    dplyr::mutate(
      home = paste0('Home: ', stringr::str_replace(home_lwda, ' Iowa LWDA', '')),
      work = paste0('Work: ', stringr::str_replace(work_lwda, ' Iowa LWDA', ''))
    ) |>
    dplyr::group_by(home, work) |>
    dplyr::summarise(commuters = sum(commuters, na.rm = TRUE), .groups = 'drop') |>
    dplyr::slice_max(commuters, n = 35, with_ties = FALSE)

  ggplot2::ggplot(x, ggplot2::aes(y = commuters, axis1 = home, axis2 = work)) +
    ggalluvial::geom_alluvium(ggplot2::aes(fill = commuters), alpha = 0.75, width = 0.13) +
    ggalluvial::geom_stratum(width = 0.18, fill = 'grey96', color = 'grey35') +
    ggalluvial::stat_stratum(
      mapping = ggplot2::aes(label = ggplot2::after_stat(stratum)),
      geom = 'text', size = 2.8, color = atlas_brand()$black,
      family = atlas_font_family(), na.rm = TRUE
    ) +
    ggplot2::scale_x_discrete(limits = c('Home LWDA', 'Work LWDA'), expand = c(0.12, 0.12)) +
    ggplot2::scale_y_continuous(labels = fmt_jobs) +
    atlas_color_scale_continuous(labels = fmt_jobs) +
    ggplot2::labs(
      title = 'Iowa AI labor sheds: where workers live and where jobs are located',
      subtitle = 'Commuting flows help identify whether AI training should be planned by residence, workplace, or both.',
      x = NULL, y = 'Commuters', fill = 'Commuters',
      caption = 'Top LWDA-to-LWDA commuting flows from LODES, when available.'
    ) +
    plot_theme_public(base_size = 11) +
    ggplot2::theme(panel.grid = ggplot2::element_blank())
}

plot_11_county_equity_capacity_scatter <- function(data) {
  if (!nrow(data$county)) return(NULL)
  capacity_field <- if ('training_capacity_index' %in% names(data$county)) 'training_capacity_index' else if ('share_bachelors_plus' %in% names(data$county)) 'share_bachelors_plus' else NA_character_
  if (is.na(capacity_field)) return(NULL)
  x <- data$county
  if (!'risk_opportunity_gap' %in% names(x)) x$risk_opportunity_gap <- x$automation_exposure - x$pro_worker_opportunity
  x <- x |>
    dplyr::mutate(
      training_capacity_proxy = suppressWarnings(as.numeric(.data[[capacity_field]])),
      risk_opportunity_gap = dplyr::coalesce(suppressWarnings(as.numeric(risk_opportunity_gap)), automation_exposure - pro_worker_opportunity),
      label_score = pmax(risk_opportunity_gap, 0) * estimated_jobs * (1 - dplyr::coalesce(training_capacity_proxy, 0))
    ) |>
    dplyr::filter(is.finite(training_capacity_proxy), is.finite(risk_opportunity_gap), estimated_jobs > 0)
  lab <- x |> dplyr::slice_max(label_score, n = 15, with_ties = FALSE)
  x_label <- if (identical(capacity_field, 'training_capacity_index')) 'Multi-component training-capacity index' else 'Bachelor-share fallback proxy'
  subtitle <- if (identical(capacity_field, 'training_capacity_index')) 'High pressure plus lower capacity can indicate where shared, applied, and non-degree AI training infrastructure is most important.' else 'Methodology-v2 capacity inputs were unavailable; the bachelor-share proxy is shown only as a fallback.'
  caption <- if (identical(capacity_field, 'training_capacity_index')) 'Capacity combines ACS access indicators with optional community-college, completion, apprenticeship, WIOA, employer release-time, child-care, and travel inputs; reliability is published separately.' else 'Fallback planning signal only; populate the methodology-v2 training-capacity inputs for a broader measure.'

  ggplot2::ggplot(x, ggplot2::aes(x = training_capacity_proxy, y = risk_opportunity_gap)) +
    ggplot2::geom_hline(yintercept = 0, color = 'grey35') +
    ggplot2::geom_point(ggplot2::aes(size = estimated_jobs, fill = lwda_combined), shape = 21, color = 'grey20', alpha = 0.88) +
    ggrepel::geom_text_repel(na.rm = TRUE, data = lab, ggplot2::aes(label = county_name), size = 3, seed = 22, max.overlaps = Inf, family = atlas_font_family(), color = atlas_brand()$black) +
    ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::scale_y_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::scale_size_area(max_size = 15, labels = fmt_jobs) +
    ggplot2::labs(title = 'County AI transition pressure and local training capacity', subtitle = subtitle, x = x_label, y = 'Risk minus opportunity', size = 'Estimated jobs', fill = 'Combined LWDA', caption = caption) +
    plot_theme_public(base_size = 11) +
    ggplot2::theme(legend.position = 'right')
}

plot_12_lwda_top_occupation_lollipops <- function(data) {
  if (!nrow(data$training)) return(NULL)
  x <- data$training |>
    dplyr::group_by(lwda_combined) |>
    dplyr::slice_max(estimated_jobs * dplyr::coalesce(pro_worker_opportunity, 0), n = 6, with_ties = FALSE) |>
    dplyr::ungroup() |>
    dplyr::mutate(
      occ_short = wrap_label(occupation_title, 28),
      lwda_short = stringr::str_replace(lwda_combined, ' Iowa LWDA', ''),
      occ_short = forcats::fct_reorder(occ_short, estimated_jobs)
    )

  ggplot2::ggplot(x) +
    ggplot2::geom_segment(ggplot2::aes(x = automation_exposure, xend = pro_worker_opportunity, y = occ_short, yend = occ_short), color = 'grey55', linewidth = 0.55) +
    ggplot2::geom_point(ggplot2::aes(x = automation_exposure, y = occ_short), color = atlas_brand()$red, size = 2.1) +
    ggplot2::geom_point(ggplot2::aes(x = pro_worker_opportunity, y = occ_short, size = estimated_jobs), color = atlas_brand()$blue, alpha = 0.82) +
    ggplot2::facet_wrap(~lwda_short, scales = 'free_y', ncol = 2) +
    ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
    ggplot2::scale_size_area(max_size = 9, labels = fmt_jobs) +
    ggplot2::labs(
      title = 'Top occupations where AI training can convert risk into opportunity',
      subtitle = 'Red dot = automation exposure; blue dot = pro-worker opportunity. Large blue dots represent more jobs.',
      x = 'Score', y = NULL, size = 'Estimated jobs',
      caption = 'Focus on occupations where the blue dot is near or to the right of the red dot, and where employment scale is large.'
    ) +
    plot_theme_public(base_size = 10)
}

plot_13_transition_waffle <- function(data) {
  if (!nrow(data$atlas)) return(NULL)
  shares <- data$atlas |>
    dplyr::group_by(transition_priority) |>
    dplyr::summarise(estimated_jobs = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop') |>
    dplyr::mutate(
      share = estimated_jobs / sum(estimated_jobs, na.rm = TRUE),
      n_tiles = round(share * 100)
    )
  diff <- 100 - sum(shares$n_tiles, na.rm = TRUE)
  if (nrow(shares) && diff != 0) shares$n_tiles[which.max(shares$estimated_jobs)] <- shares$n_tiles[which.max(shares$estimated_jobs)] + diff

  grid <- shares |>
    tidyr::uncount(n_tiles) |>
    dplyr::mutate(tile_id = dplyr::row_number(), x = ((tile_id - 1) %% 10) + 1, y = ceiling(tile_id / 10))

  labels <- shares |>
    dplyr::mutate(label = paste0(transition_priority, '\n', scales::percent(share, accuracy = 1), ' | ', fmt_jobs(estimated_jobs), ' jobs'))

  ggplot2::ggplot(grid, ggplot2::aes(x = x, y = y, fill = transition_priority)) +
    ggplot2::geom_tile(color = 'white', linewidth = 0.8) +
    ggplot2::coord_equal() +
    ggplot2::scale_y_reverse() +
    ggplot2::scale_fill_manual(values = palette_for_actions(labels$transition_priority), breaks = labels$transition_priority, labels = labels$label) +
    ggplot2::labs(
      title = 'Statewide AI workforce transition portfolio',
      subtitle = 'Each square is about one percent of estimated jobs in the atlas.',
      fill = 'Job share',
      caption = 'This is a simple public-facing companion to the more technical maps and exposure plots.'
    ) +
    ggplot2::theme_void(base_size = 11) +
    ggplot2::theme(
      legend.position = 'right',
      plot.title = ggplot2::element_text(face = 'bold', size = 17),
      plot.subtitle = ggplot2::element_text(color = 'grey30'),
      plot.caption = ggplot2::element_text(color = 'grey35', hjust = 0)
    )
}

plot_14_occupation_group_sector_matrix <- function(data) {
  if (!nrow(data$atlas)) return(NULL)
  soc_major_lookup <- tibble::tribble(
    ~soc2, ~soc_group,
    '11', 'Management', '13', 'Business & financial', '15', 'Computer & math',
    '17', 'Architecture & engineering', '19', 'Life/physical/social science',
    '21', 'Community & social service', '23', 'Legal', '25', 'Education',
    '27', 'Arts/media', '29', 'Healthcare practitioners', '31', 'Healthcare support',
    '33', 'Protective service', '35', 'Food preparation', '37', 'Cleaning/maintenance',
    '39', 'Personal care/service', '41', 'Sales', '43', 'Office/admin',
    '45', 'Farming/fishing/forestry', '47', 'Construction/extraction',
    '49', 'Installation/repair', '51', 'Production', '53', 'Transportation'
  )
  x <- data$atlas |>
    dplyr::mutate(soc2 = stringr::str_sub(soc_code, 1, 2)) |>
    dplyr::left_join(soc_major_lookup, by = 'soc2') |>
    dplyr::filter(!is.na(soc_group), estimated_jobs > 0) |>
    dplyr::group_by(soc_group, iowa_priority_sector) |>
    dplyr::summarise(
      risk_gap = w_mean(automation_exposure - pro_worker_opportunity_local, estimated_jobs),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::group_by(soc_group) |>
    dplyr::mutate(group_jobs = sum(estimated_jobs, na.rm = TRUE)) |>
    dplyr::ungroup() |>
    dplyr::filter(group_jobs >= stats::quantile(group_jobs, 0.25, na.rm = TRUE)) |>
    dplyr::mutate(
      soc_group = forcats::fct_reorder(soc_group, group_jobs),
      sector = forcats::fct_reorder(wrap_label(iowa_priority_sector, 18), estimated_jobs, .fun = sum, .desc = TRUE)
    )

  ggplot2::ggplot(x, ggplot2::aes(x = sector, y = soc_group, fill = risk_gap)) +
    ggplot2::geom_tile(color = 'white') +
    ggplot2::geom_text(ggplot2::aes(label = fmt_jobs(estimated_jobs)), size = 2.4, color = atlas_brand()$black, family = atlas_font_family(), na.rm = TRUE) +
    ggplot2::scale_fill_gradient2(low = atlas_brand()$blue, mid = 'white', high = atlas_brand()$red, midpoint = 0, labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::labs(
      title = 'Occupation group × sector AI transition matrix',
      subtitle = 'Fill shows risk minus opportunity; labels show estimated jobs. This identifies sector-occupation cells for employer roundtables.',
      x = NULL, y = NULL, fill = 'Risk gap',
      caption = 'Use this for sector strategy: e.g., manufacturing production roles vs. finance office/admin roles vs. healthcare support roles.'
    ) +
    plot_theme_public(base_size = 10) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 40, hjust = 1))
}



plot_15_lwda_transition_share_bars <- function(data) {
  if (!nrow(data$atlas)) return(NULL)
  x <- data$atlas |>
    dplyr::filter(estimated_jobs > 0, !is.na(transition_priority)) |>
    dplyr::mutate(lwda_short = stringr::str_replace(lwda_combined, ' Iowa LWDA', '')) |>
    dplyr::group_by(lwda_short, transition_priority) |>
    dplyr::summarise(estimated_jobs = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop') |>
    dplyr::group_by(lwda_short) |>
    dplyr::mutate(total_jobs = sum(estimated_jobs, na.rm = TRUE), share = estimated_jobs / total_jobs) |>
    dplyr::ungroup()
  ord <- x |>
    dplyr::filter(transition_priority %in% c('Protect and redesign', 'Upgrade through AI-complementary training')) |>
    dplyr::group_by(lwda_short) |>
    dplyr::summarise(action_share = sum(share, na.rm = TRUE), .groups = 'drop')
  x <- x |>
    dplyr::left_join(ord, by = 'lwda_short') |>
    dplyr::mutate(lwda_short = forcats::fct_reorder(lwda_short, dplyr::coalesce(action_share, 0)))

  ggplot2::ggplot(x, ggplot2::aes(x = share, y = lwda_short, fill = transition_priority)) +
    ggplot2::geom_col(width = 0.72, color = 'white') +
    ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::scale_fill_manual(values = palette_for_actions(x$transition_priority), na.value = 'grey70') +
    ggplot2::labs(
      title = 'LWDA transition-action mix',
      subtitle = 'Each bar is a region’s estimated job portfolio split by protect, upgrade, scale, and monitor actions.',
      x = 'Share of estimated jobs', y = NULL, fill = 'Transition action',
      caption = 'Use this to compare whether regions need more redesign work, AI-complementary training, or pro-worker scaling capacity.'
    ) +
    plot_theme_public(base_size = 11)
}

plot_16_county_action_job_stack <- function(data, top_n = 30) {
  if (!nrow(data$county)) return(NULL)
  x <- data$county |>
    dplyr::mutate(
      monitor_jobs = pmax(0, estimated_jobs - dplyr::coalesce(protective_redesign_jobs, 0) -
                            dplyr::coalesce(upgrade_training_jobs, 0) - dplyr::coalesce(scale_opportunity_jobs, 0)),
      action_jobs = dplyr::coalesce(protective_redesign_jobs, 0) + dplyr::coalesce(upgrade_training_jobs, 0) + dplyr::coalesce(scale_opportunity_jobs, 0)
    ) |>
    dplyr::slice_max(action_jobs, n = top_n, with_ties = FALSE) |>
    tidyr::pivot_longer(
      c(protective_redesign_jobs, upgrade_training_jobs, scale_opportunity_jobs, monitor_jobs),
      names_to = 'action_raw', values_to = 'jobs'
    ) |>
    dplyr::mutate(
      transition_priority = dplyr::recode(
        action_raw,
        protective_redesign_jobs = 'Protect and redesign',
        upgrade_training_jobs = 'Upgrade through AI-complementary training',
        scale_opportunity_jobs = 'Scale pro-worker AI opportunity',
        monitor_jobs = 'Monitor'
      ),
      county_label = forcats::fct_reorder(county_name, action_jobs)
    ) |>
    dplyr::filter(jobs > 0)

  ggplot2::ggplot(x, ggplot2::aes(x = jobs, y = county_label, fill = transition_priority)) +
    ggplot2::geom_col(color = 'white', linewidth = 0.2) +
    ggplot2::scale_x_continuous(labels = fmt_jobs) +
    ggplot2::scale_fill_manual(values = palette_for_actions(x$transition_priority), na.value = 'grey70') +
    ggplot2::labs(
      title = 'Counties with the largest AI transition-action job pools',
      subtitle = 'The chart ranks counties by jobs in protect, upgrade, and scale categories, while still showing the monitor base.',
      x = 'Estimated jobs', y = NULL, fill = 'Transition action',
      caption = 'Use this for county-level grant targeting and employer outreach.'
    ) +
    plot_theme_public(base_size = 10)
}

plot_17_sector_action_mix_heatmap <- function(data) {
  if (!nrow(data$atlas)) return(NULL)
  x <- data$atlas |>
    dplyr::filter(estimated_jobs > 0, !is.na(transition_priority), !is.na(iowa_priority_sector)) |>
    dplyr::group_by(iowa_priority_sector, transition_priority) |>
    dplyr::summarise(estimated_jobs = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop') |>
    dplyr::group_by(iowa_priority_sector) |>
    dplyr::mutate(total_jobs = sum(estimated_jobs, na.rm = TRUE), share = estimated_jobs / total_jobs) |>
    dplyr::ungroup() |>
    dplyr::group_by(iowa_priority_sector) |>
    dplyr::filter(total_jobs >= stats::quantile(total_jobs, 0.25, na.rm = TRUE)) |>
    dplyr::ungroup() |>
    dplyr::mutate(
      sector = forcats::fct_reorder(wrap_label(iowa_priority_sector, 22), total_jobs),
      transition_priority = factor(transition_priority, levels = names(transition_palette))
    )

  ggplot2::ggplot(x, ggplot2::aes(x = transition_priority, y = sector, fill = share)) +
    ggplot2::geom_tile(color = 'white', linewidth = 0.35) +
    ggplot2::geom_text(ggplot2::aes(label = paste0(scales::percent(share, accuracy = 1), '\n', fmt_jobs(estimated_jobs))), size = 2.6, color = atlas_brand()$black, family = atlas_font_family(), na.rm = TRUE) +
    ggplot2::scale_fill_gradient(low = 'white', high = atlas_brand()$blue, labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::labs(
      title = 'Sector transition-action mix',
      subtitle = 'Each cell shows the share and number of jobs in a sector assigned to a transition action.',
      x = NULL, y = NULL, fill = 'Sector share',
      caption = 'This turns sector strategy into a concrete action portfolio.'
    ) +
    plot_theme_public(base_size = 10) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 30, hjust = 1))
}

plot_18_soc_task_channel_heatmap <- function(data) {
  if (!nrow(data$occ_scores)) return(NULL)
  soc_major_lookup <- tibble::tribble(
    ~soc2, ~soc_group,
    '11', 'Management', '13', 'Business & financial', '15', 'Computer & math',
    '17', 'Architecture & engineering', '19', 'Science', '21', 'Community/social service',
    '23', 'Legal', '25', 'Education', '27', 'Arts/media', '29', 'Healthcare practitioners',
    '31', 'Healthcare support', '33', 'Protective service', '35', 'Food preparation',
    '37', 'Cleaning/maintenance', '39', 'Personal care/service', '41', 'Sales',
    '43', 'Office/admin', '45', 'Farming/fishing/forestry', '47', 'Construction/extraction',
    '49', 'Installation/repair', '51', 'Production', '53', 'Transportation'
  )
  cols <- c('manual_share_proxy', 'cognitive_share_proxy', 'interpersonal_share_proxy',
            'automation_exposure', 'augmentation_potential', 'expertise_leveling_potential', 'new_task_opportunity')
  x <- data$occ_scores |>
    dplyr::mutate(soc2 = stringr::str_sub(soc_code, 1, 2)) |>
    dplyr::left_join(soc_major_lookup, by = 'soc2') |>
    dplyr::filter(!is.na(soc_group), state_emp > 0) |>
    dplyr::group_by(soc_group) |>
    dplyr::summarise(dplyr::across(dplyr::all_of(cols), ~w_mean(.x, state_emp)), jobs = sum(state_emp, na.rm = TRUE), .groups = 'drop') |>
    tidyr::pivot_longer(dplyr::all_of(cols), names_to = 'metric', values_to = 'score') |>
    dplyr::mutate(
      metric = dplyr::recode(metric,
        manual_share_proxy = 'Manual-task proxy', cognitive_share_proxy = 'Cognitive-task proxy',
        interpersonal_share_proxy = 'Interpersonal-task proxy', automation_exposure = 'Automation exposure',
        augmentation_potential = 'Augmentation potential', expertise_leveling_potential = 'Expertise leveling',
        new_task_opportunity = 'New-task opportunity'
      ),
      soc_group = forcats::fct_reorder(soc_group, jobs)
    ) |>
    dplyr::filter(is.finite(score))

  ggplot2::ggplot(x, ggplot2::aes(x = metric, y = soc_group, fill = score)) +
    ggplot2::geom_tile(color = 'white', linewidth = 0.35) +
    ggplot2::geom_text(ggplot2::aes(label = scales::percent(score, accuracy = 1)), size = 2.4, color = atlas_brand()$black, family = atlas_font_family(), na.rm = TRUE) +
    atlas_color_scale_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::labs(
      title = 'Occupation-group task and AI channel profile',
      subtitle = 'A compact view of which occupational families are manual, cognitive, interpersonal, exposed, and pro-worker-opportunity rich.',
      x = NULL, y = NULL, fill = 'Score',
      caption = 'Task-type proxies come from O*NET task text and work-activity scoring in the atlas pipeline.'
    ) +
    plot_theme_public(base_size = 10) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 35, hjust = 1))
}

plot_19_county_metric_small_multiple_map <- function(data) {
  if (is.null(data$shapes) || !nrow(data$county)) return(NULL)
  mapdat <- data$shapes |>
    dplyr::left_join(data$county, by = 'county_fips') |>
    dplyr::mutate(
      `Automation exposure` = automation_exposure,
      `Pro-worker opportunity` = pro_worker_opportunity,
      `Risk minus opportunity` = risk_opportunity_gap,
      `Scale-opportunity job share` = scale_opportunity_share
    ) |>
    tidyr::pivot_longer(c(`Automation exposure`, `Pro-worker opportunity`, `Risk minus opportunity`, `Scale-opportunity job share`), names_to = 'metric', values_to = 'value') |>
    dplyr::group_by(metric) |>
    dplyr::mutate(metric_percentile = dplyr::percent_rank(value)) |>
    dplyr::ungroup()

  ggplot2::ggplot(mapdat) +
    ggplot2::geom_sf(ggplot2::aes(fill = metric_percentile), color = 'white', linewidth = 0.12) +
    ggplot2::facet_wrap(~metric, ncol = 2) +
    atlas_color_scale_continuous(labels = atlas_axis_percent(accuracy = 1), na.value = 'grey90') +
    ggplot2::labs(
      title = 'County AI transition signals, side by side',
      subtitle = 'Each panel uses within-metric percentiles so counties can be compared on several planning signals at once.',
      fill = 'Within-metric percentile',
      caption = 'Use the individual maps for detail; use this panel to compare geography across metrics.'
    ) +
    ggplot2::theme_void(base_size = 10) +
    ggplot2::theme(
      strip.text = ggplot2::element_text(face = 'bold'),
      legend.position = 'right',
      plot.title = ggplot2::element_text(face = 'bold', size = 16),
      plot.subtitle = ggplot2::element_text(color = 'grey30'),
      plot.caption = ggplot2::element_text(color = 'grey35', hjust = 0)
    )
}

plot_20_training_funnel <- function(data) {
  if (!nrow(data$atlas)) return(NULL)
  total <- sum(data$atlas$estimated_jobs, na.rm = TRUE)
  x <- tibble::tibble(
    stage = c('All scored jobs', 'Automation exposure ≥ 65%', 'Protect or redesign', 'Upgrade through AI training', 'Scale pro-worker opportunity', 'Top listed training priorities'),
    jobs = c(
      total,
      sum(data$atlas$estimated_jobs[data$atlas$automation_exposure >= 0.65], na.rm = TRUE),
      sum(data$atlas$estimated_jobs[data$atlas$transition_priority == 'Protect and redesign'], na.rm = TRUE),
      sum(data$atlas$estimated_jobs[data$atlas$transition_priority == 'Upgrade through AI-complementary training'], na.rm = TRUE),
      sum(data$atlas$estimated_jobs[data$atlas$transition_priority == 'Scale pro-worker AI opportunity'], na.rm = TRUE),
      if (nrow(data$training)) sum(data$training$estimated_jobs, na.rm = TRUE) else NA_real_
    )
  ) |>
    dplyr::mutate(share = jobs / total, stage = factor(stage, levels = rev(stage))) |>
    dplyr::filter(is.finite(jobs), jobs >= 0)

  ggplot2::ggplot(x, ggplot2::aes(x = jobs, y = stage)) +
    ggplot2::geom_col(fill = atlas_brand()$blue, alpha = 0.88, width = 0.62) +
    ggplot2::geom_text(ggplot2::aes(label = paste0(fmt_jobs(jobs), ' jobs | ', scales::percent(share, accuracy = 1))), hjust = -0.04, size = 3.4, color = atlas_brand()$black, family = atlas_font_family(), na.rm = TRUE) +
    ggplot2::scale_x_continuous(labels = fmt_jobs, expand = ggplot2::expansion(mult = c(0, 0.22))) +
    ggplot2::labs(
      title = 'From statewide exposure to actionable training priorities',
      subtitle = 'A public-facing funnel that separates all scored jobs from jobs needing protection, upgrading, or opportunity scaling.',
      x = 'Estimated jobs', y = NULL,
      caption = 'This is a communication aid, not a causal estimate of displacement.'
    ) +
    plot_theme_public(base_size = 11)
}

plot_21_sector_wage_risk_lens <- function(data) {
  if (!nrow(data$atlas)) return(NULL)
  x <- data$atlas |>
    dplyr::group_by(iowa_priority_sector) |>
    dplyr::summarise(
      hourly_mean = w_mean(hourly_mean, estimated_jobs),
      risk_gap = w_mean(automation_exposure - pro_worker_opportunity_local, estimated_jobs),
      new_task_opportunity = w_mean(new_task_opportunity_local, estimated_jobs),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::filter(is.finite(hourly_mean), is.finite(risk_gap), estimated_jobs > 0)
  lab <- x |> dplyr::slice_max(estimated_jobs, n = 14, with_ties = FALSE)

  ggplot2::ggplot(x, ggplot2::aes(x = hourly_mean, y = risk_gap)) +
    ggplot2::geom_hline(yintercept = 0, color = 'grey35') +
    ggplot2::geom_point(ggplot2::aes(size = estimated_jobs, fill = new_task_opportunity), shape = 21, color = 'grey20', alpha = 0.9) +
    ggrepel::geom_text_repel(na.rm = TRUE, data = lab, ggplot2::aes(label = iowa_priority_sector), seed = 31, size = 3.2, max.overlaps = Inf, family = atlas_font_family(), color = atlas_brand()$black) +
    ggplot2::scale_x_continuous(labels = scales::dollar_format(accuracy = 1)) +
    ggplot2::scale_y_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::scale_size_area(max_size = 17, labels = fmt_jobs) +
    atlas_color_scale_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::labs(
      title = 'Sector wage lens: where risk threatens higher-value labor markets',
      subtitle = 'Economic developers can use this to balance wage preservation, job scale, and new-task opportunity.',
      x = 'Estimated mean hourly wage', y = 'Risk minus opportunity', size = 'Estimated jobs', fill = 'New-task opportunity',
      caption = 'Wages are employment-weighted from Iowa OEWS occupation wages allocated across sectors.'
    ) +
    plot_theme_public(base_size = 11)
}

plot_22_lwda_risk_opportunity_dumbbell <- function(data) {
  if (!nrow(data$lwda)) return(NULL)
  x <- data$lwda |>
    dplyr::mutate(
      lwda_short = stringr::str_replace(lwda_combined, ' Iowa LWDA', ''),
      lwda_short = forcats::fct_reorder(lwda_short, automation_exposure - pro_worker_opportunity)
    ) |>
    dplyr::filter(is.finite(automation_exposure), is.finite(pro_worker_opportunity))

  ggplot2::ggplot(x) +
    ggplot2::geom_segment(ggplot2::aes(x = pro_worker_opportunity, xend = automation_exposure, y = lwda_short, yend = lwda_short), color = 'grey60', linewidth = 1.1) +
    ggplot2::geom_point(ggplot2::aes(x = pro_worker_opportunity, y = lwda_short, size = estimated_jobs), color = atlas_brand()$blue, alpha = 0.85) +
    ggplot2::geom_point(ggplot2::aes(x = automation_exposure, y = lwda_short), color = atlas_brand()$red, size = 3.8) +
    ggplot2::scale_x_continuous(labels = atlas_axis_percent(accuracy = 1), limits = c(0, 1)) +
    ggplot2::scale_size_area(max_size = 11, labels = fmt_jobs) +
    ggplot2::labs(
      title = 'LWDA risk-opportunity gap',
      subtitle = 'Red dot = automation exposure; blue dot = pro-worker opportunity. Larger blue dots indicate larger regional job bases.',
      x = 'Employment-weighted score', y = NULL, size = 'Estimated jobs',
      caption = 'Regions where red sits far to the right of blue may need more redesign and complementary-training capacity.'
    ) +
    plot_theme_public(base_size = 11)
}


# ---- Additional economic-development visuals -------------------------------
soc_major_lookup_public <- function() {
  tibble::tribble(
    ~soc2, ~soc_group,
    '11', 'Management', '13', 'Business & financial', '15', 'Computer & math',
    '17', 'Architecture & engineering', '19', 'Science', '21', 'Community/social service',
    '23', 'Legal', '25', 'Education', '27', 'Arts/media', '29', 'Healthcare practitioners',
    '31', 'Healthcare support', '33', 'Protective service', '35', 'Food preparation',
    '37', 'Cleaning/maintenance', '39', 'Personal care/service', '41', 'Sales',
    '43', 'Office/admin', '45', 'Farming/fishing/forestry', '47', 'Construction/extraction',
    '49', 'Installation/repair', '51', 'Production', '53', 'Transportation'
  )
}

plot_23_county_wage_risk_lens <- function(data) {
  if (!nrow(data$atlas)) return(NULL)
  atlas <- data$atlas
  if (!'hourly_mean' %in% names(atlas)) atlas$hourly_mean <- NA_real_
  if (!'annual_mean' %in% names(atlas)) atlas$annual_mean <- NA_real_
  x <- atlas |>
    dplyr::mutate(
      wage_hourly = dplyr::if_else(is.na(hourly_mean) & !is.na(annual_mean), annual_mean / 2080, hourly_mean),
      risk_gap = automation_exposure - pro_worker_opportunity_local
    ) |>
    dplyr::group_by(county_fips, county_name, lwda_combined) |>
    dplyr::summarise(
      hourly_mean = w_mean(wage_hourly, estimated_jobs),
      automation_exposure = w_mean(automation_exposure, estimated_jobs),
      pro_worker_opportunity = w_mean(pro_worker_opportunity_local, estimated_jobs),
      risk_gap = w_mean(risk_gap, estimated_jobs),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::filter(is.finite(hourly_mean), is.finite(risk_gap), estimated_jobs > 0)
  if (!nrow(x)) return(NULL)
  lab <- x |>
    dplyr::mutate(label_score = pmax(risk_gap, 0) * estimated_jobs * pmax(hourly_mean, 1)) |>
    dplyr::slice_max(label_score, n = 16, with_ties = FALSE)

  ggplot2::ggplot(x, ggplot2::aes(x = hourly_mean, y = risk_gap)) +
    ggplot2::geom_hline(yintercept = 0, color = 'grey35', linewidth = 0.45) +
    ggplot2::geom_point(ggplot2::aes(size = estimated_jobs, fill = lwda_combined), shape = 21, color = 'grey20', alpha = 0.88) +
    ggrepel::geom_text_repel(na.rm = TRUE, data = lab, ggplot2::aes(label = county_name), seed = 23, size = 3, max.overlaps = Inf, family = atlas_font_family(), color = atlas_brand()$black) +
    ggplot2::scale_x_continuous(labels = scales::dollar_format(accuracy = 1)) +
    ggplot2::scale_y_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::scale_size_area(max_size = 15, labels = fmt_jobs) +
    ggplot2::labs(
      title = 'County wage value and AI transition pressure',
      subtitle = 'Counties above zero combine relatively higher automation exposure than pro-worker opportunity. Larger bubbles indicate more jobs in the atlas.',
      x = 'Employment-weighted mean hourly wage', y = 'Automation exposure minus pro-worker opportunity',
      size = 'Estimated jobs', fill = 'Combined LWDA',
      caption = 'Use this view to prioritize places where transition pressure affects a meaningful wage base.'
    ) +
    plot_theme_public(base_size = 11) +
    ggplot2::theme(legend.position = 'right')
}

plot_24_sector_channel_scorecard <- function(data) {
  if (!nrow(data$sector)) return(NULL)
  cols <- c('automation_exposure', 'augmentation_potential', 'expertise_leveling_potential', 'new_task_opportunity', 'pro_worker_opportunity')
  cols <- intersect(cols, names(data$sector))
  if (length(cols) < 2) return(NULL)
  x <- data$sector |>
    dplyr::filter(estimated_jobs > 0, !is.na(iowa_priority_sector)) |>
    dplyr::group_by(iowa_priority_sector) |>
    dplyr::summarise(
      dplyr::across(dplyr::all_of(cols), ~w_mean(.x, estimated_jobs)),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::filter(estimated_jobs > 0) |>
    tidyr::pivot_longer(dplyr::all_of(cols), names_to = 'metric', values_to = 'score') |>
    dplyr::mutate(
      metric = metric_label(metric),
      sector = forcats::fct_reorder(wrap_label(iowa_priority_sector, 22), estimated_jobs)
    ) |>
    dplyr::filter(is.finite(score))
  if (!nrow(x)) return(NULL)

  ggplot2::ggplot(x, ggplot2::aes(x = metric, y = sector, fill = score)) +
    ggplot2::geom_tile(color = 'white', linewidth = 0.35) +
    ggplot2::geom_text(ggplot2::aes(label = scales::percent(score, accuracy = 1)), size = 2.6, color = atlas_brand()$black, family = atlas_font_family(), na.rm = TRUE) +
    atlas_color_scale_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::labs(
      title = 'Sector AI channel scorecard',
      subtitle = 'Employment-weighted sector scores show whether a sector story is mainly automation, augmentation, expertise leveling, or new-task opportunity.',
      x = NULL, y = NULL, fill = 'Score',
      caption = 'This is a compact briefing slide for economic developers building sector partnerships.'
    ) +
    plot_theme_public(base_size = 10) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 35, hjust = 1))
}

plot_25_lwda_training_occ_group_heatmap <- function(data) {
  if (!nrow(data$training)) return(NULL)
  training <- data$training
  if (!'hourly_mean' %in% names(training)) training$hourly_mean <- NA_real_
  lookup <- soc_major_lookup_public()
  x <- training |>
    dplyr::mutate(soc2 = stringr::str_sub(soc_code, 1, 2)) |>
    dplyr::left_join(lookup, by = 'soc2') |>
    dplyr::filter(!is.na(soc_group), estimated_jobs > 0) |>
    dplyr::group_by(lwda_combined, soc_group) |>
    dplyr::summarise(
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      pro_worker_opportunity = w_mean(pro_worker_opportunity, estimated_jobs),
      automation_exposure = w_mean(automation_exposure, estimated_jobs),
      hourly_mean = w_mean(hourly_mean, estimated_jobs),
      .groups = 'drop'
    ) |>
    dplyr::filter(estimated_jobs > 0, is.finite(pro_worker_opportunity))
  if (!nrow(x)) return(NULL)
  top_groups <- x |>
    dplyr::group_by(soc_group) |>
    dplyr::summarise(total_jobs = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop') |>
    dplyr::slice_max(total_jobs, n = 14, with_ties = FALSE)
  x <- x |>
    dplyr::semi_join(top_groups, by = 'soc_group') |>
    dplyr::mutate(
      lwda_short = stringr::str_replace(lwda_combined, ' Iowa LWDA', ''),
      soc_group = forcats::fct_reorder(soc_group, estimated_jobs, .fun = sum),
      lwda_short = forcats::fct_reorder(lwda_short, estimated_jobs, .fun = sum, .desc = TRUE)
    )

  ggplot2::ggplot(x, ggplot2::aes(x = lwda_short, y = soc_group, fill = pro_worker_opportunity)) +
    ggplot2::geom_tile(color = 'white', linewidth = 0.35) +
    ggplot2::geom_text(ggplot2::aes(label = fmt_jobs(estimated_jobs)), size = 2.6, color = atlas_brand()$black, family = atlas_font_family(), na.rm = TRUE) +
    atlas_color_scale_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::labs(
      title = 'Regional training opportunity by occupation family',
      subtitle = 'Labels show estimated training-priority jobs; fill shows pro-worker opportunity. This helps community colleges align programs by LWDA.',
      x = NULL, y = NULL, fill = 'Opportunity',
      caption = 'Rows are the largest statewide training-priority occupation families in the atlas.'
    ) +
    plot_theme_public(base_size = 10) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 25, hjust = 1))
}

plot_26_county_action_leaderboard <- function(data) {
  if (!nrow(data$county)) return(NULL)
  county <- data$county
  for (nm in c('protective_redesign_jobs', 'upgrade_training_jobs', 'scale_opportunity_jobs')) {
    if (!nm %in% names(county)) county[[nm]] <- 0
  }
  x <- county |>
    dplyr::mutate(
      protective_jobs = dplyr::coalesce(protective_redesign_jobs, 0),
      upgrade_jobs = dplyr::coalesce(upgrade_training_jobs, 0),
      scale_jobs = dplyr::coalesce(scale_opportunity_jobs, 0),
      actionable_jobs = protective_jobs + upgrade_jobs + scale_jobs,
      top_action = dplyr::case_when(
        protective_jobs >= upgrade_jobs & protective_jobs >= scale_jobs ~ 'Protect and redesign',
        upgrade_jobs >= protective_jobs & upgrade_jobs >= scale_jobs ~ 'Upgrade through AI-complementary training',
        scale_jobs >= protective_jobs & scale_jobs >= upgrade_jobs ~ 'Scale pro-worker AI opportunity',
        TRUE ~ 'Monitor'
      ),
      lwda_short = stringr::str_replace(lwda_combined, ' Iowa LWDA', '')
    ) |>
    dplyr::filter(actionable_jobs > 0, !is.na(county_name), !is.na(lwda_short)) |>
    dplyr::group_by(lwda_short) |>
    dplyr::slice_max(actionable_jobs, n = 8, with_ties = FALSE) |>
    dplyr::ungroup() |>
    dplyr::mutate(
      county_label = forcats::fct_reorder(county_name, actionable_jobs),
      top_action = factor(top_action, levels = names(transition_palette))
    )
  if (!nrow(x)) return(NULL)

  ggplot2::ggplot(x, ggplot2::aes(x = actionable_jobs, y = county_label, fill = top_action)) +
    ggplot2::geom_col(width = 0.72) +
    ggplot2::geom_text(ggplot2::aes(label = fmt_jobs(actionable_jobs)), hjust = -0.08, size = 2.8, color = atlas_brand()$black, family = atlas_font_family(), na.rm = TRUE) +
    ggplot2::facet_wrap(~lwda_short, scales = 'free_y') +
    ggplot2::scale_x_continuous(labels = fmt_jobs, expand = ggplot2::expansion(mult = c(0, 0.18))) +
    ggplot2::scale_fill_manual(values = palette_for_actions(x$top_action), na.value = 'grey70') +
    ggplot2::labs(
      title = 'County AI action leaderboard by LWDA',
      subtitle = 'Bars show actionable jobs in the protect, upgrade, or scale categories; color shows the largest action category in the county.',
      x = 'Actionable jobs', y = NULL, fill = 'Largest action category',
      caption = 'Use this figure to pick counties for listening sessions, grant applications, and employer convenings.'
    ) +
    plot_theme_public(base_size = 10) +
    ggplot2::theme(legend.position = 'bottom')
}

# ---- Master runner ---------------------------------------------------------
make_public_visualizations <- function(install_missing = TRUE, build_if_missing = TRUE, refresh = FALSE) {
  install_public_viz_packages(install_missing = install_missing)
  data <- get_public_viz_data(build_if_missing = build_if_missing, refresh = refresh)

  figure_specs <- list(
    list(id = '01', filename = 'public_01_county_bivariate_risk_opportunity.png', width = 13, height = 7.5,
         audience = 'Public, policymakers', question = 'Which counties have both high automation exposure and high pro-worker AI opportunity?',
         fun = plot_01_county_bivariate_risk_opportunity),
    list(id = '02', filename = 'public_02_county_dominant_transition_action.png', width = 11, height = 7,
         audience = 'Workforce boards, county leaders', question = 'What is the dominant workforce action in each county?',
         fun = plot_02_county_dominant_transition_action),
    list(id = '03', filename = 'public_03_lwda_ai_compass.png', width = 13, height = 10,
         audience = 'Workforce boards', question = 'What is each LWDA’s AI channel profile?',
         fun = plot_03_lwda_ai_compass),
    list(id = '04', filename = 'public_04_lwda_sector_bubble_heatmap.png', width = 14, height = 8,
         audience = 'Economic developers', question = 'Where do job scale and transition pressure intersect by sector and LWDA?',
         fun = plot_04_lwda_sector_bubble_heatmap),
    list(id = '05', filename = 'public_05_sector_policy_quadrant.png', width = 11.5, height = 8,
         audience = 'Policymakers, chambers, sector partnerships', question = 'Which sectors need protection, upgrading, or scaling?',
         fun = plot_05_sector_policy_quadrant),
    list(id = '06', filename = 'public_06_occupation_wage_risk_bubble.png', width = 12, height = 8,
         audience = 'Training providers, employers', question = 'Which large occupations combine wage value, risk, and opportunity?',
         fun = plot_06_occupation_wage_risk_bubble),
    list(id = '07', filename = 'public_07_training_pipeline_alluvial.png', width = 15, height = 9,
         audience = 'Community colleges, workforce boards', question = 'How do places, sectors, and transition actions connect?',
         fun = plot_07_training_pipeline_alluvial),
    list(id = '08', filename = 'public_08_training_priority_treemap.png', width = 14, height = 9,
         audience = 'Training providers, public', question = 'Which occupations form the highest-value regional training portfolio?',
         fun = plot_08_training_priority_treemap),
    list(id = '09', filename = 'public_09_risk_distribution_ridges.png', width = 12, height = 8,
         audience = 'Analysts, policymakers', question = 'How much high-risk tail exposure exists inside each LWDA?',
         fun = plot_09_risk_distribution_ridges),
    list(id = '10', filename = 'public_10_lwda_commuting_alluvial.png', width = 12, height = 8,
         audience = 'Regional planners', question = 'Where do workers live relative to where exposed/opportunity jobs are located?',
         fun = plot_10_lwda_commuting_alluvial),
    list(id = '11', filename = 'public_11_county_equity_capacity_scatter.png', width = 12, height = 8,
         audience = 'Equity and access planners', question = 'Which counties combine transition pressure with lower training-capacity proxy?',
         fun = plot_11_county_equity_capacity_scatter),
    list(id = '12', filename = 'public_12_lwda_top_occupation_lollipops.png', width = 13, height = 11,
         audience = 'Community colleges, employer advisory boards', question = 'Which occupations should be prioritized within each LWDA?',
         fun = plot_12_lwda_top_occupation_lollipops),
    list(id = '13', filename = 'public_13_transition_waffle.png', width = 11, height = 7,
         audience = 'Public, elected officials', question = 'What share of jobs falls into each transition action?',
         fun = plot_13_transition_waffle),
    list(id = '14', filename = 'public_14_occupation_group_sector_matrix.png', width = 15, height = 9,
         audience = 'Economic developers, employers', question = 'Which occupation groups in which sectors should be targeted for roundtables?',
         fun = plot_14_occupation_group_sector_matrix),
    list(id = '15', filename = 'public_15_lwda_transition_action_mix.png', width = 12, height = 7,
         audience = 'Workforce boards, policymakers', question = 'How does each LWDA’s job portfolio split across transition actions?',
         fun = plot_15_lwda_transition_share_bars),
    list(id = '16', filename = 'public_16_county_action_job_stack.png', width = 12, height = 10,
         audience = 'County leaders, grant writers', question = 'Which counties have the largest actionable AI transition job pools?',
         fun = plot_16_county_action_job_stack),
    list(id = '17', filename = 'public_17_sector_action_mix_heatmap.png', width = 12.5, height = 9,
         audience = 'Economic developers, sector partnerships', question = 'What action mix is implied for each sector?',
         fun = plot_17_sector_action_mix_heatmap),
    list(id = '18', filename = 'public_18_soc_task_channel_heatmap.png', width = 13, height = 9,
         audience = 'Policy analysts, training planners', question = 'Which occupation groups are manual, cognitive, interpersonal, exposed, and opportunity rich?',
         fun = plot_18_soc_task_channel_heatmap),
    list(id = '19', filename = 'public_19_county_metric_small_multiple_map.png', width = 12, height = 9,
         audience = 'Public, policymakers', question = 'How do several county AI transition signals compare geographically?',
         fun = plot_19_county_metric_small_multiple_map),
    list(id = '20', filename = 'public_20_training_funnel.png', width = 12, height = 7,
         audience = 'Public, workforce boards', question = 'How do statewide jobs narrow from all scored jobs to actionable training priorities?',
         fun = plot_20_training_funnel),
    list(id = '21', filename = 'public_21_sector_wage_risk_lens.png', width = 12, height = 8,
         audience = 'Economic developers, chambers', question = 'Where do wage value, risk pressure, job scale, and new-task opportunity intersect by sector?',
         fun = plot_21_sector_wage_risk_lens),
    list(id = '22', filename = 'public_22_lwda_risk_opportunity_dumbbell.png', width = 12, height = 7,
         audience = 'Workforce boards, local leaders', question = 'How large is the gap between automation exposure and pro-worker opportunity by LWDA?',
         fun = plot_22_lwda_risk_opportunity_dumbbell),
    list(id = '23', filename = 'public_23_county_wage_risk_lens.png', width = 12, height = 8,
         audience = 'Economic developers, county leaders', question = 'Where does AI transition pressure intersect with county wage value?',
         fun = plot_23_county_wage_risk_lens),
    list(id = '24', filename = 'public_24_sector_channel_scorecard.png', width = 13, height = 8.5,
         audience = 'Economic developers, sector partnerships', question = 'Which AI channel defines each Iowa priority sector?',
         fun = plot_24_sector_channel_scorecard),
    list(id = '25', filename = 'public_25_lwda_training_occ_group_heatmap.png', width = 12.5, height = 8.5,
         audience = 'Community colleges, workforce boards', question = 'Which occupation families should training partners prioritize by LWDA?',
         fun = plot_25_lwda_training_occ_group_heatmap),
    list(id = '26', filename = 'public_26_county_action_leaderboard.png', width = 13, height = 9,
         audience = 'County leaders, grant writers, workforce boards', question = 'Which counties have the largest actionable AI transition job pools?',
         fun = plot_26_county_action_leaderboard)
  )

  results <- purrr::map_dfr(figure_specs, function(spec) {
    message('Creating figure ', spec$id, ': ', spec$filename)
    plot_obj <- tryCatch(spec$fun(data), error = function(e) {
      warning('Could not create ', spec$filename, ': ', conditionMessage(e), call. = FALSE)
      NULL
    })
    if (is.null(plot_obj)) {
      return(tibble::tibble(
        id = spec$id, filename = spec$filename, status = 'skipped', path = NA_character_,
        audience = spec$audience, question = spec$question,
        png_channels = NA_integer_, has_alpha = NA, transparent_pixels = NA_real_
      ))
    }
    out <- tryCatch(
      save_public_plot(plot_obj, spec$filename, width = spec$width, height = spec$height),
      error = function(e) {
        warning('Could not save ', spec$filename, ': ', conditionMessage(e), call. = FALSE)
        NA_character_
      }
    )
    if (is.na(out) || !file.exists(out)) {
      return(tibble::tibble(
        id = spec$id, filename = spec$filename, status = 'skipped', path = NA_character_,
        audience = spec$audience, question = spec$question,
        png_channels = NA_integer_, has_alpha = NA, transparent_pixels = NA_real_
      ))
    }
    alpha_status <- if (identical(spec$id, '01')) atlas_png_alpha_status(out) else list(channels = NA_integer_, has_alpha = NA, transparent_pixels = NA_real_)
    tibble::tibble(
      id = spec$id, filename = spec$filename, status = 'created', path = out,
      audience = spec$audience, question = spec$question,
      png_channels = as.integer(alpha_status$channels),
      has_alpha = as.logical(alpha_status$has_alpha),
      transparent_pixels = as.double(alpha_status$transparent_pixels)
    )
  })

  p <- paths()
  fs::dir_create(p$outputs)
  if (exists('v2_build_id', mode = 'function')) {
    results <- results |>
      dplyr::mutate(
        build_id = v2_build_id(),
        methodology_version = as.character(load_methodology_v2_config()$methodology_version)
      )
  } else {
    results <- results |>
      dplyr::mutate(build_id = NA_character_, methodology_version = NA_character_)
  }
  readr::write_csv(results, file.path(p$outputs, 'public_visualization_manifest.csv'))
  alpha_check <- results |>
    dplyr::filter(id == '01') |>
    dplyr::transmute(
      figure = filename,
      path = path,
      png_channels = png_channels,
      has_alpha = has_alpha,
      transparent_pixels = transparent_pixels,
      transparent = isTRUE(has_alpha[[1L]]) && transparent_pixels[[1L]] > 0,
      checked_at = format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z')
    )
  readr::write_csv(alpha_check, file.path(p$outputs, 'png_transparency_check.csv'))
  if (!nrow(alpha_check) || !isTRUE(alpha_check$transparent[[1L]])) {
    stop('Figure 01 transparency validation failed. See outputs/png_transparency_check.csv.', call. = FALSE)
  }

  gallery <- tryCatch(write_public_visualization_gallery(results), error = function(e) {
    warning('Could not write public visualization gallery: ', conditionMessage(e), call. = FALSE)
    NA_character_
  })
  message('Done. Created ', sum(results$status == 'created'), ' public visualization files in ', file.path(p$figures, 'public'))
  if (!is.na(gallery)) message('Wrote public visualization gallery: ', gallery)
  invisible(results)
}


# METHODOLOGY_V2_FIGURE18_SCHEMA_FALLBACK_V1
# Figure 18 compatibility contract. Methodology v2 may retain the validated
# AI-channel columns while omitting the older manual/cognitive/interpersonal
# proxy columns. This override uses documented aliases when available and
# otherwise plots the validated channels that actually exist. It never guesses
# units or fabricates missing task-type shares.
.atlas_v2_copy_first_alias <- function(x, target, aliases) {
  if (target %in% names(x)) return(x)
  hit <- aliases[aliases %in% names(x)]
  if (length(hit)) x[[target]] <- x[[hit[[1L]]]]
  x
}

.atlas_v2_weighted_mean <- function(x, w) {
  x <- suppressWarnings(as.numeric(x))
  w <- suppressWarnings(as.numeric(w))
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  sum(x[ok] * w[ok]) / sum(w[ok])
}

.atlas_v2_figure18_placeholder <- function(message_text) {
  ggplot2::ggplot() +
    ggplot2::annotate(
      "text", x = 0.5, y = 0.5, label = message_text,
      family = atlas_font_family(), color = atlas_brand()$black,
      size = 4, hjust = 0.5, vjust = 0.5
    ) +
    ggplot2::xlim(0, 1) + ggplot2::ylim(0, 1) +
    ggplot2::labs(
      title = "Occupation-group task and AI channel profile",
      subtitle = "No compatible occupation-level channel fields were available for this build.",
      caption = "The figure is retained as a diagnostic rather than displaying invented values."
    ) +
    plot_theme_public(base_size = 10) +
    ggplot2::theme(axis.text = ggplot2::element_blank(), axis.ticks = ggplot2::element_blank(),
                   panel.grid = ggplot2::element_blank())
}

plot_18_soc_task_channel_heatmap <- function(data) {
  if (is.null(data$occ_scores) || !nrow(data$occ_scores)) {
    return(.atlas_v2_figure18_placeholder("Occupation score data were not available."))
  }

  occ <- as.data.frame(data$occ_scores, stringsAsFactors = FALSE)

  # Normalize common Methodology v2 aliases without creating synthetic values.
  alias_map <- list(
    manual_share_proxy = c("manual_task_share", "task_manual_share", "manual_share", "manual_task_proxy"),
    cognitive_share_proxy = c("cognitive_task_share", "task_cognitive_share", "cognitive_share", "cognitive_task_proxy"),
    interpersonal_share_proxy = c("interpersonal_task_share", "task_interpersonal_share", "interpersonal_share", "interpersonal_task_proxy"),
    automation_exposure = c("automation_exposure_local", "automation_score"),
    augmentation_potential = c("augmentation_potential_local", "augmentation_score"),
    expertise_leveling_potential = c("expertise_leveling_potential_local", "expertise_leveling_score"),
    new_task_opportunity = c("new_task_opportunity_local", "new_task_score"),
    pro_worker_opportunity = c("pro_worker_opportunity_local", "pro_worker_score"),
    physical_ai_exposure = c("physical_digital_ai_exposure", "physical_digital_exposure"),
    language_cognitive_ai_exposure = c("language_cognitive_exposure", "cognitive_ai_exposure")
  )
  for (target in names(alias_map)) {
    occ <- .atlas_v2_copy_first_alias(occ, target, alias_map[[target]])
  }

  if (!"soc_code" %in% names(occ)) {
    code_hit <- intersect(c("onet_soc_code", "occupation_code", "occ_code"), names(occ))
    if (length(code_hit)) occ$soc_code <- occ[[code_hit[[1L]]]]
  }
  if (!"soc_code" %in% names(occ)) {
    return(.atlas_v2_figure18_placeholder("A SOC occupation code was not available."))
  }

  weight_hit <- intersect(
    c("state_emp", "estimated_jobs", "total_employment", "employment", "jobs"),
    names(occ)
  )
  if (length(weight_hit)) {
    occ$.__atlas_plot_weight <- suppressWarnings(as.numeric(occ[[weight_hit[[1L]]]]))
  } else {
    occ$.__atlas_plot_weight <- 1
  }
  occ$.__atlas_plot_weight[!is.finite(occ$.__atlas_plot_weight) | occ$.__atlas_plot_weight <= 0] <- 1

  preferred <- c(
    "manual_share_proxy", "cognitive_share_proxy", "interpersonal_share_proxy",
    "automation_exposure", "augmentation_potential",
    "expertise_leveling_potential", "new_task_opportunity",
    "pro_worker_opportunity", "language_cognitive_ai_exposure",
    "physical_ai_exposure"
  )
  cols <- intersect(preferred, names(occ))
  cols <- cols[vapply(cols, function(nm) {
    z <- suppressWarnings(as.numeric(occ[[nm]]))
    any(is.finite(z))
  }, logical(1))]

  if (length(cols) < 2L) {
    return(.atlas_v2_figure18_placeholder("Fewer than two validated channel fields were available."))
  }

  # Methodology v2 defines these fields as proportions in [0,1]. Fail rather
  # than silently rescaling an invalid unit.
  for (nm in cols) {
    occ[[nm]] <- suppressWarnings(as.numeric(occ[[nm]]))
    bad <- is.finite(occ[[nm]]) & (occ[[nm]] < -1e-8 | occ[[nm]] > 1 + 1e-8)
    if (any(bad)) {
      stop("Figure 18 received out-of-schema values in `", nm, "`; expected proportions in [0,1].", call. = FALSE)
    }
  }

  soc_major_lookup <- tibble::tribble(
    ~soc2, ~soc_group,
    "11", "Management", "13", "Business & financial", "15", "Computer & math",
    "17", "Architecture & engineering", "19", "Science", "21", "Community/social service",
    "23", "Legal", "25", "Education", "27", "Arts/media", "29", "Healthcare practitioners",
    "31", "Healthcare support", "33", "Protective service", "35", "Food preparation",
    "37", "Cleaning/maintenance", "39", "Personal care/service", "41", "Sales",
    "43", "Office/admin", "45", "Farming/fishing/forestry", "47", "Construction/extraction",
    "49", "Installation/repair", "51", "Production", "53", "Transportation"
  )

  x <- occ |>
    dplyr::mutate(
      soc_code = as.character(soc_code),
      soc2 = stringr::str_sub(soc_code, 1, 2)
    ) |>
    dplyr::left_join(soc_major_lookup, by = "soc2") |>
    dplyr::filter(!is.na(soc_group), is.finite(.__atlas_plot_weight), .__atlas_plot_weight > 0) |>
    dplyr::group_by(soc_group) |>
    dplyr::summarise(
      dplyr::across(
        dplyr::all_of(cols),
        ~.atlas_v2_weighted_mean(.x, .__atlas_plot_weight)
      ),
      jobs = sum(.__atlas_plot_weight, na.rm = TRUE),
      .groups = "drop"
    ) |>
    tidyr::pivot_longer(dplyr::all_of(cols), names_to = "metric", values_to = "score") |>
    dplyr::filter(is.finite(score))

  if (!nrow(x)) {
    return(.atlas_v2_figure18_placeholder("No finite occupation-group channel scores remained after validation."))
  }

  label_map <- c(
    manual_share_proxy = "Manual-task proxy",
    cognitive_share_proxy = "Cognitive-task proxy",
    interpersonal_share_proxy = "Interpersonal-task proxy",
    automation_exposure = "Automation exposure",
    augmentation_potential = "Augmentation potential",
    expertise_leveling_potential = "Expertise leveling",
    new_task_opportunity = "New-task opportunity",
    pro_worker_opportunity = "Pro-worker opportunity",
    language_cognitive_ai_exposure = "Language/cognitive AI",
    physical_ai_exposure = "Physical-digital AI"
  )
  x$metric <- unname(label_map[x$metric])
  x$metric[is.na(x$metric)] <- "Other validated channel"
  jobs_by_group <- stats::setNames(x$jobs, x$soc_group)
  x$soc_group <- forcats::fct_reorder(x$soc_group, unname(jobs_by_group[as.character(x$soc_group)]))

  has_task_proxies <- any(c("manual_share_proxy", "cognitive_share_proxy", "interpersonal_share_proxy") %in% cols)
  subtitle_text <- if (has_task_proxies) {
    "Employment-weighted task-type proxies and validated AI transition channels by major occupation group."
  } else {
    "Employment-weighted validated AI transition channels by major occupation group; legacy task-share proxies were not retained in this build."
  }
  caption_text <- if (has_task_proxies) {
    "Task-type proxies and AI channels come from the versioned O*NET scoring pipeline."
  } else {
    "No task-type shares were imputed. The figure displays only fields present in the validated Methodology v2 occupation-score table."
  }

  ggplot2::ggplot(x, ggplot2::aes(x = metric, y = soc_group, fill = score)) +
    ggplot2::geom_tile(color = "white", linewidth = 0.35) +
    ggplot2::geom_text(
      ggplot2::aes(label = scales::percent(score, accuracy = 1)),
      size = 2.4, color = atlas_brand()$black,
      family = atlas_font_family(), na.rm = TRUE
    ) +
    atlas_color_scale_continuous(labels = atlas_axis_percent(accuracy = 1)) +
    ggplot2::labs(
      title = "Occupation-group task and AI channel profile",
      subtitle = subtitle_text,
      x = NULL, y = NULL, fill = "Score", caption = caption_text
    ) +
    plot_theme_public(base_size = 10) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 35, hjust = 1))
}

if (sys.nframe() == 0) {
  make_public_visualizations(install_missing = TRUE, build_if_missing = TRUE, refresh = FALSE)
}
