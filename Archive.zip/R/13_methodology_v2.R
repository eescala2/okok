
# Methodology v2 skill-feature matrix dimension contract -----------------
# Matrix subsetting in base R drops dimensions when one column survives.
# This helper restores the intended occupation-by-feature matrix before
# SOC row names are assigned, while refusing ambiguous reshaping.
v2_skill_feature_matrix_contract <- function(x, row_ids, context = "skill transitions") {
  row_ids <- as.character(row_ids)
  n_ids <- length(row_ids)

  if (n_ids == 0L) {
    return(matrix(numeric(), nrow = 0L, ncol = 0L,
                  dimnames = list(character(), character())))
  }

  if (is.data.frame(x)) x <- as.matrix(x)

  if (is.null(dim(x))) {
    n_values <- length(x)

    if (n_values == n_ids) {
      # The common one-feature case: a matrix subset was simplified to a
      # vector. Restore one row per occupation and one feature column.
      x <- matrix(x, nrow = n_ids, ncol = 1L)
    } else if (n_ids == 1L && n_values > 0L) {
      x <- matrix(x, nrow = 1L)
    } else if (n_values > 0L && n_values %% n_ids == 0L) {
      # A flattened multi-feature matrix can be restored only when its
      # length is an exact multiple of the number of occupations.
      x <- matrix(x, nrow = n_ids)
    } else {
      stop(
        sprintf(
          paste0(
            "%s produced an undimensioned feature object of length %s " ,
            "for %s SOC rows; the orientation cannot be recovered safely."
          ),
          context, n_values, n_ids
        ),
        call. = FALSE
      )
    }
  } else {
    x <- as.matrix(x)
  }

  # Recover a transposed occupation-by-feature matrix when unambiguous.
  if (nrow(x) != n_ids && ncol(x) == n_ids) x <- t(x)

  if (nrow(x) != n_ids) {
    stop(
      sprintf(
        paste0(
          "%s feature matrix has %s rows and %s columns, but %s SOC " ,
          "identifiers were supplied."
        ),
        context, nrow(x), ncol(x), n_ids
      ),
      call. = FALSE
    )
  }

  # Skill-distance calculations require numeric features. Coerce only
  # values that are genuinely numeric; fail on hidden text columns.
  if (!is.numeric(x)) {
    old_dim <- dim(x)
    old_dimnames <- dimnames(x)
    x_chr <- as.character(x)
    x_num <- suppressWarnings(as.numeric(x_chr))
    nonnumeric <- is.na(x_num) & !is.na(x_chr) & nzchar(trimws(x_chr))
    if (any(nonnumeric)) {
      examples <- unique(x_chr[nonnumeric])
      examples <- head(examples, 5L)
      stop(
        paste0(
          context, " feature matrix contains nonnumeric values: ",
          paste(examples, collapse = ", ")
        ),
        call. = FALSE
      )
    }
    x <- matrix(x_num, nrow = old_dim[[1L]], ncol = old_dim[[2L]],
                dimnames = old_dimnames)
  }

  if (is.null(colnames(x))) {
    colnames(x) <- paste0("skill_feature_", seq_len(ncol(x)))
  }

  bad_ids <- is.na(row_ids) | !nzchar(trimws(row_ids))
  if (any(bad_ids)) {
    row_ids[bad_ids] <- paste0("missing_soc_", which(bad_ids))
  }
  rownames(x) <- make.unique(row_ids)
  x
}


# Methodology v2 reliability employment-support contract (all sites) -------
v2_ensure_reliability_jobs_all_sites <- function(.data) {
  stopifnot(is.data.frame(.data))
  n <- nrow(.data)
  to_num <- function(x) suppressWarnings(as.numeric(as.character(x)))

  if ("estimated_jobs" %in% names(.data)) {
    .data[["estimated_jobs"]] <- to_num(.data[["estimated_jobs"]])
    return(.data)
  }

  aliases <- c(
    "total_estimated_jobs", "total_jobs", "county_estimated_jobs",
    "county_jobs", "county_total_jobs", "employment_support",
    "estimated_employment", "modeled_employment",
    "total_employment", "county_total_employment",
    "support_jobs", "base_jobs", "all_jobs", "jobs"
  )
  hit <- aliases[aliases %in% names(.data)]
  if (length(hit)) {
    .data[["estimated_jobs"]] <- to_num(.data[[hit[[1L]]]])
    return(.data)
  }

  if (all(c("actionable_jobs", "monitor_jobs") %in% names(.data))) {
    .data[["estimated_jobs"]] <-
      to_num(.data[["actionable_jobs"]]) +
      to_num(.data[["monitor_jobs"]])
    return(.data)
  }

  share_names <- c("actionable_job_share", "actionable_share")
  share_hit <- share_names[share_names %in% names(.data)]
  if ("actionable_jobs" %in% names(.data) && length(share_hit)) {
    aj <- to_num(.data[["actionable_jobs"]])
    sh <- to_num(.data[[share_hit[[1L]]]])
    .data[["estimated_jobs"]] <- ifelse(
      is.finite(sh) & sh > 0, aj / sh, NA_real_
    )
    return(.data)
  }

  # Absence of an employment support measure is itself low reliability. Do
  # not invent a count. NA causes threshold conditions to evaluate as false,
  # so a final TRUE ~ "C" rule remains conservative. Preserve an audit flag.
  .data[["estimated_jobs"]] <- rep(NA_real_, n)
  .data[["reliability_support_missing"]] <- rep(TRUE, n)
  warning(
    paste0(
      "No explicit employment-support field survived before a reliability ",
      "classification. estimated_jobs was set to NA and the estimate should ",
      "be treated as reliability class C. Available columns: ",
      paste(names(.data), collapse = ", ")
    ),
    call. = FALSE
  )
  .data
}


# Methodology v2 reliability employment-support contract --------------------
# Reliability classes require the modeled employment support used to judge
# whether an estimate is sufficiently large and stable. Preserve the canonical
# estimated_jobs field; accept only explicit, documented aliases when an
# earlier summary uses a different name. Never infer support from score size.
v2_ensure_reliability_jobs <- function(.data) {
  stopifnot(is.data.frame(.data))

  to_numeric <- function(x) suppressWarnings(as.numeric(as.character(x)))

  if ("estimated_jobs" %in% names(.data)) {
    .data[["estimated_jobs"]] <- to_numeric(.data[["estimated_jobs"]])
    return(.data)
  }

  # Ordered from most explicit county-total names to more general aliases.
  aliases <- c(
    "total_estimated_jobs",
    "total_jobs",
    "county_estimated_jobs",
    "county_jobs",
    "employment_support",
    "estimated_employment",
    "modeled_employment",
    "jobs"
  )
  alias <- aliases[aliases %in% names(.data)]

  if (length(alias)) {
    .data[["estimated_jobs"]] <- to_numeric(.data[[alias[[1L]]]])
    return(.data)
  }

  # A county action summary may store the total in two explicit pieces.
  if (all(c("actionable_jobs", "monitor_jobs") %in% names(.data))) {
    .data[["estimated_jobs"]] <-
      to_numeric(.data[["actionable_jobs"]]) +
      to_numeric(.data[["monitor_jobs"]])
    return(.data)
  }

  # If only actionable jobs and their share survive, recover the documented
  # total algebraically. Zero-share rows cannot identify a total and remain NA.
  share_names <- c("actionable_job_share", "actionable_share")
  share_name <- share_names[share_names %in% names(.data)]
  if ("actionable_jobs" %in% names(.data) && length(share_name)) {
    aj <- to_numeric(.data[["actionable_jobs"]])
    sh <- to_numeric(.data[[share_name[[1L]]]])
    .data[["estimated_jobs"]] <- ifelse(
      is.finite(sh) & sh > 0,
      aj / sh,
      NA_real_
    )
    return(.data)
  }

  stop(
    paste0(
      "Reliability classification requires an employment-support field, but ",
      "none was available after the upstream transformation. Expected ",
      "estimated_jobs or an explicit total-jobs alias. Available columns: ",
      paste(names(.data), collapse = ", ")
    ),
    call. = FALSE
  )
}


# Methodology v2 grouped-branch compatibility helper -------------------------
# A county x industry group has one scalar decision about whether local shares
# are usable, but the selected branch contains one value per occupation row.
# dplyr::if_else() sizes branches to the scalar condition; this helper instead
# uses scalar control flow for scalar conditions and dplyr::if_else() otherwise.
atlas_group_if_else <- function(condition, true, false, missing = NULL,
                                ptype = NULL, size = NULL) {
  condition <- as.logical(condition)

  if (length(condition) == 1L) {
    if (isTRUE(condition)) return(true)
    if (identical(condition, FALSE)) return(false)

    if (!is.null(missing)) return(missing)

    # Preserve a common vector type when the scalar condition is NA.
    prototype <- vctrs::vec_ptype_common(true, false)
    return(vctrs::vec_init(prototype, max(length(true), length(false), 1L)))
  }

  dplyr::if_else(
    condition = condition,
    true = true,
    false = false,
    missing = missing,
    ptype = ptype,
    size = size
  )
}

# 13_methodology_v2.R -------------------------------------------------------
# Methodology v2 for the Iowa AI Workforce Atlas.
#
# This layer preserves the public-data and reporting workflow while addressing
# the principal audit findings:
#   * explicit score units and typed schemas (no unit guessing),
#   * versioned configuration instead of hard-coded thresholds/geography,
#   * task-importance-weighted mean exposure and concentration,
#   * a separate physical-AI channel,
#   * empirical-Bayes partial pooling and uncertainty/reliability classes,
#   * threshold sensitivity and county actionable-job profiles,
#   * a multi-component training-capacity proxy,
#   * observed-adoption inputs kept separate from technical exposure,
#   * deterministic training rankings and skill-transition pathways.
#
# The estimates remain synthetic planning estimates. They are not official
# county-SOC employment counts and are not job-loss forecasts.

source(file.path(project_root(), 'R', '00_setup.R'))
source(file.path(project_root(), 'R', '01_lwda_crosswalk.R'))
source(file.path(project_root(), 'R', '02_data_download.R'))
source(file.path(project_root(), 'R', '03_ai_scores.R'))
source(file.path(project_root(), 'R', '04_build_atlas.R'))

v2_clip01 <- function(x) pmin(1, pmax(0, suppressWarnings(as.numeric(x))))

v2_weighted_mean <- function(x, w) {
  x <- suppressWarnings(as.numeric(x)); w <- suppressWarnings(as.numeric(w))
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  stats::weighted.mean(x[ok], w[ok])
}

v2_weighted_var <- function(x, w) {
  x <- suppressWarnings(as.numeric(x)); w <- suppressWarnings(as.numeric(w))
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (sum(ok) < 2L) return(0)
  mu <- stats::weighted.mean(x[ok], w[ok])
  sum(w[ok] * (x[ok] - mu)^2) / sum(w[ok])
}

v2_mode_char <- function(x, default = NA_character_) {
  x <- as.character(x)
  x <- x[!is.na(x) & nzchar(x)]
  if (!length(x)) return(default)
  tab <- sort(table(x), decreasing = TRUE)
  names(tab)[[1L]]
}

v2_require_unit_interval <- function(x, label = deparse(substitute(x)), allow_missing = TRUE) {
  y <- suppressWarnings(as.numeric(x))
  bad <- is.finite(y) & (y < -1e-9 | y > 1 + 1e-9)
  if (any(bad)) {
    stop(label, ' must use explicit proportion units in [0,1]; found ', sum(bad),
         ' out-of-range values. No automatic percent-to-proportion conversion is performed.', call. = FALSE)
  }
  if (!isTRUE(allow_missing) && any(!is.finite(y))) {
    stop(label, ' contains missing/non-finite values but the schema does not allow them.', call. = FALSE)
  }
  y
}

v2_weighted_quantile <- function(x, w, probs) {
  x <- suppressWarnings(as.numeric(x)); w <- suppressWarnings(as.numeric(w))
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(rep(NA_real_, length(probs)))
  x <- x[ok]; w <- w[ok]
  ord <- order(x, na.last = NA)
  x <- x[ord]; w <- w[ord]
  cw <- cumsum(w) / sum(w)
  vapply(probs, function(p) x[which(cw >= p)[1L]], numeric(1))
}

v2_percent_rank <- function(x) {
  x <- suppressWarnings(as.numeric(x))
  out <- rep(NA_real_, length(x))
  ok <- is.finite(x)
  if (sum(ok) == 1L) out[ok] <- 0.5
  if (sum(ok) > 1L) out[ok] <- rank(x[ok], ties.method = 'average') / (sum(ok) + 1)
  out
}

v2_saturate <- function(x, scale = 2) {
  x <- pmax(0, suppressWarnings(as.numeric(x)))
  1 - exp(-x / max(scale, 1e-6))
}

v2_linear_score <- function(df, weights, label = 'configured linear score') {
  weights <- unlist(weights)
  if (!length(weights)) stop(label, ' has no configured weights.', call. = FALSE)
  missing <- setdiff(names(weights), names(df))
  if (length(missing)) stop(label, ' references missing columns: ', paste(missing, collapse = ', '), call. = FALSE)
  out <- rep(0, nrow(df))
  for (nm in names(weights)) out <- out + as.numeric(weights[[nm]]) * suppressWarnings(as.numeric(df[[nm]]))
  out
}

v2_methodology_paths <- function() {
  p <- paths()
  list(
    root = p$root,
    config_dir = file.path(p$root, 'config'),
    templates = file.path(p$inputs, 'templates'),
    outputs = file.path(p$outputs, 'methodology_v2'),
    figures = file.path(p$figures, 'methodology_v2'),
    processed = p$processed,
    raw = p$raw
  )
}

load_methodology_v2_config <- function() {
  p <- v2_methodology_paths()
  fs::dir_create(c(p$config_dir, p$templates, p$outputs, p$figures))
  f <- file.path(p$config_dir, 'methodology_v2.yml')
  if (!file.exists(f)) stop('Missing config/methodology_v2.yml.', call. = FALSE)
  yaml::read_yaml(f)
}

v2_read_config_csv <- function(name) {
  f <- file.path(v2_methodology_paths()$config_dir, name)
  if (!file.exists(f)) stop('Missing methodology configuration file: ', f, call. = FALSE)
  readr::read_csv(f, show_col_types = FALSE, progress = FALSE)
}

v2_action_taxonomy <- function() {
  x <- v2_read_config_csv('action_taxonomy.csv')
  required <- c('action_code', 'label', 'sort_order', 'actionable', 'color')
  if (!all(required %in% names(x))) stop('config/action_taxonomy.csv is missing required fields: ', paste(setdiff(required, names(x)), collapse = ', '), call. = FALSE)
  x |>
    dplyr::mutate(
      action_code = as.character(action_code),
      label = as.character(label),
      sort_order = as.integer(sort_order),
      actionable = as.logical(actionable),
      color = as.character(color)
    ) |>
    dplyr::arrange(sort_order)
}

v2_action_label <- function(action_code) {
  tax <- v2_action_taxonomy()
  out <- tax$label[match(action_code, tax$action_code)]
  if (any(is.na(out))) stop('Unknown action code in methodology configuration: ', paste(unique(action_code[is.na(out)]), collapse = ', '), call. = FALSE)
  out
}

v2_lwda_display_name <- function(x) {
  cross <- v2_read_config_csv('lwda_combinations.csv') |>
    dplyr::select(lwda_combined, display_name) |>
    dplyr::distinct()
  lookup <- stats::setNames(cross$display_name, cross$lwda_combined)
  out <- unname(lookup[as.character(x)])
  dplyr::coalesce(out, as.character(x))
}

v2_build_id <- function(force_new = FALSE) {
  existing <- getOption('ia_atlas_build_id', NULL)
  if (!isTRUE(force_new) && !is.null(existing) && nzchar(existing)) return(existing)
  cfg_path <- file.path(v2_methodology_paths()$config_dir, 'methodology_v2.yml')
  cfg_hash <- substr(unname(tools::md5sum(cfg_path)), 1, 8)
  id <- paste0(format(Sys.time(), '%Y%m%dT%H%M%S'), '_', cfg_hash)
  options(ia_atlas_build_id = id)
  id
}

v2_resolve_refresh <- function() {
  cfg <- load_methodology_v2_config()
  mode <- tolower(as.character(cfg$build$refresh_mode %||% 'auto'))
  if (identical(mode, 'always')) return(TRUE)
  if (identical(mode, 'never')) return(FALSE)
  p <- paths()
  critical <- c(
    file.path(p$processed, 'oews_iowa_occupations.csv'),
    file.path(p$processed, 'onet_tasks.csv'),
    file.path(p$processed, 'bls_nem_occupation_industry.csv'),
    file.path(p$processed, 'acs_county_demographics.csv')
  )
  ages <- vapply(critical[file.exists(critical)], function(f) {
    as.numeric(difftime(Sys.time(), file.info(f)$mtime, units = 'days'))
  }, numeric(1))
  if (!length(ages)) return(TRUE)
  any(ages > as.numeric(cfg$build$max_cache_age_days %||% 45))
}

v2_assert_score_schema <- function(df, context = 'score table', stop_on_error = NULL) {
  cfg <- load_methodology_v2_config()
  if (is.null(stop_on_error)) stop_on_error <- isTRUE(cfg$build$fail_on_schema_error)
  schema <- v2_read_config_csv('score_schema.csv')
  issues <- list()
  for (i in seq_len(nrow(schema))) {
    nm <- schema$column[[i]]
    if (!nm %in% names(df)) {
      issues[[length(issues) + 1L]] <- tibble::tibble(column = nm, issue = 'missing column', count = nrow(df))
      next
    }
    x <- df[[nm]]
    if (!is.numeric(x)) issues[[length(issues) + 1L]] <- tibble::tibble(column = nm, issue = paste0('type is ', class(x)[1]), count = length(x))
    bad_range <- sum(is.finite(suppressWarnings(as.numeric(x))) &
                       (suppressWarnings(as.numeric(x)) < schema$minimum[[i]] - 1e-9 |
                          suppressWarnings(as.numeric(x)) > schema$maximum[[i]] + 1e-9), na.rm = TRUE)
    if (bad_range > 0) issues[[length(issues) + 1L]] <- tibble::tibble(column = nm, issue = 'outside configured range', count = bad_range)
    if (!isTRUE(schema$allow_missing[[i]])) {
      miss <- sum(!is.finite(suppressWarnings(as.numeric(x))))
      if (miss > 0) issues[[length(issues) + 1L]] <- tibble::tibble(column = nm, issue = 'missing/non-finite', count = miss)
    }
  }
  out <- dplyr::bind_rows(issues)
  if (nrow(out)) {
    msg <- paste0('Typed score-schema validation failed for ', context, ': ', paste(paste(out$column, out$issue, out$count, sep = '/'), collapse = '; '))
    if (isTRUE(stop_on_error)) stop(msg, call. = FALSE) else warning(msg, call. = FALSE)
  }
  invisible(out)
}

v2_dictionary_scores <- function(text, dictionary = v2_read_config_csv('task_channel_dictionary.csv')) {
  text <- stringr::str_to_lower(dplyr::coalesce(as.character(text), ''))
  channels <- unique(dictionary$channel)
  out <- setNames(vector('list', length(channels)), channels)
  for (channel in channels) {
    d <- dictionary[dictionary$channel == channel, , drop = FALSE]
    score <- rep(0, length(text))
    for (j in seq_len(nrow(d))) {
      hit <- stringr::str_detect(text, stringr::regex(d$pattern[[j]], ignore_case = TRUE))
      score <- score + as.numeric(hit) * as.numeric(d$weight[[j]])
    }
    out[[channel]] <- score
  }
  tibble::as_tibble(out)
}

v2_task_scores <- function(onet) {
  cfg <- load_methodology_v2_config()
  tasks <- normalize_onet_tasks(onet$tasks)
  ratings <- normalize_task_ratings(onet$task_ratings)
  im <- ratings |>
    dplyr::filter(toupper(scale_id) %in% c('IM', 'IMPORTANCE')) |>
    dplyr::group_by(soc_code, task_id) |>
    dplyr::summarise(task_importance = mean(data_value, na.rm = TRUE), .groups = 'drop')
  x <- tasks |>
    dplyr::left_join(im, by = c('soc_code', 'task_id')) |>
    dplyr::mutate(task_importance = dplyr::coalesce(task_importance, 3))
  ds <- v2_dictionary_scores(x$task_text)
  sat <- as.numeric(cfg$score_model$task_hit_saturation %||% 2)
  for (nm in names(ds)) ds[[nm]] <- v2_saturate(ds[[nm]], sat)
  x <- dplyr::bind_cols(x, ds)
  required_channels <- c('automation', 'augmentation', 'expertise', 'new_task', 'physical_ai', 'manual', 'cognitive', 'interpersonal', 'verification')
  for (nm in required_channels) if (!nm %in% names(x)) x[[nm]] <- 0
  formulas <- cfg$score_model$channel_formulas
  x$task_ai_relevance <- v2_clip01(v2_linear_score(x, formulas$task_ai_relevance, 'task_ai_relevance'))
  x$task_automation <- v2_clip01(v2_linear_score(x, formulas$task_automation, 'task_automation'))
  x$task_augmentation <- v2_clip01(v2_linear_score(x, formulas$task_augmentation, 'task_augmentation'))
  x$task_expertise_leveling <- v2_clip01(v2_linear_score(x, formulas$task_expertise_leveling, 'task_expertise_leveling'))
  x$task_new_opportunity <- v2_clip01(v2_linear_score(x, formulas$task_new_opportunity, 'task_new_opportunity'))
  x$task_physical_ai <- v2_clip01(v2_linear_score(x, formulas$task_physical_ai, 'task_physical_ai'))
  x
}

v2_occupation_scores <- function(onet, aioe = tibble::tibble(), oews = tibble::tibble()) {
  cfg <- load_methodology_v2_config()
  tasks <- v2_task_scores(onet)
  zones <- onet$job_zones
  if (nrow(zones)) {
    soc_col <- first_existing_name(zones, c('soc_code', 'o_net_soc_code', 'onet_soc_code'))
    zone_col <- first_existing_name(zones, c('job_zone', 'zone'))
    jz <- if (!is.na(soc_col) && !is.na(zone_col)) {
      zones |>
        dplyr::transmute(soc_code = clean_soc(.data[[soc_col]]), job_zone = readr::parse_number(as.character(.data[[zone_col]]))) |>
        dplyr::distinct(soc_code, .keep_all = TRUE)
    } else tibble::tibble(soc_code = character(), job_zone = numeric())
  } else jz <- tibble::tibble(soc_code = character(), job_zone = numeric())

  occ <- tasks |>
    dplyr::group_by(soc_code) |>
    dplyr::summarise(
      onet_title = first_non_missing(onet_title),
      task_count = dplyr::n(),
      mean_task_exposure = v2_weighted_mean(task_ai_relevance, task_importance),
      task_exposure_concentration = v2_clip01(as.numeric(cfg$score_model$concentration_multiplier %||% 4) * v2_weighted_var(task_ai_relevance, task_importance)),
      automation_task_mean = v2_weighted_mean(task_automation, task_importance),
      augmentation_task_mean = v2_weighted_mean(task_augmentation, task_importance),
      expertise_task_mean = v2_weighted_mean(task_expertise_leveling, task_importance),
      new_task_mean = v2_weighted_mean(task_new_opportunity, task_importance),
      physical_ai_exposure = v2_weighted_mean(task_physical_ai, task_importance),
      manual_task_share = v2_weighted_mean(manual, task_importance),
      cognitive_task_share = v2_weighted_mean(cognitive, task_importance),
      interpersonal_task_share = v2_weighted_mean(interpersonal, task_importance),
      verification_task_share = v2_weighted_mean(verification, task_importance),
      .groups = 'drop'
    ) |>
    dplyr::left_join(jz, by = 'soc_code')
  zone_min <- as.numeric(cfg$score_model$job_zone_minimum %||% 1)
  zone_max <- as.numeric(cfg$score_model$job_zone_maximum %||% 4)
  occ$job_zone_norm <- v2_clip01((pmin(dplyr::coalesce(occ$job_zone, 2), zone_max) - zone_min) / pmax(zone_max - zone_min, 1))
  occ$task_reallocation_potential <- v2_clip01(occ$task_exposure_concentration)
  formulas <- cfg$score_model$channel_formulas
  occ$automation_exposure <- v2_clip01(v2_linear_score(occ, formulas$occupation_automation, 'occupation_automation'))
  occ$augmentation_potential <- v2_clip01(v2_linear_score(occ, formulas$occupation_augmentation, 'occupation_augmentation'))
  occ$expertise_leveling_potential <- v2_clip01(v2_linear_score(occ, formulas$occupation_expertise_leveling, 'occupation_expertise_leveling'))
  occ$new_task_opportunity <- v2_clip01(v2_linear_score(occ, formulas$occupation_new_task, 'occupation_new_task'))

  weights <- unlist(cfg$score_model$pro_worker_weights)
  positive_weight_sum <- sum(weights, na.rm = TRUE)
  if (!is.finite(positive_weight_sum) || positive_weight_sum <= 0) stop('Configured pro-worker weights must sum to a positive value.', call. = FALSE)
  penalty <- as.numeric(cfg$score_model$automation_penalty %||% 0.15)
  tpw <- unlist(cfg$score_model$transition_pressure_weights)
  occ <- occ |>
    dplyr::mutate(
      pro_worker_opportunity = v2_clip01(
        (as.numeric(weights[['augmentation_potential']] %||% 0.20) * augmentation_potential +
           as.numeric(weights[['expertise_leveling_potential']] %||% 0.20) * expertise_leveling_potential +
           as.numeric(weights[['new_task_opportunity']] %||% 0.40) * new_task_opportunity +
           as.numeric(weights[['task_reallocation_potential']] %||% 0.20) * task_reallocation_potential) /
          positive_weight_sum - penalty * automation_exposure
      ),
      transition_pressure = v2_clip01(
        as.numeric(tpw[['automation_exposure']] %||% 0.60) * automation_exposure +
          as.numeric(tpw[['mean_task_exposure']] %||% 0.25) * mean_task_exposure +
          as.numeric(tpw[['physical_ai_exposure']] %||% 0.15) * physical_ai_exposure +
          as.numeric(tpw[['task_reallocation_potential']] %||% -0.20) * task_reallocation_potential
      )
    )

  if (nrow(aioe) && all(c('soc_code', 'aioe_score') %in% names(aioe))) {
    aioe2 <- aioe |>
      dplyr::transmute(soc_code = clean_soc(soc_code), aioe_external_score = suppressWarnings(as.numeric(aioe_score))) |>
      dplyr::mutate(aioe_external_percentile = v2_percent_rank(aioe_external_score)) |>
      dplyr::distinct(soc_code, .keep_all = TRUE)
    occ <- dplyr::left_join(occ, aioe2, by = 'soc_code')
  } else {
    occ$aioe_external_score <- NA_real_
    occ$aioe_external_percentile <- NA_real_
  }

  if (nrow(oews)) {
    oews2 <- oews |>
      dplyr::transmute(
        soc_code = clean_soc(soc_code),
        occupation_title = as.character(occupation_title),
        state_emp = suppressWarnings(as.numeric(state_emp)),
        hourly_mean = suppressWarnings(as.numeric(hourly_mean)),
        annual_mean = suppressWarnings(as.numeric(annual_mean)),
        hourly_median = suppressWarnings(as.numeric(hourly_median)),
        annual_median = suppressWarnings(as.numeric(annual_median))
      ) |>
      dplyr::distinct(soc_code, .keep_all = TRUE)
    occ <- dplyr::left_join(occ, oews2, by = 'soc_code')
  }
  if (!'occupation_title' %in% names(occ)) occ$occupation_title <- occ$onet_title
  occ <- occ |>
    dplyr::mutate(
      occupation_title = dplyr::coalesce(occupation_title, onet_title, soc_code),
      score_unit = 'proportion',
      score_methodology_version = as.character(cfg$methodology_version),
      score_interpretation = 'workflow pressure/opportunity; not a job-loss forecast'
    ) |>
    dplyr::arrange(dplyr::desc(transition_pressure), dplyr::desc(state_emp), soc_code)

  v2_assert_score_schema(occ, 'methodology-v2 occupation scores')
  occ
}

v2_partial_pool_jobs <- function(atlas, cfg = load_methodology_v2_config()) {
  required <- c('county_fips', 'naics2', 'soc_code', 'estimated_jobs', 'county_industry_emp', 'lwda_combined')
  if (!all(required %in% names(atlas))) stop('Atlas is missing fields required for methodology-v2 partial pooling: ', paste(setdiff(required, names(atlas)), collapse = ', '), call. = FALSE)
  prior_strength <- as.numeric(cfg$small_area$prior_strength_jobs %||% 1500)
  raw <- atlas |>
    dplyr::mutate(
      estimated_jobs_point_rake = pmax(0, as.numeric(estimated_jobs)),
      county_industry_emp = pmax(0, as.numeric(county_industry_emp)),
      raw_share = dplyr::if_else(county_industry_emp > 0, estimated_jobs_point_rake / county_industry_emp, 0)
    )
  prior <- raw |>
    dplyr::group_by(lwda_combined, naics2, soc_code) |>
    dplyr::summarise(prior_jobs = sum(estimated_jobs_point_rake, na.rm = TRUE), prior_margin = sum(county_industry_emp, na.rm = TRUE), .groups = 'drop') |>
    dplyr::mutate(prior_share = dplyr::if_else(prior_margin > 0, prior_jobs / prior_margin, 0)) |>
    dplyr::select(
      dplyr::any_of(c(
        "estimated_jobs", "total_estimated_jobs", "total_jobs",
        "county_estimated_jobs", "county_jobs", "employment_support",
        "estimated_employment", "modeled_employment", "jobs",
        "actionable_jobs", "monitor_jobs", "actionable_job_share",
        "actionable_share"
      )),lwda_combined, naics2, soc_code, prior_share)
  pooled <- raw |>
    dplyr::left_join(prior, by = c('lwda_combined', 'naics2', 'soc_code')) |>
    dplyr::mutate(
      pooling_weight = county_industry_emp / (county_industry_emp + prior_strength),
      pooled_share_unscaled = pooling_weight * raw_share + (1 - pooling_weight) * dplyr::coalesce(prior_share, raw_share)
    ) |>
    dplyr::group_by(county_fips, naics2) |>
    dplyr::mutate(
      pooled_share = atlas_group_if_else(sum(pooled_share_unscaled, na.rm = TRUE) > 0,
                                    pooled_share_unscaled / sum(pooled_share_unscaled, na.rm = TRUE), raw_share),
      estimated_jobs = county_industry_emp * pooled_share
    ) |>
    dplyr::ungroup()

  # OEWS and QWI/LODES measure different employment universes. To make the
  # simultaneous margins coherent, preserve the OEWS detailed-occupation
  # distribution while scaling its statewide total to the county-industry
  # control universe. Both raw and scaled controls are published.
  occ_benchmarks <- pooled |>
    dplyr::group_by(soc_code) |>
    dplyr::summarise(state_emp_raw_oews = max(suppressWarnings(as.numeric(state_emp)), na.rm = TRUE), .groups = 'drop') |>
    dplyr::mutate(state_emp_raw_oews = dplyr::if_else(is.infinite(state_emp_raw_oews), NA_real_, state_emp_raw_oews)) |>
    dplyr::filter(is.finite(state_emp_raw_oews), state_emp_raw_oews > 0)
  ci_targets <- pooled |>
    dplyr::group_by(county_fips, naics2) |>
    dplyr::summarise(county_industry_emp = max(county_industry_emp, na.rm = TRUE), .groups = 'drop')
  county_control_total <- sum(ci_targets$county_industry_emp, na.rm = TRUE)
  oews_control_total <- sum(occ_benchmarks$state_emp_raw_oews, na.rm = TRUE)
  benchmark_scale_factor <- if (is.finite(oews_control_total) && oews_control_total > 0) county_control_total / oews_control_total else 1
  occ_benchmarks <- occ_benchmarks |>
    dplyr::mutate(
      state_emp_benchmark = state_emp_raw_oews * benchmark_scale_factor,
      state_emp_benchmark_scale_factor = benchmark_scale_factor,
      state_emp_benchmark_definition = 'OEWS detailed-SOC distribution scaled to the QWI/LODES county-industry employment universe'
    )
  occ_targets <- occ_benchmarks |>
    dplyr::transmute(soc_code, state_emp = state_emp_benchmark)

  pooled <- rake_estimated_jobs(pooled, occ_targets, ci_targets, iter = 30) |>
    dplyr::left_join(occ_benchmarks, by = 'soc_code')

  interval_level <- as.numeric(cfg$small_area$interval_level %||% 0.95)
  interval_alpha <- (1 - interval_level) / 2
  source_factor <- dplyr::if_else(stringr::str_detect(dplyr::coalesce(as.character(pooled$emp_source), ''), 'QWI'), 1, 0.45)
  max_neff <- as.numeric(cfg$small_area$maximum_effective_n %||% 5000)
  divisor <- as.numeric(cfg$small_area$effective_jobs_divisor %||% 25)
  pooled |>
    v2_ensure_reliability_jobs() |>
    dplyr::mutate(
      estimated_jobs_v2 = estimated_jobs,
      source_support_factor = source_factor,
      effective_n = pmin(max_neff, pmax(5, county_industry_emp / divisor * source_support_factor)),
      posterior_share = dplyr::if_else(county_industry_emp > 0, estimated_jobs_v2 / county_industry_emp, 0),
      beta_alpha = posterior_share * effective_n + 0.5,
      beta_beta = (1 - posterior_share) * effective_n + 0.5,
      estimated_jobs_lower = county_industry_emp * stats::qbeta(interval_alpha, beta_alpha, beta_beta),
      estimated_jobs_upper = county_industry_emp * stats::qbeta(1 - interval_alpha, beta_alpha, beta_beta),
      cell_interval_relative_width = (estimated_jobs_upper - estimated_jobs_lower) / pmax(estimated_jobs_v2, 1),
      cell_reliability_class = dplyr::case_when(
        stringr::str_detect(dplyr::coalesce(as.character(emp_source), ''), 'QWI') & effective_n >= as.numeric(cfg$small_area$cell_reliability_qwi_min_effective_n %||% 100) & cell_interval_relative_width <= as.numeric(cfg$small_area$cell_reliability_qwi_max_relative_width %||% 0.75) ~ 'B',
        effective_n >= as.numeric(cfg$small_area$cell_reliability_b_min_effective_n %||% 40) & cell_interval_relative_width <= as.numeric(cfg$small_area$cell_reliability_b_max_relative_width %||% 1.50) ~ 'B',
        TRUE ~ 'C'
      )
    )
}

v2_action_threshold_values <- function(atlas, scenarios = v2_read_config_csv('action_thresholds.csv')) {
  weights <- atlas$estimated_jobs
  support <- pmax(atlas$augmentation_potential, atlas$expertise_leveling_potential, atlas$task_reallocation_potential, na.rm = TRUE)
  gap <- atlas$automation_exposure - atlas$pro_worker_opportunity
  purrr::map_dfr(seq_len(nrow(scenarios)), function(i) {
    s <- scenarios[i, ]
    tibble::tibble(
      scenario = s$scenario,
      protect_automation = v2_weighted_quantile(atlas$automation_exposure, weights, s$protect_automation),
      protect_gap = v2_weighted_quantile(gap, weights, s$protect_gap),
      upgrade_automation = v2_weighted_quantile(atlas$automation_exposure, weights, s$upgrade_automation),
      upgrade_support = v2_weighted_quantile(support, weights, s$upgrade_support),
      scale_pro_worker = v2_weighted_quantile(atlas$pro_worker_opportunity, weights, s$scale_pro_worker),
      scale_new_task = v2_weighted_quantile(atlas$new_task_opportunity, weights, s$scale_new_task),
      description = s$description
    )
  })
}

v2_classify_actions <- function(atlas, threshold_values) {
  gap <- atlas$automation_exposure - atlas$pro_worker_opportunity
  support <- pmax(atlas$augmentation_potential, atlas$expertise_leveling_potential, atlas$task_reallocation_potential, na.rm = TRUE)
  protect_label <- v2_action_label('protect')
  upgrade_label <- v2_action_label('upgrade')
  scale_label <- v2_action_label('scale')
  monitor_label <- v2_action_label('monitor')
  out <- atlas
  for (i in seq_len(nrow(threshold_values))) {
    t <- threshold_values[i, ]
    nm <- paste0('transition_priority_', make.names(t$scenario))
    out[[nm]] <- dplyr::case_when(
      atlas$automation_exposure >= t$protect_automation & gap >= t$protect_gap ~ protect_label,
      atlas$automation_exposure >= t$upgrade_automation & support >= t$upgrade_support ~ upgrade_label,
      atlas$pro_worker_opportunity >= t$scale_pro_worker | atlas$new_task_opportunity >= t$scale_new_task ~ scale_label,
      TRUE ~ monitor_label
    )
  }
  baseline <- 'transition_priority_balanced'
  if (!baseline %in% names(out)) baseline <- grep('^transition_priority_', names(out), value = TRUE)[1]
  out$transition_priority <- out[[baseline]]
  taxonomy <- v2_action_taxonomy()
  out$transition_priority_code <- taxonomy$action_code[match(out$transition_priority, taxonomy$label)]
  out$actionable <- out$transition_priority != monitor_label
  out$risk_opportunity_gap <- gap
  out
}

v2_geo_metric_long <- function(atlas, group_vars, cfg = load_methodology_v2_config()) {
  metrics <- c('automation_exposure', 'augmentation_potential', 'expertise_leveling_potential', 'new_task_opportunity', 'pro_worker_opportunity', 'transition_pressure', 'physical_ai_exposure')
  floor_qwi <- as.numeric(cfg$small_area$uncertainty_floor_qwi %||% 0.012)
  floor_lodes <- as.numeric(cfg$small_area$uncertainty_floor_lodes %||% 0.025)
  z_value <- stats::qnorm(0.5 + as.numeric(cfg$small_area$interval_level %||% 0.95) / 2)
  atlas |>
    dplyr::group_by(dplyr::across(dplyr::all_of(group_vars))) |>
    dplyr::group_modify(function(.x, .y) {
      jobs <- .x$estimated_jobs
      qwi_share <- sum(jobs[stringr::str_detect(dplyr::coalesce(as.character(.x$emp_source), ''), 'QWI')], na.rm = TRUE) / sum(jobs, na.rm = TRUE)
      floor <- qwi_share * floor_qwi + (1 - qwi_share) * floor_lodes
      neff <- pmin(10000, sum(.x$effective_n, na.rm = TRUE))
      purrr::map_dfr(metrics, function(metric) {
        mu <- v2_weighted_mean(.x[[metric]], jobs)
        vv <- v2_weighted_var(.x[[metric]], jobs)
        se <- sqrt(vv / pmax(neff, 10) + floor^2)
        tibble::tibble(metric = metric, estimate_raw = mu, standard_error = se,
                       lower_raw = v2_clip01(mu - z_value * se), upper_raw = v2_clip01(mu + z_value * se),
                       effective_n = neff, qwi_job_share = qwi_share,
                       estimated_jobs = sum(jobs, na.rm = TRUE))
      })
    }) |>
    dplyr::ungroup()
}

v2_widen_metric_summary <- function(long) {
  estimates <- long |>
    dplyr::select(-standard_error, -effective_n, -qwi_job_share, -estimated_jobs) |>
    tidyr::pivot_wider(names_from = metric, values_from = c(estimate_raw, lower_raw, upper_raw), names_glue = '{metric}_{.value}')
  meta <- long |>
    dplyr::group_by(dplyr::across(-c(metric, estimate_raw, standard_error, lower_raw, upper_raw))) |>
    dplyr::slice(1) |>
    dplyr::ungroup() |>
    dplyr::select(-metric, -estimate_raw, -standard_error, -lower_raw, -upper_raw)
  keys <- intersect(names(meta), names(estimates))
  dplyr::left_join(meta, estimates, by = keys)
}

v2_county_summary <- function(atlas, capacity = tibble::tibble(), cfg = load_methodology_v2_config()) {
  protect_label <- v2_action_label('protect'); upgrade_label <- v2_action_label('upgrade'); scale_label <- v2_action_label('scale'); monitor_label <- v2_action_label('monitor')
  long <- v2_geo_metric_long(atlas, c('county_fips', 'county_name', 'lwda_combined'), cfg)
  lwda_prior <- v2_geo_metric_long(atlas, c('lwda_combined'), cfg) |>
    dplyr::select(lwda_combined, metric, lwda_estimate = estimate_raw, lwda_se = standard_error)
  prior_strength <- as.numeric(cfg$small_area$county_prior_strength %||% 1200)
  z_value <- stats::qnorm(0.5 + as.numeric(cfg$small_area$interval_level %||% 0.95) / 2)
  pooled <- long |>
    dplyr::left_join(lwda_prior, by = c('lwda_combined', 'metric')) |>
    dplyr::mutate(
      shrinkage_weight = estimated_jobs / (estimated_jobs + prior_strength),
      estimate = v2_clip01(shrinkage_weight * estimate_raw + (1 - shrinkage_weight) * lwda_estimate),
      standard_error_pooled = sqrt((shrinkage_weight * standard_error)^2 + ((1 - shrinkage_weight) * lwda_se)^2),
      lower = v2_clip01(estimate - z_value * standard_error_pooled),
      upper = v2_clip01(estimate + z_value * standard_error_pooled)
    )
  county_meta <- pooled |>
    dplyr::group_by(county_fips, county_name, lwda_combined) |>
    dplyr::summarise(
      qwi_job_share = max(qwi_job_share, na.rm = TRUE),
      effective_n = max(effective_n, na.rm = TRUE),
      .groups = 'drop'
    )
  wide <- pooled |>
    dplyr::select(county_fips, county_name, lwda_combined, metric, estimate, lower, upper, estimate_raw) |>
    tidyr::pivot_wider(names_from = metric, values_from = c(estimate, lower, upper, estimate_raw), names_glue = '{metric}_{.value}')

  action_jobs <- atlas |>
    dplyr::group_by(county_fips, county_name, lwda_combined, transition_priority) |>
    dplyr::summarise(action_jobs = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop')
  totals <- action_jobs |>
    dplyr::group_by(county_fips, county_name, lwda_combined) |>
    dplyr::summarise(estimated_jobs = sum(action_jobs), .groups = 'drop')
  actions <- action_jobs |>
    dplyr::left_join(totals, by = c('county_fips', 'county_name', 'lwda_combined')) |>
    dplyr::mutate(action_share = action_jobs / estimated_jobs)
  dominant <- actions |>
    dplyr::group_by(county_fips, county_name, lwda_combined) |>
    dplyr::slice_max(action_jobs, n = 1, with_ties = FALSE) |>
    dplyr::transmute(county_fips, county_name, lwda_combined, dominant_action = transition_priority)
  nonmonitor <- actions |>
    dplyr::filter(transition_priority != monitor_label) |>
    dplyr::group_by(county_fips, county_name, lwda_combined) |>
    dplyr::slice_max(action_jobs, n = 1, with_ties = FALSE) |>
    dplyr::transmute(county_fips, county_name, lwda_combined,
                     largest_non_monitor_action = transition_priority,
                     largest_non_monitor_jobs = action_jobs,
                     largest_non_monitor_share = action_share)
  action_profile <- actions |>
    dplyr::group_by(county_fips, county_name, lwda_combined) |>
    dplyr::summarise(
      estimated_jobs = sum(action_jobs, na.rm = TRUE),
      actionable_jobs = sum(action_jobs[transition_priority != monitor_label], na.rm = TRUE),
      actionable_share = sum(action_share[transition_priority != monitor_label], na.rm = TRUE),
      protective_redesign_jobs = sum(action_jobs[transition_priority == protect_label], na.rm = TRUE),
      upgrade_training_jobs = sum(action_jobs[transition_priority == upgrade_label], na.rm = TRUE),
      scale_opportunity_jobs = sum(action_jobs[transition_priority == scale_label], na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::left_join(dominant, by = c('county_fips', 'county_name', 'lwda_combined')) |>
    dplyr::left_join(nonmonitor, by = c('county_fips', 'county_name', 'lwda_combined')) |>
    dplyr::mutate(
      largest_non_monitor_action = dplyr::coalesce(largest_non_monitor_action, monitor_label),
      largest_non_monitor_jobs = dplyr::coalesce(largest_non_monitor_jobs, 0),
      largest_non_monitor_share = dplyr::coalesce(largest_non_monitor_share, 0)
    )

  top_cells <- atlas |>
    dplyr::filter(transition_priority != monitor_label) |>
    dplyr::group_by(county_fips, county_name, lwda_combined, transition_priority, iowa_priority_sector, soc_code, occupation_title) |>
    dplyr::summarise(estimated_jobs = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop') |>
    dplyr::left_join(nonmonitor |> dplyr::select(
      # M2_RELIABILITY_SUPPORT_FIELDS_ALL_SITES
      dplyr::any_of(c(
        "estimated_jobs", "total_estimated_jobs", "total_jobs",
        "county_estimated_jobs", "county_jobs",
        "county_total_jobs", "employment_support",
        "estimated_employment", "modeled_employment",
        "total_employment", "county_total_employment",
        "support_jobs", "base_jobs", "all_jobs", "jobs",
        "actionable_jobs", "monitor_jobs",
        "actionable_job_share", "actionable_share"
      )),county_fips, largest_non_monitor_action), by = 'county_fips') |>
    dplyr::filter(transition_priority == largest_non_monitor_action) |>
    dplyr::group_by(county_fips) |>
    dplyr::slice_max(estimated_jobs, n = 1, with_ties = FALSE) |>
    dplyr::transmute(county_fips,
                     top_action_sector = iowa_priority_sector,
                     top_action_soc = soc_code,
                     top_action_occupation = occupation_title,
                     top_action_cell_jobs = estimated_jobs)

  out <- wide |>
    dplyr::left_join(county_meta, by = c('county_fips', 'county_name', 'lwda_combined')) |>
    dplyr::left_join(action_profile, by = c('county_fips', 'county_name', 'lwda_combined')) |>
    dplyr::left_join(top_cells, by = 'county_fips')
  if (nrow(capacity)) out <- dplyr::left_join(out, capacity, by = c('county_fips', 'county_name'))

  key_width <- pmax(
    out$automation_exposure_upper - out$automation_exposure_lower,
    out$pro_worker_opportunity_upper - out$pro_worker_opportunity_lower,
    na.rm = TRUE
  )
  out |>
    # M2_RELIABILITY_ALL_SITES
    v2_ensure_reliability_jobs_all_sites() |>
    dplyr::mutate(
      reliability_class = dplyr::case_when(
        estimated_jobs >= as.numeric(cfg$small_area$reliability_a_min_jobs %||% 20000) &
          key_width <= as.numeric(cfg$small_area$reliability_a_max_interval_width %||% 0.055) &
          qwi_job_share >= 0.75 ~ 'A',
        estimated_jobs >= as.numeric(cfg$small_area$reliability_b_min_jobs %||% 5000) &
          key_width <= as.numeric(cfg$small_area$reliability_b_max_interval_width %||% 0.10) ~ 'B',
        TRUE ~ 'C'
      ),
      automation_exposure = automation_exposure_estimate,
      augmentation_potential = augmentation_potential_estimate,
      expertise_leveling_potential = expertise_leveling_potential_estimate,
      new_task_opportunity = new_task_opportunity_estimate,
      pro_worker_opportunity = pro_worker_opportunity_estimate,
      transition_pressure = transition_pressure_estimate,
      physical_ai_exposure = physical_ai_exposure_estimate,
      risk_opportunity_gap = automation_exposure - pro_worker_opportunity,
      protective_redesign_share = protective_redesign_jobs / estimated_jobs,
      upgrade_training_share = upgrade_training_jobs / estimated_jobs,
      scale_opportunity_share = scale_opportunity_jobs / estimated_jobs,
      lwda_display_name = v2_lwda_display_name(lwda_combined),
      methodology_version = as.character(cfg$methodology_version),
      public_interpretation = 'workflow pressure/opportunity; not a job-loss forecast'
    ) |>
    dplyr::arrange(dplyr::desc(actionable_jobs), county_name)
}

v2_lwda_summary <- function(atlas, cfg = load_methodology_v2_config()) {
  monitor_label <- v2_action_label('monitor')
  long <- v2_geo_metric_long(atlas, c('lwda_combined'), cfg)
  metrics <- long |>
    dplyr::select(lwda_combined, metric, estimate = estimate_raw, lower = lower_raw, upper = upper_raw, estimated_jobs, qwi_job_share) |>
    tidyr::pivot_wider(names_from = metric, values_from = c(estimate, lower, upper), names_glue = '{metric}_{.value}')
  action <- atlas |>
    dplyr::group_by(lwda_combined, transition_priority) |>
    dplyr::summarise(action_jobs = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop') |>
    dplyr::group_by(lwda_combined) |>
    dplyr::mutate(estimated_jobs = sum(action_jobs), action_share = action_jobs / estimated_jobs) |>
    dplyr::summarise(
      estimated_jobs = first(estimated_jobs),
      actionable_jobs = sum(action_jobs[transition_priority != monitor_label]),
      actionable_share = sum(action_share[transition_priority != monitor_label]),
      .groups = 'drop'
    )
  metrics |>
    dplyr::left_join(action, by = 'lwda_combined') |>
    # M2_RELIABILITY_ALL_SITES
    v2_ensure_reliability_jobs_all_sites() |>
    dplyr::mutate(
      automation_exposure = automation_exposure_estimate,
      augmentation_potential = augmentation_potential_estimate,
      expertise_leveling_potential = expertise_leveling_potential_estimate,
      new_task_opportunity = new_task_opportunity_estimate,
      pro_worker_opportunity = pro_worker_opportunity_estimate,
      transition_pressure = transition_pressure_estimate,
      physical_ai_exposure = physical_ai_exposure_estimate,
      risk_opportunity_gap = automation_exposure - pro_worker_opportunity,
      reliability_class = dplyr::case_when(qwi_job_share >= as.numeric(cfg$small_area$lwda_reliability_a_min_qwi_share %||% 0.75) ~ 'A', estimated_jobs >= as.numeric(cfg$small_area$lwda_reliability_b_min_jobs %||% 100000) ~ 'B', TRUE ~ 'C'),
      lwda_display_name = v2_lwda_display_name(lwda_combined),
      methodology_version = as.character(cfg$methodology_version)
    ) |>
    dplyr::arrange(dplyr::desc(estimated_jobs))
}

v2_sector_summary <- function(atlas) {
  monitor_label <- v2_action_label('monitor')
  atlas |>
    dplyr::group_by(lwda_combined, iowa_priority_sector) |>
    dplyr::summarise(
      automation_exposure = v2_weighted_mean(automation_exposure, estimated_jobs),
      augmentation_potential = v2_weighted_mean(augmentation_potential, estimated_jobs),
      expertise_leveling_potential = v2_weighted_mean(expertise_leveling_potential, estimated_jobs),
      new_task_opportunity = v2_weighted_mean(new_task_opportunity, estimated_jobs),
      pro_worker_opportunity = v2_weighted_mean(pro_worker_opportunity, estimated_jobs),
      transition_pressure = v2_weighted_mean(transition_pressure, estimated_jobs),
      physical_ai_exposure = v2_weighted_mean(physical_ai_exposure, estimated_jobs),
      task_reallocation_potential = v2_weighted_mean(task_reallocation_potential, estimated_jobs),
      hourly_mean = v2_weighted_mean(hourly_mean, estimated_jobs),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      actionable_jobs = sum(estimated_jobs[transition_priority != monitor_label], na.rm = TRUE),
      .groups = 'drop'
    ) |>
    dplyr::mutate(
      actionable_share = actionable_jobs / estimated_jobs,
      risk_opportunity_gap = automation_exposure - pro_worker_opportunity
    ) |>
    dplyr::arrange(lwda_combined, dplyr::desc(estimated_jobs))
}

v2_training_priorities <- function(atlas, cfg = load_methodology_v2_config()) {
  monitor_label <- v2_action_label('monitor')
  reliability_weight <- unlist(cfg$training_priority$reliability_weights %||% list(A = 1, B = 0.85, C = 0.65))
  capability_weights <- unlist(cfg$training_priority$capability_weights %||% list(new_task_opportunity = 0.40, expertise_leveling_potential = 0.25, augmentation_potential = 0.20, task_reallocation_potential = 0.15))
  x <- atlas |>
    dplyr::filter(transition_priority != monitor_label) |>
    dplyr::group_by(lwda_combined, iowa_priority_sector, soc_code, occupation_title, transition_priority) |>
    dplyr::summarise(
      automation_exposure = v2_weighted_mean(automation_exposure, estimated_jobs),
      augmentation_potential = v2_weighted_mean(augmentation_potential, estimated_jobs),
      expertise_leveling_potential = v2_weighted_mean(expertise_leveling_potential, estimated_jobs),
      new_task_opportunity = v2_weighted_mean(new_task_opportunity, estimated_jobs),
      pro_worker_opportunity = v2_weighted_mean(pro_worker_opportunity, estimated_jobs),
      task_reallocation_potential = v2_weighted_mean(task_reallocation_potential, estimated_jobs),
      physical_ai_exposure = v2_weighted_mean(physical_ai_exposure, estimated_jobs),
      transition_pressure = v2_weighted_mean(transition_pressure, estimated_jobs),
      hourly_mean = v2_weighted_mean(hourly_mean, estimated_jobs),
      estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
      reliability_class = v2_mode_char(cell_reliability_class, default = 'C'),
      .groups = 'drop'
    ) |>
    dplyr::mutate(
      wage_percentile = v2_percent_rank(hourly_mean),
      worker_capability_score = v2_clip01(
        as.numeric(capability_weights[['new_task_opportunity']] %||% 0.40) * new_task_opportunity +
          as.numeric(capability_weights[['expertise_leveling_potential']] %||% 0.25) * expertise_leveling_potential +
          as.numeric(capability_weights[['augmentation_potential']] %||% 0.20) * augmentation_potential +
          as.numeric(capability_weights[['task_reallocation_potential']] %||% 0.15) * task_reallocation_potential
      ),
      reliability_weight = dplyr::coalesce(unname(reliability_weight[reliability_class]), 0.65),
      priority_score = sqrt(pmax(estimated_jobs, 0)) * worker_capability_score * reliability_weight * (
        as.numeric(cfg$training_priority$wage_percentile_base %||% 0.90) +
          as.numeric(cfg$training_priority$wage_percentile_bonus %||% 0.10) * dplyr::coalesce(wage_percentile, 0.5)
      )
    ) |>
    dplyr::group_by(lwda_combined) |>
    dplyr::arrange(dplyr::desc(priority_score), dplyr::desc(estimated_jobs), occupation_title, .by_group = TRUE) |>
    dplyr::mutate(priority_rank = dplyr::row_number()) |>
    dplyr::slice_head(n = as.integer(cfg$outputs$top_training_per_lwda %||% 25)) |>
    dplyr::ungroup() |>
    dplyr::arrange(lwda_combined, priority_rank)
  x
}

get_acs_training_capacity_v2 <- function(refresh = FALSE) {
  cfg0 <- load_config(); p <- paths()
  out <- file.path(p$processed, 'acs_training_capacity_v2.csv')
  if (file.exists(out) && !refresh) return(readr::read_csv(out, show_col_types = FALSE))
  vars <- c(
    population = 'B01003_001',
    median_household_income = 'B19013_001',
    total_25plus = 'B15003_001',
    bachelor = 'B15003_022', masters = 'B15003_023', professional = 'B15003_024', doctorate = 'B15003_025',
    internet_total = 'B28002_001', broadband_any = 'B28002_004',
    households = 'B08201_001', no_vehicle = 'B08201_002',
    labor_age_total = 'B23025_001', civilian_labor_force = 'B23025_003',
    poverty_total = 'B17001_001', poverty_below = 'B17001_002'
  )
  key <- Sys.getenv('CENSUS_API_KEY')
  if (nzchar(key)) tidycensus::census_api_key(key, install = FALSE, overwrite = TRUE)
  x <- tryCatch(
    tidycensus::get_acs(geography = 'county', state = cfg0$state_fips, variables = vars,
                        year = cfg0$acs_year, survey = 'acs5', output = 'wide', cache_table = TRUE) |>
      janitor::clean_names() |>
      dplyr::transmute(
        county_fips = geoid,
        county_name = stringr::str_remove(name, ' County, Iowa'),
        population = population_e,
        median_household_income = median_household_income_e,
        share_bachelors_plus = (bachelor_e + masters_e + professional_e + doctorate_e) / total_25plus_e,
        broadband_access = broadband_any_e / internet_total_e,
        vehicle_access = 1 - no_vehicle_e / households_e,
        labor_force_participation = civilian_labor_force_e / labor_age_total_e,
        poverty_rate = poverty_below_e / poverty_total_e
      ),
    error = function(e) {
      warning('ACS training-capacity extension failed: ', conditionMessage(e), call. = FALSE)
      base <- get_acs_county_demographics(cfg0, refresh = FALSE)
      base |>
        dplyr::mutate(broadband_access = NA_real_, vehicle_access = NA_real_, labor_force_participation = NA_real_, poverty_rate = NA_real_)
    }
  )
  readr::write_csv(x, out)
  x
}

v2_training_capacity_index <- function(refresh = FALSE, cfg = load_methodology_v2_config()) {
  p <- paths()
  acs <- get_acs_training_capacity_v2(refresh = refresh)
  local_candidates <- c(
    file.path(p$inputs, 'training_capacity_local_inputs.csv'),
    file.path(p$inputs, 'templates', 'training_capacity_local_inputs_template.csv')
  )
  local_file <- local_candidates[file.exists(local_candidates)][1]
  local <- if (length(local_file) && !is.na(local_file)) readr::read_csv(local_file, show_col_types = FALSE) else tibble::tibble()
  if (nrow(local)) {
    if (!'notes' %in% names(local)) local$notes <- ''
    local <- local |>
      dplyr::mutate(county_fips = stringr::str_pad(as.character(readr::parse_number(as.character(county_fips))), 5, pad = '0')) |>
      dplyr::filter(!is.na(county_fips), !stringr::str_detect(dplyr::coalesce(notes, ''), 'Delete example'))
  }
  x <- acs |>
    dplyr::mutate(
      county_fips = stringr::str_pad(as.character(readr::parse_number(as.character(county_fips))), 5, pad = '0'),
      income_resilience = v2_percent_rank(median_household_income),
      education_foundation = v2_percent_rank(share_bachelors_plus),
      low_poverty = 1 - v2_clip01(poverty_rate)
    )
  if (nrow(local)) x <- dplyr::left_join(x, local, by = 'county_fips', suffix = c('', '_local'))
  for (nm in c('community_college_seats', 'completion_rate', 'apprenticeship_slots', 'wioa_activity', 'employer_release_time', 'childcare_access', 'travel_time_to_training_minutes')) {
    if (!nm %in% names(x)) x[[nm]] <- NA_real_
  }
  x <- x |>
    dplyr::mutate(
      community_college_seats = v2_percent_rank(community_college_seats / pmax(population, 1) * 1000),
      completion_rate = v2_clip01(completion_rate),
      apprenticeship_slots = v2_percent_rank(apprenticeship_slots / pmax(population, 1) * 1000),
      wioa_activity = v2_percent_rank(wioa_activity / pmax(population, 1) * 1000),
      employer_release_time = v2_clip01(employer_release_time),
      childcare_access = v2_clip01(childcare_access),
      travel_access = ifelse(is.finite(travel_time_to_training_minutes), 1 - v2_percent_rank(travel_time_to_training_minutes), NA_real_)
    )
  weights <- unlist(cfg$training_capacity$weights)
  component_names <- intersect(names(weights), names(x))
  mat <- as.data.frame(x[component_names])
  value <- numeric(nrow(x)); coverage <- numeric(nrow(x))
  for (i in seq_len(nrow(x))) {
    vals <- suppressWarnings(as.numeric(mat[i, ]))
    ok <- is.finite(vals)
    coverage[[i]] <- sum(weights[component_names][ok]) / sum(weights[component_names])
    value[[i]] <- if (any(ok)) sum(vals[ok] * weights[component_names][ok]) / sum(weights[component_names][ok]) else NA_real_
  }
  local_component_count <- rowSums(is.finite(as.matrix(dplyr::select(x, community_college_seats, completion_rate, apprenticeship_slots, wioa_activity))))
  x |>
    dplyr::mutate(
      training_capacity_index = v2_clip01(value),
      training_capacity_component_coverage = coverage,
      training_capacity_reliability = dplyr::case_when(
        coverage >= 0.85 & local_component_count >= 2 ~ 'A',
        coverage >= as.numeric(cfg$training_capacity$minimum_component_coverage %||% 0.50) ~ 'B',
        TRUE ~ 'C'
      ),
      training_capacity_label = 'Multi-component access/capacity proxy; local program and support data improve reliability'
    ) |>
    dplyr::select(county_fips, county_name, population, median_household_income, share_bachelors_plus,
                  broadband_access, vehicle_access, labor_force_participation, poverty_rate,
                  dplyr::any_of(c('community_college_seats', 'completion_rate', 'apprenticeship_slots', 'wioa_activity', 'employer_release_time', 'childcare_access', 'travel_access')),
                  training_capacity_index, training_capacity_component_coverage, training_capacity_reliability, training_capacity_label)
}

v2_action_sensitivity_summary <- function(atlas, threshold_values) {
  monitor_label <- v2_action_label('monitor')
  action_cols <- grep('^transition_priority_', names(atlas), value = TRUE)
  long <- atlas |>
    dplyr::select(county_fips, county_name, lwda_combined, estimated_jobs, dplyr::all_of(action_cols)) |>
    tidyr::pivot_longer(dplyr::all_of(action_cols), names_to = 'scenario', values_to = 'transition_priority') |>
    dplyr::mutate(scenario = stringr::str_remove(scenario, '^transition_priority_'))
  by_scenario <- long |>
    dplyr::group_by(county_fips, county_name, lwda_combined, scenario, transition_priority) |>
    dplyr::summarise(action_jobs = sum(estimated_jobs, na.rm = TRUE), .groups = 'drop') |>
    dplyr::group_by(county_fips, county_name, lwda_combined, scenario) |>
    dplyr::mutate(total_jobs = sum(action_jobs), action_share = action_jobs / total_jobs) |>
    dplyr::summarise(
      total_jobs = first(total_jobs),
      actionable_jobs = sum(action_jobs[transition_priority != monitor_label]),
      actionable_share = sum(action_share[transition_priority != monitor_label]),
      largest_non_monitor_action = {
        z <- which(transition_priority != monitor_label)
        if (length(z)) transition_priority[z[which.max(action_jobs[z])]] else monitor_label
      },
      .groups = 'drop'
    )
  spread <- by_scenario |>
    dplyr::group_by(county_fips, county_name, lwda_combined) |>
    dplyr::summarise(
      actionable_share_min = min(actionable_share, na.rm = TRUE),
      actionable_share_max = max(actionable_share, na.rm = TRUE),
      actionable_share_range = actionable_share_max - actionable_share_min,
      action_scenario_agreement = max(table(largest_non_monitor_action)) / dplyr::n(),
      .groups = 'drop'
    )
  list(by_scenario = by_scenario, county_range = spread, thresholds = threshold_values)
}


v2_score_weight_sensitivity <- function(atlas, cfg = load_methodology_v2_config()) {
  scenarios <- v2_read_config_csv('score_weight_scenarios.csv')
  required <- c(
    'scenario', 'augmentation_weight', 'expertise_weight', 'new_task_weight',
    'reallocation_weight', 'automation_penalty', 'pressure_automation_weight',
    'pressure_mean_weight', 'pressure_physical_weight',
    'pressure_reallocation_weight', 'description'
  )
  if (!all(required %in% names(scenarios))) {
    stop('config/score_weight_scenarios.csv is missing: ',
         paste(setdiff(required, names(scenarios)), collapse = ', '), call. = FALSE)
  }
  baseline_thresholds <- v2_action_threshold_values(atlas)
  threshold <- baseline_thresholds |>
    dplyr::filter(scenario == 'balanced') |>
    dplyr::slice_head(n = 1)
  if (!nrow(threshold)) threshold <- baseline_thresholds |> dplyr::slice_head(n = 1)

  protect_label <- v2_action_label('protect')
  upgrade_label <- v2_action_label('upgrade')
  scale_label <- v2_action_label('scale')
  monitor_label <- v2_action_label('monitor')
  support <- pmax(
    atlas$augmentation_potential,
    atlas$expertise_leveling_potential,
    atlas$task_reallocation_potential,
    na.rm = TRUE
  )

  cell_scenarios <- purrr::map_dfr(seq_len(nrow(scenarios)), function(i) {
    sw <- scenarios[i, ]
    positive_sum <- sum(c(sw$augmentation_weight, sw$expertise_weight,
                          sw$new_task_weight, sw$reallocation_weight), na.rm = TRUE)
    if (!is.finite(positive_sum) || positive_sum <= 0) {
      stop('Positive pro-worker weights must sum to more than zero for scenario ', sw$scenario, '.', call. = FALSE)
    }
    pw <- v2_clip01(
      (sw$augmentation_weight * atlas$augmentation_potential +
         sw$expertise_weight * atlas$expertise_leveling_potential +
         sw$new_task_weight * atlas$new_task_opportunity +
         sw$reallocation_weight * atlas$task_reallocation_potential) / positive_sum -
        sw$automation_penalty * atlas$automation_exposure
    )
    pressure <- v2_clip01(
      sw$pressure_automation_weight * atlas$automation_exposure +
        sw$pressure_mean_weight * atlas$mean_task_exposure +
        sw$pressure_physical_weight * atlas$physical_ai_exposure +
        sw$pressure_reallocation_weight * atlas$task_reallocation_potential
    )
    gap <- atlas$automation_exposure - pw
    action <- dplyr::case_when(
      atlas$automation_exposure >= threshold$protect_automation[[1]] & gap >= threshold$protect_gap[[1]] ~ protect_label,
      atlas$automation_exposure >= threshold$upgrade_automation[[1]] & support >= threshold$upgrade_support[[1]] ~ upgrade_label,
      pw >= threshold$scale_pro_worker[[1]] | atlas$new_task_opportunity >= threshold$scale_new_task[[1]] ~ scale_label,
      TRUE ~ monitor_label
    )
    tibble::tibble(
      county_fips = atlas$county_fips,
      county_name = atlas$county_name,
      lwda_combined = atlas$lwda_combined,
      estimated_jobs = atlas$estimated_jobs,
      scenario = as.character(sw$scenario),
      scenario_description = as.character(sw$description),
      pro_worker_opportunity = pw,
      transition_pressure = pressure,
      transition_priority = action,
      actionable = action != monitor_label
    )
  })

  summarise_level <- function(x, vars, geography_type) {
    x |>
      dplyr::group_by(dplyr::across(dplyr::all_of(c(vars, 'scenario', 'scenario_description')))) |>
      dplyr::summarise(
        pro_worker_opportunity = v2_weighted_mean(pro_worker_opportunity, estimated_jobs),
        transition_pressure = v2_weighted_mean(transition_pressure, estimated_jobs),
        actionable_jobs = sum(estimated_jobs[actionable], na.rm = TRUE),
        estimated_jobs = sum(estimated_jobs, na.rm = TRUE),
        actionable_share = actionable_jobs / estimated_jobs,
        .groups = 'drop'
      ) |>
      dplyr::mutate(geography_type = geography_type, .before = 1)
  }
  out <- dplyr::bind_rows(
    summarise_level(cell_scenarios, c('lwda_combined'), 'LWDA'),
    summarise_level(cell_scenarios, c('county_fips', 'county_name', 'lwda_combined'), 'County')
  )
  baseline <- out |>
    dplyr::filter(scenario == 'balanced') |>
    dplyr::select(
      geography_type, dplyr::any_of(c('county_fips', 'county_name', 'lwda_combined')),
      baseline_pro_worker = pro_worker_opportunity,
      baseline_pressure = transition_pressure,
      baseline_actionable_share = actionable_share
    )
  join_keys <- intersect(names(out), names(baseline))
  join_keys <- setdiff(join_keys, c('pro_worker_opportunity', 'transition_pressure', 'actionable_share'))
  join_keys <- intersect(join_keys, c('geography_type', 'county_fips', 'county_name', 'lwda_combined'))
  out |>
    dplyr::left_join(baseline, by = join_keys) |>
    dplyr::mutate(
      pro_worker_delta_from_balanced = pro_worker_opportunity - baseline_pro_worker,
      pressure_delta_from_balanced = transition_pressure - baseline_pressure,
      actionable_share_delta_from_balanced = actionable_share - baseline_actionable_share
    ) |>
    dplyr::group_by(geography_type, scenario) |>
    dplyr::mutate(
      pro_worker_rank = dplyr::min_rank(dplyr::desc(pro_worker_opportunity)),
      transition_pressure_rank = dplyr::min_rank(dplyr::desc(transition_pressure))
    ) |>
    dplyr::ungroup() |>
    dplyr::arrange(geography_type, scenario, dplyr::desc(estimated_jobs))
}

v2_find_onet_file <- function(patterns) {
  root <- file.path(paths()$raw, 'onet')
  if (!dir.exists(root)) return(NA_character_)
  files <- list.files(root, recursive = TRUE, full.names = TRUE)
  for (pat in patterns) {
    hit <- files[stringr::str_detect(basename(files), stringr::regex(pat, ignore_case = TRUE))]
    if (length(hit)) return(hit[[1]])
  }
  NA_character_
}

v2_work_activity_features <- function(onet, occ_scores) {
  wa <- onet$work_activities
  if (!nrow(wa)) {
    return(occ_scores |>
             dplyr::select(soc_code, automation_exposure, augmentation_potential, expertise_leveling_potential,
                           new_task_opportunity, task_reallocation_potential, physical_ai_exposure,
                           manual_task_share, cognitive_task_share, interpersonal_task_share))
  }
  soc_col <- first_existing_name(wa, c('soc_code', 'o_net_soc_code', 'onet_soc_code'))
  element_col <- first_existing_name(wa, c('element_id', 'element_name', 'work_activity'))
  scale_col <- first_existing_name(wa, c('scale_id', 'scale'))
  value_col <- first_existing_name(wa, c('data_value', 'value'))
  if (any(is.na(c(soc_col, element_col, value_col)))) {
    return(occ_scores |>
             dplyr::select(soc_code, automation_exposure, augmentation_potential, expertise_leveling_potential,
                           new_task_opportunity, task_reallocation_potential, physical_ai_exposure,
                           manual_task_share, cognitive_task_share, interpersonal_task_share))
  }
  x <- wa |>
    dplyr::transmute(
      soc_code = clean_soc(.data[[soc_col]]),
      feature = as.character(.data[[element_col]]),
      scale = if (!is.na(scale_col)) as.character(.data[[scale_col]]) else 'VALUE',
      value = readr::parse_number(as.character(.data[[value_col]]))
    ) |>
    dplyr::filter(stringr::str_detect(soc_code, '^\\d{2}-\\d{4}$'), is.finite(value)) |>
    dplyr::mutate(value = dplyr::case_when(toupper(scale) == 'IM' ~ value / 5, toupper(scale) == 'LV' ~ value / 7, TRUE ~ v2_percent_rank(value)),
                  feature = paste0(make.names(feature), '_', make.names(scale))) |>
    dplyr::group_by(soc_code, feature) |>
    dplyr::summarise(value = mean(value, na.rm = TRUE), .groups = 'drop') |>
    tidyr::pivot_wider(names_from = feature, values_from = value, values_fill = 0)
  dplyr::left_join(
    occ_scores |>
      dplyr::select(soc_code, automation_exposure, augmentation_potential, expertise_leveling_potential,
                    new_task_opportunity, task_reallocation_potential, physical_ai_exposure,
                    manual_task_share, cognitive_task_share, interpersonal_task_share),
    x,
    by = 'soc_code'
  ) |>
    dplyr::mutate(dplyr::across(-soc_code, ~dplyr::coalesce(as.numeric(.x), 0)))
}

v2_skill_transition_paths <- function(onet, occ_scores, cfg = load_methodology_v2_config()) {
  features <- v2_work_activity_features(onet, occ_scores)
  meta <- occ_scores |>
    dplyr::filter(is.finite(state_emp), state_emp > 0) |>
    dplyr::select(soc_code, occupation_title, state_emp, hourly_mean, job_zone,
                  automation_exposure, pro_worker_opportunity, transition_pressure, new_task_opportunity)
  features <- dplyr::inner_join(meta |> dplyr::select(soc_code), features, by = 'soc_code') |>
    dplyr::distinct(soc_code, .keep_all = TRUE)
  feature_cols <- setdiff(names(features), 'soc_code')
  if (!length(feature_cols) || nrow(features) < 2) return(tibble::tibble())
  m <- as.matrix(features[feature_cols]); storage.mode(m) <- 'double'
  m[!is.finite(m)] <- 0
  norms <- sqrt(rowSums(m^2)); norms[norms == 0] <- 1
  sim <- tcrossprod(m / norms)
  distance <- 1 - pmax(-1, pmin(1, sim))
  distance <- v2_skill_feature_matrix_contract(distance, features$soc_code, context = "v2_skill_transition_paths"); colnames(distance) <- features$soc_code
  meta <- meta |> dplyr::filter(soc_code %in% features$soc_code) |> dplyr::distinct(soc_code, .keep_all = TRUE)
  origin_cut <- v2_weighted_quantile(meta$transition_pressure, meta$state_emp, 0.65)
  origins <- meta |> dplyr::filter(transition_pressure >= origin_cut)
  max_dist <- as.numeric(cfg$skill_transitions$maximum_distance %||% 0.40)
  max_zone <- as.numeric(cfg$skill_transitions$maximum_job_zone_change %||% 1)
  min_wage_ratio <- as.numeric(cfg$skill_transitions$minimum_destination_wage_ratio %||% 0.90)
  min_emp <- as.numeric(cfg$skill_transitions$minimum_destination_state_employment %||% 250)
  n_dest <- as.integer(cfg$skill_transitions$destinations_per_origin %||% 5)
  transition_weights <- unlist(cfg$skill_transitions$transition_score_weights %||% list(skill_similarity = 1, opportunity_gain = 0.35, pressure_reduction = 0.35, wage_ratio = 0.10))
  purrr::map_dfr(seq_len(nrow(origins)), function(i) {
    o <- origins[i, ]
    d <- distance[o$soc_code, meta$soc_code]
    cand <- meta |>
      dplyr::mutate(
        origin_soc = o$soc_code,
        origin_occupation = o$occupation_title,
        origin_wage = o$hourly_mean,
        origin_transition_pressure = o$transition_pressure,
        skill_distance = as.numeric(d),
        wage_ratio = hourly_mean / pmax(o$hourly_mean, 1),
        job_zone_change = abs(dplyr::coalesce(job_zone, 2) - dplyr::coalesce(o$job_zone, 2)),
        opportunity_gain = pro_worker_opportunity - o$pro_worker_opportunity,
        pressure_reduction = o$transition_pressure - transition_pressure,
        transition_score = as.numeric(transition_weights[['skill_similarity']] %||% 1) * (1 - skill_distance) +
          as.numeric(transition_weights[['opportunity_gain']] %||% 0.35) * pmax(opportunity_gain, 0) +
          as.numeric(transition_weights[['pressure_reduction']] %||% 0.35) * pmax(pressure_reduction, 0) +
          as.numeric(transition_weights[['wage_ratio']] %||% 0.10) * pmin(wage_ratio, 1.5)
      ) |>
      dplyr::filter(
        soc_code != o$soc_code,
        skill_distance <= max_dist,
        job_zone_change <= max_zone,
        wage_ratio >= min_wage_ratio,
        state_emp >= min_emp,
        pressure_reduction > 0 | opportunity_gain > 0
      ) |>
      dplyr::arrange(dplyr::desc(transition_score), skill_distance, dplyr::desc(state_emp)) |>
      dplyr::slice_head(n = n_dest) |>
      dplyr::transmute(
        origin_soc, origin_occupation, destination_soc = soc_code, destination_occupation = occupation_title,
        skill_distance, job_zone_change, origin_wage, destination_wage = hourly_mean, wage_ratio,
        origin_transition_pressure, destination_transition_pressure = transition_pressure,
        destination_pro_worker_opportunity = pro_worker_opportunity,
        opportunity_gain, pressure_reduction, destination_state_employment = state_emp,
        transition_score, transition_basis = if (ncol(features) > 10) 'O*NET work-activity and channel profile' else 'channel-profile fallback'
      )
    cand
  })
}

v2_parse_binary_or_proportion <- function(x) {
  if (is.logical(x)) return(as.numeric(x))
  ch <- stringr::str_to_lower(stringr::str_trim(as.character(x)))
  out <- suppressWarnings(as.numeric(ch))
  out[ch %in% c('yes', 'y', 'true', 't', 'used', 'use', 'adopted')] <- 1
  out[ch %in% c('no', 'n', 'false', 'f', 'not used', 'not adopted')] <- 0
  out
}

v2_map_input_sector <- function(x) {
  x <- as.character(x)
  sector_names <- unique(industry_sector_labels()$iowa_priority_sector)
  direct <- dplyr::if_else(x %in% sector_names, x, NA_character_)
  naics <- normalize_naics2(x)
  mapped <- industry_sector_labels()$iowa_priority_sector[match(naics, industry_sector_labels()$naics2)]
  dplyr::coalesce(direct, mapped)
}

v2_read_adoption_source <- function(path, source_type) {
  if (!file.exists(path)) return(tibble::tibble())
  x <- tryCatch(readr::read_csv(path, show_col_types = FALSE, progress = FALSE), error = function(e) tibble::tibble())
  if (!nrow(x)) return(tibble::tibble())
  names(x) <- janitor::make_clean_names(names(x))
  if ('notes' %in% names(x)) {
    x <- x |> dplyr::filter(!stringr::str_detect(dplyr::coalesce(notes, ''), stringr::regex('delete example', ignore_case = TRUE)))
  }
  if ('geography_name' %in% names(x)) {
    x <- x |> dplyr::filter(is.na(geography_name) | !nzchar(geography_name) | stringr::str_detect(geography_name, stringr::regex('Iowa', ignore_case = TRUE)))
  }
  sector_col <- intersect(c('iowa_priority_sector', 'sector_key', 'sector', 'sector_name', 'naics2'), names(x))[1]
  if (is.na(sector_col)) return(tibble::tibble())
  x$iowa_priority_sector <- v2_map_input_sector(x[[sector_col]])

  if (identical(source_type, 'Iowa employer pulse')) {
    rate_col <- intersect(c('ai_use_now', 'uses_ai', 'ai_use_rate'), names(x))[1]
    expected_col <- intersect(c('expected_use_6_months', 'expected_use_6_months_rate'), names(x))[1]
    if (is.na(rate_col)) return(tibble::tibble())
    x$ai_use_value <- v2_parse_binary_or_proportion(x[[rate_col]])
    x$expected_value <- if (!is.na(expected_col)) v2_parse_binary_or_proportion(x[[expected_col]]) else NA_real_
    x$ai_use_value <- v2_require_unit_interval(x$ai_use_value, paste0(source_type, ' ai_use_now'), allow_missing = TRUE)
    x$expected_value <- v2_require_unit_interval(x$expected_value, paste0(source_type, ' expected_use_6_months'), allow_missing = TRUE)
    return(
      x |>
        dplyr::filter(!is.na(iowa_priority_sector), is.finite(ai_use_value)) |>
        dplyr::group_by(iowa_priority_sector) |>
        dplyr::summarise(
          ai_use_rate = mean(ai_use_value, na.rm = TRUE),
          expected_use_6_months_rate = if (any(is.finite(expected_value))) mean(expected_value, na.rm = TRUE) else NA_real_,
          observations = dplyr::n(),
          standard_error = sqrt(ai_use_rate * (1 - ai_use_rate) / pmax(observations, 1)),
          .groups = 'drop'
        ) |>
        dplyr::mutate(source_type = source_type, source_file = normalizePath(path, winslash = '/', mustWork = FALSE))
    )
  }

  rate_col <- intersect(c('ai_use_rate', 'adoption_rate', 'ai_use_now_rate', 'estimate', 'rate'), names(x))[1]
  expected_col <- intersect(c('expected_use_6_months_rate', 'expected_rate'), names(x))[1]
  se_col <- intersect(c('standard_error', 'se', 'margin_standard_error'), names(x))[1]
  if (is.na(rate_col)) return(tibble::tibble())
  out <- x |>
    dplyr::transmute(
      iowa_priority_sector,
      ai_use_rate = suppressWarnings(as.numeric(.data[[rate_col]])),
      expected_use_6_months_rate = if (!is.na(expected_col)) suppressWarnings(as.numeric(.data[[expected_col]])) else NA_real_,
      standard_error = if (!is.na(se_col)) suppressWarnings(as.numeric(.data[[se_col]])) else NA_real_,
      observations = if ('observations' %in% names(x)) suppressWarnings(as.numeric(observations)) else NA_real_
    )
  out$ai_use_rate <- v2_require_unit_interval(out$ai_use_rate, paste0(source_type, ' ai_use_rate'), allow_missing = TRUE)
  out$expected_use_6_months_rate <- v2_require_unit_interval(out$expected_use_6_months_rate, paste0(source_type, ' expected_use_6_months_rate'), allow_missing = TRUE)
  out |>
    dplyr::filter(!is.na(iowa_priority_sector), is.finite(ai_use_rate)) |>
    dplyr::group_by(iowa_priority_sector) |>
    dplyr::summarise(
      ai_use_rate = mean(ai_use_rate, na.rm = TRUE),
      expected_use_6_months_rate = if (any(is.finite(expected_use_6_months_rate))) mean(expected_use_6_months_rate, na.rm = TRUE) else NA_real_,
      standard_error = if (any(is.finite(standard_error))) mean(standard_error, na.rm = TRUE) else NA_real_,
      observations = if (any(is.finite(observations))) sum(observations, na.rm = TRUE) else NA_real_,
      .groups = 'drop'
    ) |>
    dplyr::mutate(source_type = source_type, source_file = normalizePath(path, winslash = '/', mustWork = FALSE))
}

v2_observed_adoption_layer <- function(sector_summary, cfg = load_methodology_v2_config()) {
  p <- paths()
  btos_name <- cfg$observed_adoption$btos_local_filename %||% 'btos_ai_use.csv'
  pulse_name <- cfg$observed_adoption$employer_pulse_filename %||% 'iowa_employer_pulse.csv'
  btos_candidates <- c(file.path(p$inputs, btos_name), file.path(p$raw, 'btos', btos_name), file.path(p$processed, btos_name))
  pulse_candidates <- c(file.path(p$inputs, pulse_name), file.path(p$processed, pulse_name))
  btos_file <- btos_candidates[file.exists(btos_candidates)][1]
  pulse_file <- pulse_candidates[file.exists(pulse_candidates)][1]
  btos <- if (length(btos_file) && !is.na(btos_file)) v2_read_adoption_source(btos_file, 'Census BTOS') else tibble::tibble()
  pulse <- if (length(pulse_file) && !is.na(pulse_file)) v2_read_adoption_source(pulse_file, 'Iowa employer pulse') else tibble::tibble()
  detail <- dplyr::bind_rows(btos, pulse)

  status <- dplyr::bind_rows(
    tibble::tibble(layer = 'Technical exposure', status = 'available', source = 'O*NET plus public employment data', imputed = FALSE),
    tibble::tibble(layer = 'Census BTOS employer adoption', status = if (nrow(btos)) 'loaded' else 'not loaded', source = if (nrow(btos)) unique(btos$source_file)[1] else paste0('Add inputs/', btos_name), imputed = FALSE),
    tibble::tibble(layer = 'Iowa employer pulse', status = if (nrow(pulse)) 'loaded' else 'not loaded', source = if (nrow(pulse)) unique(pulse$source_file)[1] else paste0('Add inputs/', pulse_name), imputed = FALSE)
  )

  if (!nrow(detail)) {
    return(list(
      sector = sector_summary |>
        dplyr::mutate(
          observed_ai_adoption = NA_real_, expected_ai_adoption_6_months = NA_real_,
          btos_ai_use_rate = NA_real_, iowa_pulse_ai_use_rate = NA_real_,
          adoption_standard_error = NA_real_, adoption_source = NA_character_, adoption_observations = NA_real_
        ),
      source_detail = detail,
      status = status
    ))
  }

  # Preserve each source separately, then produce a transparent precision-weighted
  # nowcast only when more than one source exists. The variance floor prevents a
  # survey with an unrealistically tiny or missing standard error from dominating.
  detail <- detail |>
    dplyr::mutate(
      variance = dplyr::if_else(is.finite(standard_error) & standard_error > 0, standard_error^2, NA_real_),
      precision_weight = dplyr::if_else(is.finite(variance), 1 / pmax(variance, as.numeric(cfg$observed_adoption$adoption_variance_floor %||% 0.0004)), dplyr::coalesce(observations, 1))
    )
  combined <- detail |>
    dplyr::group_by(iowa_priority_sector) |>
    dplyr::summarise(
      observed_ai_adoption = stats::weighted.mean(ai_use_rate, precision_weight, na.rm = TRUE),
      expected_ai_adoption_6_months = if (any(is.finite(expected_use_6_months_rate))) stats::weighted.mean(expected_use_6_months_rate[is.finite(expected_use_6_months_rate)], precision_weight[is.finite(expected_use_6_months_rate)], na.rm = TRUE) else NA_real_,
      adoption_standard_error = sqrt(1 / sum(precision_weight, na.rm = TRUE)),
      adoption_observations = if (any(is.finite(observations))) sum(observations, na.rm = TRUE) else NA_real_,
      btos_ai_use_rate = if (any(source_type == 'Census BTOS')) mean(ai_use_rate[source_type == 'Census BTOS'], na.rm = TRUE) else NA_real_,
      iowa_pulse_ai_use_rate = if (any(source_type == 'Iowa employer pulse')) mean(ai_use_rate[source_type == 'Iowa employer pulse'], na.rm = TRUE) else NA_real_,
      adoption_source = paste(sort(unique(source_type)), collapse = ' + '),
      .groups = 'drop'
    )
  sector <- sector_summary |>
    dplyr::left_join(combined, by = 'iowa_priority_sector')
  status <- dplyr::bind_rows(
    status,
    tibble::tibble(
      layer = 'Observed employer adoption nowcast',
      status = if (any(is.finite(sector$observed_ai_adoption))) 'loaded; technical exposure kept separate' else 'no matching sectors',
      source = paste(sort(unique(detail$source_type)), collapse = ' + '),
      imputed = FALSE
    )
  )
  list(sector = sector, source_detail = detail, status = status)
}


v2_read_optional_local_input <- function(filename, template_filename = NULL) {
  p <- paths()
  candidates <- c(
    file.path(p$inputs, filename),
    if (!is.null(template_filename)) file.path(p$inputs, 'templates', template_filename) else character()
  )
  f <- candidates[file.exists(candidates)][1]
  if (!length(f) || is.na(f)) return(list(data = tibble::tibble(), path = NA_character_, status = 'not loaded'))
  x <- tryCatch(readr::read_csv(f, show_col_types = FALSE), error = function(e) tibble::tibble())
  names(x) <- janitor::make_clean_names(names(x))
  if ('notes' %in% names(x)) x <- x |> dplyr::filter(!stringr::str_detect(dplyr::coalesce(notes, ''), stringr::regex('delete example', ignore_case = TRUE)))
  list(data = x, path = normalizePath(f, winslash = '/', mustWork = FALSE), status = if (nrow(x)) 'loaded' else 'template only/no observations')
}

v2_worker_outcomes_layer <- function(cfg = load_methodology_v2_config()) {
  filename <- cfg$observed_adoption$worker_pulse_filename %||% 'iowa_worker_pulse.csv'
  inp <- v2_read_optional_local_input(filename, 'iowa_worker_pulse_template.csv')
  if (!nrow(inp$data)) {
    return(list(
      summary = tibble::tibble(),
      records = tibble::tibble(),
      status = tibble::tibble(layer = 'Worker use and realized outcomes', status = inp$status, source = dplyr::coalesce(inp$path, 'Add inputs/iowa_worker_pulse.csv'), imputed = FALSE)
    ))
  }
  required <- c('baseline_task_minutes', 'time_saved_minutes', 'review_minutes', 'error_correction_minutes', 'quality_change_rate')
  missing <- setdiff(required, names(inp$data))
  if (length(missing)) stop('Worker pulse is missing required columns: ', paste(missing, collapse = ', '), call. = FALSE)
  x <- inp$data |>
    dplyr::mutate(
      county_fips = if ('county_fips' %in% names(inp$data)) clean_fips(county_fips, 5) else NA_character_,
      soc_code = if ('soc_code' %in% names(inp$data)) clean_soc(soc_code) else NA_character_,
      naics2 = if ('naics2' %in% names(inp$data)) normalize_naics2(naics2) else NA_character_,
      baseline_task_minutes = suppressWarnings(as.numeric(baseline_task_minutes)),
      time_saved_minutes = suppressWarnings(as.numeric(time_saved_minutes)),
      review_minutes = suppressWarnings(as.numeric(review_minutes)),
      error_correction_minutes = suppressWarnings(as.numeric(error_correction_minutes)),
      quality_change_rate = suppressWarnings(as.numeric(quality_change_rate))
    )
  x$quality_change_rate <- v2_require_unit_interval((x$quality_change_rate + 1) / 2, 'Worker-pulse quality_change_rate transformed from [-1,1]', allow_missing = TRUE) * 2 - 1
  x <- x |>
    dplyr::mutate(
      net_time_saved_minutes = time_saved_minutes - review_minutes - error_correction_minutes,
      net_time_savings_rate = dplyr::if_else(baseline_task_minutes > 0, net_time_saved_minutes / baseline_task_minutes, NA_real_),
      quality_adjusted_productivity_change = dplyr::if_else(
        is.finite(net_time_savings_rate) & is.finite(quality_change_rate),
        (1 + net_time_savings_rate) * (1 + quality_change_rate) - 1,
        NA_real_
      ),
      requires_additional_time = net_time_saved_minutes < 0
    )
  summary <- x |>
    dplyr::group_by(dplyr::across(dplyr::any_of(c('county_fips', 'naics2', 'soc_code')))) |>
    dplyr::summarise(
      responses = dplyr::n(),
      mean_net_time_saved_minutes = mean(net_time_saved_minutes, na.rm = TRUE),
      median_net_time_saved_minutes = stats::median(net_time_saved_minutes, na.rm = TRUE),
      mean_quality_change_rate = mean(quality_change_rate, na.rm = TRUE),
      mean_quality_adjusted_productivity_change = mean(quality_adjusted_productivity_change, na.rm = TRUE),
      share_requiring_additional_time = mean(requires_additional_time, na.rm = TRUE),
      .groups = 'drop'
    )
  list(
    summary = summary,
    records = x,
    status = tibble::tibble(layer = 'Worker use and realized outcomes', status = 'loaded', source = inp$path, imputed = FALSE)
  )
}

v2_employer_pilot_layer <- function() {
  inp <- v2_read_optional_local_input('employer_pilot_outcomes.csv', 'employer_pilot_outcomes_template.csv')
  if (!nrow(inp$data)) {
    return(list(
      summary = tibble::tibble(),
      records = tibble::tibble(),
      status = tibble::tibble(layer = 'Employer pilot outcomes', status = inp$status, source = dplyr::coalesce(inp$path, 'Add inputs/employer_pilot_outcomes.csv'), imputed = FALSE)
    ))
  }
  x <- inp$data
  if (!all(c('pilot_id', 'period', 'treated') %in% names(x))) stop('Employer pilot input requires pilot_id, period, and treated.', call. = FALSE)
  numeric_metrics <- intersect(c('throughput', 'error_rate', 'service_access', 'wage', 'retention', 'workload', 'incidents', 'customer_outcome', 'human_override_rate'), names(x))
  x <- x |> dplyr::mutate(dplyr::across(dplyr::all_of(numeric_metrics), ~suppressWarnings(as.numeric(.x))))
  long <- x |>
    tidyr::pivot_longer(dplyr::all_of(numeric_metrics), names_to = 'outcome', values_to = 'value') |>
    dplyr::filter(is.finite(value))
  summary <- if (nrow(long)) {
    long |>
      dplyr::group_by(pilot_id, outcome, treated, period) |>
      dplyr::summarise(n = dplyr::n(), mean_value = mean(value), .groups = 'drop') |>
      dplyr::group_by(pilot_id, outcome, treated) |>
      dplyr::mutate(baseline = mean(mean_value[stringr::str_to_lower(period) %in% c('pre', 'baseline')], na.rm = TRUE),
                    followup = mean(mean_value[stringr::str_to_lower(period) %in% c('post', 'followup', 'follow-up')], na.rm = TRUE)) |>
      dplyr::summarise(baseline = first(baseline), followup = first(followup), change = followup - baseline, observations = sum(n), .groups = 'drop') |>
      dplyr::group_by(pilot_id, outcome) |>
      dplyr::mutate(
        comparison_change = change[treated == 0][1] %||% NA_real_,
        difference_in_differences = dplyr::if_else(treated == 1 & is.finite(comparison_change), change - comparison_change, NA_real_)
      ) |>
      dplyr::ungroup()
  } else tibble::tibble()
  list(
    summary = summary,
    records = x,
    status = tibble::tibble(layer = 'Employer pilot outcomes', status = 'loaded; descriptive/DID-ready summary', source = inp$path, imputed = FALSE)
  )
}

v2_write_governance_outputs <- function() {
  p <- v2_methodology_paths()
  template <- tibble::tribble(
    ~nist_function, ~profile_field, ~required_for_publicly_supported_pilot,
    'GOVERN', 'Accountable executive, worker/stakeholder roles, legal authority, procurement controls, documentation owner', TRUE,
    'MAP', 'Intended users, affected workers, task/workflow context, prohibited uses, data access, foreseeable harms, risk tolerance', TRUE,
    'MEASURE', 'Baseline and follow-up quality, error, workload, equity, wage, retention, service-access, incident, and override measures', TRUE,
    'MANAGE', 'Human oversight, escalation, appeals, logging, incident response, vendor lock-in, exit and rollback procedures', TRUE
  )
  readr::write_csv(template, file.path(p$outputs, 'ai_pilot_governance_profile.csv'))
  invisible(template)
}

apply_methodology_v2 <- function(refresh = FALSE, overwrite_primary_outputs = TRUE) {
  setup_packages(install_optional = FALSE)
  cfg <- load_methodology_v2_config(); p <- paths(); vp <- v2_methodology_paths()
  fs::dir_create(c(vp$outputs, vp$figures))
  set.seed(as.integer(cfg$build$random_seed %||% 20260818))
  build_id <- v2_build_id()
  message('Applying methodology v2.0: explicit schemas, partial pooling, uncertainty, sensitivity, capacity, adoption separation, and skill transitions.')

  if (!compat_table_exists('county_industry_occupation_atlas', p$processed)) {
    build_atlas(refresh = refresh, install_optional = FALSE)
  }
  atlas <- read_compat_table('county_industry_occupation_atlas', p$processed) |> dplyr::as_tibble()
  onet <- get_onet(load_config(), refresh = refresh)
  oews <- get_oews_iowa(load_config(), refresh = refresh)
  aioe <- get_aioe(refresh = refresh)
  occ <- v2_occupation_scores(onet, aioe, oews)
  readr::write_csv(occ, file.path(p$processed, 'occupation_ai_scores_v2.csv'))

  legacy_score_cols <- intersect(c('automation_exposure', 'augmentation_potential', 'expertise_leveling_potential', 'new_task_opportunity', 'pro_worker_opportunity', 'risk_minus_opportunity'), names(atlas))
  for (nm in legacy_score_cols) atlas[[paste0(nm, '_legacy_v1')]] <- atlas[[nm]]
  drop_join <- intersect(c('occupation_title', 'state_emp', 'hourly_mean', 'annual_mean', 'hourly_median', 'annual_median'), names(atlas))
  score_replace <- setdiff(names(occ), c('soc_code', 'occupation_title', 'state_emp', 'hourly_mean', 'annual_mean', 'hourly_median', 'annual_median'))
  atlas <- atlas |>
    dplyr::select(-dplyr::any_of(score_replace)) |>
    dplyr::left_join(occ |> dplyr::select(-dplyr::any_of(drop_join)), by = 'soc_code')

  modifiers <- v2_read_config_csv('sector_channel_modifiers.csv')
  atlas <- atlas |>
    dplyr::left_join(modifiers, by = 'iowa_priority_sector') |>
    dplyr::mutate(
      new_task_modifier = dplyr::coalesce(new_task_modifier, 0),
      physical_ai_modifier = dplyr::coalesce(physical_ai_modifier, 0),
      governance_intensity = dplyr::coalesce(governance_intensity, 0.05),
      new_task_opportunity_raw = new_task_opportunity,
      physical_ai_exposure_raw = physical_ai_exposure,
      pro_worker_opportunity_raw = pro_worker_opportunity,
      new_task_opportunity = v2_clip01(new_task_opportunity_raw + new_task_modifier),
      physical_ai_exposure = v2_clip01(physical_ai_exposure_raw + physical_ai_modifier),
      pro_worker_opportunity = v2_clip01(pro_worker_opportunity_raw + as.numeric(cfg$score_model$sector_modifier_application$pro_worker_new_task_weight %||% 0.20) * new_task_modifier),
      sector_modifier_status = dplyr::if_else(abs(new_task_modifier) + abs(physical_ai_modifier) > 0, 'configured scenario adjustment', 'no sector adjustment'),
      transition_pressure = v2_clip01(transition_pressure + as.numeric(cfg$score_model$sector_modifier_application$transition_pressure_physical_weight %||% 0.15) * physical_ai_modifier),
      score_methodology_version = as.character(cfg$methodology_version),
      build_id = build_id
    )
  atlas <- v2_partial_pool_jobs(atlas, cfg)
  threshold_values <- v2_action_threshold_values(atlas)
  atlas <- v2_classify_actions(atlas, threshold_values)
  v2_assert_score_schema(atlas, 'methodology-v2 atlas')

  capacity <- v2_training_capacity_index(refresh = refresh, cfg = cfg)
  county <- v2_county_summary(atlas, capacity, cfg)
  lwda <- v2_lwda_summary(atlas, cfg)
  sector <- v2_sector_summary(atlas)
  training <- v2_training_priorities(atlas, cfg)
  sensitivity <- v2_action_sensitivity_summary(atlas, threshold_values)
  weight_sensitivity <- v2_score_weight_sensitivity(atlas, cfg)
  county <- county |>
    dplyr::left_join(sensitivity$county_range, by = c('county_fips', 'county_name', 'lwda_combined'))

  adoption <- v2_observed_adoption_layer(sector, cfg)
  worker_outcomes <- v2_worker_outcomes_layer(cfg)
  pilot_outcomes <- v2_employer_pilot_layer()
  adoption$status <- dplyr::bind_rows(adoption$status, worker_outcomes$status, pilot_outcomes$status)
  skill_paths <- v2_skill_transition_paths(onet, occ, cfg)

  write_compat_table(atlas, 'county_industry_occupation_atlas', p$processed)
  write_compat_table(atlas, 'county_industry_occupation_atlas_v2', p$processed)
  readr::write_csv(county, file.path(p$processed, 'county_summary_v2.csv'))
  readr::write_csv(lwda, file.path(p$processed, 'lwda_summary_v2.csv'))
  readr::write_csv(sector, file.path(p$processed, 'sector_lwda_summary_v2.csv'))
  readr::write_csv(training, file.path(p$processed, 'training_priority_occupations_v2.csv'))
  readr::write_csv(capacity, file.path(p$processed, 'training_capacity_index_v2.csv'))
  readr::write_csv(sensitivity$by_scenario, file.path(p$processed, 'county_action_sensitivity_v2.csv'))
  readr::write_csv(sensitivity$thresholds, file.path(p$processed, 'action_threshold_values_v2.csv'))
  readr::write_csv(weight_sensitivity, file.path(p$processed, 'score_weight_sensitivity_v2.csv'))
  readr::write_csv(skill_paths, file.path(p$processed, 'occupation_skill_transition_paths_v2.csv'))
  readr::write_csv(adoption$sector, file.path(p$processed, 'sector_observed_adoption_v2.csv'))
  readr::write_csv(adoption$source_detail, file.path(p$processed, 'sector_observed_adoption_sources_v2.csv'))
  readr::write_csv(adoption$status, file.path(p$processed, 'observed_adoption_status_v2.csv'))
  readr::write_csv(worker_outcomes$summary, file.path(p$processed, 'worker_quality_adjusted_outcomes_v2.csv'))
  readr::write_csv(pilot_outcomes$summary, file.path(p$processed, 'employer_pilot_outcomes_summary_v2.csv'))
  readr::write_csv(occ, file.path(p$processed, 'occupation_ai_scores.csv'))
  if (isTRUE(overwrite_primary_outputs)) {
    readr::write_csv(county, file.path(p$processed, 'county_summary.csv'))
    readr::write_csv(lwda, file.path(p$processed, 'lwda_summary.csv'))
    readr::write_csv(sector, file.path(p$processed, 'sector_lwda_summary.csv'))
    readr::write_csv(training, file.path(p$processed, 'training_priority_occupations.csv'))
  }
  v2_write_governance_outputs()
  readr::write_csv(tibble::tibble(
    build_id = build_id,
    methodology_version = as.character(cfg$methodology_version),
    generated_at = format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z'),
    interpretation = as.character(cfg$release_status),
    occupation_scores = nrow(occ),
    atlas_cells = nrow(atlas),
    counties = dplyr::n_distinct(atlas$county_fips),
    lwdas = dplyr::n_distinct(atlas$lwda_combined),
    adoption_observed = any(is.finite(adoption$sector$observed_ai_adoption))
  ), file.path(vp$outputs, 'methodology_v2_build_summary.csv'))

  message('Methodology v2 outputs written to data_processed/ and outputs/methodology_v2/.')
  invisible(list(atlas = atlas, occupation_scores = occ, county = county, lwda = lwda, sector = sector,
                 training = training, capacity = capacity, sensitivity = sensitivity, weight_sensitivity = weight_sensitivity, skill_paths = skill_paths,
                 adoption = adoption, worker_outcomes = worker_outcomes, pilot_outcomes = pilot_outcomes,
                 thresholds = threshold_values, build_id = build_id))
}

if (sys.nframe() == 0) apply_methodology_v2(refresh = v2_resolve_refresh())
