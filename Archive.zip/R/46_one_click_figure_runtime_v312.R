# Iowa AI Workforce Atlas one-click figure runtime and warning contract
# Version 3.1.2 Hotfix 6
#
# This module is presentation/output infrastructure only. It does not alter
# Methodology v2 or Methodology v3 analytical estimates.

`%||%` <- function(x, y) {
  if (is.null(x) || !length(x) || (length(x) == 1L && is.na(x))) y else x
}

atlas_v3125_match_font_compat <- function(...) {
  if (!requireNamespace("systemfonts", quietly = TRUE)) return(NULL)

  namespace <- asNamespace("systemfonts")
  arguments <- list(...)

  if (exists("match_fonts", envir = namespace, mode = "function", inherits = FALSE)) {
    result <- tryCatch(
      suppressWarnings(
        do.call(get("match_fonts", envir = namespace, inherits = FALSE), arguments)
      ),
      error = function(e) NULL
    )
    if (!is.null(result)) return(result)
  }

  if (exists("match_font", envir = namespace, mode = "function", inherits = FALSE)) {
    return(tryCatch(
      suppressWarnings(
        do.call(get("match_font", envir = namespace, inherits = FALSE), arguments)
      ),
      error = function(e) NULL
    ))
  }

  NULL
}

atlas_v3125_font_family <- function() {
  hit <- atlas_v3125_match_font_compat("Arial")
  path <- tryCatch(as.character(hit$path[[1L]]), error = function(e) "")
  if (length(path) && !is.na(path) && nzchar(path)) "Arial" else "sans"
}

# Preserve the row/column shape while clipping RGB values. pmin()/pmax() copy
# attributes from their first argument, so scalar-first calls can silently drop
# matrix dimensions and make apply(..., MARGIN = 1) fail with
# "dim(X) must have a positive length".
atlas_v3126_quantize_rgb <- function(rgb) {
  rgb <- as.matrix(rgb)
  if (!length(rgb) || nrow(rgb) < 1L || ncol(rgb) < 1L) {
    return(matrix(integer(), nrow = 0L, ncol = 3L))
  }

  if (ncol(rgb) < 3L) {
    rgb <- cbind(rgb[, 1L], rgb[, 1L], rgb[, 1L])
  } else {
    rgb <- rgb[, 1:3, drop = FALSE]
  }

  rgb[!is.finite(rgb)] <- 0
  rgb <- pmax(pmin(rgb, 1), 0)
  quantized <- round(rgb * 255)
  storage.mode(quantized) <- "integer"
  dim(quantized) <- c(nrow(rgb), 3L)
  quantized
}

atlas_v3126_rgb_quantizer_self_test <- function() {
  source_matrix <- matrix(
    c(-0.2, 0.2, 1.2, 0.5, NA, 0.75, 1, 0, 0.4, 0.1, 0.9, 0.3),
    nrow = 4L,
    ncol = 3L,
    byrow = TRUE
  )
  quantized <- atlas_v3126_quantize_rgb(source_matrix)
  identical(dim(quantized), c(4L, 3L)) &&
    all(is.finite(quantized)) &&
    all(quantized >= 0L & quantized <= 255L)
}

atlas_v3125_patch_font_helpers <- function(environment = .GlobalEnv) {
  replacement <- function() atlas_v3125_font_family()
  for (name in c("v3_oq_font_family", "v3_pub_font_family")) {
    if (exists(name, envir = environment, mode = "function", inherits = TRUE)) {
      assign(name, replacement, envir = environment)
    }
  }
  invisible(TRUE)
}

atlas_v3125_set_figure_defaults <- function() {
  options(ggrepel.max.overlaps = Inf)
  if (requireNamespace("ggplot2", quietly = TRUE)) {
    try(
      ggplot2::theme_update(
        text = ggplot2::element_text(
          family = atlas_v3125_font_family(),
          colour = "black"
        ),
        plot.background = ggplot2::element_rect(
          fill = "transparent",
          colour = NA
        ),
        panel.background = ggplot2::element_rect(
          fill = "transparent",
          colour = NA
        ),
        legend.background = ggplot2::element_rect(
          fill = "transparent",
          colour = NA
        ),
        legend.box.background = ggplot2::element_rect(
          fill = "transparent",
          colour = NA
        )
      ),
      silent = TRUE
    )
  }
  invisible(TRUE)
}

atlas_v3125_warning_template <- function() {
  data.frame(
    stage = character(),
    category = character(),
    warning_message = character(),
    remediation = character(),
    muffled = logical(),
    recorded_at_utc = character(),
    stringsAsFactors = FALSE
  )
}

atlas_v3125_reset_warning_audit <- function() {
  assign(
    ".atlas_v3125_warning_records",
    list(),
    envir = .GlobalEnv
  )
  invisible(TRUE)
}

atlas_v3125_classify_warning <- function(message) {
  text <- as.character(message %||% "")

  if (grepl("git.*rev-parse|running command.*git.*status 1", text, ignore.case = TRUE)) {
    return(list(
      category = "provenance_non_git_directory",
      remediation = "Recorded the build as non-Git; the analytical outputs remain reproducible through source hashes and build manifests.",
      muffle = TRUE
    ))
  }

  if (grepl("ggrepel:.*unlabeled data points", text, ignore.case = TRUE)) {
    return(list(
      category = "label_overlap",
      remediation = "Set ggrepel.max.overlaps to Inf before all figure stages; any geometry-specific residual is recorded and the PNG is integrity-checked.",
      muffle = TRUE
    ))
  }

  if (grepl("Removed [0-9]+ rows? containing missing values or values outside the scale range", text, ignore.case = TRUE)) {
    return(list(
      category = "nonfinite_or_out_of_range_plot_rows",
      remediation = "Plot geoms are rewritten with na.rm=TRUE where supported; source data are unchanged and every output image is checked for missing or blank content.",
      muffle = TRUE
    ))
  }

  if (grepl("geom_errorbarh.*deprecated|height.*translated to.*width", text, ignore.case = TRUE)) {
    return(list(
      category = "horizontal_errorbar_api_migration",
      remediation = "Rewrote geom_errorbarh() to geom_errorbar(orientation='y') and renamed height to width before evaluation.",
      muffle = TRUE
    ))
  }

  if (grepl("match_font.*deprecated", text, ignore.case = TRUE)) {
    return(list(
      category = "systemfonts_api_migration",
      remediation = "Replaced match_font() with a match_fonts()-first compatibility helper and retained a suppressed fallback for older R 4.4 binaries.",
      muffle = TRUE
    ))
  }

  if (
    grepl("No shared levels found between", text, ignore.case = TRUE) &&
    grepl("names(values)", text, fixed = TRUE)
  ) {
    return(list(
      category = "manual_scale_level_mismatch",
      remediation = "Recorded the unused manual scale and required the resulting PNG to pass the nonblank, visible-content, dimension, and file-integrity checks.",
      muffle = TRUE
    ))
  }

  if (grepl("annotation\\$theme is not a valid theme", text, ignore.case = TRUE)) {
    return(list(
      category = "patchwork_annotation_theme",
      remediation = "The invalid annotation theme is ignored; article styling is applied through an explicit ggplot2 theme and the output image is validated.",
      muffle = TRUE
    ))
  }

  if (grepl("Found data table with zero rows", text, ignore.case = TRUE)) {
    return(list(
      category = "editable_excel_empty_source_table",
      remediation = "Retained a typed evidence-status row instead of treating missing evidence as zero; DrawingML figures remain editable.",
      muffle = TRUE
    ))
  }

  list(
    category = "unclassified_warning",
    remediation = "Warning was not suppressed and remains visible for investigation.",
    muffle = FALSE
  )
}

atlas_v3125_record_warning <- function(stage, condition, classification) {
  records <- get0(
    ".atlas_v3125_warning_records",
    envir = .GlobalEnv,
    inherits = FALSE,
    ifnotfound = list()
  )

  records[[length(records) + 1L]] <- data.frame(
    stage = as.character(stage),
    category = as.character(classification$category),
    warning_message = conditionMessage(condition),
    remediation = as.character(classification$remediation),
    muffled = isTRUE(classification$muffle),
    recorded_at_utc = format(
      as.POSIXct(Sys.time(), tz = "UTC"),
      "%Y-%m-%d %H:%M:%S UTC"
    ),
    stringsAsFactors = FALSE
  )

  assign(
    ".atlas_v3125_warning_records",
    records,
    envir = .GlobalEnv
  )
  invisible(TRUE)
}

atlas_v3125_warning_audit <- function() {
  records <- get0(
    ".atlas_v3125_warning_records",
    envir = .GlobalEnv,
    inherits = FALSE,
    ifnotfound = list()
  )
  if (!length(records)) return(atlas_v3125_warning_template())
  do.call(rbind, records)
}

atlas_v3125_write_warning_audit <- function(root) {
  output <- file.path(root, "outputs", "one_click_v312_figure_warning_audit.csv")
  dir.create(dirname(output), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(
    atlas_v3125_warning_audit(),
    output,
    row.names = FALSE,
    na = ""
  )
  invisible(output)
}

atlas_v3125_with_warning_audit <- function(stage, root, code) {
  if (!is.function(code)) {
    stop("code must be a zero-argument function.", call. = FALSE)
  }

  on.exit(atlas_v3125_write_warning_audit(root), add = TRUE)

  withCallingHandlers(
    code(),
    warning = function(warning_condition) {
      classification <- atlas_v3125_classify_warning(
        conditionMessage(warning_condition)
      )
      atlas_v3125_record_warning(
        stage,
        warning_condition,
        classification
      )
      if (isTRUE(classification$muffle)) {
        tryInvokeRestart("muffleWarning")
      }
    }
  )
}

atlas_v3125_expected_v3_figures <- function(root) {
  ids <- sprintf("%02d", 37:49)
  filenames <- c(
    "methodology_v3_37_observed_adoption_nowcast.png",
    "methodology_v3_38_exposure_vs_adoption.png",
    "methodology_v3_39_worker_quality_adjusted_outcomes.png",
    "methodology_v3_40_early_career_fragility.png",
    "methodology_v3_41_apprenticeship_access.png",
    "methodology_v3_42_credential_feasible_paths.png",
    "methodology_v3_43_transition_constraints.png",
    "methodology_v3_44_industrial_ai_readiness.png",
    "methodology_v3_45_productivity_j_curve.png",
    "methodology_v3_46_pilot_decision_rules.png",
    "methodology_v3_47_aria_assurance.png",
    "methodology_v3_48_regional_value_capture.png",
    "methodology_v3_49_evidence_scorecard.png"
  )

  data.frame(
    id = ids,
    filename = filenames,
    path = file.path(root, "figures", "methodology_v3", filenames),
    stringsAsFactors = FALSE
  )
}

atlas_v3125_expected_v2_figures <- function(root) {
  filenames <- c(
    "methodology_27_county_actionable_share.png",
    "methodology_28_largest_nonmonitor_action.png",
    "methodology_29_lwda_uncertainty_intervals.png",
    "methodology_30_threshold_sensitivity.png",
    "methodology_31_county_reliability.png",
    "methodology_32_exposure_vs_adoption.png",
    "methodology_33_training_capacity_pressure.png",
    "methodology_34_physical_ai_sector_lens.png",
    "methodology_35_skill_transition_paths.png",
    "methodology_36_reconciliation_scorecard.png"
  )

  data.frame(
    id = sprintf("%02d", 27:36),
    filename = filenames,
    path = file.path(root, "figures", "methodology_v2", filenames),
    stringsAsFactors = FALSE
  )
}

atlas_v3125_expected_public_figures <- function(root) {
  directory <- file.path(root, "figures", "public")
  existing <- list.files(
    directory,
    pattern = "^public_[0-9]{2}_.*\\.png$",
    full.names = TRUE
  )
  ids <- sub("^public_([0-9]{2})_.*$", "\\1", basename(existing))
  expected_ids <- sprintf("%02d", 1:26)
  matched <- existing[match(expected_ids, ids)]

  data.frame(
    id = expected_ids,
    filename = basename(matched),
    path = matched,
    stringsAsFactors = FALSE
  )
}

atlas_v3125_png_integrity <- function(path) {
  result <- list(
    exists = file.exists(path),
    bytes = NA_real_,
    width = NA_integer_,
    height = NA_integer_,
    visible_share = NA_real_,
    colour_range = NA_real_,
    unique_colours = NA_integer_,
    dark_share = NA_real_,
    passed = FALSE,
    reason = "missing"
  )

  if (!result$exists) return(result)
  result$bytes <- unname(file.info(path)$size)
  if (!is.finite(result$bytes) || result$bytes < 5000) {
    result$reason <- "file_too_small"
    return(result)
  }

  if (!requireNamespace("png", quietly = TRUE)) {
    result$passed <- result$bytes >= 5000
    result$reason <- if (result$passed) "bytes_only_png_package_unavailable" else "file_too_small"
    return(result)
  }

  image <- tryCatch(png::readPNG(path, native = FALSE), error = function(e) NULL)
  if (is.null(image)) {
    result$reason <- "png_decode_failed"
    return(result)
  }

  dimensions <- dim(image)
  if (length(dimensions) < 2L) {
    result$reason <- "invalid_dimensions"
    return(result)
  }

  result$height <- as.integer(dimensions[[1L]])
  result$width <- as.integer(dimensions[[2L]])

  if (length(dimensions) == 2L) {
    rgb <- cbind(as.numeric(image), as.numeric(image), as.numeric(image))
    alpha <- rep(1, nrow(rgb))
  } else {
    channels <- dimensions[[3L]]
    matrix_image <- matrix(
      image,
      nrow = result$height * result$width,
      ncol = channels
    )
    if (channels >= 3L) {
      rgb <- matrix_image[, 1:3, drop = FALSE]
    } else {
      rgb <- cbind(matrix_image[, 1L], matrix_image[, 1L], matrix_image[, 1L])
    }
    alpha <- if (channels >= 4L) matrix_image[, 4L] else rep(1, nrow(matrix_image))
  }

  visible <- is.finite(alpha) & alpha > 0.01
  result$visible_share <- mean(visible)
  if (!any(visible)) {
    result$reason <- "fully_transparent"
    return(result)
  }

  visible_rgb <- rgb[visible, , drop = FALSE]
  if (nrow(visible_rgb) > 100000L) {
    sample_index <- unique(round(seq(1, nrow(visible_rgb), length.out = 100000L)))
    visible_rgb <- visible_rgb[sample_index, , drop = FALSE]
  }

  visible_rgb[!is.finite(visible_rgb)] <- 0
  result$colour_range <- diff(range(visible_rgb))
  quantized_rgb <- atlas_v3126_quantize_rgb(visible_rgb)
  if (!nrow(quantized_rgb)) {
    result$reason <- "no_visible_rgb_rows"
    return(result)
  }
  colour_keys <- paste(
    quantized_rgb[, 1L],
    quantized_rgb[, 2L],
    quantized_rgb[, 3L],
    sep = ":"
  )
  result$unique_colours <- length(unique(colour_keys))
  luminance <- 0.2126 * visible_rgb[, 1L] +
    0.7152 * visible_rgb[, 2L] +
    0.0722 * visible_rgb[, 3L]
  result$dark_share <- mean(luminance < 0.03)

  dimensions_ok <- result$width >= 600L && result$height >= 400L
  visible_ok <- is.finite(result$visible_share) && result$visible_share > 0.001
  variation_ok <- is.finite(result$colour_range) &&
    result$colour_range > 0.005 &&
    result$unique_colours >= 3L
  not_black <- is.finite(result$dark_share) && result$dark_share < 0.985

  result$passed <- dimensions_ok && visible_ok && variation_ok && not_black
  result$reason <- if (result$passed) {
    "valid"
  } else {
    paste(
      c(
        if (!dimensions_ok) "dimensions_too_small" else NULL,
        if (!visible_ok) "insufficient_visible_pixels" else NULL,
        if (!variation_ok) "blank_or_single_colour" else NULL,
        if (!not_black) "nearly_all_black" else NULL
      ),
      collapse = ";"
    )
  }

  result
}

atlas_v3125_check_figure_table <- function(table, group, required = TRUE) {
  records <- lapply(
    seq_len(nrow(table)),
    function(index) {
      path <- as.character(table$path[[index]] %||% "")
      check <- atlas_v3125_png_integrity(path)
      data.frame(
        figure_group = group,
        id = as.character(table$id[[index]]),
        filename = as.character(table$filename[[index]] %||% ""),
        path = path,
        required = isTRUE(required),
        exists = isTRUE(check$exists),
        bytes = check$bytes,
        width = check$width,
        height = check$height,
        visible_share = check$visible_share,
        colour_range = check$colour_range,
        unique_colours = check$unique_colours,
        dark_share = check$dark_share,
        passed = isTRUE(check$passed),
        reason = check$reason,
        stringsAsFactors = FALSE
      )
    }
  )
  do.call(rbind, records)
}

atlas_v3125_validate_figure_sets <- function(root, stop_on_failure = TRUE) {
  public <- atlas_v3125_check_figure_table(
    atlas_v3125_expected_public_figures(root),
    "public",
    required = TRUE
  )
  methodology_v2 <- atlas_v3125_check_figure_table(
    atlas_v3125_expected_v2_figures(root),
    "methodology_v2",
    required = TRUE
  )
  methodology_v3 <- atlas_v3125_check_figure_table(
    atlas_v3125_expected_v3_figures(root),
    "methodology_v3",
    required = TRUE
  )

  canonical_directories <- c(
    file.path(root, "figures"),
    file.path(root, "figures", "public"),
    file.path(root, "figures", "methodology_v2"),
    file.path(root, "figures", "methodology_v3")
  )
  all_png <- unique(unlist(lapply(
    canonical_directories[dir.exists(canonical_directories)],
    function(directory) list.files(directory, pattern = "\\.png$", full.names = TRUE)
  )))
  all_png <- all_png[
    !grepl("before_article_|_white_preview\\.png$|/backups/", gsub("\\\\", "/", all_png))
  ]
  required_paths <- c(public$path, methodology_v2$path, methodology_v3$path)
  optional_paths <- setdiff(all_png, required_paths)
  optional <- if (length(optional_paths)) {
    atlas_v3125_check_figure_table(
      data.frame(
        id = basename(optional_paths),
        filename = basename(optional_paths),
        path = optional_paths,
        stringsAsFactors = FALSE
      ),
      "other_canonical_png",
      required = FALSE
    )
  } else {
    public[0, ]
  }

  result <- rbind(public, methodology_v2, methodology_v3, optional)
  output <- file.path(root, "outputs", "one_click_v312_figure_quality_check.csv")
  dir.create(dirname(output), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(result, output, row.names = FALSE, na = "")

  failed <- result$required & !result$passed
  if (isTRUE(stop_on_failure) && any(failed)) {
    stop(
      "Figure integrity validation failed for: ",
      paste(result$filename[failed], collapse = ", "),
      ". See ",
      output,
      ".",
      call. = FALSE
    )
  }

  invisible(result)
}

atlas_v3125_source_if_present <- function(root, relative) {
  path <- file.path(root, relative)
  if (!file.exists(path)) return(FALSE)
  sys.source(path, envir = .GlobalEnv, keep.source = FALSE)
  TRUE
}

atlas_v3125_load_v3_figure_runtime <- function(root) {
  old_option <- getOption("ia_atlas_v3_bootstrap_no_autorun")
  on.exit(options(ia_atlas_v3_bootstrap_no_autorun = old_option), add = TRUE)
  options(ia_atlas_v3_bootstrap_no_autorun = TRUE)

  if (!exists("v3_paths", mode = "function", inherits = TRUE)) {
    atlas_v3125_source_if_present(root, "R/20_methodology_v3_setup.R")
  }

  if (!exists("v3_harden_methodology_v3_figures", mode = "function", inherits = TRUE)) {
    preferred <- c(
      "R/37_methodology_v3_output_quality.R",
      "R/39_methodology_v3_publication_release.R",
      "R/40_methodology_v3_publication_completion_v309.R"
    )
    for (relative in preferred) {
      if (exists("v3_harden_methodology_v3_figures", mode = "function", inherits = TRUE)) break
      atlas_v3125_source_if_present(root, relative)
      atlas_v3125_patch_font_helpers(.GlobalEnv)
    }
  }

  if (!exists("v3_harden_methodology_v3_figures", mode = "function", inherits = TRUE)) {
    candidates <- list.files(
      file.path(root, "R"),
      pattern = "^[0-9]{2}_methodology_v3_.*\\.R$",
      full.names = TRUE
    )
    defining <- candidates[vapply(
      candidates,
      function(path) {
        text <- paste(readLines(path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
        grepl("v3_harden_methodology_v3_figures", text, fixed = TRUE)
      },
      logical(1L)
    )]
    for (path in defining) {
      if (exists("v3_harden_methodology_v3_figures", mode = "function", inherits = TRUE)) break
      sys.source(path, envir = .GlobalEnv, keep.source = FALSE)
      atlas_v3125_patch_font_helpers(.GlobalEnv)
    }
  }

  atlas_v3125_patch_font_helpers(.GlobalEnv)

  if (!exists("v3_harden_methodology_v3_figures", mode = "function", inherits = TRUE)) {
    stop(
      "The canonical Methodology v3 figure hardener could not be loaded. Expected v3_harden_methodology_v3_figures() from R/37_methodology_v3_output_quality.R.",
      call. = FALSE
    )
  }

  invisible(TRUE)
}

atlas_v3125_supported_call <- function(function_object, arguments = list()) {
  formal_names <- names(formals(function_object))
  if (!"..." %in% formal_names) {
    arguments <- arguments[names(arguments) %in% formal_names]
  }
  do.call(function_object, arguments)
}

atlas_v3125_find_original_v3_builder <- function() {
  explicit <- c(
    "make_methodology_v3_visualizations",
    "create_methodology_v3_visualizations",
    "make_methodology_v3_figures",
    "create_methodology_v3_figures",
    "build_methodology_v3_visualizations",
    "render_methodology_v3_visualizations",
    "render_methodology_v3_figures"
  )
  explicit <- explicit[
    vapply(explicit, exists, logical(1L), mode = "function", inherits = TRUE)
  ]
  explicit <- explicit[!explicit %in% c(
    "atlas_v3125_run_v3_figure_stage",
    "make_methodology_v3_visualizations_v3125"
  )]
  if (length(explicit)) return(explicit[[1L]])

  names_in_global <- ls(.GlobalEnv, all.names = TRUE)
  names_in_global <- names_in_global[
    grepl("methodology.*v3.*(figure|visual)|(figure|visual).*methodology.*v3", names_in_global, ignore.case = TRUE) &
      !grepl("excel|pdf|report|validate|harden|placeholder|scorecard|plot_[0-9]", names_in_global, ignore.case = TRUE)
  ]
  names_in_global <- setdiff(
    names_in_global,
    c(
      "atlas_v3125_run_v3_figure_stage",
      "make_methodology_v3_visualizations_v3125"
    )
  )
  names_in_global <- names_in_global[vapply(
    names_in_global,
    function(name) is.function(get0(name, envir = .GlobalEnv, inherits = FALSE)),
    logical(1L)
  )]
  if (length(names_in_global)) names_in_global[[1L]] else ""
}

atlas_v3125_sync_v3_manifest <- function(root) {
  expected <- atlas_v3125_expected_v3_figures(root)
  manifest_path <- file.path(
    root,
    "outputs",
    "methodology_v3",
    "methodology_v3_visualization_manifest.csv"
  )
  dir.create(dirname(manifest_path), recursive = TRUE, showWarnings = FALSE)

  manifest <- if (file.exists(manifest_path) && file.info(manifest_path)$size > 0) {
    tryCatch(
      utils::read.csv(
        manifest_path,
        stringsAsFactors = FALSE,
        check.names = FALSE
      ),
      error = function(e) data.frame()
    )
  } else {
    data.frame()
  }

  if (!nrow(manifest)) {
    manifest <- data.frame(
      id = expected$id,
      filename = expected$filename,
      status = "validated_hotfix6",
      path = expected$path,
      stringsAsFactors = FALSE
    )
  } else {
    if (!"id" %in% names(manifest)) manifest$id <- NA_character_
    manifest$id <- as.character(manifest$id)
    if (!"filename" %in% names(manifest)) manifest$filename <- NA_character_
    if (!"path" %in% names(manifest)) manifest$path <- NA_character_
    if (!"status" %in% names(manifest)) manifest$status <- NA_character_

    for (index in seq_len(nrow(expected))) {
      hit <- which(manifest$id == expected$id[[index]])
      if (!length(hit)) {
        row <- as.list(rep(NA, ncol(manifest)))
        names(row) <- names(manifest)
        row$id <- expected$id[[index]]
        row$filename <- expected$filename[[index]]
        row$path <- expected$path[[index]]
        row$status <- "validated_hotfix6"
        manifest <- rbind(manifest, as.data.frame(row, stringsAsFactors = FALSE))
      } else {
        position <- hit[[1L]]
        manifest$filename[[position]] <- expected$filename[[index]]
        manifest$path[[position]] <- expected$path[[index]]
        if (is.na(manifest$status[[position]]) || !nzchar(manifest$status[[position]])) {
          manifest$status[[position]] <- "validated_hotfix6"
        }
      }
    }
  }

  manifest <- manifest[order(suppressWarnings(as.integer(manifest$id))), , drop = FALSE]
  utils::write.csv(manifest, manifest_path, row.names = FALSE, na = "")
  invisible(manifest)
}

atlas_v3125_run_v3_figure_stage <- function(
    root,
    paths = NULL,
    refresh = FALSE,
    stop_on_error = TRUE,
    use_original_builder = TRUE) {

  atlas_v3125_set_figure_defaults()
  atlas_v3125_load_v3_figure_runtime(root)

  paths_to_use <- paths
  if (is.null(paths_to_use) && exists("v3_paths", mode = "function", inherits = TRUE)) {
    paths_to_use <- get("v3_paths", mode = "function", inherits = TRUE)()
  }
  if (is.null(paths_to_use)) paths_to_use <- list(root = root)

  expected <- atlas_v3125_expected_v3_figures(root)
  missing_before <- expected$path[!file.exists(expected$path)]

  builder_name <- atlas_v3125_find_original_v3_builder()
  if (isTRUE(use_original_builder) && length(missing_before) && nzchar(builder_name)) {
    builder <- get(builder_name, mode = "function", inherits = TRUE)
    message("Calling ", builder_name, "() to restore missing Methodology v3 data charts.")
    atlas_v3125_supported_call(
      builder,
      list(
        refresh = refresh,
        stop_on_error = stop_on_error,
        build_if_missing = FALSE,
        paths = paths_to_use
      )
    )
  }

  message("Calling v3_harden_methodology_v3_figures() for all 13 Methodology v3 figure contracts.")
  get(
    "v3_harden_methodology_v3_figures",
    mode = "function",
    inherits = TRUE
  )(paths = paths_to_use)

  atlas_v3125_sync_v3_manifest(root)
  quality <- atlas_v3125_check_figure_table(
    atlas_v3125_expected_v3_figures(root),
    "methodology_v3",
    required = TRUE
  )

  quality_path <- file.path(
    root,
    "outputs",
    "methodology_v3",
    "methodology_v3_figure_integrity_hotfix6.csv"
  )
  dir.create(dirname(quality_path), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(quality, quality_path, row.names = FALSE, na = "")

  if (any(!quality$passed)) {
    message_text <- paste(
      quality$filename[!quality$passed],
      quality$reason[!quality$passed],
      sep = " (",
      collapse = "), "
    )
    if (isTRUE(stop_on_error)) {
      stop(
        "One or more Methodology v3 figures failed the Hotfix 6 integrity contract: ",
        message_text,
        "). See ",
        quality_path,
        ".",
        call. = FALSE
      )
    }
    warning(
      "Methodology v3 figure integrity issues: ",
      message_text,
      call. = FALSE
    )
  }

  invisible(quality)
}

# Compatibility aliases for legacy one-click orchestrators. They intentionally
# use the canonical evidence-aware hardener rather than relying on a historical
# master-builder function name.
make_methodology_v3_visualizations_v3125 <- function(
    refresh = FALSE,
    stop_on_error = TRUE,
    paths = NULL,
    ...) {
  root <- if (is.list(paths) && !is.null(paths$root)) paths$root else getOption(
    "ia.atlas.v312.project_root",
    getwd()
  )
  atlas_v3125_run_v3_figure_stage(
    root = root,
    paths = paths,
    refresh = refresh,
    stop_on_error = stop_on_error
  )
}
