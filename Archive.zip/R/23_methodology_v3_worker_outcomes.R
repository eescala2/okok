# Methodology v3 worker task use and quality-adjusted outcomes

v3_read_worker_outcomes <- function(paths = v3_paths()) {
  path <- file.path(paths$inputs, "worker_task_outcomes.csv")
  if (!file.exists(path)) path <- file.path(paths$inputs, "worker_task_outcomes_template.csv")
  x <- v3_drop_example_rows(v3_read_csv(path))
  if (!nrow(x)) return(tibble::tibble())
  x <- v3_clean_names(x)
  v3_require_columns(x, c(
    "response_id", "baseline_units", "baseline_minutes", "baseline_error_rate",
    "ai_units", "ai_active_minutes", "review_minutes", "correction_minutes",
    "rework_minutes", "ai_error_rate"
  ), "Worker task outcomes")
  num_cols <- intersect(c(
    "worker_tenure_months", "early_career_flag", "ai_use_days_last_week",
    "baseline_units", "baseline_minutes", "baseline_error_rate", "ai_units",
    "ai_active_minutes", "review_minutes", "correction_minutes", "rework_minutes",
    "ai_error_rate", "quality_rating_before", "quality_rating_after", "workload_before",
    "workload_after", "autonomy_before", "autonomy_after", "surveillance_intensity",
    "schedule_volatility", "wage_change", "bonus_or_gain_share", "worker_weight"
  ), names(x))
  x <- x |>
    dplyr::mutate(
      dplyr::across(dplyr::all_of(num_cols), v3_as_numeric),
      county_fips = if ("county_fips" %in% names(x)) v3_normalize_fips5(county_fips) else NA_character_,
      naics2 = if ("naics2" %in% names(x)) v3_normalize_naics2(naics2) else NA_character_,
      soc_code = if ("soc_code" %in% names(x)) v3_normalize_soc(soc_code) else NA_character_,
      worker_weight = dplyr::coalesce(worker_weight, 1),
      early_career_flag = dplyr::coalesce(as.integer(early_career_flag), as.integer(worker_tenure_months <= 36))
    )
  x$baseline_error_rate <- v3_validate_unit_interval(x$baseline_error_rate, "baseline_error_rate")
  x$ai_error_rate <- v3_validate_unit_interval(x$ai_error_rate, "ai_error_rate")
  x
}

v3_calculate_worker_outcomes <- function(x, cfg) {
  if (!nrow(x)) return(tibble::tibble())
  x |>
    dplyr::mutate(
      baseline_good_units = pmax(baseline_units, 0) * (1 - baseline_error_rate),
      ai_good_units = pmax(ai_units, 0) * (1 - ai_error_rate),
      baseline_total_minutes = pmax(baseline_minutes, 1),
      ai_total_minutes = pmax(ai_active_minutes, 0) + pmax(review_minutes, 0) +
        pmax(correction_minutes, 0) + pmax(rework_minutes, 0),
      ai_total_minutes = pmax(ai_total_minutes, 1),
      baseline_quality_adjusted_productivity = baseline_good_units / baseline_total_minutes,
      ai_quality_adjusted_productivity = ai_good_units / ai_total_minutes,
      quality_adjusted_productivity_ratio = dplyr::if_else(
        baseline_quality_adjusted_productivity > 0,
        ai_quality_adjusted_productivity / baseline_quality_adjusted_productivity,
        NA_real_
      ),
      gross_minutes_saved = baseline_total_minutes - pmax(ai_active_minutes, 0),
      review_correction_burden = pmax(review_minutes, 0) + pmax(correction_minutes, 0) + pmax(rework_minutes, 0),
      net_minutes_saved = baseline_total_minutes - ai_total_minutes,
      quality_ratio = dplyr::if_else(baseline_error_rate < 1,
                                     (1 - ai_error_rate) / (1 - baseline_error_rate), NA_real_),
      error_rate_change = ai_error_rate - baseline_error_rate,
      workload_change = workload_after - workload_before,
      autonomy_change = autonomy_after - autonomy_before,
      quality_rating_change = quality_rating_after - quality_rating_before,
      worker_benefit_index = rowMeans(cbind(
        -v3_zscore(workload_change),
        v3_zscore(autonomy_change),
        -v3_zscore(surveillance_intensity),
        -v3_zscore(schedule_volatility),
        v3_zscore(wage_change),
        v3_zscore(bonus_or_gain_share)
      ), na.rm = TRUE),
      pro_worker_outcome_pass = dplyr::case_when(
        !is.finite(quality_adjusted_productivity_ratio) ~ NA,
        quality_adjusted_productivity_ratio < (cfg$worker_outcomes$minimum_productivity_ratio %||% 1) ~ FALSE,
        quality_ratio < (cfg$worker_outcomes$quality_floor_ratio %||% 0.98) ~ FALSE,
        error_rate_change > (cfg$worker_outcomes$error_noninferiority_margin %||% 0) ~ FALSE,
        workload_change > (cfg$worker_outcomes$workload_noninferiority_margin %||% 0) ~ FALSE,
        worker_benefit_index < (cfg$worker_outcomes$worker_benefit_minimum %||% 0) ~ FALSE,
        TRUE ~ TRUE
      ),
      evidence_status = "OBSERVED"
    )
}

v3_summarize_worker_outcomes <- function(x, cfg) {
  if (!nrow(x)) return(tibble::tibble())
  group_vars <- intersect(c("pilot_id", "lwda_combined", "naics2", "soc_code", "occupation_title", "task_id", "task_name", "early_career_flag"), names(x))
  x |>
    dplyr::group_by(dplyr::across(dplyr::all_of(group_vars))) |>
    dplyr::summarise(
      respondents = dplyr::n_distinct(response_id),
      weighted_respondents = sum(worker_weight, na.rm = TRUE),
      ai_use_days_last_week = v3_weighted_mean(ai_use_days_last_week, worker_weight),
      gross_minutes_saved = v3_weighted_mean(gross_minutes_saved, worker_weight),
      review_correction_burden = v3_weighted_mean(review_correction_burden, worker_weight),
      net_minutes_saved = v3_weighted_mean(net_minutes_saved, worker_weight),
      quality_adjusted_productivity_ratio = v3_weighted_mean(quality_adjusted_productivity_ratio, worker_weight),
      quality_ratio = v3_weighted_mean(quality_ratio, worker_weight),
      error_rate_change = v3_weighted_mean(error_rate_change, worker_weight),
      workload_change = v3_weighted_mean(workload_change, worker_weight),
      autonomy_change = v3_weighted_mean(autonomy_change, worker_weight),
      surveillance_intensity = v3_weighted_mean(surveillance_intensity, worker_weight),
      schedule_volatility = v3_weighted_mean(schedule_volatility, worker_weight),
      worker_benefit_index = v3_weighted_mean(worker_benefit_index, worker_weight),
      pro_worker_pass_share = v3_weighted_mean(as.numeric(pro_worker_outcome_pass), worker_weight),
      reliability_class = v3_reliability_class(
        n = respondents,
        coverage = mean(stats::complete.cases(dplyr::pick(dplyr::all_of(c(
          "quality_adjusted_productivity_ratio", "quality_ratio", "worker_benefit_index"
        ))))),
        observed = TRUE,
        fallback = FALSE
      ),
      evidence_status = "OBSERVED",
      .groups = "drop"
    ) |>
    dplyr::mutate(
      publication_eligible = respondents >= (cfg$worker_outcomes$minimum_cell_n %||% 20),
      interpretation = dplyr::case_when(
        !publication_eligible ~ "Insufficient local sample for public cell reporting",
        pro_worker_pass_share >= 0.75 ~ "Observed evidence is broadly pro-worker",
        pro_worker_pass_share >= 0.50 ~ "Mixed worker outcome evidence",
        TRUE ~ "Observed worker outcomes require redesign or suspension review"
      )
    )
}

apply_methodology_v3_worker_outcomes <- function(paths = v3_paths(), cfg = v3_load_config(paths$root)) {
  raw <- v3_read_worker_outcomes(paths)
  calculated <- v3_calculate_worker_outcomes(raw, cfg)
  summary <- v3_summarize_worker_outcomes(calculated, cfg)
  status <- tibble::tibble(
    module = "worker_task_use_and_quality_adjusted_outcomes",
    rows_raw = nrow(raw),
    rows_summary = nrow(summary),
    evidence_status = if (nrow(raw)) "OBSERVED" else "UNAVAILABLE",
    note = if (nrow(raw))
      "Quality-adjusted productivity uses good units divided by total active, review, correction, and rework minutes."
    else
      "No Iowa worker pulse or pilot task-outcome records were supplied; no local worker outcome is imputed from exposure."
  )
  v3_write_csv(calculated, file.path(paths$processed, "worker_quality_adjusted_outcomes.csv"))
  v3_write_csv(summary, file.path(paths$processed, "worker_outcomes_summary.csv"))
  v3_write_csv(status, file.path(paths$outputs, "worker_outcomes_status_v3.csv"))
  list(raw = raw, calculated = calculated, summary = summary, status = status)
}
