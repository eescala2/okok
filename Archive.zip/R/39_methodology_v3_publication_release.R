# Methodology v3.0.8 publication-release output layer
#
# This module is intentionally limited to presentation and output contracts.
# It does not change Methodology v2 or v3 analytical estimates.
#
# It provides:
# - article-ready, transparent, high-resolution evidence-status graphics;
# - a readable evidence scorecard;
# - report-safe HTML figure emission (no knit_image_paths text);
# - a publication-ready all-figures PDF compendium;
# - strict validation of figures, HTML reports, report PDFs, and editable Excel.

v3_pub_or <- function(x, y) {
  if (is.null(x) || length(x) == 0L || (length(x) == 1L && is.na(x))) y else x
}

if (!exists("%||%", mode = "function", inherits = TRUE)) {
  `%||%` <- v3_pub_or
}

v3_pub_paths <- function(paths = NULL) {
  if (is.null(paths)) {
    provider <- get0("v3_paths", mode = "function", inherits = TRUE)
    if (is.function(provider)) paths <- provider()
  }
  if (!is.list(paths)) paths <- list(root = getwd())

  root <- normalizePath(paths$root %||% getwd(), winslash = "/", mustWork = FALSE)
  outputs_root <- paths$outputs_root %||% file.path(root, "outputs")
  outputs_v3 <- paths$outputs %||% paths$outputs_v3 %||% file.path(outputs_root, "methodology_v3")
  figures_v3 <- paths$figures %||% paths$figures_v3 %||% file.path(root, "figures", "methodology_v3")
  processed <- paths$processed %||% file.path(root, "data_processed", "methodology_v3")

  dir.create(outputs_root, recursive = TRUE, showWarnings = FALSE)
  dir.create(outputs_v3, recursive = TRUE, showWarnings = FALSE)
  dir.create(figures_v3, recursive = TRUE, showWarnings = FALSE)

  list(
    root = root,
    outputs_root = outputs_root,
    outputs_v3 = outputs_v3,
    figures_v3 = figures_v3,
    processed = processed
  )
}

v3_pub_font_family <- function() {
  if (requireNamespace("systemfonts", quietly = TRUE)) {
    exports <- getNamespaceExports("systemfonts")
    hit <- if ("match_fonts" %in% exports) {
      tryCatch(systemfonts::match_fonts("Arial"), error = function(e) NULL)
    } else {
      suppressWarnings(tryCatch(systemfonts::match_font("Arial"), error = function(e) NULL))
    }
    if (!is.null(hit) && is.character(hit$path) && length(hit$path) && nzchar(hit$path[[1L]])) {
      return("Arial")
    }
  }
  "sans"
}

v3_pub_theme <- function(base_size = 10) {
  family <- v3_pub_font_family()
  ggplot2::theme_minimal(base_family = family, base_size = base_size) +
    ggplot2::theme(
      text = ggplot2::element_text(family = family, color = "black"),
      axis.title = ggplot2::element_text(size = 10, face = "plain", color = "black"),
      axis.text = ggplot2::element_text(size = 10, face = "plain", color = "black"),
      legend.title = ggplot2::element_text(size = 10, face = "bold", color = "black"),
      legend.text = ggplot2::element_text(size = 10, face = "plain", color = "black"),
      strip.text = ggplot2::element_text(size = 10, face = "bold", color = "black"),
      plot.caption = ggplot2::element_text(size = 9, hjust = 0, color = "black"),
      plot.background = ggplot2::element_rect(fill = "transparent", color = NA),
      panel.background = ggplot2::element_rect(fill = "transparent", color = NA),
      legend.background = ggplot2::element_rect(fill = "transparent", color = NA),
      legend.box.background = ggplot2::element_rect(fill = "transparent", color = NA),
      plot.margin = ggplot2::margin(12, 18, 12, 18)
    )
}

v3_pub_install_graphics_defaults <- function() {
  if (requireNamespace("ggplot2", quietly = TRUE)) {
    try(ggplot2::theme_set(v3_pub_theme()), silent = TRUE)
    try(ggplot2::update_geom_defaults("point", list(colour = "#1C5DBA")), silent = TRUE)
    try(ggplot2::update_geom_defaults("line", list(colour = "#1C5DBA")), silent = TRUE)
    try(ggplot2::update_geom_defaults("bar", list(fill = "#1C5DBA")), silent = TRUE)
    try(ggplot2::update_geom_defaults("col", list(fill = "#1C5DBA")), silent = TRUE)
  }
  invisible(TRUE)
}

v3_pub_figure_catalog <- function() {
  tibble::tribble(
    ~id, ~filename, ~title, ~module, ~dependency,
    "37", "methodology_v3_37_observed_adoption_nowcast.png", "Observed adoption nowcast", "observed_adoption_nowcast", "Census BTOS AI supplement and/or a normalized Iowa employer pulse",
    "38", "methodology_v3_38_exposure_vs_adoption.png", "Exposure versus observed adoption", "observed_adoption_nowcast", "Observed BTOS or Iowa adoption estimates joined to the exposure atlas",
    "39", "methodology_v3_39_worker_quality_adjusted_outcomes.png", "Worker task use and quality-adjusted outcomes", "quality_adjusted_worker_outcomes", "Iowa worker pulse or preregistered pilot task-outcome records",
    "40", "methodology_v3_40_early_career_fragility.png", "Early-career fragility", "early_career_fragility", "Usable Census QWI sex-by-age records or a normalized local early-career file",
    "41", "methodology_v3_41_apprenticeship_access.png", "Apprenticeship access", "apprenticeship_access", "Registered apprenticeship capacity, registrations, completions, wages, and waitlists",
    "42", "methodology_v3_42_credential_feasible_paths.png", "Credential-feasible transition pathways", "credential_feasible_transitions", "Credential, training-program, access, wage, opening, and employer-validation records",
    "43", "methodology_v3_43_transition_constraints.png", "Transition constraint audit", "credential_feasible_transitions", "Candidate occupation pairs plus credential, physical, schedule, commute, and training constraints",
    "44", "methodology_v3_44_industrial_ai_readiness.png", "Industrial AI readiness", "industrial_ai_readiness", "Employer or site readiness assessments covering capital, sensors, data, cyber, maintenance, management, and training",
    "45", "methodology_v3_45_productivity_j_curve.png", "Industrial AI productivity J-curve", "productivity_j_curve", "Readiness assessments plus implementation, operating-cost, ramp, plateau, and worker-gain assumptions",
    "46", "methodology_v3_46_pilot_decision_rules.png", "Pilot scale, redesign, suspend, or stop decisions", "causal_pilot_registry", "Preregistered pilot registry, comparison design, incidents, appeals, and 30, 90, and 180-day outcomes",
    "47", "methodology_v3_47_aria_assurance.png", "NIST/ARIA assurance coverage", "nist_aria_system_assurance", "Pilot or system model testing, red teaming, field testing, and system-level evaluation records",
    "48", "methodology_v3_48_regional_value_capture.png", "Regional value capture", "regional_value_capture", "BEA regional data plus Iowa value-added, labor-income, supplier, leakage, and worker-share assumptions",
    "49", "methodology_v3_49_evidence_scorecard.png", "Methodology v3 evidence scorecard", "evidence_scorecard", "Module-level and public-source evidence-status records"
  )
}

v3_pub_status_inputs <- function(paths = NULL) {
  p <- v3_pub_paths(paths)
  read_csv_safe <- function(path) {
    if (!file.exists(path) || is.na(file.info(path)$size) || file.info(path)$size <= 0) {
      return(tibble::tibble())
    }
    tryCatch(
      readr::read_csv(path, show_col_types = FALSE, progress = FALSE),
      error = function(e) tibble::tibble()
    )
  }
  list(
    paths = p,
    modules = read_csv_safe(file.path(p$outputs_v3, "methodology_v3_module_status.csv")),
    gaps = read_csv_safe(file.path(p$outputs_v3, "evidence_gap_register_v3.csv")),
    public = read_csv_safe(file.path(p$outputs_v3, "public_data_status_v3.csv"))
  )
}

v3_pub_module_record <- function(module, status_inputs) {
  modules <- status_inputs$modules
  gaps <- status_inputs$gaps
  hit <- if (nrow(modules) && "module" %in% names(modules)) {
    dplyr::filter(modules, .data$module == module)
  } else tibble::tibble()
  gap <- if (nrow(gaps) && "module" %in% names(gaps)) {
    dplyr::filter(gaps, .data$module == module)
  } else tibble::tibble()

  list(
    rows = if (nrow(hit) && "rows" %in% names(hit)) suppressWarnings(as.numeric(hit$rows[[1L]])) else 0,
    status = if (nrow(hit) && "evidence_status" %in% names(hit)) as.character(hit$evidence_status[[1L]]) else "UNAVAILABLE",
    note = if (nrow(hit) && "note" %in% names(hit)) as.character(hit$note[[1L]]) else "No validated evidence rows were available.",
    required_action = if (nrow(gap) && "required_action" %in% names(gap)) as.character(gap$required_action[[1L]]) else "Connect a validated public or local source before publishing a substantive estimate."
  )
}

v3_evidence_placeholder_plot_v308 <- function(
  title = NULL,
  message = NULL,
  subtitle = NULL,
  note = NULL,
  detail = NULL,
  module = NULL,
  dependency = NULL,
  required_action = NULL,
  rows = 0,
  status = "UNAVAILABLE",
  ...
) {
  dots <- list(...)
  candidates <- unlist(
    c(list(message, subtitle, note, detail), dots[vapply(dots, is.character, logical(1L))]),
    use.names = FALSE
  )
  candidates <- candidates[!is.na(candidates) & nzchar(trimws(candidates))]

  detail <- as.character(detail %||% if (length(candidates)) candidates[[1L]] else "No validated evidence rows were available.")
  dependency <- as.character(dependency %||% "A validated public, administrative, employer, worker, or pilot input is required.")
  required_action <- as.character(required_action %||% "Connect the required source and rerun the evidence layer. Retain UNAVAILABLE until validation passes.")
  status <- toupper(as.character(status %||% "UNAVAILABLE"))
  rows <- suppressWarnings(as.numeric(rows %||% 0))
  if (!is.finite(rows)) rows <- 0

  family <- v3_pub_font_family()
  blue <- "#1C5DBA"
  teal <- "#00808D"
  pale <- "#F5F8E8"
  grey <- "#4D4D4D"

  status_label <- paste0(status, " | ", scales::comma(rows, accuracy = 1), " validated rows")

  ggplot2::ggplot() +
    ggplot2::annotate(
      "rect", xmin = 0.025, xmax = 0.975, ymin = 0.075, ymax = 0.925,
      fill = pale, color = blue, linewidth = 1.0
    ) +
    ggplot2::annotate(
      "rect", xmin = 0.025, xmax = 0.052, ymin = 0.075, ymax = 0.925,
      fill = blue, color = blue
    ) +
    ggplot2::annotate(
      "text", x = 0.082, y = 0.84, label = "EVIDENCE UNAVAILABLE",
      hjust = 0, vjust = 1, family = family, fontface = "bold", size = 7.1, color = teal
    ) +
    ggplot2::annotate(
      "text", x = 0.082, y = 0.735, label = status_label,
      hjust = 0, vjust = 1, family = family, fontface = "bold", size = 4.8, color = blue
    ) +
    ggplot2::annotate(
      "text", x = 0.082, y = 0.635, label = "WHAT THIS MEANS",
      hjust = 0, vjust = 1, family = family, fontface = "bold", size = 4.3, color = blue
    ) +
    ggplot2::annotate(
      "text", x = 0.082, y = 0.585,
      label = stringr::str_wrap(detail, width = 88),
      hjust = 0, vjust = 1, family = family, size = 4.2, color = "black", lineheight = 1.10
    ) +
    ggplot2::annotate(
      "text", x = 0.082, y = 0.405, label = "EVIDENCE REQUIRED",
      hjust = 0, vjust = 1, family = family, fontface = "bold", size = 4.3, color = blue
    ) +
    ggplot2::annotate(
      "text", x = 0.082, y = 0.355,
      label = stringr::str_wrap(dependency, width = 88),
      hjust = 0, vjust = 1, family = family, size = 4.2, color = "black", lineheight = 1.10
    ) +
    ggplot2::annotate(
      "text", x = 0.082, y = 0.195, label = "NEXT STEP",
      hjust = 0, vjust = 1, family = family, fontface = "bold", size = 4.3, color = blue
    ) +
    ggplot2::annotate(
      "text", x = 0.082, y = 0.145,
      label = stringr::str_wrap(required_action, width = 88),
      hjust = 0, vjust = 1, family = family, size = 4.1, color = "black", lineheight = 1.10
    ) +
    ggplot2::annotate(
      "text", x = 0.962, y = 0.095,
      label = "No adoption, productivity, worker-benefit, readiness, causal, or value-capture estimate is inferred from exposure alone.",
      hjust = 1, vjust = 0, family = family, size = 3.2, color = grey
    ) +
    ggplot2::coord_cartesian(xlim = c(0, 1), ylim = c(0, 1), clip = "off") +
    ggplot2::theme_void(base_family = family) +
    ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = "transparent", color = NA),
      panel.background = ggplot2::element_rect(fill = "transparent", color = NA),
      plot.margin = ggplot2::margin(10, 12, 10, 12)
    )
}

# Override the previous output-quality placeholder helper.
v3_evidence_placeholder_plot_v304 <- v3_evidence_placeholder_plot_v308

v3_evidence_scorecard_plot_v308 <- function(paths = NULL) {
  si <- v3_pub_status_inputs(paths)
  modules <- si$modules
  public <- si$public

  if (!nrow(modules)) {
    modules <- tibble::tibble(
      module = "Methodology v3 evidence modules",
      rows = 0,
      evidence_status = "UNAVAILABLE"
    )
  }

  module_df <- modules |>
    dplyr::transmute(
      section = "Evidence modules",
      item = stringr::str_to_sentence(gsub("_", " ", as.character(.data$module))),
      rows = suppressWarnings(as.numeric(.data$rows)),
      status = toupper(as.character(.data$evidence_status))
    )

  public_df <- if (nrow(public)) {
    source_col <- intersect(c("source", "dataset", "name"), names(public))
    status_col <- intersect(c("status", "evidence_status"), names(public))
    rows_col <- intersect(c("rows", "validated_rows", "record_count"), names(public))

    tibble::tibble(
      section = "Public inputs",
      item = if (length(source_col)) as.character(public[[source_col[[1L]]]]) else "Public input",
      rows = if (length(rows_col)) suppressWarnings(as.numeric(public[[rows_col[[1L]]]])) else 0,
      status = if (length(status_col)) toupper(as.character(public[[status_col[[1L]]]])) else "UNAVAILABLE"
    )
  } else {
    tibble::tibble(
      section = "Public inputs",
      item = "No public-source status file",
      rows = 0,
      status = "UNAVAILABLE"
    )
  }

  df <- dplyr::bind_rows(public_df, module_df) |>
    dplyr::mutate(
      status = dplyr::case_when(
        .data$status %in% c("AVAILABLE", "OBSERVED", "COMPLETE") ~ "AVAILABLE",
        .data$status %in% c("PROVISIONAL", "PARTIAL", "MODELED", "BENCHMARKED", "SCENARIO") ~ "PROVISIONAL",
        TRUE ~ "UNAVAILABLE"
      ),
      rows = dplyr::coalesce(.data$rows, 0),
      label = paste0(.data$status, " | ", scales::comma(.data$rows, accuracy = 1), " rows"),
      item = stringr::str_wrap(.data$item, width = 34)
    )

  df$item_key <- factor(
    paste(df$section, df$item, sep = "___"),
    levels = rev(paste(df$section, df$item, sep = "___"))
  )

  family <- v3_pub_font_family()
  fills <- c(AVAILABLE = "#C6D667", PROVISIONAL = "#E0A624", UNAVAILABLE = "#B32A2D")
  label_colours <- c(AVAILABLE = "black", PROVISIONAL = "black", UNAVAILABLE = "white")

  ggplot2::ggplot(df, ggplot2::aes(x = 1, y = .data$item_key, fill = .data$status)) +
    ggplot2::geom_tile(width = 0.96, height = 0.76, color = "white", linewidth = 0.6) +
    ggplot2::geom_text(
      ggplot2::aes(label = .data$label, color = .data$status),
      family = family, fontface = "bold", size = 3.9, na.rm = TRUE
    ) +
    ggplot2::facet_grid(rows = ggplot2::vars(section), scales = "free_y", space = "free_y", switch = "y") +
    ggplot2::scale_fill_manual(values = fills, drop = FALSE) +
    ggplot2::scale_color_manual(values = label_colours, guide = "none", drop = FALSE) +
    ggplot2::scale_y_discrete(labels = function(x) sub("^.*___", "", x)) +
    ggplot2::scale_x_continuous(limits = c(0.40, 1.60), expand = c(0, 0)) +
    ggplot2::labs(
      x = NULL, y = NULL, fill = "Evidence status",
      caption = "Validated records available to the Methodology v3 evidence layer. UNAVAILABLE is retained rather than inferred from exposure."
    ) +
    v3_pub_theme(base_size = 10) +
    ggplot2::theme(
      axis.text.x = ggplot2::element_blank(),
      axis.ticks.x = ggplot2::element_blank(),
      axis.text.y = ggplot2::element_text(color = "black", size = 10),
      panel.grid = ggplot2::element_blank(),
      strip.placement = "outside",
      strip.text.y.left = ggplot2::element_text(angle = 0, hjust = 1, color = "#00808D", size = 11, face = "bold"),
      legend.position = "bottom",
      plot.caption = ggplot2::element_text(hjust = 0, color = "black", size = 9.5)
    )
}

v3_evidence_scorecard_plot_v304 <- v3_evidence_scorecard_plot_v308

v3_pub_save_plot <- function(plot, path, width = 11, height = 6.5, dpi = 300) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  if (inherits(plot, "ggplot")) {
    plot <- plot + ggplot2::theme(
      plot.background = ggplot2::element_rect(fill = "transparent", color = NA),
      panel.background = ggplot2::element_rect(fill = "transparent", color = NA),
      legend.background = ggplot2::element_rect(fill = "transparent", color = NA)
    )
  }
  device <- if (requireNamespace("ragg", quietly = TRUE)) ragg::agg_png else "png"
  ggplot2::ggsave(
    filename = path,
    plot = plot,
    width = width,
    height = height,
    units = "in",
    dpi = dpi,
    bg = "transparent",
    device = device,
    limitsize = FALSE
  )
  invisible(path)
}

# Override the previous saver so the evidence-aware figures are article-ready.
v3_oq_save_plot <- v3_pub_save_plot

v3_pub_html_escape <- function(x) {
  x <- as.character(x %||% "")
  if (requireNamespace("htmltools", quietly = TRUE)) {
    return(as.character(htmltools::htmlEscape(x, attribute = FALSE)))
  }
  x <- gsub("&", "&amp;", x, fixed = TRUE)
  x <- gsub("<", "&lt;", x, fixed = TRUE)
  x <- gsub(">", "&gt;", x, fixed = TRUE)
  x <- gsub('"', "&quot;", x, fixed = TRUE)
  x
}

v3_pub_html_attr_escape <- function(x) {
  x <- as.character(x %||% "")
  if (requireNamespace("htmltools", quietly = TRUE)) {
    return(as.character(htmltools::htmlEscape(x, attribute = TRUE)))
  }
  v3_pub_html_escape(x)
}

v3_pub_resolve_figure_path <- function(id, report_env = NULL) {
  if (is.null(report_env)) {
    report_env <- if (requireNamespace("knitr", quietly = TRUE)) knitr::knit_global() else .GlobalEnv
  }

  manifest <- get0("manifest", envir = report_env, inherits = TRUE)
  paths <- get0("paths", envir = report_env, inherits = TRUE)
  p <- v3_pub_paths(paths)
  id_chr <- as.character(id)
  candidate <- character()

  if (is.data.frame(manifest) && nrow(manifest) && "id" %in% names(manifest)) {
    hit <- which(as.character(manifest$id) == id_chr)
    if (length(hit)) {
      path_col <- intersect(c("path", "output_path", "file", "filename"), names(manifest))
      if (length(path_col)) candidate <- as.character(manifest[[path_col[[1L]]]][hit[[1L]]])
    }
  }

  catalog <- v3_pub_figure_catalog()
  catalog_hit <- which(catalog$id == id_chr)
  fallback_name <- if (length(catalog_hit)) catalog$filename[[catalog_hit[[1L]]]] else paste0("methodology_v3_", id_chr, ".png")

  tries <- unique(c(
    candidate,
    if (length(candidate)) file.path(p$root, candidate) else character(),
    if (length(candidate)) file.path(p$figures_v3, basename(candidate)) else character(),
    file.path(p$figures_v3, fallback_name)
  ))
  tries <- tries[!is.na(tries) & nzchar(tries)]
  hit <- tries[file.exists(tries)]
  if (!length(hit)) return(NA_character_)
  normalizePath(hit[[1L]], winslash = "/", mustWork = TRUE)
}

v3_pub_image_uri <- function(path) {
  if (!file.exists(path)) return(NA_character_)
  out <- tryCatch(knitr::image_uri(path), error = function(e) NA_character_)
  if (length(out) && !is.na(out) && nzchar(out)) return(out)
  if (requireNamespace("xfun", quietly = TRUE)) {
    out <- tryCatch(xfun::base64_uri(path), error = function(e) NA_character_)
    if (length(out) && !is.na(out) && nzchar(out)) return(out)
  }
  paste0("file://", utils::URLencode(normalizePath(path, winslash = "/", mustWork = TRUE), reserved = FALSE))
}

v3_publication_figure_block <- function(id, title, note) {
  if (!requireNamespace("knitr", quietly = TRUE)) {
    stop("The knitr package is required to emit Methodology v3 report figures.", call. = FALSE)
  }

  path <- v3_pub_resolve_figure_path(id, knitr::knit_global())
  title_html <- v3_pub_html_escape(title)
  note_html <- v3_pub_html_escape(note)
  id_html <- v3_pub_html_attr_escape(as.character(id))

  if (is.na(path) || !file.exists(path)) {
    html <- paste0(
      '<figure class="report-figure methodology-v3-figure" data-figure-id="', id_html, '">',
      '<div class="figure-title">Figure ', id_html, '. ', title_html, '</div>',
      '<div class="figure-unavailable">Figure unavailable. Rebuild the Methodology v3 visualization layer.</div>',
      '<figcaption class="source-note">', note_html, '</figcaption>',
      '</figure>'
    )
    return(knitr::asis_output(html))
  }

  src <- v3_pub_image_uri(path)
  alt <- paste0(title, ". ", sub("^Source:\\s*", "", note, ignore.case = TRUE))
  html <- paste0(
    '<figure class="report-figure methodology-v3-figure" data-figure-id="', id_html, '">',
    '<div class="figure-title">Figure ', id_html, '. ', title_html, '</div>',
    '<img class="methodology-v3-figure-img" src="', v3_pub_html_attr_escape(src), '" alt="', v3_pub_html_attr_escape(alt), '">',
    '<figcaption class="source-note">', note_html, '</figcaption>',
    '</figure>'
  )
  knitr::asis_output(html)
}

v3_install_publication_report_context <- function(report_env = NULL) {
  if (!requireNamespace("knitr", quietly = TRUE)) return(invisible(FALSE))
  if (is.null(report_env)) report_env <- knitr::knit_global()

  knitr::opts_chunk$set(
    echo = FALSE,
    warning = FALSE,
    message = FALSE,
    results = "asis",
    fig.align = "center",
    out.width = "100%"
  )

  assign(
    "figure_block",
    function(id, title, note) v3_publication_figure_block(id = id, title = title, note = note),
    envir = report_env
  )

  invisible(TRUE)
}

v3_pub_open_pdf_device <- function(path, width = 11, height = 8.5) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  if (file.exists(path)) unlink(path, force = TRUE)
  grDevices::pdf(
    path,
    width = width,
    height = height,
    onefile = TRUE,
    useDingbats = FALSE,
    family = "Helvetica",
    paper = "special"
  )
  invisible("pdf")
}

v3_pub_compendium_files <- function(paths = NULL) {
  p <- v3_pub_paths(paths)
  catalog <- v3_pub_figure_catalog()
  files <- file.path(p$figures_v3, catalog$filename)
  tibble::tibble(
    id = catalog$id,
    title = catalog$title,
    path = files
  ) |>
    dplyr::filter(file.exists(.data$path))
}

v3_pdf_watchdog_create_compendium <- function(paths = NULL, force = TRUE) {
  p <- v3_pub_paths(paths)
  output <- file.path(p$outputs_root, "all_generated_figures_methodology_v3_printable.pdf")
  files <- v3_pub_compendium_files(paths)

  if (!nrow(files)) {
    stop("No Methodology v3 PNG figures were found for the publication compendium.", call. = FALSE)
  }
  if (!requireNamespace("png", quietly = TRUE)) {
    utils::install.packages("png", dependencies = NA, quiet = TRUE)
  }
  if (!requireNamespace("png", quietly = TRUE)) {
    stop("The png package is required for the publication figure compendium.", call. = FALSE)
  }
  if (file.exists(output) && isTRUE(force)) unlink(output, force = TRUE)

  v3_pub_open_pdf_device(output, width = 11, height = 8.5)
  on.exit(try(grDevices::dev.off(), silent = TRUE), add = TRUE)

  for (i in seq_len(nrow(files))) {
    img <- tryCatch(png::readPNG(files$path[[i]]), error = function(e) NULL)
    if (is.null(img)) next

    dims <- dim(img)
    aspect <- if (length(dims) >= 2L && dims[[1L]] > 0) dims[[2L]] / dims[[1L]] else 16 / 9
    max_w <- 10.35
    max_h <- 6.82
    w <- min(max_w, max_h * aspect)
    h <- w / aspect

    grid::grid.newpage()
    grid::grid.rect(gp = grid::gpar(fill = "white", col = NA))
    grid::grid.text(
      paste0("Figure ", files$id[[i]], ". ", files$title[[i]]),
      x = grid::unit(0.5, "npc"), y = grid::unit(0.965, "npc"),
      gp = grid::gpar(fontfamily = "Helvetica", fontsize = 12, fontface = "bold", col = "black")
    )
    grid::grid.raster(
      img,
      x = grid::unit(0.5, "npc"), y = grid::unit(0.49, "npc"),
      width = grid::unit(w, "in"), height = grid::unit(h, "in"),
      interpolate = TRUE
    )
    grid::grid.text(
      "Source: Iowa AI Workforce Atlas Methodology v3 evidence system. UNAVAILABLE panels indicate that no validated evidence was imputed.",
      x = grid::unit(0.03, "npc"), y = grid::unit(0.025, "npc"), just = c("left", "bottom"),
      gp = grid::gpar(fontfamily = "Helvetica", fontsize = 10, col = "black")
    )
  }

  grDevices::dev.off()
  on.exit(NULL, add = FALSE)
  output
}

v3_pub_html_quality <- function(path) {
  out <- list(exists = file.exists(path), bytes = 0, valid = FALSE, detail = "")
  if (!out$exists) {
    out$detail <- "missing"
    return(out)
  }
  out$bytes <- unname(file.info(path)$size)
  txt <- paste(readLines(path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
  bad <- c(
    knit_image_paths = grepl("knit_image_paths", txt, fixed = TRUE),
    readonly_warning = grepl("object is read-only and cannot be modified", txt, fixed = TRUE),
    escaped_table_title = grepl("&lt;div class=\\\"table-title\\\"", txt),
    printed_setup_marker = grepl("IA_ATLAS_V3_ATOMIC_REPORT_CONTEXT", txt, fixed = TRUE)
  )
  figure_count <- length(gregexpr("data-figure-id=", txt, fixed = TRUE)[[1L]])
  if (identical(figure_count, 1L) && gregexpr("data-figure-id=", txt, fixed = TRUE)[[1L]][[1L]] == -1L) figure_count <- 0L
  out$valid <- out$bytes > 100000 && !any(bad) && figure_count >= 13L
  out$detail <- paste0(
    "figures=", figure_count,
    "; bad=", paste(names(bad)[bad], collapse = ",")
  )
  out
}

v3_pub_pdf_quality <- function(path, html = NULL) {
  if (exists("v3_pdf_watchdog_valid", mode = "function", inherits = TRUE)) {
    x <- v3_pdf_watchdog_valid(path, html)
  } else if (exists("v3_oq_pdf_valid", mode = "function", inherits = TRUE)) {
    x <- v3_oq_pdf_valid(path, html)
  } else {
    x <- list(exists = file.exists(path), bytes = if (file.exists(path)) file.info(path)$size else 0, pages = NA_integer_, first_text = "", valid = FALSE)
  }

  text_all <- ""
  if (file.exists(path) && requireNamespace("pdftools", quietly = TRUE)) {
    text_all <- paste(tryCatch(pdftools::pdf_text(path), error = function(e) character()), collapse = "\n")
  }
  bad_report_text <- grepl("knit_image_paths|object is read-only and cannot be modified|Search Google or type a URL", text_all, ignore.case = TRUE)
  pages_ok <- is.na(x$pages) || suppressWarnings(as.integer(x$pages)) >= 10L
  x$valid <- isTRUE(x$valid) && !bad_report_text && pages_ok
  x$detail <- paste0("pages=", x$pages %||% NA_integer_, "; bad_report_text=", bad_report_text)
  x
}

v3_pub_excel_quality <- function(paths = NULL) {
  p <- v3_pub_paths(paths)
  workbook <- file.path(p$outputs_root, "iowa_ai_workforce_atlas_methodology_v3_editable_figures.xlsx")
  manifest_path <- file.path(p$outputs_v3, "editable_excel_figure_manifest_v3.csv")
  out <- list(
    workbook = workbook,
    manifest = manifest_path,
    exists = file.exists(workbook),
    bytes = if (file.exists(workbook)) unname(file.info(workbook)$size) else 0,
    manifest_rows = 0L,
    editable_rows = 0L,
    drawing_xml = 0L,
    valid = FALSE,
    detail = ""
  )

  manifest <- if (file.exists(manifest_path)) {
    tryCatch(readr::read_csv(manifest_path, show_col_types = FALSE, progress = FALSE), error = function(e) tibble::tibble())
  } else tibble::tibble()

  out$manifest_rows <- nrow(manifest)
  if (nrow(manifest)) {
    status_col <- intersect(c("status", "output_status"), names(manifest))
    id_col <- intersect(c("id", "figure_id"), names(manifest))
    keep <- rep(TRUE, nrow(manifest))
    if (length(id_col)) keep <- as.character(manifest[[id_col[[1L]]]]) %in% as.character(37:49)
    if (length(status_col)) {
      out$editable_rows <- sum(keep & grepl("editable", as.character(manifest[[status_col[[1L]]]]), ignore.case = TRUE), na.rm = TRUE)
    } else {
      out$editable_rows <- sum(keep)
    }
  }

  if (file.exists(workbook)) {
    listing <- tryCatch(utils::unzip(workbook, list = TRUE), error = function(e) NULL)
    if (!is.null(listing) && "Name" %in% names(listing)) {
      out$drawing_xml <- sum(grepl("^xl/drawings/drawing[0-9]+\\.xml$", listing$Name))
    }
  }

  out$valid <- out$exists && out$bytes > 100000 && out$manifest_rows >= 13L && out$editable_rows >= 13L && out$drawing_xml >= 13L
  out$detail <- paste0(
    "manifest_rows=", out$manifest_rows,
    "; editable_rows=", out$editable_rows,
    "; drawing_xml=", out$drawing_xml
  )
  out
}

v3_validate_methodology_v3_publication_release <- function(paths = NULL, stop_on_failure = TRUE) {
  p <- v3_pub_paths(paths)
  catalog <- v3_pub_figure_catalog()

  figure_checks <- purrr::map_dfr(seq_len(nrow(catalog)), function(i) {
    path <- file.path(p$figures_v3, catalog$filename[[i]])
    dims <- c(NA_integer_, NA_integer_)
    if (file.exists(path) && requireNamespace("png", quietly = TRUE)) {
      img <- tryCatch(png::readPNG(path), error = function(e) NULL)
      if (!is.null(img) && length(dim(img)) >= 2L) dims <- c(dim(img)[[2L]], dim(img)[[1L]])
    }
    passed <- file.exists(path) && file.info(path)$size > 35000 && (is.na(dims[[1L]]) || (dims[[1L]] >= 1800L && dims[[2L]] >= 1000L))
    tibble::tibble(
      check = paste0("Figure ", catalog$id[[i]], " article-ready PNG"),
      path = path,
      passed = passed,
      detail = paste0("bytes=", if (file.exists(path)) file.info(path)$size else 0, "; pixels=", paste(dims, collapse = "x"))
    )
  })

  html_jobs <- tibble::tribble(
    ~check, ~path,
    "Quarto Methodology v3 HTML embeds all figures cleanly", file.path(p$outputs_root, "atlas_methodology_v3_quarto.html"),
    "R Markdown Methodology v3 HTML embeds all figures cleanly", file.path(p$outputs_root, "atlas_methodology_v3_rmarkdown.html")
  )
  html_checks <- purrr::pmap_dfr(html_jobs, function(check, path) {
    x <- v3_pub_html_quality(path)
    tibble::tibble(check = check, path = path, passed = isTRUE(x$valid), detail = x$detail)
  })

  pdf_jobs <- tibble::tribble(
    ~check, ~path, ~html,
    "Quarto Methodology v3 PDF is a clean multi-page report", file.path(p$outputs_root, "atlas_methodology_v3_quarto.pdf"), file.path(p$outputs_root, "atlas_methodology_v3_quarto.html"),
    "R Markdown Methodology v3 PDF is a clean multi-page report", file.path(p$outputs_root, "atlas_methodology_v3_rmarkdown.pdf"), file.path(p$outputs_root, "atlas_methodology_v3_rmarkdown.html"),
    "Methodology v3 all-figures compendium exists", file.path(p$outputs_root, "all_generated_figures_methodology_v3_printable.pdf"), NA_character_
  )
  pdf_checks <- purrr::pmap_dfr(pdf_jobs, function(check, path, html) {
    if (grepl("compendium", check, ignore.case = TRUE)) {
      exists <- file.exists(path)
      pages <- NA_integer_
      if (exists && requireNamespace("pdftools", quietly = TRUE)) {
        pages <- tryCatch(as.integer(pdftools::pdf_info(path)$pages), error = function(e) NA_integer_)
      }
      passed <- exists && file.info(path)$size > 250000 && (is.na(pages) || pages >= 13L)
      tibble::tibble(check = check, path = path, passed = passed, detail = paste0("pages=", pages, "; bytes=", if (exists) file.info(path)$size else 0))
    } else {
      x <- v3_pub_pdf_quality(path, html)
      tibble::tibble(check = check, path = path, passed = isTRUE(x$valid), detail = x$detail)
    }
  })

  excel <- v3_pub_excel_quality(paths)
  excel_check <- tibble::tibble(
    check = "Editable Excel workbook contains all 13 Methodology v3 vector drawings",
    path = excel$workbook,
    passed = isTRUE(excel$valid),
    detail = excel$detail
  )

  out <- dplyr::bind_rows(figure_checks, html_checks, pdf_checks, excel_check) |>
    dplyr::mutate(checked_at_utc = format(Sys.time(), tz = "UTC", usetz = TRUE))

  output <- file.path(p$outputs_v3, "publication_release_output_check_v308.csv")
  readr::write_csv(out, output, na = "")

  if (isTRUE(stop_on_failure) && any(!out$passed)) {
    failed <- paste(out$check[!out$passed], collapse = "; ")
    stop("Methodology v3 publication-release validation failed: ", failed, ". See ", output, ".", call. = FALSE)
  }

  message("Methodology v3 publication-release validation passed. Wrote: ", output)
  invisible(out)
}

# Apply the publication defaults whenever this module is sourced.
v3_pub_install_graphics_defaults()
