# Methodology v3 end-to-end output validation

v3_check_file <- function(label, path, minimum_bytes = 1) {
  exists <- file.exists(path)
  bytes <- if (exists) as.numeric(file.info(path)$size) else NA_real_
  tibble::tibble(
    check = label,
    path = normalizePath(path, winslash = "/", mustWork = FALSE),
    exists = exists,
    bytes = bytes,
    passed = exists && is.finite(bytes) && bytes >= minimum_bytes,
    detail = if (!exists) "missing" else if (bytes < minimum_bytes) "file is smaller than expected" else "ok"
  )
}

v3_check_csv <- function(label, path, minimum_rows = 0L, required_columns = character()) {
  base <- v3_check_file(label, path, 1)
  if (!base$passed) return(base)
  x <- tryCatch(v3_read_csv(path), error = function(e) NULL)
  if (is.null(x)) {
    base$passed <- FALSE; base$detail <- "could not parse CSV"; return(base)
  }
  missing <- setdiff(required_columns, names(x))
  base$passed <- nrow(x) >= minimum_rows && !length(missing)
  base$detail <- paste0("rows=", nrow(x), if (length(missing)) paste0("; missing columns: ", paste(missing, collapse = ", ")) else "")
  base
}

validate_methodology_v3_outputs <- function(paths = v3_paths(), stop_on_missing = TRUE) {
  root_out <- file.path(paths$root, "outputs")
  checks <- list(
    v3_check_file("Methodology v3 results RDS", file.path(paths$processed, "methodology_v3_results.rds"), 500),
    v3_check_csv("Module status", file.path(paths$outputs, "methodology_v3_module_status.csv"), 7, c("module", "evidence_status")),
    v3_check_csv("Public data status", file.path(paths$outputs, "public_data_status_v3.csv"), 5, c("source", "status")),
    v3_check_csv("V3 visualization manifest", file.path(paths$outputs, "methodology_v3_visualization_manifest.csv"), 13, c("id", "path", "status")),
    v3_check_file("V3 Quarto HTML", file.path(root_out, "atlas_methodology_v3_quarto.html"), 10000),
    v3_check_file("V3 R Markdown HTML", file.path(root_out, "atlas_methodology_v3_rmarkdown.html"), 10000),
    v3_check_file("V3 Quarto PDF", file.path(root_out, "atlas_methodology_v3_quarto.pdf"), 10000),
    v3_check_file("V3 R Markdown PDF", file.path(root_out, "atlas_methodology_v3_rmarkdown.pdf"), 10000),
    v3_check_file("V3 all-figures PDF", file.path(root_out, "all_generated_figures_methodology_v3_printable.pdf"), 10000),
    v3_check_file("V3 editable Excel", file.path(root_out, "iowa_ai_workforce_atlas_methodology_v3_editable_figures.xlsx"), 10000),
    v3_check_csv("V3 Excel manifest", file.path(paths$outputs, "editable_excel_figure_manifest_v3.csv"), 13, c("id", "sheet", "status")),
    v3_check_csv("V3 model card", file.path(paths$outputs, "model_card_v3.csv"), 10, c("field", "value")),
    v3_check_csv("V3 dataset inventory", file.path(paths$outputs, "dataset_inventory_v3.csv"), 1, c("relative_file", "sha256_or_md5")),
    v3_check_csv("V3 evidence gap register", file.path(paths$outputs, "evidence_gap_register_v3.csv"), 7, c("module", "evidence_status", "required_action")),
    v3_check_csv("V3 roadmap", file.path(paths$outputs, "methodology_v3_36_month_roadmap.csv"), 4, c("stage", "actions"))
  )
  manifest_path <- file.path(paths$outputs, "methodology_v3_visualization_manifest.csv")
  if (file.exists(manifest_path)) {
    m <- v3_read_csv(manifest_path)
    for (i in seq_len(nrow(m))) {
      checks[[length(checks) + 1L]] <- v3_check_file(paste0("V3 figure ", m$id[[i]]), m$path[[i]], 1000)
    }
  }
  out <- dplyr::bind_rows(checks)
  v3_write_csv(out, file.path(paths$outputs, "run_all_output_check_v3.csv"))
  failed <- out |> dplyr::filter(!passed)
  if (nrow(failed) && isTRUE(stop_on_missing)) {
    stop(
      "Methodology v3 output validation failed for ", nrow(failed), " item(s): ",
      paste(failed$check, collapse = "; "),
      ". Review outputs/methodology_v3/run_all_output_check_v3.csv.",
      call. = FALSE
    )
  }
  if (nrow(failed)) warning("Methodology v3 output validation found ", nrow(failed), " failed item(s).", call. = FALSE)
  else message("Methodology v3 output validation passed. Wrote: ", file.path(paths$outputs, "run_all_output_check_v3.csv"))
  out
}
