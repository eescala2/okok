# Iowa AI Workforce Atlas v3.1.3-clean-r7
# HTOPS configuration and compact, readable publication graphics.
# This module changes data-source configuration and publication presentation only.
# It does not alter Methodology v2/v3 scoring, weights, thresholds, or evidence rules.

if (!exists("%||%", mode = "function")) {
  `%||%` <- function(x, y) if (is.null(x) || !length(x)) y else x
}

.atlas_v317_state <- new.env(parent = emptyenv())

atlas_v317_root <- function(root = NULL) {
  candidate <- root %||% getOption("ia.atlas.v312.project_root", getwd())
  normalizePath(candidate, winslash = "/", mustWork = FALSE)
}

atlas_v317_htops_paths <- function(root = NULL) {
  root <- atlas_v317_root(root)
  list(
    canonical = file.path(root, "inputs", "htops_ai_benchmark.csv"),
    template = file.path(root, "inputs", "htops_ai_benchmark_template.csv"),
    mapping = file.path(root, "config", "htops_mapping.yml"),
    processed = file.path(root, "data_processed", "methodology_v3", "htops_ai_benchmark.csv"),
    status = file.path(root, "outputs", "methodology_v3", "htops_configuration_status_v317.csv")
  )
}

atlas_v317_read_delimited <- function(path) {
  if (!file.exists(path)) stop("Input file does not exist: ", path, call. = FALSE)
  ext <- tolower(tools::file_ext(path))
  if (ext == "zip") {
    listing <- utils::unzip(path, list = TRUE)
    candidates <- listing$Name[grepl("\\.(csv|csv\\.gz|tsv|txt)$", listing$Name, ignore.case = TRUE)]
    if (!length(candidates)) stop("The ZIP contains no CSV/TSV text file.", call. = FALSE)
    td <- tempfile("htops_zip_")
    dir.create(td)
    utils::unzip(path, files = candidates[[1L]], exdir = td)
    return(atlas_v317_read_delimited(file.path(td, candidates[[1L]])))
  }
  if (ext %in% c("xlsx", "xls")) {
    if (!requireNamespace("readxl", quietly = TRUE)) stop("readxl is required for an Excel HTOPS input.", call. = FALSE)
    return(as.data.frame(readxl::read_excel(path), check.names = FALSE))
  }
  if (ext == "rds") return(as.data.frame(readRDS(path), check.names = FALSE))
  if (requireNamespace("readr", quietly = TRUE)) {
    if (ext == "tsv") return(as.data.frame(readr::read_tsv(path, show_col_types = FALSE), check.names = FALSE))
    return(as.data.frame(readr::read_csv(path, show_col_types = FALSE), check.names = FALSE))
  }
  utils::read.csv(path, check.names = FALSE, stringsAsFactors = FALSE)
}

atlas_v317_htops_required_columns <- function() {
  c("cycle", "geography", "population", "subgroup_type", "subgroup_value", "measure", "estimate")
}

atlas_v317_validate_htops <- function(x, stop_on_error = TRUE) {
  x <- as.data.frame(x, stringsAsFactors = FALSE, check.names = FALSE)
  missing <- setdiff(atlas_v317_htops_required_columns(), names(x))
  issues <- character()
  if (length(missing)) issues <- c(issues, paste0("missing columns: ", paste(missing, collapse = ", ")))
  if (!length(missing)) {
    estimate <- suppressWarnings(as.numeric(x$estimate))
    bad <- !is.finite(estimate) | estimate < 0 | estimate > 1
    if (any(bad)) issues <- c(issues, paste0(sum(bad), " estimate value(s) are not finite proportions in [0,1]"))
    empty_measure <- is.na(x$measure) | !nzchar(trimws(as.character(x$measure)))
    if (any(empty_measure)) issues <- c(issues, paste0(sum(empty_measure), " row(s) have an empty measure"))
    dup_key <- duplicated(x[c("cycle", "geography", "population", "subgroup_type", "subgroup_value", "measure")])
    if (any(dup_key)) issues <- c(issues, paste0(sum(dup_key), " duplicate benchmark key(s)"))
  }
  ok <- !length(issues) && nrow(x) > 0L
  if (!nrow(x)) issues <- c(issues, "no benchmark rows")
  if (!ok && isTRUE(stop_on_error)) stop("HTOPS benchmark validation failed: ", paste(unique(issues), collapse = "; "), call. = FALSE)
  list(ok = ok, rows = nrow(x), issues = unique(issues), data = x)
}

atlas_v317_load_htops_benchmark <- function(root = NULL, required = FALSE) {
  p <- atlas_v317_htops_paths(root)$canonical
  if (!file.exists(p)) {
    if (isTRUE(required)) stop("HTOPS benchmark is not configured: ", p, call. = FALSE)
    return(data.frame())
  }
  out <- atlas_v317_read_delimited(p)
  checked <- atlas_v317_validate_htops(out, stop_on_error = required)
  if (!checked$ok) return(data.frame())
  out <- checked$data
  out$estimate <- as.numeric(out$estimate)
  for (nm in c("standard_error", "lower_95", "upper_95", "unweighted_n", "weighted_n")) {
    if (!nm %in% names(out)) out[[nm]] <- NA_real_
    out[[nm]] <- suppressWarnings(as.numeric(out[[nm]]))
  }
  if (!"source" %in% names(out)) out$source <- "HTOPS"
  if (!"evidence_status" %in% names(out)) out$evidence_status <- "BENCHMARKED"
  out$period <- out$cycle
  out$value <- out$estimate
  out$lower <- out$lower_95
  out$upper <- out$upper_95
  out$sample_n <- out$unweighted_n
  out
}

atlas_v317_weighted_binary <- function(value, weight, yes_values, no_values) {
  value_chr <- trimws(as.character(value))
  yes <- value_chr %in% trimws(as.character(yes_values))
  no <- value_chr %in% trimws(as.character(no_values))
  keep <- (yes | no) & is.finite(weight) & weight > 0
  if (!any(keep)) return(c(estimate = NA_real_, standard_error = NA_real_, lower_95 = NA_real_, upper_95 = NA_real_, unweighted_n = 0, weighted_n = 0))
  y <- as.numeric(yes[keep])
  w <- weight[keep]
  estimate <- sum(w * y) / sum(w)
  n_eff <- (sum(w)^2) / sum(w^2)
  se <- if (is.finite(n_eff) && n_eff > 1) sqrt(max(estimate * (1 - estimate), 0) / n_eff) else NA_real_
  c(
    estimate = estimate,
    standard_error = se,
    lower_95 = if (is.finite(se)) max(0, estimate - 1.96 * se) else NA_real_,
    upper_95 = if (is.finite(se)) min(1, estimate + 1.96 * se) else NA_real_,
    unweighted_n = sum(keep),
    weighted_n = sum(w)
  )
}

atlas_v317_configure_htops <- function(
    input_file = Sys.getenv("IA_ATLAS_HTOPS_INPUT", unset = ""),
    mapping_file = file.path(atlas_v317_root(), "config", "htops_mapping.yml"),
    root = NULL) {
  root <- atlas_v317_root(root)
  if (!nzchar(input_file)) {
    if (interactive()) input_file <- file.choose() else stop("Set IA_ATLAS_HTOPS_INPUT or pass input_file.", call. = FALSE)
  }
  raw <- atlas_v317_read_delimited(input_file)
  required <- atlas_v317_htops_required_columns()
  if (all(required %in% names(raw))) {
    normalized <- raw
    if (!"source_file" %in% names(normalized)) normalized$source_file <- basename(input_file)
    if (!"retrieved_at_utc" %in% names(normalized)) normalized$retrieved_at_utc <- format(Sys.time(), tz = "UTC", usetz = TRUE)
    if (!"evidence_status" %in% names(normalized)) normalized$evidence_status <- "BENCHMARKED"
    if (!"variance_method" %in% names(normalized)) normalized$variance_method <- "Supplied estimate/precision fields"
  } else {
    if (!requireNamespace("yaml", quietly = TRUE)) stop("yaml is required for mapped HTOPS microdata.", call. = FALSE)
    if (!file.exists(mapping_file)) stop("HTOPS mapping file not found: ", mapping_file, call. = FALSE)
    cfg <- yaml::read_yaml(mapping_file)
    weight_column <- as.character(cfg$weight_column %||% "")
    if (nzchar(weight_column) && !weight_column %in% names(raw)) stop("Configured HTOPS weight column not found: ", weight_column, call. = FALSE)
    weight <- if (nzchar(weight_column)) suppressWarnings(as.numeric(raw[[weight_column]])) else rep(1, nrow(raw))
    filters <- cfg$filters %||% list()
    if (length(filters)) {
      for (nm in names(filters)) {
        if (!nm %in% names(raw)) stop("Configured HTOPS filter column not found: ", nm, call. = FALSE)
        raw <- raw[as.character(raw[[nm]]) %in% as.character(filters[[nm]]), , drop = FALSE]
      }
      weight <- if (nzchar(weight_column)) suppressWarnings(as.numeric(raw[[weight_column]])) else rep(1, nrow(raw))
    }
    cycle_column <- as.character(cfg$cycle_column %||% "")
    if (nzchar(cycle_column) && !cycle_column %in% names(raw)) stop("Configured cycle column not found: ", cycle_column, call. = FALSE)
    cycle_values <- if (nzchar(cycle_column)) as.character(raw[[cycle_column]]) else rep(as.character(cfg$cycle %||% "unspecified_cycle"), nrow(raw))
    geography <- as.character(cfg$geography %||% "United States")
    population <- as.character(cfg$population %||% "Configured HTOPS analytic population")
    measures <- cfg$measures %||% list()
    if (!length(measures)) stop("No HTOPS measures are configured in config/htops_mapping.yml.", call. = FALSE)
    subgroups <- c(list(list(type = "all", column = "")), cfg$subgroups %||% list())
    rows <- list(); k <- 0L
    for (measure_cfg in measures) {
      measure <- as.character(measure_cfg$measure %||% "")
      column <- as.character(measure_cfg$column %||% "")
      if (!nzchar(measure) || !nzchar(column) || !column %in% names(raw)) stop("Each HTOPS measure needs a valid measure and column.", call. = FALSE)
      yes_values <- measure_cfg$yes_values %||% character()
      no_values <- measure_cfg$no_values %||% character()
      if (!length(yes_values) || !length(no_values)) stop("Measure ", measure, " needs yes_values and no_values.", call. = FALSE)
      for (cycle in unique(cycle_values)) {
        cycle_keep <- !is.na(cycle_values) & cycle_values == cycle
        for (subgroup in subgroups) {
          subgroup_type <- as.character(subgroup$type %||% "all")
          subgroup_column <- as.character(subgroup$column %||% "")
          if (!nzchar(subgroup_column)) {
            group_values <- "All"
          } else {
            if (!subgroup_column %in% names(raw)) stop("Configured subgroup column not found: ", subgroup_column, call. = FALSE)
            group_values <- unique(as.character(raw[[subgroup_column]][cycle_keep]))
            group_values <- group_values[!is.na(group_values) & nzchar(group_values)]
          }
          for (group_value in group_values) {
            keep <- cycle_keep
            if (nzchar(subgroup_column)) keep <- keep & as.character(raw[[subgroup_column]]) == group_value
            est <- atlas_v317_weighted_binary(raw[[column]][keep], weight[keep], yes_values, no_values)
            if (!is.finite(est[["estimate"]])) next
            k <- k + 1L
            rows[[k]] <- data.frame(
              cycle = cycle,
              geography = geography,
              population = population,
              subgroup_type = subgroup_type,
              subgroup_value = group_value,
              measure = measure,
              estimate = unname(est[["estimate"]]),
              standard_error = unname(est[["standard_error"]]),
              lower_95 = unname(est[["lower_95"]]),
              upper_95 = unname(est[["upper_95"]]),
              unweighted_n = unname(est[["unweighted_n"]]),
              weighted_n = unname(est[["weighted_n"]]),
              evidence_status = "BENCHMARKED",
              source = "HTOPS public-use file",
              source_file = basename(input_file),
              retrieved_at_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
              variance_method = "Kish effective-n approximation; use official published or replicate-weight precision for final inference",
              notes = as.character(measure_cfg$notes %||% ""),
              stringsAsFactors = FALSE
            )
          }
        }
      }
    }
    normalized <- if (length(rows)) do.call(rbind, rows) else data.frame()
  }
  checked <- atlas_v317_validate_htops(normalized, stop_on_error = TRUE)
  normalized <- checked$data
  paths <- atlas_v317_htops_paths(root)
  dir.create(dirname(paths$canonical), recursive = TRUE, showWarnings = FALSE)
  dir.create(dirname(paths$processed), recursive = TRUE, showWarnings = FALSE)
  dir.create(dirname(paths$status), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(normalized, paths$canonical, row.names = FALSE, na = "")
  utils::write.csv(normalized, paths$processed, row.names = FALSE, na = "")
  status <- data.frame(
    source = "HTOPS benchmark",
    configured = TRUE,
    rows = nrow(normalized),
    usable_rows = nrow(normalized),
    status = "available",
    diagnostic = paste0("Validated normalized HTOPS benchmark: ", nrow(normalized), " row(s). National household evidence remains a benchmark, not an Iowa employer pulse."),
    configured_at_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
    stringsAsFactors = FALSE
  )
  utils::write.csv(status, paths$status, row.names = FALSE)
  atlas_v317_reconcile_htops_status(root = root)
  message("Configured HTOPS benchmark: ", paths$canonical)
  message("Rows: ", nrow(normalized))
  invisible(normalized)
}

atlas_v317_update_htops_row <- function(status, htops) {
  if (!is.data.frame(status) || !nrow(status)) return(status)
  source_col <- intersect(c("source", "input", "dataset", "name"), names(status))
  if (!length(source_col)) return(status)
  source_col <- source_col[[1L]]
  hit <- grepl("htops", as.character(status[[source_col]]), ignore.case = TRUE)
  if (!any(hit)) return(status)
  if ("rows" %in% names(status)) status$rows[hit] <- nrow(htops)
  if ("usable_rows" %in% names(status)) status$usable_rows[hit] <- nrow(htops)
  if ("configured" %in% names(status)) status$configured[hit] <- TRUE
  if ("status" %in% names(status)) status$status[hit] <- "available"
  if ("evidence_status" %in% names(status)) status$evidence_status[hit] <- "BENCHMARKED"
  if ("availability_code" %in% names(status)) status$availability_code[hit] <- "available"
  note <- paste0("Validated HTOPS benchmark available (", nrow(htops), " rows). It is a national household benchmark and does not substitute for Iowa employer or worker-outcome evidence.")
  if ("diagnostic" %in% names(status)) status$diagnostic[hit] <- note
  if ("availability_explanation" %in% names(status)) status$availability_explanation[hit] <- note
  status
}

atlas_v317_reconcile_htops_status <- function(root = NULL) {
  root <- atlas_v317_root(root)
  htops <- atlas_v317_load_htops_benchmark(root, required = FALSE)
  if (!nrow(htops)) return(invisible(FALSE))
  files <- c(
    file.path(root, "outputs", "methodology_v3", "public_data_status_v3.csv"),
    file.path(root, "outputs", "methodology_v3", "source_availability_status_v3.csv")
  )
  for (path in files[file.exists(files)]) {
    x <- tryCatch(utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE), error = function(e) NULL)
    if (is.null(x)) next
    updated <- atlas_v317_update_htops_row(x, htops)
    utils::write.csv(updated, path, row.names = FALSE, na = "")
  }
  invisible(TRUE)
}

atlas_v317_install_htops_status_wrapper <- function() {
  nm <- "v3_pub_status_inputs"
  if (!exists(nm, mode = "function", envir = .GlobalEnv, inherits = TRUE)) return(invisible(FALSE))
  current <- get(nm, mode = "function", envir = .GlobalEnv, inherits = TRUE)
  if (isTRUE(attr(current, "atlas_v317_htops_wrapper"))) return(invisible(TRUE))
  original <- current
  wrapper <- function(...) {
    out <- original(...)
    htops <- atlas_v317_load_htops_benchmark(required = FALSE)
    if (nrow(htops)) out <- atlas_v317_update_htops_row(out, htops)
    out
  }
  attr(wrapper, "atlas_v317_htops_wrapper") <- TRUE
  assign(nm, wrapper, envir = .GlobalEnv)
  invisible(TRUE)
}

# Common optional-loader aliases. Existing project functions are never overwritten.
for (.nm in c("v3_load_htops_benchmark", "v3_read_htops_benchmark", "v3_get_htops_benchmark", "get_htops_benchmark")) {
  if (!exists(.nm, mode = "function", envir = .GlobalEnv, inherits = FALSE)) {
    assign(.nm, function(...) atlas_v317_load_htops_benchmark(...), envir = .GlobalEnv)
  }
}
rm(.nm)

atlas_v317_set_visual_defaults <- function() {
  options(ggrepel.max.overlaps = Inf)
  if (!requireNamespace("ggplot2", quietly = TRUE)) return(invisible(FALSE))
  current <- ggplot2::theme_get()
  compact <- ggplot2::theme(
    plot.title.position = "plot",
    plot.caption.position = "plot",
    plot.title = ggplot2::element_text(size = 13, face = "bold", lineheight = 1.04, margin = ggplot2::margin(b = 4)),
    plot.subtitle = ggplot2::element_text(size = 10.5, lineheight = 1.08, margin = ggplot2::margin(b = 5)),
    plot.caption = ggplot2::element_text(size = 8.2, lineheight = 1.08, margin = ggplot2::margin(t = 4)),
    axis.title = ggplot2::element_text(size = 10, face = "bold"),
    axis.text = ggplot2::element_text(size = 9),
    strip.text = ggplot2::element_text(size = 9.5, face = "bold"),
    panel.spacing = grid::unit(0.55, "lines"),
    legend.position = "bottom",
    legend.box = "vertical",
    legend.title = ggplot2::element_text(size = 9, face = "bold"),
    legend.text = ggplot2::element_text(size = 8.5),
    legend.margin = ggplot2::margin(0, 0, 0, 0),
    legend.box.margin = ggplot2::margin(0, 0, 0, 0),
    legend.spacing.y = grid::unit(0.08, "cm"),
    plot.margin = ggplot2::margin(5, 7, 5, 7, unit = "pt")
  )
  ggplot2::theme_set(current + compact)
  invisible(TRUE)
}

atlas_v317_png_bbox <- function(image, tolerance = 0.035) {
  dims <- dim(image)
  if (length(dims) < 3L || dims[[3L]] < 3L) return(NULL)
  h <- dims[[1L]]; w <- dims[[2L]]
  corners <- rbind(image[1, 1, 1:3], image[1, w, 1:3], image[h, 1, 1:3], image[h, w, 1:3])
  background <- apply(corners, 2, stats::median, na.rm = TRUE)
  delta <- sqrt((image[, , 1] - background[[1L]])^2 + (image[, , 2] - background[[2L]])^2 + (image[, , 3] - background[[3L]])^2)
  alpha <- if (dims[[3L]] >= 4L) image[, , 4] else matrix(1, nrow = h, ncol = w)
  mask <- is.finite(delta) & alpha > 0.02 & delta > tolerance
  idx <- which(mask, arr.ind = TRUE)
  if (!nrow(idx) || nrow(idx) < 25L) return(NULL)
  c(top = min(idx[, 1]), bottom = max(idx[, 1]), left = min(idx[, 2]), right = max(idx[, 2]))
}

atlas_v317_trim_png <- function(path, padding_px = 18L, tolerance = 0.035, rewrite = TRUE) {
  if (!requireNamespace("png", quietly = TRUE)) stop("The png package is required for lossless figure whitespace trimming.", call. = FALSE)
  info <- file.info(path)
  image <- png::readPNG(path, native = FALSE, info = TRUE)
  dims <- dim(image); h <- dims[[1L]]; w <- dims[[2L]]
  bbox <- atlas_v317_png_bbox(image, tolerance = tolerance)
  if (is.null(bbox)) {
    return(data.frame(file = normalizePath(path, winslash = "/", mustWork = FALSE), width_before = w, height_before = h, width_after = w, height_after = h, outer_whitespace_before = NA_real_, cropped = FALSE, status = "content_not_detected", stringsAsFactors = FALSE))
  }
  padding_px <- max(8L, min(as.integer(padding_px), 40L))
  top <- max(1L, bbox[["top"]] - padding_px)
  bottom <- min(h, bbox[["bottom"]] + padding_px)
  left <- max(1L, bbox[["left"]] - padding_px)
  right <- min(w, bbox[["right"]] + padding_px)
  new_h <- bottom - top + 1L; new_w <- right - left + 1L
  whitespace <- 1 - ((bbox[["bottom"]] - bbox[["top"]] + 1L) * (bbox[["right"]] - bbox[["left"]] + 1L)) / (h * w)
  cropped <- new_h < h - 2L || new_w < w - 2L
  if (isTRUE(rewrite) && cropped) {
    cropped_image <- image[top:bottom, left:right, , drop = FALSE]
    target <- tempfile(pattern = "atlas_v317_", tmpdir = dirname(path), fileext = ".png")
    dpi <- attr(image, "info")$dpi %||% c(144, 144)
    png::writePNG(cropped_image, target = target, dpi = dpi)
    if (.Platform$OS.type == "windows" && file.exists(path)) unlink(path)
    if (!file.rename(target, path)) {
      ok <- file.copy(target, path, overwrite = TRUE)
      unlink(target)
      if (!ok) stop("Could not replace trimmed PNG: ", path, call. = FALSE)
    }
  }
  data.frame(
    file = normalizePath(path, winslash = "/", mustWork = FALSE),
    width_before = w,
    height_before = h,
    width_after = new_w,
    height_after = new_h,
    outer_whitespace_before = whitespace,
    cropped = cropped,
    status = if (cropped) "trimmed" else "already_compact",
    stringsAsFactors = FALSE
  )
}

atlas_v317_write_figure_gallery <- function(audit, root = NULL) {
  root <- atlas_v317_root(root)
  output <- file.path(root, "outputs", "figure_readability_gallery_v317.html")
  dir.create(dirname(output), recursive = TRUE, showWarnings = FALSE)
  rows <- vapply(seq_len(nrow(audit)), function(i) {    prefix <- paste0(sub("/+$", "", root), "/")
    rel <- if (startsWith(audit$file[[i]], prefix)) substring(audit$file[[i]], nchar(prefix) + 1L) else audit$file[[i]]
    paste0("<article><h2>", basename(rel), "</h2><img src=\"../", rel, "\" alt=\"", basename(rel), "\"><p>", audit$width_after[[i]], " × ", audit$height_after[[i]], " px; ", audit$status[[i]], "</p></article>")
  }, character(1))
  html <- paste0(
    "<!doctype html><html><head><meta charset=\"utf-8\"><title>Iowa AI Atlas figure readability gallery</title>",
    "<style>body{font-family:system-ui;margin:12px;background:#f5f6f7}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(520px,1fr));gap:12px}article{background:white;padding:10px;border:1px solid #ccd2d8;border-radius:6px}h1{grid-column:1/-1}h2{font-size:15px;margin:0 0 6px}img{display:block;width:100%;height:auto;max-height:780px;object-fit:contain;margin:auto}p{font-size:12px;margin:5px 0 0}</style></head><body><main><h1>Iowa AI Workforce Atlas — figure readability audit</h1>",
    paste(rows, collapse = "\n"), "</main></body></html>"
  )
  writeLines(html, output, useBytes = TRUE)
  invisible(output)
}

atlas_v317_optimize_all_figures <- function(root = NULL, rewrite = TRUE) {
  root <- atlas_v317_root(root)
  figure_root <- file.path(root, "figures")
  if (!dir.exists(figure_root)) return(invisible(data.frame()))
  files <- list.files(figure_root, pattern = "\\.png$", recursive = TRUE, full.names = TRUE, ignore.case = TRUE)
  if (!length(files)) return(invisible(data.frame()))
  results <- lapply(seq_along(files), function(i) {
    message("  Figure whitespace audit ", i, "/", length(files), ": ", basename(files[[i]]))
    tryCatch(atlas_v317_trim_png(files[[i]], rewrite = rewrite), error = function(e) data.frame(file = normalizePath(files[[i]], winslash = "/", mustWork = FALSE), width_before = NA_integer_, height_before = NA_integer_, width_after = NA_integer_, height_after = NA_integer_, outer_whitespace_before = NA_real_, cropped = FALSE, status = paste0("error: ", conditionMessage(e)), stringsAsFactors = FALSE))
  })
  audit <- do.call(rbind, results)
  audit$aspect_ratio <- audit$width_after / audit$height_after
  audit$resolution_ok <- is.finite(audit$width_after) & is.finite(audit$height_after) & audit$width_after >= 900 & audit$height_after >= 500
  audit$readability_status <- ifelse(grepl("^error", audit$status), "FAIL", ifelse(!audit$resolution_ok, "REVIEW_RESOLUTION", ifelse(audit$aspect_ratio > 3.4 | audit$aspect_ratio < 0.30, "REVIEW_ASPECT", "PASS")))
  output <- file.path(root, "outputs", "figure_readability_audit_v317.csv")
  dir.create(dirname(output), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(audit, output, row.names = FALSE, na = "")
  atlas_v317_write_figure_gallery(audit, root)
  invisible(audit)
}

atlas_v317_compact_css <- function() {
  paste0(
    "\n<style id=\"atlas-v317-compact-readable-figures\">\n",
    "figure,.figure{margin:.18rem auto .42rem!important;break-inside: auto !important;page-break-inside: auto !important;}",
    "figure img,.figure img{display:block;max-width:100%!important;width:auto;height:auto;max-height: 7.25in !important;object-fit:contain;margin:.05rem auto!important}",
    "figcaption,.figure-caption{margin:.12rem auto .25rem!important;line-height:1.12;font-size:.88em}",
    ".cell-output-display{margin:.1rem 0 .3rem!important}",
    "table{break-inside: auto !important;page-break-inside: auto !important;}",
    "@media print{@page{size:letter;margin:.42in .45in .45in}.page-columns .content{max-width:none!important}",
    "body{font-size:9.3pt;line-height:1.18}h1{margin:.28rem 0 .16rem;font-size:17pt}h2{margin:.24rem 0 .12rem;font-size:14pt}h3{margin:.2rem 0 .1rem;font-size:11.5pt}",
    "p{margin:.12rem 0 .3rem}figure img,.figure img{max-height:8.05in!important}pre{font-size:7.5pt}th,td{padding:2px 4px!important}}\n",
    "</style>\n"
  )
}

atlas_v317_polish_html <- function(path) {
  if (!file.exists(path)) return(invisible(FALSE))
  text <- paste(readLines(path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
  marker <- "atlas-v317-compact-readable-figures"
  if (grepl(marker, text, fixed = TRUE)) return(invisible(TRUE))
  css <- atlas_v317_compact_css()
  if (grepl("</head>", text, fixed = TRUE)) text <- sub("</head>", paste0(css, "</head>"), text, fixed = TRUE) else text <- paste0(css, text)
  writeLines(text, path, useBytes = TRUE)
  invisible(TRUE)
}

atlas_v317_polish_all_html <- function(root = NULL) {
  root <- atlas_v317_root(root)
  files <- unique(c(
    list.files(file.path(root, "outputs"), pattern = "\\.html$", recursive = TRUE, full.names = TRUE, ignore.case = TRUE),
    list.files(root, pattern = "\\.html$", full.names = TRUE, ignore.case = TRUE)
  ))
  for (path in files[file.exists(files)]) atlas_v317_polish_html(path)
  invisible(files)
}

atlas_v317_wrap_around <- function(name, before = NULL, after = NULL) {
  if (!exists(name, mode = "function", envir = .GlobalEnv, inherits = TRUE)) return(invisible(FALSE))
  current <- get(name, mode = "function", envir = .GlobalEnv, inherits = TRUE)
  if (isTRUE(attr(current, "atlas_v317_wrapper"))) return(invisible(TRUE))
  original <- current
  wrapper <- function(...) {
    if (is.function(before)) {
      tryCatch(before(), error = function(e) warning("v3.1.3-clean-r7 pre-publication warning: ", conditionMessage(e), call. = FALSE))
    }
    result <- original(...)
    if (is.function(after)) {
      tryCatch(after(result), error = function(e) warning("v3.1.3-clean-r7 publication post-processing warning: ", conditionMessage(e), call. = FALSE))
    }
    result
  }
  attr(wrapper, "atlas_v317_wrapper") <- TRUE
  assign(name, wrapper, envir = .GlobalEnv)
  invisible(TRUE)
}

atlas_v317_install_runtime_wrappers <- function(root = NULL) {
  atlas_v317_set_visual_defaults()
  atlas_v317_install_htops_status_wrapper()
  # The complete figure tree is optimized once immediately before each report family
  # is rendered, rather than after every individual figure generator.
  before_report <- function() atlas_v317_optimize_all_figures(root = root, rewrite = TRUE)
  after_report <- function(result) atlas_v317_polish_all_html(root = root)
  for (nm in c("render_reports", "render_methodology_v3_reports")) {
    atlas_v317_wrap_around(nm, before = before_report, after = after_report)
  }
  invisible(TRUE)
}

atlas_v317_finalize_publication <- function(root = NULL) {
  root <- atlas_v317_root(root)
  atlas_v317_reconcile_htops_status(root)
  atlas_v317_optimize_all_figures(root, rewrite = TRUE)
  atlas_v317_polish_all_html(root)
  message("v3.1.3-clean-r7 visual audit: outputs/figure_readability_audit_v317.csv")
  message("v3.1.3-clean-r7 gallery: outputs/figure_readability_gallery_v317.html")
  invisible(TRUE)
}

try(atlas_v317_set_visual_defaults(), silent = TRUE)
try(atlas_v317_install_runtime_wrappers(), silent = TRUE)
