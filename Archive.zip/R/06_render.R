# 06_render.R ---------------------------------------------------------------
# Render both Quarto and R Markdown versions of the report.
#
# Hotfix notes:
# - quarto::quarto_render() does not support an output_dir argument.
# - This script renders the Quarto HTML safely and places/copies the result in
#   outputs/atlas_quarto.html.
# - R Markdown is still rendered with rmarkdown::render(..., output_dir = "outputs").

.atlas_find_root <- function() {
  here <- normalizePath(getwd(), winslash = '/', mustWork = TRUE)
  candidates <- unique(c(
    here,
    dirname(here),
    normalizePath(file.path(here, '..'), winslash = '/', mustWork = FALSE),
    normalizePath(file.path(here, '../..'), winslash = '/', mustWork = FALSE)
  ))
  for (cand in candidates) {
    if (file.exists(file.path(cand, 'config.yml')) && dir.exists(file.path(cand, 'R'))) {
      return(normalizePath(cand, winslash = '/', mustWork = TRUE))
    }
  }
  here
}

root0 <- .atlas_find_root()
source(file.path(root0, 'R', '00_setup.R'))
source(file.path(project_root(), 'R', '05_visualize.R'))

.copy_quarto_output_to_outputs <- function(root, output_name) {
  out_dir <- file.path(root, 'outputs')
  fs::dir_create(out_dir)

  root_file <- file.path(root, output_name)
  final_file <- file.path(out_dir, output_name)

  support_dir_name <- paste0(tools::file_path_sans_ext(output_name), '_files')
  root_support <- file.path(root, support_dir_name)
  final_support <- file.path(out_dir, support_dir_name)

  if (file.exists(root_file) && normalizePath(root_file, mustWork = FALSE) != normalizePath(final_file, mustWork = FALSE)) {
    file.copy(root_file, final_file, overwrite = TRUE)
    unlink(root_file, force = TRUE)
  }

  if (dir.exists(root_support)) {
    unlink(final_support, recursive = TRUE, force = TRUE)
    file.copy(root_support, out_dir, recursive = TRUE, overwrite = TRUE)
    unlink(root_support, recursive = TRUE, force = TRUE)
  }

  file.exists(final_file)
}

.render_quarto_html <- function(input = 'atlas.qmd', output_name = 'atlas_quarto.html', quiet = FALSE) {
  p <- paths()
  fs::dir_create(p$outputs)

  if (!requireNamespace('quarto', quietly = TRUE)) {
    warning('The quarto R package is not installed. Skipping atlas.qmd render.', call. = FALSE)
    return(FALSE)
  }
  quarto_cli_available <- if ('quarto_available' %in% getNamespaceExports('quarto')) {
    isTRUE(quarto::quarto_available())
  } else {
    nzchar(Sys.which('quarto'))
  }
  if (!quarto_cli_available) {
    warning('Quarto CLI is not available. Skipping atlas.qmd render. Install Quarto from https://quarto.org.', call. = FALSE)
    return(FALSE)
  }

  # Clean old root-level artifacts so stale files are not mistaken for a fresh render.
  unlink(file.path(p$root, output_name), force = TRUE)
  unlink(file.path(p$root, paste0(tools::file_path_sans_ext(output_name), '_files')), recursive = TRUE, force = TRUE)

  final_file <- file.path(p$outputs, output_name)

  # On Windows, especially in OneDrive-managed folders, Quarto can fail while
  # removing its hidden .quarto cache when --output-dir is used. Render to the
  # project root by default and then copy the output into outputs/. Advanced
  # users can opt back into --output-dir with IA_ATLAS_QUARTO_TRY_OUTPUT_DIR=true.
  try_output_dir <- identical(tolower(Sys.getenv('IA_ATLAS_QUARTO_TRY_OUTPUT_DIR', unset = 'false')), 'true')
  if (isTRUE(try_output_dir)) {
    rendered_dir <- tryCatch({
      quarto::quarto_render(
        input = input,
        output_format = 'html',
        output_file = output_name,
        quarto_args = c('--output-dir', 'outputs'),
        quiet = quiet
      )
      TRUE
    }, error = function(e) {
      message('Quarto render with --output-dir did not complete: ', conditionMessage(e))
      FALSE
    })
    if (rendered_dir && file.exists(final_file)) {
      message('Wrote Quarto report: ', final_file)
      return(TRUE)
    }
    if (rendered_dir && .copy_quarto_output_to_outputs(p$root, output_name)) {
      message('Wrote Quarto report: ', final_file)
      return(TRUE)
    }
  }

  rendered <- tryCatch({
    quarto::quarto_render(
      input = input,
      output_format = 'html',
      output_file = output_name,
      quiet = quiet
    )
    TRUE
  }, error = function(e) {
    warning('Could not render atlas.qmd: ', conditionMessage(e), call. = FALSE)
    FALSE
  })

  if (rendered && .copy_quarto_output_to_outputs(p$root, output_name)) {
    message('Wrote Quarto report: ', final_file)
    return(TRUE)
  }

  warning('Quarto finished but outputs/atlas_quarto.html was not found.', call. = FALSE)
  FALSE
}

.render_rmarkdown_html <- function(input = 'atlas.Rmd', output_name = 'atlas_rmarkdown.html', quiet = FALSE) {
  p <- paths()
  fs::dir_create(p$outputs)
  ok <- tryCatch({
    rmarkdown::render(
      input = input,
      output_dir = 'outputs',
      output_file = output_name,
      clean = TRUE,
      quiet = quiet
    )
    TRUE
  }, error = function(e) {
    warning('Could not render atlas.Rmd: ', conditionMessage(e), call. = FALSE)
    FALSE
  })
  if (ok) message('Wrote R Markdown report: ', file.path(p$outputs, output_name))
  ok
}

render_reports <- function(refresh = FALSE, stop_on_error = TRUE, quiet = FALSE, make_core_figures = TRUE) {
  setup_packages(install_optional = FALSE)
  if (isTRUE(make_core_figures)) make_figures(refresh = refresh)

  p <- paths()
  old <- getwd()
  on.exit(setwd(old), add = TRUE)
  setwd(p$root)

  q_ok <- .render_quarto_html(quiet = quiet)
  r_ok <- .render_rmarkdown_html(quiet = quiet)

  if (isTRUE(stop_on_error) && (!q_ok || !r_ok)) {
    failed <- c(if (!q_ok) 'Quarto atlas.qmd' else NULL, if (!r_ok) 'R Markdown atlas.Rmd' else NULL)
    stop('Report render failed for: ', paste(failed, collapse = ', '), call. = FALSE)
  }

  manifest <- tibble::tibble(
    report = c('Quarto HTML', 'R Markdown HTML'),
    file = c(file.path(p$outputs, 'atlas_quarto.html'), file.path(p$outputs, 'atlas_rmarkdown.html')),
    status = c(if (q_ok) 'created' else 'failed', if (r_ok) 'created' else 'failed'),
    build_id = if (exists('v2_build_id', mode = 'function')) v2_build_id() else NA_character_,
    methodology_version = if (exists('load_methodology_v2_config', mode = 'function')) as.character(load_methodology_v2_config()$methodology_version) else NA_character_,
    generated_at = format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z')
  )
  readr::write_csv(manifest, file.path(p$outputs, 'report_render_manifest.csv'))
  invisible(list(quarto = q_ok, rmarkdown = r_ok, manifest = manifest))
}
