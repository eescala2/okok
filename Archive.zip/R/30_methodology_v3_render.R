# Methodology v3 HTML/PDF rendering with progress, timeout, and accessibility checklist

v3_quarto_available <- function() {
  if (requireNamespace("quarto", quietly = TRUE)) {
    ok <- tryCatch(quarto::quarto_available(), error = function(e) FALSE)
    if (isTRUE(ok)) return(TRUE)
  }
  nzchar(Sys.which("quarto"))
}

v3_render_quarto <- function(root, paths, quiet = FALSE) {
  input <- file.path(root, "atlas_v3.qmd")
  if (!file.exists(input)) stop("Missing atlas_v3.qmd", call. = FALSE)
  final <- file.path(root, "outputs", "atlas_methodology_v3_quarto.html")
  local_out <- file.path(root, "atlas_methodology_v3_quarto.html")
  unlink(c(final, local_out), force = TRUE)
  if (!v3_quarto_available()) stop("Quarto CLI is unavailable. Install Quarto or run inside Positron with its bundled Quarto.", call. = FALSE)
  ok <- FALSE
  if (requireNamespace("quarto", quietly = TRUE)) {
    ok <- tryCatch({
      quarto::quarto_render(
        input = input,
        output_format = "html",
        output_file = basename(local_out),
        execute_dir = root,
        quiet = quiet
      )
      TRUE
    }, error = function(e) {
      message("Quarto R wrapper did not complete; retrying with the CLI: ", conditionMessage(e))
      FALSE
    })
  }
  if (!ok) {
    q <- Sys.which("quarto")
    args <- c("render", shQuote(input), "--to", "html", "--output", shQuote(basename(local_out)), "--execute-dir", shQuote(root))
    status <- system2(q, args = args, stdout = if (quiet) FALSE else "", stderr = if (quiet) FALSE else "")
    ok <- identical(status, 0L)
  }
  candidates <- c(local_out, file.path(root, "outputs", basename(local_out)))
  src <- candidates[file.exists(candidates)]
  if (!length(src)) stop("Quarto did not create the Methodology v3 HTML report.", call. = FALSE)
  dir.create(dirname(final), recursive = TRUE, showWarnings = FALSE)
  if (normalizePath(src[[1]], winslash = "/", mustWork = FALSE) != normalizePath(final, winslash = "/", mustWork = FALSE)) {
    file.copy(src[[1]], final, overwrite = TRUE)
  }
  message("Wrote Methodology v3 Quarto report: ", normalizePath(final, winslash = "/", mustWork = FALSE))
  final
}

v3_render_rmarkdown <- function(root, paths, quiet = FALSE) {
  input <- file.path(root, "atlas_v3.Rmd")
  if (!file.exists(input)) stop("Missing atlas_v3.Rmd", call. = FALSE)
  if (!requireNamespace("rmarkdown", quietly = TRUE)) stop("The rmarkdown package is required.", call. = FALSE)
  final <- file.path(root, "outputs", "atlas_methodology_v3_rmarkdown.html")
  unlink(final, force = TRUE)
  rmarkdown::render(
    input = input,
    output_format = "html_document",
    output_file = basename(final),
    output_dir = dirname(final),
    envir = new.env(parent = globalenv()),
    quiet = quiet,
    clean = TRUE
  )
  if (!file.exists(final)) stop("R Markdown did not create the Methodology v3 HTML report.", call. = FALSE)
  message("Wrote Methodology v3 R Markdown report: ", normalizePath(final, winslash = "/", mustWork = FALSE))
  final
}

render_methodology_v3_reports <- function(quiet = FALSE, paths = v3_paths()) {
  old <- getwd(); on.exit(setwd(old), add = TRUE); setwd(paths$root)
  q <- v3_render_quarto(paths$root, paths, quiet)
  r <- v3_render_rmarkdown(paths$root, paths, quiet)
  list(quarto = q, rmarkdown = r)
}

v3_find_browser <- function() {
  env <- unique(c(
    Sys.getenv("IA_ATLAS_CHROME", unset = ""),
    Sys.getenv("PAGEDOWN_CHROME", unset = ""),
    Sys.getenv("CHROME_PATH", unset = "")
  ))
  candidates <- c(
    env[nzchar(env)],
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
    "C:/Program Files/Google/Chrome/Application/chrome.exe",
    "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
    "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
    "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
    Sys.which(c("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "microsoft-edge", "msedge"))
  )
  candidates <- unique(candidates[nzchar(candidates)])
  hit <- candidates[file.exists(candidates)]
  if (length(hit)) normalizePath(hit[[1]], winslash = "/", mustWork = TRUE) else NA_character_
}

v3_file_url <- function(path) {
  p <- normalizePath(path, winslash = "/", mustWork = TRUE)
  if (.Platform$OS.type == "windows") paste0("file:///", utils::URLencode(p, reserved = TRUE)) else paste0("file://", utils::URLencode(p, reserved = TRUE))
}

v3_browser_print <- function(html, pdf, browser = v3_find_browser(), tagged = TRUE, timeout_seconds = NULL) {
  if (is.na(browser) || !file.exists(browser)) return(list(ok = FALSE, status = "browser_not_found", log = ""))
  timeout_seconds <- timeout_seconds %||% as.numeric(Sys.getenv(
    "IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS", unset = "240"
  ))
  if (!is.finite(timeout_seconds) || timeout_seconds < 30) timeout_seconds <- 240
  dir.create(dirname(pdf), recursive = TRUE, showWarnings = FALSE)
  unlink(pdf, force = TRUE)
  profile <- tempfile("iowa-atlas-v3-browser-profile-")
  dir.create(profile, recursive = TRUE, showWarnings = FALSE)
  on.exit(unlink(profile, recursive = TRUE, force = TRUE), add = TRUE)
  if (!requireNamespace("processx", quietly = TRUE)) {
    return(list(
      ok = FALSE,
      status = "processx_required_no_unbounded_fallback",
      log = "processx is required; no unbounded system2 browser fallback was attempted."
    ))
  }
  base_args <- c(
    "--disable-gpu", "--disable-dev-shm-usage", "--no-first-run", "--no-default-browser-check",
    "--allow-file-access-from-files", "--no-pdf-header-footer",
    paste0("--user-data-dir=", normalizePath(profile, winslash = "/", mustWork = TRUE)),
    paste0("--print-to-pdf=", normalizePath(pdf, winslash = "/", mustWork = FALSE))
  )
  if (isTRUE(tagged)) base_args <- c(base_args, "--export-tagged-pdf", "--generate-pdf-document-outline")
  attempts <- list(c("--headless=new", base_args, v3_file_url(html)), c("--headless", base_args, v3_file_url(html)))
  logs <- character()
  for (attempt_index in seq_along(attempts)) {
    args <- attempts[[attempt_index]]
    message(
      "Starting bounded Methodology v3 browser PDF attempt ",
      attempt_index, "/", length(attempts),
      " [timeout=", timeout_seconds, "s]."
    )
    res <- tryCatch(
      processx::run(
        browser,
        args,
        timeout = timeout_seconds * 1000,
        echo = FALSE,
        error_on_status = FALSE,
        windows_hide_window = TRUE,
        cleanup_tree = TRUE
      ),
      error = function(e) list(
        status = 124L,
        stdout = "",
        stderr = paste0("Browser process failed or timed out: ", conditionMessage(e))
      )
    )
    logs <- c(logs, res$stdout %||% "", res$stderr %||% "")
    if (file.exists(pdf) && file.info(pdf)$size > 10000) {
      return(list(ok = TRUE, status = if (tagged) "created_from_html_direct_chromium_tagged_attempt" else "created_from_html_direct_chromium", log = paste(logs, collapse = "\n")))
    }
  }
  list(ok = FALSE, status = "browser_print_failed", log = paste(logs, collapse = "\n"))
}

v3_figure_catalog <- function(paths = v3_paths()) {
  roots <- c(file.path(paths$root, "figures"), paths$figures)
  files <- unique(unlist(lapply(roots[dir.exists(roots)], function(d) list.files(d, pattern = "(?i)\\.png$", recursive = TRUE, full.names = TRUE))))
  files <- files[file.exists(files)]
  if (!length(files)) return(tibble::tibble())
  tibble::tibble(
    id = sprintf("F%03d", seq_along(files)),
    filename = basename(files),
    path = normalizePath(files, winslash = "/", mustWork = FALSE),
    title = tools::toTitleCase(gsub("[_-]+", " ", tools::file_path_sans_ext(basename(files))))
  )
}

v3_make_figure_compendium <- function(catalog, output, width = 11, height = 8.5) {
  if (!nrow(catalog)) return(FALSE)
  if (!requireNamespace("png", quietly = TRUE)) v3_install_packages("png", required = TRUE)
  grDevices::pdf(output, width = width, height = height, onefile = TRUE, family = "Helvetica", paper = "special")
  on.exit(try(grDevices::dev.off(), silent = TRUE), add = TRUE)
  for (i in seq_len(nrow(catalog))) {
    img <- tryCatch(png::readPNG(catalog$path[[i]], native = FALSE), error = function(e) NULL)
    grid::grid.newpage()
    grid::grid.text(
      paste0("Figure ", catalog$id[[i]], ". ", catalog$title[[i]]),
      x = 0.5, y = 0.965,
      gp = grid::gpar(fontfamily = "Helvetica", fontsize = 12, fontface = "bold", lineheight = 1.15)
    )
    if (!is.null(img)) {
      grid::grid.raster(img, x = 0.5, y = 0.50, width = 0.94, height = 0.84, interpolate = TRUE)
    } else {
      grid::grid.text("Image could not be read.", gp = grid::gpar(fontfamily = "Helvetica", fontsize = 11))
    }
    grid::grid.text(
      paste0("Source: Iowa AI Workforce Atlas Methodology v3. File: ", catalog$filename[[i]]),
      x = 0.03, y = 0.03, just = "left",
      gp = grid::gpar(fontfamily = "Helvetica", fontsize = 9, lineheight = 1.15)
    )
  }
  grDevices::dev.off(); on.exit(NULL, add = FALSE)
  file.exists(output) && file.info(output)$size > 10000
}

make_methodology_v3_pdf_reports <- function(html_reports = NULL, paths = v3_paths()) {
  if (is.null(html_reports)) {
    html_reports <- list(
      quarto = file.path(paths$root, "outputs", "atlas_methodology_v3_quarto.html"),
      rmarkdown = file.path(paths$root, "outputs", "atlas_methodology_v3_rmarkdown.html")
    )
  }
  browser <- v3_find_browser()
  manifest <- list()
  targets <- list(
    list(name = "Quarto Methodology v3 PDF", html = html_reports$quarto, pdf = file.path(paths$root, "outputs", "atlas_methodology_v3_quarto.pdf")),
    list(name = "R Markdown Methodology v3 PDF", html = html_reports$rmarkdown, pdf = file.path(paths$root, "outputs", "atlas_methodology_v3_rmarkdown.pdf"))
  )
  for (i in seq_along(targets)) {
    t <- targets[[i]]
    message("Methodology v3 PDF ", i, "/3: printing ", t$name, ". This may take several minutes for the embedded figure appendix.")
    if (!file.exists(t$html)) {
      result <- list(ok = FALSE, status = "html_missing", log = "")
    } else {
      result <- v3_browser_print(t$html, t$pdf, browser, tagged = TRUE)
      if (!result$ok) result <- v3_browser_print(t$html, t$pdf, browser, tagged = FALSE)
    }
    manifest[[length(manifest) + 1L]] <- tibble::tibble(
      artifact = t$name, source_html = t$html, output_pdf = t$pdf,
      exists = file.exists(t$pdf), bytes = if (file.exists(t$pdf)) file.info(t$pdf)$size else NA_real_,
      status = result$status, browser = browser, log = substr(result$log %||% "", 1, 5000)
    )
  }
  message("Methodology v3 PDF 3/3: creating the all-figures printable compendium.")
  catalog <- v3_figure_catalog(paths)
  compendium <- file.path(paths$root, "outputs", "all_generated_figures_methodology_v3_printable.pdf")
  comp_ok <- v3_make_figure_compendium(catalog, compendium)
  manifest[[length(manifest) + 1L]] <- tibble::tibble(
    artifact = "All generated figures Methodology v3 compendium", source_html = NA_character_, output_pdf = compendium,
    exists = file.exists(compendium), bytes = if (file.exists(compendium)) file.info(compendium)$size else NA_real_,
    status = if (comp_ok) "created_figure_compendium" else "figure_compendium_failed", browser = NA_character_, log = ""
  )
  out <- dplyr::bind_rows(manifest)
  v3_write_csv(out, file.path(paths$outputs, "pdf_report_manifest_v3.csv"))
  checklist <- tibble::tibble(
    item = c(
      "Semantic headings and document language in HTML source",
      "Real HTML tables with header rows",
      "Figure titles in report body and source notes below figures",
      "Alternative text/figure descriptions in HTML report",
      "Browser tagged-PDF attempt",
      "Manual PDF/UA and reading-order review before public release"
    ),
    status = c("implemented", "implemented", "implemented", "implemented", ifelse(any(grepl("tagged", out$status)), "attempted", "not available"), "required"),
    note = c(
      "Generated by atlas_v3.qmd and atlas_v3.Rmd.",
      "Tables use semantic HTML output.",
      "Report styling follows the requested Arial and caption/source conventions.",
      "Each Methodology v3 figure has a descriptive title and source note.",
      "Support depends on the installed Chromium/Edge build.",
      "Automated browser printing cannot certify WCAG or PDF/UA conformance by itself."
    )
  )
  v3_write_csv(checklist, file.path(paths$outputs, "pdf_accessibility_checklist_v3.csv"))
  message("Methodology v3 PDF outputs recorded in: ", file.path(paths$outputs, "pdf_report_manifest_v3.csv"))
  out
}
