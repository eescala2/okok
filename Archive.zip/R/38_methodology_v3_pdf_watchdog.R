# Methodology v3.0.6 cross-platform PDF watchdog
#
# Purpose
# - prevents indefinite blocking while Chrome/Edge prints long HTML reports;
# - emits a visible heartbeat with elapsed time and current PDF size;
# - accepts a completed, valid PDF even when the browser process does not exit;
# - terminates stalled browser process trees after a configurable timeout;
# - prefers a conservative Chrome strategy on Apple Silicon and Edge on Windows;
# - recreates the Methodology v3 all-figures compendium without a browser.

v3_pdf_wd_or <- function(x, y) {
  if (is.null(x) || !length(x) || (length(x) == 1L && is.na(x))) y else x
}

v3_pdf_watchdog_paths <- function(paths = NULL) {
  if (is.null(paths)) {
    provider <- get0("v3_paths", mode = "function", inherits = TRUE)
    if (is.function(provider)) paths <- provider()
  }
  if (!is.list(paths)) paths <- list(root = getwd())

  root <- normalizePath(paths$root %||% getwd(), winslash = "/", mustWork = FALSE)
  outputs_root <- file.path(root, "outputs")
  outputs_v3 <- file.path(outputs_root, "methodology_v3")
  figures_v3 <- file.path(root, "figures", "methodology_v3")
  dir.create(outputs_root, recursive = TRUE, showWarnings = FALSE)
  dir.create(outputs_v3, recursive = TRUE, showWarnings = FALSE)
  dir.create(figures_v3, recursive = TRUE, showWarnings = FALSE)

  list(
    root = root,
    outputs_root = outputs_root,
    outputs_v3 = outputs_v3,
    figures_v3 = figures_v3
  )
}

# Avoid depending on another module's infix helper.
if (!exists("%||%", mode = "function", inherits = TRUE)) {
  `%||%` <- v3_pdf_wd_or
}

v3_pdf_watchdog_is_apple_silicon <- function() {
  identical(Sys.info()[["sysname"]], "Darwin") &&
    grepl("arm64|aarch64", R.version$arch, ignore.case = TRUE)
}

v3_pdf_watchdog_timeout <- function() {
  raw <- Sys.getenv("IA_ATLAS_V3_PDF_TIMEOUT_SEC", unset = "")
  value <- suppressWarnings(as.numeric(raw))
  if (is.finite(value) && value >= 30) return(value)
  if (v3_pdf_watchdog_is_apple_silicon()) 420 else 900
}

v3_pdf_watchdog_heartbeat <- function() {
  raw <- Sys.getenv("IA_ATLAS_V3_PDF_HEARTBEAT_SEC", unset = "15")
  value <- suppressWarnings(as.numeric(raw))
  if (!is.finite(value) || value < 2) value <- 15
  value
}

v3_pdf_watchdog_max_attempts <- function() {
  raw <- Sys.getenv("IA_ATLAS_V3_PDF_MAX_ATTEMPTS", unset = "")
  value <- suppressWarnings(as.integer(raw))
  if (is.finite(value) && value >= 1L && value <= 4L) return(value)
  if (v3_pdf_watchdog_is_apple_silicon()) 2L else 3L
}

v3_pdf_watchdog_find_browser <- function() {
  envs <- c("IA_ATLAS_CHROME", "PAGEDOWN_CHROME", "CHROME_PATH")
  for (nm in envs) {
    candidate <- Sys.getenv(nm, unset = "")
    if (nzchar(candidate) && file.exists(candidate)) {
      return(normalizePath(candidate, winslash = "/", mustWork = TRUE))
    }
  }

  # Edge is preferred on Windows because it is normally installed and its
  # headless printing is generally isolated from the user's Chrome profile.
  candidates <- if (.Platform$OS.type == "windows") {
    c(
      "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
      "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
      "C:/Program Files/Google/Chrome/Application/chrome.exe",
      "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe"
    )
  } else {
    c(
      "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
      "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
      "/Applications/Chromium.app/Contents/MacOS/Chromium"
    )
  }
  hit <- candidates[file.exists(candidates)]
  if (length(hit)) return(normalizePath(hit[[1L]], winslash = "/", mustWork = TRUE))

  for (cmd in c("msedge", "microsoft-edge", "google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "chrome")) {
    candidate <- Sys.which(cmd)
    if (nzchar(candidate)) return(candidate)
  }
  ""
}

v3_pdf_watchdog_file_url <- function(path) {
  if (exists("v3_oq_file_url", mode = "function", inherits = TRUE)) {
    return(v3_oq_file_url(path))
  }
  path <- normalizePath(path, winslash = "/", mustWork = TRUE)
  encoded <- utils::URLencode(path, reserved = FALSE)
  if (.Platform$OS.type == "windows" && grepl("^[A-Za-z]:/", path)) {
    paste0("file:///", encoded)
  } else {
    paste0("file://", encoded)
  }
}

v3_pdf_watchdog_info <- function(path) {
  if (exists("v3_oq_pdf_info", mode = "function", inherits = TRUE)) {
    return(v3_oq_pdf_info(path))
  }
  out <- list(
    exists = file.exists(path),
    bytes = if (file.exists(path)) unname(file.info(path)$size) else 0,
    pages = NA_integer_,
    title = NA_character_,
    first_text = ""
  )
  if (!out$exists) return(out)
  if (requireNamespace("pdftools", quietly = TRUE)) {
    info <- tryCatch(pdftools::pdf_info(path), error = function(e) NULL)
    if (!is.null(info)) {
      out$pages <- suppressWarnings(as.integer(info$pages))
      out$title <- as.character(info$title %||% NA_character_)
    }
    text <- tryCatch(pdftools::pdf_text(path), error = function(e) character())
    if (length(text)) out$first_text <- text[[1L]]
  }
  out
}

v3_pdf_watchdog_valid <- function(pdf, html = NULL) {
  if (exists("v3_oq_pdf_valid", mode = "function", inherits = TRUE)) {
    return(v3_oq_pdf_valid(pdf, html))
  }
  info <- v3_pdf_watchdog_info(pdf)
  html_bytes <- if (!is.null(html) && file.exists(html)) unname(file.info(html)$size) else 0
  min_bytes <- max(250000, min(1000000, html_bytes * 0.10))
  bad_text <- grepl("Search Google or type a URL|chrome://newtab", info$first_text, ignore.case = TRUE)
  bad_title <- !is.na(info$title) && grepl("^New Tab$|Google", info$title, ignore.case = TRUE)
  page_ok <- is.na(info$pages) || info$pages >= 3L
  valid <- isTRUE(info$exists) && is.finite(info$bytes) && info$bytes >= min_bytes && page_ok && !bad_text && !bad_title
  c(info, list(min_bytes = min_bytes, valid = valid))
}

v3_pdf_watchdog_kill <- function(proc) {
  if (is.null(proc)) return(invisible(FALSE))
  try(proc$kill_tree(), silent = TRUE)
  if (isTRUE(tryCatch(proc$is_alive(), error = function(e) FALSE))) {
    try(proc$kill(), silent = TRUE)
  }
  invisible(TRUE)
}

v3_pdf_watchdog_log_lines <- function(proc) {
  if (is.null(proc)) return(character())
  out <- tryCatch(proc$read_output_lines(), error = function(e) character())
  err <- tryCatch(proc$read_error_lines(), error = function(e) character())
  c(out, err)
}

v3_pdf_watchdog_attempt_plan <- function() {
  tagged_setting <- tolower(trimws(Sys.getenv("IA_ATLAS_V3_PDF_TAGGED", unset = "auto")))
  tagged_default <- .Platform$OS.type == "windows"
  tagged_first <- if (tagged_setting %in% c("true", "1", "yes")) TRUE else if (tagged_setting %in% c("false", "0", "no")) FALSE else tagged_default

  if (v3_pdf_watchdog_is_apple_silicon()) {
    # Legacy headless is often more stable than headless=new for local, large,
    # self-contained HTML on older Apple-Silicon Chrome builds.
    plan <- list(
      list(headless = "legacy", tagged = FALSE),
      list(headless = "new", tagged = FALSE),
      list(headless = "new", tagged = TRUE)
    )
  } else if (tagged_first) {
    plan <- list(
      list(headless = "new", tagged = TRUE),
      list(headless = "new", tagged = FALSE),
      list(headless = "legacy", tagged = FALSE)
    )
  } else {
    plan <- list(
      list(headless = "new", tagged = FALSE),
      list(headless = "legacy", tagged = FALSE),
      list(headless = "new", tagged = TRUE)
    )
  }
  plan[seq_len(min(length(plan), v3_pdf_watchdog_max_attempts()))]
}

v3_pdf_watchdog_print_once <- function(browser, html, pdf, headless = "new", tagged = FALSE, timeout_sec = NULL) {
  if (!requireNamespace("processx", quietly = TRUE)) {
    stop("The PDF watchdog requires the processx package.", call. = FALSE)
  }
  if (!file.exists(html)) stop("Missing source HTML: ", html, call. = FALSE)
  if (is.null(timeout_sec)) timeout_sec <- v3_pdf_watchdog_timeout()

  if (file.exists(pdf)) unlink(pdf, force = TRUE)
  dir.create(dirname(pdf), recursive = TRUE, showWarnings = FALSE)
  profile <- tempfile("iowa_atlas_pdf_profile_")
  dir.create(profile, recursive = TRUE, showWarnings = FALSE)
  on.exit(unlink(profile, recursive = TRUE, force = TRUE), add = TRUE)

  headless_arg <- if (identical(headless, "legacy")) "--headless" else "--headless=new"
  args <- c(
    headless_arg,
    "--disable-gpu",
    "--disable-extensions",
    "--disable-background-networking",
    "--disable-component-update",
    "--disable-default-apps",
    "--disable-sync",
    "--no-first-run",
    "--no-default-browser-check",
    "--allow-file-access-from-files",
    "--run-all-compositor-stages-before-draw",
    "--virtual-time-budget=20000",
    "--no-pdf-header-footer",
    paste0("--user-data-dir=", profile),
    paste0("--print-to-pdf=", normalizePath(pdf, winslash = "/", mustWork = FALSE))
  )
  if (isTRUE(tagged)) args <- c(args, "--generate-tagged-pdf")
  # The URL must be the final argument. Otherwise some Chrome builds open New Tab.
  args <- c(args, v3_pdf_watchdog_file_url(html))

  started <- Sys.time()
  proc <- processx::process$new(
    command = browser,
    args = args,
    stdout = "|",
    stderr = "|",
    cleanup_tree = TRUE,
    windows_hide_window = TRUE
  )
  on.exit(v3_pdf_watchdog_kill(proc), add = TRUE)

  heartbeat <- v3_pdf_watchdog_heartbeat()
  next_heartbeat <- heartbeat
  last_size <- -1
  stable_polls <- 0L
  log_lines <- character()
  result <- NULL

  repeat {
    try(proc$poll_io(1000), silent = TRUE)
    log_lines <- c(log_lines, v3_pdf_watchdog_log_lines(proc))
    if (length(log_lines) > 300L) log_lines <- tail(log_lines, 300L)

    elapsed <- as.numeric(difftime(Sys.time(), started, units = "secs"))
    current_size <- if (file.exists(pdf)) unname(file.info(pdf)$size) else 0

    if (is.finite(current_size) && current_size > 0) {
      if (identical(current_size, last_size)) stable_polls <- stable_polls + 1L else stable_polls <- 0L
      last_size <- current_size
      if (stable_polls >= 2L) {
        check <- v3_pdf_watchdog_valid(pdf, html)
        if (isTRUE(check$valid)) {
          v3_pdf_watchdog_kill(proc)
          result <- c(check, list(
            status = if (tagged) "created_tagged_watchdog_validated" else "created_watchdog_validated",
            elapsed_seconds = elapsed,
            timed_out = FALSE,
            browser_exit_status = tryCatch(proc$get_exit_status(), error = function(e) NA_integer_),
            log = paste(log_lines, collapse = "\n"),
            headless = headless,
            tagged = tagged
          ))
          break
        }
      }
    }

    if (elapsed >= next_heartbeat) {
      size_label <- if (is.finite(current_size) && current_size > 0) sprintf("%.1f MB", current_size / 1024^2) else "not written yet"
      message(sprintf(
        "  PDF watchdog: %s elapsed; current PDF: %s; browser alive: %s",
        format(round(elapsed), scientific = FALSE),
        size_label,
        tryCatch(proc$is_alive(), error = function(e) FALSE)
      ))
      next_heartbeat <- next_heartbeat + heartbeat
    }

    alive <- tryCatch(proc$is_alive(), error = function(e) FALSE)
    if (!alive) {
      check <- v3_pdf_watchdog_valid(pdf, html)
      result <- c(check, list(
        status = if (isTRUE(check$valid)) {
          if (tagged) "created_tagged_watchdog_validated" else "created_watchdog_validated"
        } else {
          "browser_exited_pdf_invalid"
        },
        elapsed_seconds = elapsed,
        timed_out = FALSE,
        browser_exit_status = tryCatch(proc$get_exit_status(), error = function(e) NA_integer_),
        log = paste(log_lines, collapse = "\n"),
        headless = headless,
        tagged = tagged
      ))
      break
    }

    if (elapsed >= timeout_sec) {
      v3_pdf_watchdog_kill(proc)
      check <- v3_pdf_watchdog_valid(pdf, html)
      result <- c(check, list(
        status = if (isTRUE(check$valid)) "created_watchdog_validated_after_timeout" else "timed_out_pdf_invalid",
        elapsed_seconds = elapsed,
        timed_out = TRUE,
        browser_exit_status = NA_integer_,
        log = paste(log_lines, collapse = "\n"),
        headless = headless,
        tagged = tagged
      ))
      break
    }
  }

  result
}

v3_pdf_watchdog_print_report <- function(browser, html, pdf, artifact, force = TRUE) {
  if (!isTRUE(force)) {
    current <- v3_pdf_watchdog_valid(pdf, html)
    if (isTRUE(current$valid)) {
      return(c(current, list(
        artifact = artifact,
        status = "retained_valid_pdf",
        elapsed_seconds = 0,
        timed_out = FALSE,
        browser_exit_status = NA_integer_,
        log = "",
        headless = NA_character_,
        tagged = NA
      )))
    }
  }

  plan <- v3_pdf_watchdog_attempt_plan()
  attempts <- vector("list", length(plan))
  for (i in seq_along(plan)) {
    message(sprintf(
      "  Attempt %d/%d for %s: headless=%s, tagged=%s, timeout=%ss",
      i, length(plan), artifact, plan[[i]]$headless, plan[[i]]$tagged,
      format(v3_pdf_watchdog_timeout(), scientific = FALSE)
    ))
    attempts[[i]] <- v3_pdf_watchdog_print_once(
      browser = browser,
      html = html,
      pdf = pdf,
      headless = plan[[i]]$headless,
      tagged = plan[[i]]$tagged,
      timeout_sec = v3_pdf_watchdog_timeout()
    )
    if (isTRUE(attempts[[i]]$valid)) {
      attempts[[i]]$artifact <- artifact
      attempts[[i]]$attempt <- i
      return(attempts[[i]])
    }
  }

  last <- attempts[[length(attempts)]]
  last$artifact <- artifact
  last$attempt <- length(attempts)
  last$status <- paste0("failed_after_", length(attempts), "_watchdog_attempts")
  last$log <- paste(vapply(attempts, function(x) x$log %||% "", character(1L)), collapse = "\n--- NEXT ATTEMPT ---\n")
  last
}

v3_pdf_watchdog_compendium_files <- function(paths = NULL) {
  p <- v3_pdf_watchdog_paths(paths)
  manifest_path <- file.path(p$outputs_v3, "methodology_v3_visualization_manifest.csv")
  files <- character()
  if (file.exists(manifest_path)) {
    manifest <- tryCatch(readr::read_csv(manifest_path, show_col_types = FALSE, progress = FALSE), error = function(e) NULL)
    if (!is.null(manifest) && nrow(manifest)) {
      candidate_col <- intersect(c("path", "output_path", "file", "filename"), names(manifest))
      if (length(candidate_col)) {
        values <- as.character(manifest[[candidate_col[[1L]]]])
        values <- ifelse(grepl("^(/|[A-Za-z]:[/\\\\])", values), values, file.path(p$figures_v3, basename(values)))
        files <- values[file.exists(values)]
      }
    }
  }
  discovered <- list.files(p$figures_v3, pattern = "\\.png$", full.names = TRUE, ignore.case = TRUE)
  files <- unique(c(files, discovered))
  if (!length(files)) return(character())
  ids <- suppressWarnings(as.integer(sub("^.*?_([0-9]{2})_.*$", "\\1", basename(files))))
  files[order(is.na(ids), ids, basename(files))]
}

v3_pdf_watchdog_create_compendium <- function(paths = NULL, force = TRUE) {
  p <- v3_pdf_watchdog_paths(paths)
  output <- file.path(p$outputs_root, "all_generated_figures_methodology_v3_printable.pdf")
  files <- v3_pdf_watchdog_compendium_files(paths)
  if (!length(files)) stop("No Methodology v3 PNG figures were found for the PDF compendium.", call. = FALSE)
  if (!requireNamespace("png", quietly = TRUE)) {
    utils::install.packages("png", dependencies = NA, quiet = TRUE)
  }
  if (!requireNamespace("png", quietly = TRUE)) stop("The png package is required for the figure compendium.", call. = FALSE)
  if (file.exists(output) && isTRUE(force)) unlink(output, force = TRUE)

  grDevices::pdf(output, width = 11, height = 8.5, onefile = TRUE, useDingbats = FALSE, family = "Helvetica")
  on.exit(try(grDevices::dev.off(), silent = TRUE), add = TRUE)
  for (path in files) {
    img <- tryCatch(png::readPNG(path), error = function(e) NULL)
    if (is.null(img)) next
    dims <- dim(img)
    aspect <- if (length(dims) >= 2L && dims[[1L]] > 0) dims[[2L]] / dims[[1L]] else 16 / 9
    max_w <- 10.25
    max_h <- 7.35
    w <- min(max_w, max_h * aspect)
    h <- w / aspect
    grid::grid.newpage()
    grid::grid.rect(gp = grid::gpar(fill = "white", col = NA))
    grid::grid.text(
      gsub("_", " ", tools::file_path_sans_ext(basename(path))),
      x = grid::unit(0.5, "npc"), y = grid::unit(0.965, "npc"),
      gp = grid::gpar(fontfamily = "Helvetica", fontsize = 12, fontface = "bold", col = "black")
    )
    grid::grid.raster(
      img,
      x = grid::unit(0.5, "npc"), y = grid::unit(0.48, "npc"),
      width = grid::unit(w, "in"), height = grid::unit(h, "in"),
      interpolate = TRUE
    )
  }
  grDevices::dev.off()
  on.exit(NULL, add = FALSE)
  output
}

v3_run_methodology_v3_pdf_stage <- function(paths = NULL, force = TRUE) {
  p <- v3_pdf_watchdog_paths(paths)
  browser <- v3_pdf_watchdog_find_browser()
  if (!nzchar(browser)) {
    stop(
      "No supported Chrome, Chromium, or Edge executable was found. Set IA_ATLAS_CHROME to its full path.",
      call. = FALSE
    )
  }

  message("Methodology v3 safe PDF 1/3: Quarto report (watchdog enabled).")
  quarto <- v3_pdf_watchdog_print_report(
    browser = browser,
    html = file.path(p$outputs_root, "atlas_methodology_v3_quarto.html"),
    pdf = file.path(p$outputs_root, "atlas_methodology_v3_quarto.pdf"),
    artifact = "Quarto Methodology v3 PDF",
    force = force
  )

  message("Methodology v3 safe PDF 2/3: R Markdown report (watchdog enabled).")
  rmarkdown <- v3_pdf_watchdog_print_report(
    browser = browser,
    html = file.path(p$outputs_root, "atlas_methodology_v3_rmarkdown.html"),
    pdf = file.path(p$outputs_root, "atlas_methodology_v3_rmarkdown.pdf"),
    artifact = "R Markdown Methodology v3 PDF",
    force = force
  )

  message("Methodology v3 safe PDF 3/3: all-figures compendium (R graphics device; no browser).")
  compendium <- v3_pdf_watchdog_create_compendium(paths = paths, force = force)

  rows <- list(quarto, rmarkdown)
  report_manifest <- purrr::map_dfr(rows, function(x) {
    tibble::tibble(
      artifact = as.character(x$artifact %||% ""),
      source_html = if (identical(x$artifact, "Quarto Methodology v3 PDF")) {
        file.path(p$outputs_root, "atlas_methodology_v3_quarto.html")
      } else {
        file.path(p$outputs_root, "atlas_methodology_v3_rmarkdown.html")
      },
      output_pdf = if (identical(x$artifact, "Quarto Methodology v3 PDF")) {
        file.path(p$outputs_root, "atlas_methodology_v3_quarto.pdf")
      } else {
        file.path(p$outputs_root, "atlas_methodology_v3_rmarkdown.pdf")
      },
      exists = isTRUE(x$exists),
      bytes = suppressWarnings(as.numeric(x$bytes %||% 0)),
      pages = suppressWarnings(as.integer(x$pages %||% NA_integer_)),
      status = as.character(x$status %||% "unknown"),
      validated = isTRUE(x$valid),
      browser = browser,
      attempt = suppressWarnings(as.integer(x$attempt %||% NA_integer_)),
      headless = as.character(x$headless %||% NA_character_),
      tagged = as.logical(x$tagged %||% NA),
      elapsed_seconds = suppressWarnings(as.numeric(x$elapsed_seconds %||% NA_real_)),
      timed_out = isTRUE(x$timed_out),
      log = as.character(x$log %||% "")
    )
  })
  report_manifest <- dplyr::bind_rows(
    report_manifest,
    tibble::tibble(
      artifact = "All generated figures Methodology v3 compendium",
      source_html = NA_character_,
      output_pdf = compendium,
      exists = file.exists(compendium),
      bytes = if (file.exists(compendium)) unname(file.info(compendium)$size) else 0,
      pages = length(v3_pdf_watchdog_compendium_files(paths)),
      status = "created_figure_compendium_watchdog",
      validated = file.exists(compendium) && file.info(compendium)$size > 250000,
      browser = NA_character_,
      attempt = NA_integer_,
      headless = NA_character_,
      tagged = NA,
      elapsed_seconds = NA_real_,
      timed_out = FALSE,
      log = ""
    )
  )

  manifest_path <- file.path(p$outputs_v3, "pdf_report_manifest_v3.csv")
  readr::write_csv(report_manifest, manifest_path, na = "")

  if (any(!report_manifest$validated)) {
    stop(
      "Methodology v3 PDF stage ended without indefinite blocking, but one or more PDFs failed validation. See ",
      manifest_path,
      ". On the Windows production machine, rerun 99_run_methodology_v3_pdf_only_safe.R.",
      call. = FALSE
    )
  }

  message("Methodology v3 PDF watchdog completed. Manifest: ", manifest_path)
  invisible(report_manifest)
}

# BEGIN IA_ATLAS_V3_PUBLICATION_RELEASE_V308_SOURCE
.v3_pub_module_candidates <- unique(c(
  file.path(getwd(), "R", "39_methodology_v3_publication_release.R"),
  file.path("R", "39_methodology_v3_publication_release.R")
))
.v3_pub_module_hit <- .v3_pub_module_candidates[file.exists(.v3_pub_module_candidates)]
if (length(.v3_pub_module_hit)) {
  sys.source(.v3_pub_module_hit[[1L]], envir = .GlobalEnv, keep.source = FALSE)
}
rm(.v3_pub_module_candidates, .v3_pub_module_hit)
# END IA_ATLAS_V3_PUBLICATION_RELEASE_V308_SOURCE



# BEGIN IA_ATLAS_V3_PUBLICATION_COMPLETION_V309_SOURCE
.v3_v309_candidates <- unique(c(
  file.path(getwd(), "R", "40_methodology_v3_publication_completion_v309.R"),
  file.path("R", "40_methodology_v3_publication_completion_v309.R")
))
.v3_v309_hit <- .v3_v309_candidates[file.exists(.v3_v309_candidates)]
if (length(.v3_v309_hit)) sys.source(.v3_v309_hit[[1L]], envir = .GlobalEnv, keep.source = FALSE)
rm(.v3_v309_candidates, .v3_v309_hit)
# END IA_ATLAS_V3_PUBLICATION_COMPLETION_V309_SOURCE
