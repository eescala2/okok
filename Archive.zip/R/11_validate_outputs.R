# 11_validate_outputs.R ----------------------------------------------------
# Final Methodology v2 output validation. The workflow does not declare a
# successful release until analytical, provenance, visual, report, PDF, and
# editable-Excel artifacts are present and reconciliation tests pass.

.atlas_find_root_validate <- function() {
  here <- normalizePath(getwd(), winslash = '/', mustWork = TRUE)
  candidates <- unique(c(
    here, dirname(here),
    normalizePath(file.path(here, '..'), winslash = '/', mustWork = FALSE),
    normalizePath(file.path(here, '../..'), winslash = '/', mustWork = FALSE)
  ))
  for (cand in candidates) {
    if (file.exists(file.path(cand, 'config.yml')) && dir.exists(file.path(cand, 'R'))) {
      return(normalizePath(cand, winslash = '/', mustWork = TRUE))
    }
  }
  here
}

root0 <- .atlas_find_root_validate()
source(file.path(root0, 'R', '00_setup.R'))

.path_exists_nonempty <- function(path) file.exists(path) && isTRUE(file.info(path)$size > 0)

.compat_output_exists <- function(name, directory) {
  any(vapply(
    c(file.path(directory, paste0(name, '.parquet')),
      file.path(directory, paste0(name, '.rds')),
      file.path(directory, paste0(name, '.csv.gz'))),
    .path_exists_nonempty,
    logical(1)
  ))
}

.manifest_created_count <- function(path) {
  if (!file.exists(path)) return(0L)
  tryCatch({
    x <- readr::read_csv(path, show_col_types = FALSE)
    if (!'status' %in% names(x)) return(0L)
    sum(x$status == 'created', na.rm = TRUE)
  }, error = function(e) 0L)
}

validate_run_outputs <- function(stop_on_missing = TRUE,
                                 expected_public_figures = 26L,
                                 expected_methodology_figures = 10L,
                                 expected_editable_figures = 40L) {
  p <- paths()
  m2 <- file.path(p$outputs, 'methodology_v2')

  alpha_check_path <- file.path(p$outputs, 'png_transparency_check.csv')
  figure01_transparent <- FALSE
  if (file.exists(alpha_check_path)) {
    figure01_transparent <- tryCatch({
      x <- readr::read_csv(alpha_check_path, show_col_types = FALSE)
      nrow(x) > 0 && isTRUE(x$transparent[[1L]]) && isTRUE(x$has_alpha[[1L]]) && x$transparent_pixels[[1L]] > 0
    }, error = function(e) FALSE)
  }

  pdf_manifest_path <- file.path(p$outputs, 'pdf_report_manifest.csv')
  quarto_pdf_from_html <- FALSE; rmarkdown_pdf_from_html <- FALSE
  if (file.exists(pdf_manifest_path)) {
    try({
      x <- readr::read_csv(pdf_manifest_path, show_col_types = FALSE)
      q <- x$status[x$output == 'Quarto PDF']; r <- x$status[x$output == 'R Markdown PDF']
      quarto_pdf_from_html <- length(q) == 1L && grepl('^created_from_html_', q)
      rmarkdown_pdf_from_html <- length(r) == 1L && grepl('^created_from_html_', r)
    }, silent = TRUE)
  }

  reconciliation_path <- file.path(m2, 'reconciliation_tests.csv')
  reconciliation_pass <- FALSE
  if (file.exists(reconciliation_path)) {
    reconciliation_pass <- tryCatch({
      x <- readr::read_csv(reconciliation_path, show_col_types = FALSE)
      nrow(x) > 0 && all(as.logical(x$pass), na.rm = FALSE)
    }, error = function(e) FALSE)
  }

  build_manifest_path <- file.path(m2, 'build_manifest.csv')
  current_build_id <- NA_character_
  if (file.exists(build_manifest_path)) {
    current_build_id <- tryCatch(readr::read_csv(build_manifest_path, show_col_types = FALSE)$build_id[[1L]], error = function(e) NA_character_)
  }
  build_manifest_files <- c(
    file.path(p$outputs, 'core_figure_manifest.csv'),
    file.path(p$outputs, 'public_visualization_manifest.csv'),
    file.path(p$outputs, 'methodology_v2_visualization_manifest.csv'),
    file.path(p$outputs, 'report_render_manifest.csv'),
    file.path(p$outputs, 'pdf_report_manifest.csv'),
    file.path(p$outputs, 'editable_excel_figure_manifest.csv')
  )
  build_id_consistent <- is.character(current_build_id) && length(current_build_id) == 1L && !is.na(current_build_id) && nzchar(current_build_id) && all(vapply(build_manifest_files, function(f) {
    if (!file.exists(f)) return(FALSE)
    tryCatch({
      x <- readr::read_csv(f, show_col_types = FALSE)
      'build_id' %in% names(x) && nrow(x) > 0 && all(!is.na(x$build_id)) && all(x$build_id == current_build_id)
    }, error = function(e) FALSE)
  }, logical(1)))

  checks <- tibble::tibble(
    artifact = c(
      'Primary atlas storage', 'Methodology v2 atlas storage',
      'Methodology v2 occupation scores', 'Methodology v2 county summary', 'Methodology v2 LWDA summary',
      'Methodology v2 sector summary', 'Methodology v2 training priorities', 'Training-capacity index',
      'Action sensitivity output', 'Threshold values output', 'Score-weight sensitivity output', 'Skill-transition pathways output',
      'Observed adoption status output', 'Observed adoption source detail', 'Worker outcome summary output', 'Employer pilot summary output',
      'Source provenance', 'Configuration provenance', 'Build manifest', 'Package version manifest', 'Model card CSV', 'Model card Markdown',
      'Cross-artifact build ID consistency',
      'Reconciliation tests present', 'All reconciliation tests pass',
      'Core figure manifest', 'County automation exposure figure', 'County pro-worker opportunity figure', 'LWDA AI metrics figure',
      'Sector risk-opportunity quadrant figure', 'Public visualization manifest', 'Public visualization gallery HTML',
      'Methodology visualization manifest', 'Figure 01 transparent RGBA PNG', 'PNG transparency validation CSV',
      'HTML report render manifest', 'Quarto HTML report', 'R Markdown HTML report', 'Quarto PDF report with all figures',
      'R Markdown PDF report with all figures', 'Quarto PDF generated from complete HTML report',
      'R Markdown PDF generated from complete HTML report', 'All generated figures printable PDF',
      'PDF report manifest', 'PDF accessibility checklist', 'Editable Excel figure workbook',
      'Editable Excel figure manifest'
    ),
    path = c(
      'data_processed/county_industry_occupation_atlas.*', 'data_processed/county_industry_occupation_atlas_v2.*',
      'data_processed/occupation_ai_scores_v2.csv', 'data_processed/county_summary_v2.csv', 'data_processed/lwda_summary_v2.csv',
      'data_processed/sector_lwda_summary_v2.csv', 'data_processed/training_priority_occupations_v2.csv', 'data_processed/training_capacity_index_v2.csv',
      'data_processed/county_action_sensitivity_v2.csv', 'data_processed/action_threshold_values_v2.csv', 'data_processed/score_weight_sensitivity_v2.csv', 'data_processed/occupation_skill_transition_paths_v2.csv',
      'data_processed/observed_adoption_status_v2.csv', 'data_processed/sector_observed_adoption_sources_v2.csv', 'data_processed/worker_quality_adjusted_outcomes_v2.csv', 'data_processed/employer_pilot_outcomes_summary_v2.csv',
      'outputs/methodology_v2/source_provenance.csv', 'outputs/methodology_v2/configuration_provenance.csv', 'outputs/methodology_v2/build_manifest.csv', 'outputs/methodology_v2/package_versions.csv',
      'outputs/methodology_v2/model_card.csv', 'MODEL_CARD.md', 'outputs/methodology_v2/build_manifest.csv::matching build_id in all manifests', 'outputs/methodology_v2/reconciliation_tests.csv',
      'outputs/methodology_v2/reconciliation_tests.csv::all pass',
      'outputs/core_figure_manifest.csv', 'figures/county_automation_exposure.png', 'figures/county_pro_worker_opportunity.png', 'figures/lwda_ai_metrics.png',
      'figures/sector_risk_opportunity_quadrant.png', 'outputs/public_visualization_manifest.csv', 'outputs/public_visualization_gallery.html',
      'outputs/methodology_v2_visualization_manifest.csv', 'figures/public/public_01_county_bivariate_risk_opportunity.png',
      'outputs/png_transparency_check.csv', 'outputs/report_render_manifest.csv', 'outputs/atlas_quarto.html', 'outputs/atlas_rmarkdown.html',
      'outputs/atlas_quarto_with_all_figures.pdf', 'outputs/atlas_rmarkdown_with_all_figures.pdf',
      'outputs/pdf_report_manifest.csv::Quarto PDF created_from_html_*', 'outputs/pdf_report_manifest.csv::R Markdown PDF created_from_html_*',
      'outputs/all_generated_figures_printable.pdf', 'outputs/pdf_report_manifest.csv', 'outputs/pdf_accessibility_checklist.csv',
      'outputs/iowa_ai_workforce_atlas_editable_figures.xlsx', 'outputs/editable_excel_figure_manifest.csv'
    ),
    exists = c(
      .compat_output_exists('county_industry_occupation_atlas', p$processed),
      .compat_output_exists('county_industry_occupation_atlas_v2', p$processed),
      .path_exists_nonempty(file.path(p$processed, 'occupation_ai_scores_v2.csv')),
      .path_exists_nonempty(file.path(p$processed, 'county_summary_v2.csv')),
      .path_exists_nonempty(file.path(p$processed, 'lwda_summary_v2.csv')),
      .path_exists_nonempty(file.path(p$processed, 'sector_lwda_summary_v2.csv')),
      .path_exists_nonempty(file.path(p$processed, 'training_priority_occupations_v2.csv')),
      .path_exists_nonempty(file.path(p$processed, 'training_capacity_index_v2.csv')),
      .path_exists_nonempty(file.path(p$processed, 'county_action_sensitivity_v2.csv')),
      .path_exists_nonempty(file.path(p$processed, 'action_threshold_values_v2.csv')),
      .path_exists_nonempty(file.path(p$processed, 'score_weight_sensitivity_v2.csv')),
      .path_exists_nonempty(file.path(p$processed, 'occupation_skill_transition_paths_v2.csv')),
      .path_exists_nonempty(file.path(p$processed, 'observed_adoption_status_v2.csv')),
      file.exists(file.path(p$processed, 'sector_observed_adoption_sources_v2.csv')),
      file.exists(file.path(p$processed, 'worker_quality_adjusted_outcomes_v2.csv')),
      file.exists(file.path(p$processed, 'employer_pilot_outcomes_summary_v2.csv')),
      .path_exists_nonempty(file.path(m2, 'source_provenance.csv')),
      .path_exists_nonempty(file.path(m2, 'configuration_provenance.csv')),
      .path_exists_nonempty(file.path(m2, 'build_manifest.csv')),
      .path_exists_nonempty(file.path(m2, 'package_versions.csv')),
      .path_exists_nonempty(file.path(m2, 'model_card.csv')),
      .path_exists_nonempty(file.path(p$root, 'MODEL_CARD.md')),
      build_id_consistent,
      .path_exists_nonempty(reconciliation_path), reconciliation_pass,
      .path_exists_nonempty(file.path(p$outputs, 'core_figure_manifest.csv')),
      .path_exists_nonempty(file.path(p$figures, 'county_automation_exposure.png')),
      .path_exists_nonempty(file.path(p$figures, 'county_pro_worker_opportunity.png')),
      .path_exists_nonempty(file.path(p$figures, 'lwda_ai_metrics.png')),
      .path_exists_nonempty(file.path(p$figures, 'sector_risk_opportunity_quadrant.png')),
      .path_exists_nonempty(file.path(p$outputs, 'public_visualization_manifest.csv')),
      .path_exists_nonempty(file.path(p$outputs, 'public_visualization_gallery.html')),
      .path_exists_nonempty(file.path(p$outputs, 'methodology_v2_visualization_manifest.csv')),
      figure01_transparent, .path_exists_nonempty(alpha_check_path),
      .path_exists_nonempty(file.path(p$outputs, 'report_render_manifest.csv')),
      .path_exists_nonempty(file.path(p$outputs, 'atlas_quarto.html')),
      .path_exists_nonempty(file.path(p$outputs, 'atlas_rmarkdown.html')),
      .path_exists_nonempty(file.path(p$outputs, 'atlas_quarto_with_all_figures.pdf')),
      .path_exists_nonempty(file.path(p$outputs, 'atlas_rmarkdown_with_all_figures.pdf')),
      quarto_pdf_from_html, rmarkdown_pdf_from_html,
      .path_exists_nonempty(file.path(p$outputs, 'all_generated_figures_printable.pdf')),
      .path_exists_nonempty(pdf_manifest_path),
      .path_exists_nonempty(file.path(p$outputs, 'pdf_accessibility_checklist.csv')),
      .path_exists_nonempty(file.path(p$outputs, 'iowa_ai_workforce_atlas_editable_figures.xlsx')),
      .path_exists_nonempty(file.path(p$outputs, 'editable_excel_figure_manifest.csv'))
    )
  )

  public_dir <- file.path(p$figures, 'public')
  public_files <- if (dir.exists(public_dir)) list.files(public_dir, pattern = '^public_[0-9]+_.*\\.(png|jpg|jpeg)$', full.names = TRUE) else character()
  public_created <- .manifest_created_count(file.path(p$outputs, 'public_visualization_manifest.csv'))
  methodology_dir <- file.path(p$figures, 'methodology_v2')
  methodology_files <- if (dir.exists(methodology_dir)) list.files(methodology_dir, pattern = '^methodology_[0-9]+_.*\\.(png|jpg|jpeg)$', full.names = TRUE) else character()
  methodology_created <- .manifest_created_count(file.path(p$outputs, 'methodology_v2_visualization_manifest.csv'))

  editable_ok <- FALSE
  editable_manifest <- file.path(p$outputs, 'editable_excel_figure_manifest.csv')
  if (file.exists(editable_manifest)) {
    editable_ok <- tryCatch({
      x <- readr::read_csv(editable_manifest, show_col_types = FALSE)
      nrow(x) >= expected_editable_figures && all(x$status == 'created_editable_drawing')
    }, error = function(e) FALSE)
  }

  checks <- dplyr::bind_rows(
    checks,
    tibble::tibble(
      artifact = c('Public figure count', 'Methodology v2 figure count', 'Editable Excel figure count'),
      path = c('figures/public/::26 figures', 'figures/methodology_v2/::10 figures', 'outputs/editable_excel_figure_manifest.csv::40 drawings'),
      exists = c(
        length(public_files) >= expected_public_figures && public_created >= expected_public_figures,
        length(methodology_files) >= expected_methodology_figures && methodology_created >= expected_methodology_figures,
        editable_ok
      )
    )
  ) |>
    dplyr::mutate(status = dplyr::if_else(exists, 'OK', 'MISSING'), checked_at = format(Sys.time(), '%Y-%m-%d %H:%M:%S %Z'))

  fs::dir_create(p$outputs)
  out <- file.path(p$outputs, 'run_all_output_check.csv')
  readr::write_csv(checks, out)
  missing <- checks |> dplyr::filter(!exists)
  if (nrow(missing)) {
    msg <- paste0('Methodology v2 run completed, but expected artifacts or validation tests are missing. See ', out, '. Missing: ', paste(missing$artifact, collapse = '; '))
    if (isTRUE(stop_on_missing)) stop(msg, call. = FALSE) else warning(msg, call. = FALSE)
  } else message('Output validation passed. Wrote: ', out)
  invisible(checks)
}

if (sys.nframe() == 0) validate_run_outputs(stop_on_missing = TRUE)
