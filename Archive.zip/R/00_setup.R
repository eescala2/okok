# 00_setup.R -----------------------------------------------------------------
# Package installation, project paths, and utility functions.

required_pkgs <- c(
  'tidyverse', 'data.table', 'readxl', 'janitor', 'httr2', 'jsonlite',
  'tidycensus', 'tigris', 'sf', 'quarto', 'rmarkdown', 'knitr', 'DT',
  'scales', 'glue', 'yaml', 'fs', 'stringr', 'Matrix', 'cli', 'ggrepel', 'png', 'digest'
)

# Packages used to create editable DrawingML figures inside Excel. These are
# installed/updated before any graphics packages are loaded because ragg and
# other graphics packages can load systemfonts. On Windows, an already-loaded
# systemfonts DLL cannot be replaced during the same R session.
editable_excel_pkgs <- c('systemfonts', 'gdtools', 'officer', 'rvg', 'openxlsx2')
editable_excel_min_versions <- c(
  systemfonts = '1.3.1',
  gdtools = '0.5.0',
  rvg = '0.4.1',
  openxlsx2 = '1.26.0'
)

# R 4.4/Puppy Cup compatibility note:
# Arrow and DuckDB are excellent high-performance storage/database packages,
# but they can be difficult to install on older R minor versions or locked-down
# Windows/Positron environments. They are now optional. If arrow is installed,
# the workflow writes Parquet just as before. If arrow is unavailable, the same
# atlas data are written/read as compressed RDS and CSV.GZ fallback files.
optional_storage_pkgs <- c('arrow', 'duckdb')

# Optional analysis packages are not required by the pipeline. Some helper
# packages are unavailable on certain R releases, so we do not install them
# automatically in run_all.R.
optional_pkgs <- c('grf', 'fixest', 'modelsummary', 'ragg', 'targets', optional_storage_pkgs)

# R 4.4.0 / Positron compatibility ---------------------------------------
# R 4.4.0 is the "Puppy Cup" release. The workflow is intentionally kept
# compatible with R >= 4.4.0 while preserving the same analysis, figures,
# HTML reports, and PDF outputs produced by the R 4.6.x run.
minimum_r_version <- package_version('4.4.0')

atlas_package_library <- function() {
  override <- Sys.getenv('IA_ATLAS_R_LIB', unset = '')
  if (nzchar(override)) return(normalizePath(path.expand(override), winslash = '/', mustWork = FALSE))

  r_tag <- paste0('R-', R.version[['major']], '.', strsplit(R.version[['minor']], '.', fixed = TRUE)[[1L]][1L])
  if (.Platform$OS.type == 'windows') {
    base <- Sys.getenv('LOCALAPPDATA', unset = '')
    if (!nzchar(base)) base <- file.path(path.expand('~'), 'AppData', 'Local')
    return(normalizePath(file.path(base, 'IowaAIWorkforceAtlas', 'library', r_tag), winslash = '/', mustWork = FALSE))
  }
  normalizePath(file.path(path.expand('~'), '.local', 'share', 'IowaAIWorkforceAtlas', 'library', r_tag), winslash = '/', mustWork = FALSE)
}

activate_atlas_package_library <- function() {
  lib <- atlas_package_library()
  dir.create(lib, recursive = TRUE, showWarnings = FALSE)
  .libPaths(unique(c(lib, .libPaths())))
  options(ia_atlas_package_library = lib)
  invisible(lib)
}

setup_repos <- function() {
  activate_atlas_package_library()
  # R 4.4 is no longer one of the two CRAN binary channels in 2026. Posit
  # Package Manager retains binaries for additional R releases, so use it
  # deterministically unless the user explicitly supplies IA_ATLAS_CRAN_REPO.
  repo <- trimws(Sys.getenv('IA_ATLAS_CRAN_REPO', unset = ''))
  if (!nzchar(repo)) repo <- 'https://packagemanager.posit.co/cran/latest'

  existing <- getOption('repos')
  other_names <- setdiff(names(existing), 'CRAN')
  other_repos <- if (length(other_names)) existing[other_names] else character()
  other_repos <- other_repos[
    !is.na(other_repos) & nzchar(other_repos) & other_repos != '@CRAN@'
  ]
  options(repos = c(CRAN = repo, other_repos))

  # libcurl is available in standard R builds on macOS/Windows and works
  # well inside Positron for BLS/Census/O*NET downloads.
  options(download.file.method = 'libcurl')
  options(tigris_use_cache = TRUE)

  # On Windows and macOS, prefer binary packages. This avoids Rtools/source
  # compilation failures for heavy packages in R 4.4.x environments.
  if (.Platform$OS.type == 'windows' || identical(Sys.info()[['sysname']], 'Darwin')) {
    options(pkgType = 'binary')
  }
  invisible(getOption('repos'))
}

check_r_compatibility <- function(strict = FALSE) {
  rv <- getRversion()
  codename <- R.version[['nickname']] %||% ''
  msg <- sprintf('Detected R %s%s.', as.character(rv), if (nzchar(codename)) paste0(' (', codename, ')') else '')
  if (!isTRUE(getOption('ia_atlas_r_version_reported', FALSE))) {
    message(msg)
    options(ia_atlas_r_version_reported = TRUE)
  }
  if (rv < minimum_r_version) {
    txt <- sprintf('This project targets R >= %s. Detected R %s. Upgrade R or use the current R 4.4.0 Puppy Cup compatibility package.',
                   as.character(minimum_r_version), as.character(rv))
    if (isTRUE(strict)) stop(txt, call. = FALSE) else warning(txt, call. = FALSE)
  }
  invisible(TRUE)
}

.install_one_package <- function(pkg, optional = FALSE) {
  msg <- if (optional) 'optional' else 'required'
  message(sprintf('Installing %s package: %s', msg, pkg))
  cores <- parallel::detectCores(logical = TRUE)
  if (is.na(cores) || cores < 2L) cores <- 2L
  ncpus <- max(1L, cores - 1L)

  install_attempt <- function(type) {
    tryCatch({
      utils::install.packages(
        pkg,
        lib = .libPaths()[1L],
        dependencies = c('Depends', 'Imports', 'LinkingTo'),
        quiet = TRUE,
        Ncpus = ncpus,
        type = type
      )
      # install.packages() can return after a warning without installing
      # anything. Require both a package in the target Atlas library and a
      # loadable namespace; an older copy in a lower-priority system library
      # must not masquerade as a successful repair.
      target_description <- file.path(.libPaths()[1L], pkg, 'DESCRIPTION')
      file.exists(target_description) && requireNamespace(pkg, quietly = TRUE)
    }, error = function(e) {
      warning(sprintf('Install failed for %s: %s', pkg, conditionMessage(e)), call. = FALSE)
      FALSE
    })
  }

  # First try the configured repository, normally Posit Package Manager, using
  # a binary on macOS/Windows so R 4.4 does not require a compiler toolchain.
  primary_type <- getOption('pkgType', 'binary')
  ok <- isTRUE(install_attempt(primary_type))

  # If the binary service is unavailable, make one explicit source attempt
  # against CRAN. This is a fallback only; Windows may require Rtools and macOS
  # may require the Xcode Command Line Tools for compiled packages.
  if (!ok) {
    old_repos <- getOption('repos')
    on.exit(options(repos = old_repos), add = TRUE)
    options(repos = c(CRAN = 'https://cloud.r-project.org'))
    fallback_type <- if (
      .Platform$OS.type == 'windows' || identical(Sys.info()[['sysname']], 'Darwin')
    ) 'source' else primary_type
    ok <- isTRUE(install_attempt(fallback_type))
  }

  if (!optional && !ok) {
    stop(
      'Required package failed to install or load namespace: ', pkg,
      '. Repository: ', getOption('repos')[['CRAN']],
      '; library: ', .libPaths()[1L],
      call. = FALSE
    )
  }
  invisible(ok)
}

installed_package_version <- function(pkg) {
  tryCatch(utils::packageVersion(pkg), error = function(e) package_version('0.0.0'))
}

package_version_is_current <- function(pkg, minimum = NULL) {
  installed <- pkg %in% rownames(utils::installed.packages())
  if (!installed) return(FALSE)
  if (is.null(minimum) || is.na(minimum) || !nzchar(as.character(minimum))) return(TRUE)
  isTRUE(installed_package_version(pkg) >= package_version(as.character(minimum)))
}

# IA_ATLAS_OPENXLSX2_R44_CAPABILITY_CONTRACT_BEGIN
atlas_openxlsx2_capability_check <- function(stop_on_error = TRUE) {
  fail <- function(message) {
    if (isTRUE(stop_on_error)) stop(message, call. = FALSE)
    warning(message, call. = FALSE)
    FALSE
  }

  if (!requireNamespace('openxlsx2', quietly = TRUE)) {
    return(fail('openxlsx2 is not installed or cannot load.'))
  }

  # Use the loaded namespace version because package files may have been updated
  # during the current session while an older namespace remains resident.
  version <- tryCatch(
    package_version(as.character(getNamespaceVersion('openxlsx2'))),
    error = function(e) package_version('0.0.0')
  )
  if (version < package_version('1.26.0')) {
    return(fail(paste0(
      'Editable Excel output requires openxlsx2 >= 1.26.0; found ',
      as.character(version), '. openxlsx2 1.24/1.25 can write DrawingML relationships while omitting rvg raster media. Run source("install_dependencies.R") in a fresh session, restart R, and rerun the smoke test.'
    )))
  }

  required_exports <- c('wb_workbook', 'wb_color', 'wb_dims')
  missing_exports <- required_exports[!vapply(required_exports, exists, logical(1), envir = asNamespace('openxlsx2'), inherits = FALSE)]
  if (length(missing_exports)) {
    return(fail(paste0(
      'The installed openxlsx2 ', as.character(version),
      ' lacks required exported APIs: ', paste(missing_exports, collapse = ', '), '.'
    )))
  }

  wb <- tryCatch(openxlsx2::wb_workbook(), error = function(e) e)
  if (inherits(wb, 'error')) {
    return(fail(paste0('openxlsx2::wb_workbook() failed: ', conditionMessage(wb))))
  }

  required_methods <- c(
    'add_worksheet', 'add_data', 'add_data_table', 'add_drawing',
    'add_font', 'add_fill', 'add_cell_style', 'merge_cells',
    'freeze_pane', 'set_col_widths', 'set_row_heights',
    'save', 'clone_worksheet'
  )
  missing_methods <- required_methods[!vapply(required_methods, function(nm) {
    is.function(tryCatch(wb[[nm]], error = function(e) NULL))
  }, logical(1))]
  if (length(missing_methods)) {
    return(fail(paste0(
      'The installed openxlsx2 ', as.character(version),
      ' lacks workbook methods required by the Atlas editable-Excel generator: ',
      paste(missing_methods, collapse = ', '), '.'
    )))
  }

  invisible(TRUE)
}
# IA_ATLAS_OPENXLSX2_R44_CAPABILITY_CONTRACT_END


# IA_ATLAS_XLSX_MEDIA_INTEGRITY_R6_BEGIN
# openxlsx2 1.24/1.25 contained a raster-registration regression affecting
# images emitted by rvg::dml_xlsx(). Save through the bound R6 method (not the
# cloning wrapper), validate the temporary OOXML package, and only then replace
# the public output. This leaves an existing valid workbook untouched when a
# new build fails.
atlas_xlsx_normalize_package_path <- function(path) {
  parts <- strsplit(gsub("\\\\", "/", path), "/", fixed = TRUE)[[1L]]
  output <- character()
  for (part in parts) {
    if (!nzchar(part) || identical(part, ".")) next
    if (identical(part, "..")) {
      if (length(output)) output <- output[-length(output)]
    } else {
      output <- c(output, part)
    }
  }
  paste(output, collapse = "/")
}

atlas_xlsx_package_integrity <- function(path, minimum_drawings = 0L) {
  minimum_drawings <- suppressWarnings(as.integer(minimum_drawings))
  if (!length(minimum_drawings) || !is.finite(minimum_drawings[[1L]]) || minimum_drawings[[1L]] < 0L) {
    minimum_drawings <- 0L
  } else {
    minimum_drawings <- minimum_drawings[[1L]]
  }
  empty_result <- function(exists, valid_zip, detail) {
    data.frame(
      workbook = path,
      exists = isTRUE(exists),
      valid_zip = isTRUE(valid_zip),
      drawing_count = NA_integer_,
      media_count = NA_integer_,
      minimum_drawings = minimum_drawings,
      missing_targets = NA_integer_,
      passed = FALSE,
      detail = detail,
      stringsAsFactors = FALSE
    )
  }
  if (!file.exists(path)) return(empty_result(FALSE, FALSE, "workbook not found"))
  listing <- tryCatch(utils::unzip(path, list = TRUE), error = function(e) NULL)
  if (is.null(listing)) return(empty_result(TRUE, FALSE, "not a readable ZIP/XLSX package"))
  files <- gsub("\\\\", "/", listing$Name)
  drawing_count <- sum(grepl("^xl/drawings/drawing[0-9]+[.]xml$", files, perl = TRUE))
  media_count <- sum(grepl("^xl/media/[^/]+$", files, perl = TRUE))
  rel_files <- files[grepl("(^|/)_rels/.*[.]rels$", files, perl = TRUE)]

  if (!requireNamespace("xml2", quietly = TRUE)) {
    return(empty_result(TRUE, TRUE, "xml2 is required for relationship validation"))
  }
  tmp <- tempfile("atlas_xlsx_validate_")
  dir.create(tmp, recursive = TRUE, showWarnings = FALSE)
  on.exit(unlink(tmp, recursive = TRUE, force = TRUE), add = TRUE)
  if (length(rel_files)) utils::unzip(path, files = rel_files, exdir = tmp)

  missing <- character()
  for (rel in rel_files) {
    rel_path <- file.path(tmp, rel)
    rel_xml <- tryCatch(xml2::read_xml(rel_path), error = function(e) NULL)
    if (is.null(rel_xml)) {
      missing <- c(missing, paste0(rel, " -> unreadable relationships XML"))
      next
    }
    nodes <- xml2::xml_find_all(rel_xml, "//*[local-name()='Relationship']")
    if (!length(nodes)) next
    targets <- xml2::xml_attr(nodes, "Target")
    modes <- xml2::xml_attr(nodes, "TargetMode")
    internal <- is.na(modes) | tolower(modes) != "external"
    targets <- unique(targets[internal & !is.na(targets) & nzchar(targets)])
    base <- if (identical(rel, "_rels/.rels")) {
      ""
    } else {
      sub("/_rels/[^/]+[.]rels$", "", rel, perl = TRUE)
    }
    for (target in targets) {
      if (grepl("^#", target)) next
      candidate <- if (grepl("^/", target)) {
        sub("^/+", "", target)
      } else {
        atlas_xlsx_normalize_package_path(paste(base, target, sep = "/"))
      }
      if (!candidate %in% files) missing <- c(missing, paste0(rel, " -> ", target))
    }
  }
  missing <- unique(missing)
  passed <- length(missing) == 0L && drawing_count >= minimum_drawings
  detail <- paste(
    c(
      if (length(missing)) {
        paste("missing relationship targets:", paste(missing, collapse = " | "))
      } else {
        "all relationship targets present"
      },
      paste0("drawings=", drawing_count, "; required>=", minimum_drawings),
      paste0("media=", media_count)
    ),
    collapse = "; "
  )
  data.frame(
    workbook = path,
    exists = TRUE,
    valid_zip = TRUE,
    drawing_count = drawing_count,
    media_count = media_count,
    minimum_drawings = minimum_drawings,
    missing_targets = length(missing),
    passed = passed,
    detail = detail,
    stringsAsFactors = FALSE
  )
}

atlas_promote_validated_file <- function(staged, output) {
  output <- normalizePath(output, winslash = "/", mustWork = FALSE)
  dir.create(dirname(output), recursive = TRUE, showWarnings = FALSE)
  backup <- paste0(output, ".atlas-r6-backup")
  unlink(backup, force = TRUE)
  had_output <- file.exists(output)

  if (had_output && !file.rename(output, backup)) {
    stop(
      "Could not protect the existing workbook before replacement. Close it in Excel and retry: ",
      output,
      call. = FALSE
    )
  }

  promoted <- file.rename(staged, output)
  if (!promoted) {
    promoted <- file.copy(
      staged,
      output,
      overwrite = TRUE,
      copy.mode = TRUE,
      copy.date = TRUE
    )
    if (promoted) unlink(staged, force = TRUE)
  }

  if (!isTRUE(promoted) || !file.exists(output)) {
    unlink(output, force = TRUE)
    if (had_output && file.exists(backup)) file.rename(backup, output)
    stop("Could not move the validated workbook into place: ", output, call. = FALSE)
  }

  # Keep the backup until the caller has validated the promoted package. This
  # makes publication transactional even if a filesystem copy is truncated.
  invisible(list(
    output = output,
    backup = backup,
    had_output = had_output
  ))
}

atlas_restore_promoted_file <- function(promotion) {
  if (is.null(promotion) || !is.list(promotion)) return(invisible(FALSE))
  output <- promotion$output %||% ""
  backup <- promotion$backup %||% ""
  had_output <- isTRUE(promotion$had_output)
  if (nzchar(output)) unlink(output, force = TRUE)
  restored <- FALSE
  if (had_output && nzchar(backup) && file.exists(backup)) {
    restored <- isTRUE(file.rename(backup, output))
  }
  invisible(restored)
}

atlas_finish_promoted_file <- function(promotion) {
  if (is.null(promotion) || !is.list(promotion)) return(invisible(FALSE))
  backup <- promotion$backup %||% ""
  if (nzchar(backup)) unlink(backup, force = TRUE)
  invisible(TRUE)
}

atlas_save_workbook_validated <- function(
    workbook,
    output_file,
    minimum_drawings = 0L,
    label = "Editable Excel workbook") {
  atlas_openxlsx2_capability_check(stop_on_error = TRUE)
  save_method <- tryCatch(workbook$save, error = function(e) NULL)
  if (!is.function(save_method)) {
    stop("The openxlsx2 workbook does not expose a bound $save() method.", call. = FALSE)
  }

  output_file <- normalizePath(output_file, winslash = "/", mustWork = FALSE)
  dir.create(dirname(output_file), recursive = TRUE, showWarnings = FALSE)
  staged <- tempfile(
    pattern = paste0(".", gsub("[^A-Za-z0-9._-]", "_", basename(output_file)), "."),
    tmpdir = dirname(output_file),
    fileext = ".xlsx"
  )
  on.exit(unlink(staged, force = TRUE), add = TRUE)

  message("  ", label, ": direct-saving a temporary XLSX package.")
  save_method(file = staged, overwrite = TRUE, flush = FALSE)

  check <- atlas_xlsx_package_integrity(
    staged,
    minimum_drawings = minimum_drawings
  )
  if (!isTRUE(check$passed[[1L]])) {
    stop(
      label, " failed pre-publication XLSX validation: ", check$detail[[1L]],
      ". The previous public workbook, if any, was not replaced.",
      call. = FALSE
    )
  }

  promotion <- atlas_promote_validated_file(staged, output_file)
  committed <- FALSE
  on.exit({
    if (!committed) atlas_restore_promoted_file(promotion)
  }, add = TRUE)

  final_check <- atlas_xlsx_package_integrity(
    output_file,
    minimum_drawings = minimum_drawings
  )
  if (!isTRUE(final_check$passed[[1L]])) {
    stop(
      label, " failed validation after file promotion: ",
      final_check$detail[[1L]],
      ". The previous workbook has been restored when one existed.",
      call. = FALSE
    )
  }

  atlas_finish_promoted_file(promotion)
  committed <- TRUE
  message(
    "  ", label, ": validated ", final_check$drawing_count[[1L]],
    " DrawingML part(s), ", final_check$media_count[[1L]],
    " media part(s), and zero missing relationship target(s)."
  )
  invisible(output_file)
}

# IA_ATLAS_XLSX_MEDIA_INTEGRITY_R6_END

ensure_editable_excel_toolchain <- function(install_missing = TRUE) {
  setup_repos()

  # If an old systemfonts namespace is already loaded, R cannot swap the DLL in
  # place. A clean session is the only reliable remedy. In a normal run_all.R
  # invocation this check occurs before ragg/ggtext/other graphics packages load.
  if ('systemfonts' %in% loadedNamespaces()) {
    loaded_version <- tryCatch(package_version(getNamespaceVersion('systemfonts')), error = function(e) package_version('0.0.0'))
    if (loaded_version < package_version(editable_excel_min_versions[['systemfonts']])) {
      stop(
        'An older systemfonts namespace (', as.character(loaded_version), ') is already loaded. ',
        'Restart the R session, then run source("R/run_all.R") once. The project now installs the editable-Excel toolchain before graphics packages load.',
        call. = FALSE
      )
    }
  }

  if ('openxlsx2' %in% loadedNamespaces()) {
    loaded_version <- tryCatch(
      package_version(as.character(getNamespaceVersion('openxlsx2'))),
      error = function(e) package_version('0.0.0')
    )
    if (loaded_version < package_version(editable_excel_min_versions[['openxlsx2']])) {
      stop(
        'An older openxlsx2 namespace (', as.character(loaded_version), ') is already loaded. ',
        'Restart R before running install_dependencies.R so the 1.26+ raster-media repair can be installed and loaded cleanly.',
        call. = FALSE
      )
    }
  }

  for (pkg in editable_excel_pkgs) {
    minimum <- unname(editable_excel_min_versions[pkg])
    if (!length(minimum) || is.na(minimum)) minimum <- NULL
    version_current <- package_version_is_current(pkg, minimum)
    # Do not load an outdated systemfonts DLL merely to test it. Only probe the
    # namespace after the installed version meets the declared minimum.
    namespace_ready <- version_current && requireNamespace(pkg, quietly = TRUE)
    needs_install <- !version_current || !namespace_ready
    if (needs_install && isTRUE(install_missing)) {
      .install_one_package(pkg, optional = FALSE)
    }
    version_current <- package_version_is_current(pkg, minimum)
    namespace_ready <- version_current && requireNamespace(pkg, quietly = TRUE)
    if (!version_current || !namespace_ready) {
      found <- as.character(installed_package_version(pkg))
      requirement <- if (is.null(minimum) || is.na(minimum)) '' else paste0(' >= ', minimum)
      stop(
        'Editable Excel dependency is unavailable, unloadable, or too old: ', pkg, requirement,
        ' (found ', found, '). Restart R and rerun; packages are installed to ',
        getOption('ia_atlas_package_library', .libPaths()[1L]), '.',
        call. = FALSE
      )
    }
  }
  # IA_ATLAS_OPENXLSX2_R44_ENSURE_CALL
  atlas_openxlsx2_capability_check(stop_on_error = TRUE)
  invisible(TRUE)
}

install_if_missing <- function(pkgs = required_pkgs, optional = FALSE) {
  setup_repos()
  # A package listed by installed.packages() can still be unloadable after an R
  # upgrade or an interrupted binary install. Namespace readiness is the useful
  # criterion for the runner.
  missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
  if (!length(missing)) return(invisible(TRUE))
  for (pkg in missing) .install_one_package(pkg, optional = optional)
  invisible(TRUE)
}

setup_packages <- function(install_optional = TRUE, strict_r = FALSE) {
  setup_repos()
  check_r_compatibility(strict = strict_r)

  # Install/update the Excel DrawingML stack before any graphics namespace can
  # lock an older systemfonts DLL on Windows/Positron.
  ensure_editable_excel_toolchain(install_missing = TRUE)
  install_if_missing(required_pkgs, optional = FALSE)

  failed <- character()
  for (pkg in required_pkgs) {
    ok <- suppressWarnings(suppressPackageStartupMessages(require(pkg, character.only = TRUE)))
    if (!ok) failed <- c(failed, pkg)
  }
  if (length(failed)) stop('Required packages could not be loaded: ', paste(failed, collapse = ', '), call. = FALSE)

  if (install_optional) install_if_missing(optional_pkgs, optional = TRUE)
  invisible(TRUE)
}

project_root <- function() {
  # Works from project root, R/ scripts, or a rendered document.
  here <- getwd()
  candidates <- c(here, dirname(here), normalizePath(file.path(here, '..'), mustWork = FALSE))
  for (cand in unique(candidates)) {
    if (file.exists(file.path(cand, 'config.yml')) && dir.exists(file.path(cand, 'R'))) {
      return(normalizePath(cand, winslash = '/', mustWork = TRUE))
    }
  }
  normalizePath(here, winslash = '/', mustWork = TRUE)
}

paths <- function() {
  root <- project_root()
  x <- list(
    root = root,
    R = file.path(root, 'R'),
    inputs = file.path(root, 'inputs'),
    raw = file.path(root, 'data_raw'),
    processed = file.path(root, 'data_processed'),
    outputs = file.path(root, 'outputs'),
    figures = file.path(root, 'figures'),
    logs = file.path(root, 'logs')
  )
  invisible(lapply(x, fs::dir_create))
  x
}

load_config <- function() {
  p <- paths()
  cfg_path <- file.path(p$root, 'config.yml')
  if (!file.exists(cfg_path)) stop('Missing config.yml at project root.', call. = FALSE)
  yaml::read_yaml(cfg_path)
}

clean_soc <- function(x) {
  x <- as.character(x)
  x <- stringr::str_trim(x)
  x <- stringr::str_replace_all(x, '\\.', '-')
  x <- stringr::str_replace(x, '\\-00$', '')
  x <- stringr::str_replace(x, '\\.[0-9]+$', '')
  # Convert 111011 or 11-1011.00 to 11-1011.
  x <- dplyr::case_when(
    stringr::str_detect(x, '^\\d{6}$') ~ paste0(substr(x, 1, 2), '-', substr(x, 3, 6)),
    stringr::str_detect(x, '^\\d{2}-\\d{4}') ~ stringr::str_extract(x, '^\\d{2}-\\d{4}'),
    TRUE ~ x
  )
  x
}

clean_fips <- function(x, width = 5) {
  stringr::str_pad(as.character(x), width = width, pad = '0')
}

rescale01 <- function(x) {
  x <- suppressWarnings(as.numeric(x))
  if (all(is.na(x))) return(rep(NA_real_, length(x)))
  rng <- range(x, na.rm = TRUE)
  if (!is.finite(rng[1]) || !is.finite(rng[2]) || abs(diff(rng)) < .Machine$double.eps) {
    return(rep(0.5, length(x)))
  }
  (x - rng[1]) / diff(rng)
}

winsor <- function(x, probs = c(0.01, 0.99)) {
  qs <- stats::quantile(x, probs = probs, na.rm = TRUE, names = FALSE)
  pmin(pmax(x, qs[1]), qs[2])
}

atlas_user_agent <- function() {
  ua <- Sys.getenv('IA_ATLAS_USER_AGENT')
  if (!nzchar(ua)) {
    ua <- 'iowa-ai-workforce-atlas/1.2 research-script https://www.bls.gov/oes/'
  }
  ua
}

is_probably_html_error <- function(path) {
  if (!file.exists(path) || file.info(path)$size == 0) return(TRUE)
  ext <- tolower(tools::file_ext(path))
  if (ext %in% c('html', 'htm')) return(TRUE)
  bytes <- tryCatch(readBin(path, what = 'raw', n = min(512, file.info(path)$size)), error = function(e) raw())
  if (!length(bytes)) return(TRUE)
  txt <- tryCatch(tolower(rawToChar(bytes, multiple = FALSE)), error = function(e) '')
  grepl('<html|forbidden|access denied|not found|request blocked', txt)
}


`%||%` <- function(x, y) {
  if (is.null(x) || length(x) == 0 || all(is.na(x))) y else x
}

download_if_needed <- function(url, dest, refresh = FALSE, mode = 'wb') {
  fs::dir_create(dirname(dest))
  if (file.exists(dest) && !refresh && file.info(dest)$size > 0 && !is_probably_html_error(dest)) return(dest)
  if (file.exists(dest)) unlink(dest)

  message('Downloading: ', url)
  ok <- FALSE
  last_error <- NULL

  # BLS occasionally rejects the default R downloader.  httr2 with an explicit
  # user agent and browser-like Accept headers is more reliable and also works
  # for Census/LEHD text files.
  if (requireNamespace('httr2', quietly = TRUE)) {
    ok <- tryCatch({
      req <- httr2::request(url) |>
        httr2::req_user_agent(atlas_user_agent()) |>
        httr2::req_headers(
          Accept = 'text/html,application/xhtml+xml,application/xml;q=0.9,application/zip,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/plain,*/*;q=0.8',
          `Accept-Language` = 'en-US,en;q=0.9'
        ) |>
        httr2::req_timeout(600) |>
        httr2::req_retry(max_tries = 3)
      httr2::req_perform(req, path = dest)
      TRUE
    }, error = function(e) {
      last_error <<- conditionMessage(e)
      FALSE
    })
  }

  if (!ok) {
    ok <- tryCatch({
      extra <- paste0('-A "', atlas_user_agent(), '"')
      utils::download.file(url, destfile = dest, mode = mode, quiet = TRUE,
                           method = 'libcurl', extra = extra)
      TRUE
    }, error = function(e) {
      last_error <<- conditionMessage(e)
      FALSE
    })
  }

  if (!ok || !file.exists(dest) || file.info(dest)$size == 0 || is_probably_html_error(dest)) {
    if (file.exists(dest)) unlink(dest)
    msg <- if (nzchar(last_error %||% '')) paste0(': ', last_error) else ''
    stop('Could not download ', url, msg, call. = FALSE)
  }
  dest
}

try_download <- function(urls, dest_dir, refresh = FALSE) {
  fs::dir_create(dest_dir)
  last_error <- NULL
  for (u in urls) {
    dest <- file.path(dest_dir, basename(u))
    ans <- tryCatch(download_if_needed(u, dest, refresh = refresh), error = function(e) {
      last_error <<- conditionMessage(e)
      NULL
    })
    if (!is.null(ans)) return(ans)
  }
  stop('All download attempts failed. Last error: ', last_error, call. = FALSE)
}

read_delim_auto <- function(path) {
  data.table::fread(path, data.table = FALSE, showProgress = FALSE) |>
    janitor::clean_names()
}

normalize_names <- function(x) janitor::make_clean_names(names(x))

first_existing <- function(...) {
  vals <- unlist(list(...), use.names = FALSE)
  vals[file.exists(vals)][1]
}

write_log <- function(text, file = 'run.log') {
  p <- paths()
  cat(format(Sys.time()), ' - ', text, '\n', file = file.path(p$logs, file), append = TRUE)
}

compat_table_paths <- function(base_name, dir = NULL) {
  if (is.null(dir)) dir <- paths()$processed
  list(
    parquet = file.path(dir, paste0(base_name, '.parquet')),
    rds = file.path(dir, paste0(base_name, '.rds')),
    csv_gz = file.path(dir, paste0(base_name, '.csv.gz')),
    csv = file.path(dir, paste0(base_name, '.csv'))
  )
}

compat_table_exists <- function(base_name, dir = NULL) {
  pp <- compat_table_paths(base_name, dir)
  any(vapply(pp, file.exists, logical(1)))
}

write_compat_table <- function(x, base_name, dir = NULL, write_csv_gz = TRUE, write_parquet = TRUE) {
  if (is.null(dir)) dir <- paths()$processed
  fs::dir_create(dir)
  pp <- compat_table_paths(base_name, dir)

  # Always write an RDS copy. This is base R, fast, and preserves column types.
  saveRDS(x, pp$rds, compress = 'xz')

  # Always write a CSV.GZ copy for transparency and users without arrow.
  if (isTRUE(write_csv_gz)) {
    readr::write_csv(x, pp$csv_gz)
  }

  parquet_status <- 'not attempted'
  if (isTRUE(write_parquet) && requireNamespace('arrow', quietly = TRUE)) {
    parquet_status <- tryCatch({
      arrow::write_parquet(x, pp$parquet)
      'written'
    }, error = function(e) {
      warning('Arrow is installed but Parquet write failed for ', base_name, ': ', conditionMessage(e),
              '. RDS/CSV.GZ fallbacks were written.', call. = FALSE)
      if (file.exists(pp$parquet)) unlink(pp$parquet)
      'failed'
    })
  } else if (isTRUE(write_parquet)) {
    parquet_status <- 'skipped: arrow not installed'
    if (file.exists(pp$parquet)) unlink(pp$parquet)
  }

  invisible(c(pp, list(parquet_status = parquet_status)))
}

read_compat_table <- function(base_name, dir = NULL) {
  if (is.null(dir)) dir <- paths()$processed
  pp <- compat_table_paths(base_name, dir)
  if (file.exists(pp$parquet) && requireNamespace('arrow', quietly = TRUE)) {
    return(arrow::read_parquet(pp$parquet) |> dplyr::as_tibble())
  }
  if (file.exists(pp$rds)) {
    return(readRDS(pp$rds) |> dplyr::as_tibble())
  }
  if (file.exists(pp$csv_gz)) {
    return(readr::read_csv(pp$csv_gz, show_col_types = FALSE))
  }
  if (file.exists(pp$csv)) {
    return(readr::read_csv(pp$csv, show_col_types = FALSE))
  }
  stop('Could not find ', base_name, ' in Parquet, RDS, CSV.GZ, or CSV form under ', dir, call. = FALSE)
}

# Backward-compatible helper used by older scripts. It now reads the best
# available compatible storage format instead of requiring arrow.
safe_read_parquet <- function(path) {
  if (is.null(path) || !nzchar(path)) return(NULL)
  base_name <- tools::file_path_sans_ext(basename(path))
  dir <- dirname(path)
  if (!compat_table_exists(base_name, dir)) return(NULL)
  read_compat_table(base_name, dir)
}
