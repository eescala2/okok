# Methodology v3 provenance, evidence-gap register, model card, and snapshots
# Version 3.0.3: cross-platform path contracts avoid regular-expression
# escaping, including project paths that contain braces or other metacharacters.

v3_safe_row_count <- function(path) {
  if (!file.exists(path)) return(NA_real_)
  ext <- tolower(tools::file_ext(path))
  out <- tryCatch({
    if (ext %in% c("csv", "gz")) {
      nrow(readr::read_csv(path, show_col_types = FALSE, progress = FALSE))
    } else if (ext == "rds") {
      object <- readRDS(path)
      if (is.data.frame(object) || is.matrix(object) || inherits(object, "ArrowTabular")) nrow(object) else NA_real_
    } else if (ext == "parquet" && requireNamespace("arrow", quietly = TRUE)) {
      nrow(arrow::read_parquet(path, as_data_frame = FALSE))
    } else {
      NA_real_
    }
  }, error = function(e) NA_real_)
  if (length(out) != 1L) return(NA_real_)
  as.numeric(out[[1]])
}

# Return paths relative to a base directory without constructing a regular
# expression from the path. This is deliberately string-based: valid project
# folders can contain regex metacharacters such as {}, [], +, (, or ).
v3_relative_path <- function(path, base) {
  if (!length(path)) return(character())
  if (length(base) != 1L || is.na(base) || !nzchar(base)) {
    stop("v3_relative_path() requires one non-missing base directory.", call. = FALSE)
  }

  path_norm <- normalizePath(path, winslash = "/", mustWork = FALSE)
  base_norm <- normalizePath(base, winslash = "/", mustWork = FALSE)
  base_norm <- sub("/+$", "", base_norm)

  path_compare <- path_norm
  base_compare <- base_norm
  if (.Platform$OS.type == "windows") {
    path_compare <- tolower(path_compare)
    base_compare <- tolower(base_compare)
  }

  prefix_compare <- paste0(base_compare, "/")
  inside <- startsWith(path_compare, prefix_compare)
  exact <- path_compare == base_compare

  out <- path_norm
  if (any(inside)) {
    out[inside] <- substring(path_norm[inside], nchar(base_norm) + 2L)
  }
  out[exact] <- "."
  out
}

v3_empty_dataset_inventory <- function() {
  tibble::tibble(
    file = character(),
    relative_file = character(),
    extension = character(),
    bytes = numeric(),
    modified_utc = character(),
    row_count = numeric(),
    sha256_or_md5 = character()
  )
}

v3_dataset_inventory <- function(paths = v3_paths()) {
  roots <- c(paths$raw, paths$processed, paths$inputs, paths$config)
  files <- unique(unlist(lapply(roots[dir.exists(roots)], function(d) {
    list.files(d, recursive = TRUE, full.names = TRUE, all.files = FALSE)
  })))
  files <- files[file.exists(files) & !dir.exists(files)]
  if (!length(files)) return(v3_empty_dataset_inventory())

  normalized_files <- normalizePath(files, winslash = "/", mustWork = FALSE)
  info <- file.info(files)

  tibble::tibble(
    file = normalized_files,
    relative_file = v3_relative_path(normalized_files, paths$root),
    extension = tolower(tools::file_ext(files)),
    bytes = as.numeric(info$size),
    modified_utc = format(info$mtime, tz = "UTC", usetz = TRUE),
    row_count = vapply(files, v3_safe_row_count, numeric(1)),
    sha256_or_md5 = vapply(files, v3_hash_file, character(1))
  )
}

v3_package_versions <- function() {
  pkgs <- unique(c(v3_required_packages(), v3_optional_packages()))
  tibble::tibble(
    package = pkgs,
    installed = vapply(pkgs, requireNamespace, logical(1), quietly = TRUE),
    version = vapply(pkgs, function(p) {
      if (!requireNamespace(p, quietly = TRUE)) return(NA_character_)
      as.character(utils::packageVersion(p))
    }, character(1))
  )
}

v3_model_card <- function(paths = v3_paths()) {
  cfg <- v3_load_config(paths$root)
  tibble::tribble(
    ~field, ~value,
    "model_name", "Iowa AI Workforce Atlas Methodology v3 evidence system",
    "version", as.character(cfg$methodology_version %||% "3.0.3"),
    "governing_principle", as.character(cfg$principle),
    "intended_use", "State, regional, county, sector, employer, and training-planning evidence; pilot and scenario governance",
    "not_intended_use", "Layoff forecast, official county-SOC employment count, automated eligibility decision, or causal claim absent a valid design",
    "base_unit", "Synthetic county x industry x occupation allocation inherited from Methodology v2",
    "adoption_measure", "Observed BTOS and optional Iowa employer pulse; never inferred from technical exposure",
    "worker_outcome_measure", "Good output divided by active plus review, correction, and rework time, with quality and job-quality safeguards",
    "early_career_measure", "QWI age-specific industry dynamics plus a separately labeled occupation-industry planning layer",
    "transition_rule", "O*NET similarity is necessary but insufficient; credentials, training, openings, wages, access, physical demands, and employer validation constrain publication",
    "industrial_rule", "Readiness is observed separately from exposure; productivity is a J-curve scenario",
    "pilot_rule", "Preregistered comparisons and predetermined scale/redesign/suspend/stop rules with ARIA-style assurance",
    "value_capture_rule", "Value added is the non-overlapping headline measure; wages, supplier purchases, worker gains, taxes, and leakage are reported separately",
    "missing_data_rule", "Unavailable evidence remains unavailable or provisional; it is not silently imputed from exposure",
    "uncertainty_rule", "Each module reports evidence status and reliability; scenarios report explicit ranges and assumptions"
  )
}

v3_evidence_gap_register <- function(results, paths = v3_paths()) {
  status <- if (exists("v3_methodology_v3_extension_status", mode = "function")) {
    v3_methodology_v3_extension_status(results)
  } else {
    dplyr::bind_rows(lapply(results, function(x) {
      if (is.list(x) && "status" %in% names(x) && is.data.frame(x$status)) x$status else tibble::tibble()
    }))
  }
  if (!nrow(status)) return(tibble::tibble())
  status |>
    dplyr::mutate(
      gap = evidence_status %in% c("UNAVAILABLE", "PROVISIONAL"),
      required_action = dplyr::case_when(
        evidence_status == "UNAVAILABLE" ~ "Collect or connect the required public/local source before making a substantive claim",
        evidence_status == "PROVISIONAL" ~ "Complete local validation, constraints, or comparison evidence before publication",
        evidence_status == "SCENARIO" ~ "Publish assumptions and sensitivity range; do not describe as observed",
        evidence_status == "BENCHMARKED" ~ "Publish calibration basis and reliability class",
        TRUE ~ "Maintain source, sample, uncertainty, and validation metadata"
      )
    )
}

v3_empty_raw_snapshot_manifest <- function() {
  tibble::tibble(
    build_id = character(),
    snapshot_mode = character(),
    source_file = character(),
    snapshot_file = character(),
    copied = logical(),
    bytes = numeric(),
    sha256_or_md5 = character()
  )
}

v3_snapshot_raw_files <- function(paths = v3_paths(), build_id = v3_build_id(paths$root)) {
  mode <- tolower(trimws(Sys.getenv("IA_ATLAS_V3_SNAPSHOT_RAW", unset = "manifest")))
  raw_files <- if (dir.exists(paths$raw)) list.files(paths$raw, recursive = TRUE, full.names = TRUE) else character()
  raw_files <- raw_files[file.exists(raw_files) & !dir.exists(raw_files)]
  if (!length(raw_files)) return(v3_empty_raw_snapshot_manifest())

  snap_dir <- file.path(paths$snapshots, build_id)
  dir.create(snap_dir, recursive = TRUE, showWarnings = FALSE)
  copied <- rep(FALSE, length(raw_files))
  destination <- rep(NA_character_, length(raw_files))

  if (mode %in% c("copy", "hardlink")) {
    for (i in seq_along(raw_files)) {
      rel <- v3_relative_path(raw_files[[i]], paths$raw)
      dest <- file.path(snap_dir, rel)
      dir.create(dirname(dest), recursive = TRUE, showWarnings = FALSE)
      ok <- FALSE
      if (mode == "hardlink") ok <- isTRUE(file.link(raw_files[[i]], dest))
      if (!ok) ok <- isTRUE(file.copy(raw_files[[i]], dest, overwrite = TRUE, copy.date = TRUE))
      copied[[i]] <- ok
      destination[[i]] <- if (ok) normalizePath(dest, winslash = "/", mustWork = FALSE) else NA_character_
    }
  }

  tibble::tibble(
    build_id = build_id,
    snapshot_mode = mode,
    source_file = normalizePath(raw_files, winslash = "/", mustWork = FALSE),
    snapshot_file = destination,
    copied = copied,
    bytes = as.numeric(file.info(raw_files)$size),
    sha256_or_md5 = vapply(raw_files, v3_hash_file, character(1))
  )
}

write_methodology_v3_provenance <- function(run, paths = v3_paths()) {
  build_id <- run$build_id %||% v3_build_id(paths$root)
  cfg <- v3_load_config(paths$root)
  registry <- v3_source_registry(paths$root)
  inventory <- v3_dataset_inventory(paths)
  packages <- v3_package_versions()
  model_card <- v3_model_card(paths)
  gaps <- v3_evidence_gap_register(run$results, paths)
  snapshots <- v3_snapshot_raw_files(paths, build_id)
  source_status <- v3_read_csv(file.path(paths$outputs, "public_data_status_v3.csv"))
  v3_write_csv(registry, file.path(paths$outputs, "source_registry_v3.csv"))
  v3_write_csv(source_status, file.path(paths$outputs, "source_availability_status_v3.csv"))
  v3_write_csv(inventory, file.path(paths$outputs, "dataset_inventory_v3.csv"))
  v3_write_csv(packages, file.path(paths$outputs, "package_versions_v3.csv"))
  v3_write_csv(model_card, file.path(paths$outputs, "model_card_v3.csv"))
  v3_write_csv(gaps, file.path(paths$outputs, "evidence_gap_register_v3.csv"))
  v3_write_csv(snapshots, file.path(paths$outputs, "raw_snapshot_manifest_v3.csv"))
  changelog <- tibble::tibble(
    version = as.character(cfg$methodology_version %||% "3.0.3"),
    build_id = build_id,
    built_at_utc = format(Sys.time(), tz = "UTC", usetz = TRUE),
    change = c(
      "Separated exposure, adoption, productivity, worker outcomes, and value capture",
      "Added observed BTOS and Iowa employer-pulse nowcasting",
      "Added quality-adjusted worker task outcomes and job-quality safeguards",
      "Added early-career QWI and apprenticeship pipeline evidence",
      "Constrained O*NET pathways by credentials, training, openings, wages, access, physical demands, and employer validation",
      "Added industrial readiness and productivity J-curve scenarios",
      "Added preregistered pilots, ARIA-style assurance, and predetermined decisions",
      "Added BEA-based regional value-capture scenarios with non-overlapping headline value added",
      "Hardened provenance and snapshot path handling without regex-derived path expressions"
    )
  )
  v3_write_csv(changelog, file.path(paths$outputs, "changelog_v3.csv"))
  list(registry = registry, inventory = inventory, packages = packages, model_card = model_card, gaps = gaps, snapshots = snapshots, changelog = changelog)
}
