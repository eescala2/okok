# Iowa AI Workforce Atlas one-click release: editable Excel
# Version 3.1.2

`%||%` <- function(x, y) {
  if (is.null(x) || !length(x) || (length(x) == 1L && is.na(x))) y else x
}

atlas_v312_excel_sheet_names <- function(workbook) {
  if (requireNamespace("openxlsx2", quietly = TRUE)) {
    exported <- getNamespaceExports("openxlsx2")
    if ("wb_get_sheet_names" %in% exported) {
      return(openxlsx2::wb_get_sheet_names(workbook))
    }
  }

  if (!is.null(workbook$sheet_names)) {
    return(as.character(workbook$sheet_names))
  }

  if (!is.null(workbook$worksheets)) {
    candidate <- names(workbook$worksheets)
    if (length(candidate)) return(candidate)
  }

  character()
}

atlas_v312_wb_add_worksheet <- function(workbook, sheet) {
  method <- tryCatch(workbook$add_worksheet, error = function(e) NULL)
  if (!is.function(method)) stop("Workbook add_worksheet() method is unavailable.", call. = FALSE)
  method(sheet)
  workbook
}

atlas_v312_wb_add_data <- function(
    workbook,
    sheet,
    data,
    start_col = 1,
    start_row = 1) {
  method <- tryCatch(workbook$add_data, error = function(e) NULL)
  if (!is.function(method)) stop("Workbook add_data() method is unavailable.", call. = FALSE)
  method(sheet = sheet, x = data, start_col = start_col, start_row = start_row)
  workbook
}

atlas_v312_wb_add_drawing <- function(
    workbook,
    sheet,
    xml,
    dims = "A3:P35") {
  method <- tryCatch(workbook$add_drawing, error = function(e) NULL)
  if (!is.function(method)) stop("Workbook add_drawing() method is unavailable.", call. = FALSE)
  method(sheet = sheet, xml = xml, dims = dims)
  workbook
}

atlas_v312_wb_save <- function(
    workbook,
    path,
    minimum_drawings = 0L,
    label = "Editable Excel workbook") {
  atlas_save_workbook_validated(
    workbook,
    path,
    minimum_drawings = minimum_drawings,
    label = label
  )
}

atlas_v312_add_article_plot_sheets <- function(
    workbook_file,
    plots,
    prefix = "Article") {

  if (!file.exists(workbook_file)) {
    stop("Editable Excel workbook does not exist: ", workbook_file, call. = FALSE)
  }
  if (!requireNamespace("openxlsx2", quietly = TRUE)) {
    stop("openxlsx2 is required.", call. = FALSE)
  }
  if (!requireNamespace("rvg", quietly = TRUE)) {
    stop("rvg is required.", call. = FALSE)
  }

  prior_drawings <- atlas_v312_count_drawings(workbook_file)
  replaced_drawings <- 0L
  workbook <- openxlsx2::wb_load(workbook_file)
  existing <- atlas_v312_excel_sheet_names(workbook)

  titles <- c(
    public_03 = "LWDA AI channel heatmap",
    public_07 = "Training pipeline - simplified flows",
    public_10 = "LWDA commuting origin-destination matrix",
    public_12 = "Top occupation risk-opportunity priorities",
    public_20 = "Training and transition funnel",
    public_26 = "County actionable-job leaderboard"
  )

  created <- list()

  for (name in names(plots)) {
    if (is.null(plots[[name]])) next
    message('  Editable article drawing: ', name)
    identifier <- sub("^public_", "", name)
    sheet <- substr(
      paste0(prefix, "_", identifier),
      1,
      31
    )

    if (sheet %in% existing) {
      remove_method <- tryCatch(workbook$remove_worksheet, error = function(e) NULL)
      if (!is.function(remove_method)) next
      remove_method(sheet)
      replaced_drawings <- replaced_drawings + 1L
      existing <- setdiff(existing, sheet)
    }

    workbook <- atlas_v312_wb_add_worksheet(workbook, sheet)
    title <- titles[[name]] %||% name
    workbook <- atlas_v312_wb_add_data(
      workbook,
      sheet,
      data.frame(
        text = c(
          paste0("Figure ", identifier, ". ", title),
          paste(
            "Editable Office DrawingML generated from the same R ggplot",
            "used for the article-ready PNG/SVG."
          ),
          paste(
            "Right-click the drawing, choose Group, then Ungroup.",
            "Complex drawings may need to be ungrouped twice."
          )
        ),
        stringsAsFactors = FALSE
      ),
      start_col = 1,
      start_row = 1
    )

    drawing <- rvg::dml_xlsx(
      ggobj = plots[[name]],
      bg = "transparent"
    )

    workbook <- atlas_v312_wb_add_drawing(
      workbook,
      sheet = sheet,
      xml = drawing,
      dims = "A5:P36"
    )

    created[[length(created) + 1L]] <- data.frame(
      plot = name,
      sheet = sheet,
      status = "created_editable_article_drawing",
      stringsAsFactors = FALSE
    )
  }

  manifest <- if (length(created)) {
    dplyr::bind_rows(created)
  } else {
    data.frame(
      plot = character(),
      sheet = character(),
      status = character()
    )
  }

  # Do not rewrite a large, already-valid package when no article plot was
  # supplied. When sheets are replaced, subtract the removed drawings before
  # adding the new ones so the minimum count reflects the final package rather
  # than double-counting replacement sheets.
  if (!length(created)) return(manifest)
  expected_drawings <- max(
    0L,
    prior_drawings - replaced_drawings + length(created)
  )
  atlas_v312_wb_save(
    workbook,
    workbook_file,
    minimum_drawings = expected_drawings,
    label = 'Editable article workbook update'
  )

  manifest
}

atlas_v312_clone_worksheet <- function(
    source_workbook,
    target_workbook,
    old_sheet,
    new_sheet) {
  method <- tryCatch(target_workbook$clone_worksheet, error = function(e) NULL)
  if (is.function(method)) {
    method(old = old_sheet, new = new_sheet, from = source_workbook)
    return(target_workbook)
  }
  if (!"wb_clone_worksheet" %in% getNamespaceExports("openxlsx2")) {
    stop("The installed openxlsx2 build cannot clone worksheets across workbooks.", call. = FALSE)
  }
  openxlsx2::wb_clone_worksheet(
    wb = target_workbook,
    old = old_sheet,
    new = new_sheet,
    from = source_workbook
  )
}

atlas_v312_count_drawings <- function(path) {
  if (!file.exists(path)) return(0L)
  listing <- unzip(path, list = TRUE)
  sum(
    grepl(
      "^xl/drawings/drawing[0-9]+\\.xml$",
      listing$Name
    )
  )
}


atlas_v312_unique_sheet_name <- function(
    proposed,
    existing) {

  base <- substr(proposed, 1L, 31L)
  if (!base %in% existing) return(base)

  for (index in seq_len(999L)) {
    suffix <- paste0("_", index)
    candidate <- paste0(
      substr(base, 1L, 31L - nchar(suffix)),
      suffix
    )
    if (!candidate %in% existing) return(candidate)
  }

  stop("Could not create a unique Excel worksheet name.", call. = FALSE)
}


atlas_v312_create_master_editable_workbook <- function(
    v2_file,
    v3_file,
    output_file,
    stop_on_failure = TRUE) {
  if (!file.exists(v2_file) || !file.exists(v3_file)) {
    stop(
      "Both authoritative v2 and v3 editable workbooks are required to create the consolidated workbook.",
      call. = FALSE
    )
  }
  source_check <- atlas_xlsx_package_integrity(v2_file, minimum_drawings = 40L)
  v3_check <- atlas_xlsx_package_integrity(v3_file, minimum_drawings = 13L)
  if (!isTRUE(source_check$passed[[1L]]) || !isTRUE(v3_check$passed[[1L]])) {
    stop("The authoritative workbooks must pass XLSX relationship validation before consolidation.", call. = FALSE)
  }

  target <- openxlsx2::wb_load(v2_file)
  source <- openxlsx2::wb_load(v3_file)
  existing <- atlas_v312_excel_sheet_names(target)
  v3_sheets <- atlas_v312_excel_sheet_names(source)
  v3_sheets <- v3_sheets[grepl("^Fig_", v3_sheets)]
  if (length(v3_sheets) < 13L) {
    stop(
      "Expected at least 13 Methodology v3 editable figure sheets, found ",
      length(v3_sheets), ".",
      call. = FALSE
    )
  }

  before <- source_check$drawing_count[[1L]]
  records <- list()
  for (item_index in seq_along(v3_sheets)) {
    old_sheet <- v3_sheets[[item_index]]
    message('  Consolidated workbook drawing ', item_index, '/', length(v3_sheets), ': ', old_sheet)
    new_sheet <- atlas_v312_unique_sheet_name(paste0("V3_", old_sheet), existing)
    existing <- c(existing, new_sheet)
    target <- atlas_v312_clone_worksheet(
      source_workbook = source,
      target_workbook = target,
      old_sheet = old_sheet,
      new_sheet = new_sheet
    )
    records[[length(records) + 1L]] <- data.frame(
      source_sheet = old_sheet,
      target_sheet = new_sheet,
      status = "cloned_with_media_and_drawing_relationships",
      stringsAsFactors = FALSE
    )
  }

  expected <- before + length(v3_sheets)
  message('  Consolidated workbook: saving XLSX package.')
  atlas_v312_wb_save(
    target,
    output_file,
    minimum_drawings = expected,
    label = 'Consolidated editable workbook'
  )
  after <- atlas_v312_count_drawings(output_file)
  success <- after >= expected

  manifest <- dplyr::bind_rows(records)
  manifest$output_file <- output_file
  manifest$drawing_count_before <- before
  manifest$drawing_count_after <- after
  manifest$minimum_expected <- expected
  readr::write_csv(
    manifest,
    file.path(dirname(output_file), "all_editable_figures_master_manifest_v312.csv")
  )
  if (!success && isTRUE(stop_on_failure)) {
    stop("The consolidated workbook did not preserve every DrawingML object.", call. = FALSE)
  }
  invisible(success)
}

