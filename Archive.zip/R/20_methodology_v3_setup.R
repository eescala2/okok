# Iowa AI Workforce Atlas -- Methodology v3 shared setup and typed contracts
# Designed as an additive extension to the working Methodology v2 project.

`%||%` <- function(x, y) if (is.null(x) || length(x) == 0L || all(is.na(x))) y else x

v3_project_root <- function(start = getwd()) {
  candidates <- unique(normalizePath(c(
    start,
    dirname(start),
    file.path(start, ".."),
    file.path(start, "../..")
  ), winslash = "/", mustWork = FALSE))
  markers <- c("atlas.qmd", "atlas.Rmd", "R", "config")
  for (p in candidates) {
    if (dir.exists(file.path(p, "R")) &&
        (file.exists(file.path(p, "atlas.qmd")) || file.exists(file.path(p, "atlas.Rmd")))) {
      return(p)
    }
  }
  stop(
    "Could not locate the Atlas project root. Open the project folder in Positron or set the working directory to the folder containing atlas.qmd and R/.",
    call. = FALSE
  )
}

v3_paths <- function(root = v3_project_root()) {
  list(
    root = root,
    raw = file.path(root, "data_raw", "methodology_v3"),
    processed = file.path(root, "data_processed", "methodology_v3"),
    figures = file.path(root, "figures", "methodology_v3"),
    outputs = file.path(root, "outputs", "methodology_v3"),
    config = file.path(root, "config"),
    inputs = file.path(root, "inputs"),
    snapshots = file.path(root, "snapshots", "methodology_v3")
  )
}

v3_ensure_directories <- function(paths = v3_paths()) {
  dirs <- unname(unlist(paths[c("raw", "processed", "figures", "outputs", "snapshots")]))
  invisible(lapply(dirs, dir.create, recursive = TRUE, showWarnings = FALSE))
  dir.create(file.path(paths$root, "outputs"), recursive = TRUE, showWarnings = FALSE)
  dir.create(file.path(paths$root, "figures"), recursive = TRUE, showWarnings = FALSE)
  invisible(paths)
}

v3_required_packages <- function() {
  c(
    "dplyr", "tidyr", "purrr", "readr", "stringr", "tibble",
    "httr2", "jsonlite", "readxl", "janitor", "yaml", "rlang",
    "ggplot2", "scales", "ggrepel", "patchwork", "sf"
  )
}

v3_optional_packages <- function() {
  c("openxlsx2", "rvg", "quarto", "rmarkdown", "knitr", "htmltools", "MASS", "fixest", "processx", "png", "ragg")
}

v3_install_packages <- function(packages, required = TRUE) {
  missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (length(missing)) {
    repos <- getOption("repos")
    if (is.null(repos) || identical(unname(repos["CRAN"]), "@CRAN@")) {
      options(repos = c(CRAN = "https://packagemanager.posit.co/cran/latest"))
    }
    for (pkg in missing) {
      try(utils::install.packages(pkg, dependencies = c("Depends", "Imports", "LinkingTo"), quiet = TRUE), silent = TRUE)
    }
  }
  still_missing <- packages[!vapply(packages, requireNamespace, logical(1), quietly = TRUE)]
  if (required && length(still_missing)) {
    stop(
      "Methodology v3 requires packages that could not be installed: ",
      paste(still_missing, collapse = ", "),
      ". Install them in a fresh R session and rerun.",
      call. = FALSE
    )
  }
  invisible(setdiff(packages, still_missing))
}

v3_setup_packages <- function(install_optional = FALSE) {
  v3_install_packages(v3_required_packages(), required = TRUE)
  if (isTRUE(install_optional)) v3_install_packages(v3_optional_packages(), required = FALSE)
  invisible(TRUE)
}

v3_load_config <- function(root = v3_project_root()) {
  path <- file.path(root, "config", "methodology_v3.yml")
  if (!file.exists(path)) stop("Missing Methodology v3 configuration: ", path, call. = FALSE)
  yaml::read_yaml(path)
}

v3_read_csv <- function(path, required = FALSE, col_types = readr::cols(.default = readr::col_guess())) {
  if (!file.exists(path)) {
    if (required) stop("Required file does not exist: ", path, call. = FALSE)
    return(tibble::tibble())
  }
  readr::read_csv(path, show_col_types = FALSE, progress = FALSE, col_types = col_types)
}

v3_write_csv <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  readr::write_csv(x, path, na = "")
  invisible(path)
}

v3_clean_names <- function(x) {
  if (requireNamespace("janitor", quietly = TRUE)) janitor::clean_names(x) else {
    names(x) <- tolower(gsub("[^A-Za-z0-9]+", "_", names(x)))
    names(x) <- gsub("^_|_$", "", names(x))
    x
  }
}

v3_require_columns <- function(x, columns, context = deparse(substitute(x))) {
  missing <- setdiff(columns, names(x))
  if (length(missing)) {
    stop(
      context, " is missing required column(s): ", paste(missing, collapse = ", "),
      ". Available columns: ", paste(names(x), collapse = ", "),
      call. = FALSE
    )
  }
  invisible(TRUE)
}

v3_drop_example_rows <- function(x) {
  if (!nrow(x)) return(x)
  flags <- rep(FALSE, nrow(x))
  for (nm in names(x)) {
    z <- trimws(as.character(x[[nm]]))
    flags <- flags | grepl("^EXAMPLE(_|$)", z, ignore.case = TRUE) |
      grepl("delete this example row", tolower(z), fixed = TRUE)
  }
  x[!flags, , drop = FALSE]
}

v3_parse_date <- function(x) {
  y <- trimws(as.character(x))
  out <- suppressWarnings(as.Date(y))
  formats <- c("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%B %d, %Y", "%b %d, %Y", "%Y%m%d")
  for (fmt in formats) {
    idx <- is.na(out) & nzchar(y)
    if (!any(idx)) break
    out[idx] <- suppressWarnings(as.Date(y[idx], format = fmt))
  }
  out
}

v3_as_numeric <- function(x) {
  if (is.numeric(x)) return(as.numeric(x))
  suppressWarnings(readr::parse_number(as.character(x), locale = readr::locale(grouping_mark = ",")))
}

v3_as_binary <- function(x) {
  if (is.logical(x)) return(as.integer(x))
  y <- trimws(tolower(as.character(x)))
  out <- rep(NA_integer_, length(y))
  out[y %in% c("1", "true", "yes", "y", "used", "current", "pass", "passed")] <- 1L
  out[y %in% c("0", "false", "no", "n", "not used", "fail", "failed")] <- 0L
  out
}

v3_clamp <- function(x, lo = 0, hi = 1) pmax(lo, pmin(hi, x))

v3_validate_unit_interval <- function(x, name, missing = c("allow", "forbid")) {
  missing <- match.arg(missing)
  z <- v3_as_numeric(x)
  bad <- which(is.finite(z) & (z < 0 | z > 1))
  if (length(bad)) {
    stop(
      name, " violates the declared [0,1] schema in ", length(bad), " row(s). ",
      "Methodology v3 does not infer percentages from magnitude. Declare and convert the source scale before validation.",
      call. = FALSE
    )
  }
  if (missing == "forbid" && anyNA(z)) stop(name, " contains missing values under a forbid-missing policy.", call. = FALSE)
  z
}

v3_normalize_fips5 <- function(x) {
  raw <- as.character(x)
  missing <- is.na(x) | !nzchar(trimws(raw))
  y <- gsub("\\D", "", raw)
  county_only <- !missing & nchar(y) >= 1L & nchar(y) <= 3L
  y[county_only] <- paste0("19", stringr::str_pad(y[county_only], 3, pad = "0"))
  y[!missing & nchar(y) == 4L] <- stringr::str_pad(y[!missing & nchar(y) == 4L], 5, pad = "0")
  y[missing | nchar(y) != 5L] <- NA_character_
  y
}

v3_normalize_naics2 <- function(x) {
  y <- gsub("\\D", "", as.character(x))
  y <- substr(y, 1, 2)
  y[!grepl("^[0-9]{2}$", y)] <- NA_character_
  y
}

v3_normalize_soc <- function(x) {
  y <- gsub("[^0-9]", "", as.character(x))
  out <- ifelse(nchar(y) >= 6, paste0(substr(y, 1, 2), "-", substr(y, 3, 6)), NA_character_)
  out
}

v3_weighted_mean <- function(x, w, na.rm = TRUE) {
  x <- v3_as_numeric(x); w <- v3_as_numeric(w)
  ok <- is.finite(x) & is.finite(w) & w > 0
  if (!any(ok)) return(NA_real_)
  stats::weighted.mean(x[ok], w[ok], na.rm = na.rm)
}

v3_weighted_rate_se <- function(rate, denominator = NA_real_, supplied_se = NA_real_) {
  rate <- v3_clamp(v3_as_numeric(rate), 0, 1)
  supplied_se <- v3_as_numeric(supplied_se)
  denominator <- v3_as_numeric(denominator)
  derived <- sqrt(pmax(rate * (1 - rate) / pmax(denominator, 1), 0))
  ifelse(is.finite(supplied_se) & supplied_se > 0, supplied_se, ifelse(is.finite(denominator) & denominator > 0, derived, NA_real_))
}

v3_logit <- function(x, epsilon = 0.005) stats::qlogis(v3_clamp(x, epsilon, 1 - epsilon))
v3_inv_logit <- function(x) stats::plogis(x)

v3_percentile <- function(x) {
  z <- v3_as_numeric(x)
  if (sum(is.finite(z)) < 2L) return(rep(NA_real_, length(z)))
  rank(z, na.last = "keep", ties.method = "average") / sum(is.finite(z))
}

v3_zscore <- function(x) {
  z <- v3_as_numeric(x)
  s <- stats::sd(z, na.rm = TRUE)
  if (!is.finite(s) || s == 0) return(ifelse(is.finite(z), 0, NA_real_))
  (z - mean(z, na.rm = TRUE)) / s
}

v3_quarter_index <- function(x) {
  x <- as.character(x)
  yr <- suppressWarnings(as.integer(substr(x, 1, 4)))
  q <- suppressWarnings(as.integer(gsub(".*Q", "", x)))
  yr * 4L + q
}

v3_quarter_label <- function(index) {
  index <- as.integer(index)
  yr <- (index - 1L) %/% 4L
  q <- index - yr * 4L
  paste0(yr, "-Q", q)
}

v3_evidence_status <- function(observed = FALSE, benchmarked = FALSE, scenario = FALSE, provisional = FALSE) {
  if (isTRUE(observed)) return("OBSERVED")
  if (isTRUE(benchmarked)) return("BENCHMARKED")
  if (isTRUE(scenario)) return("SCENARIO")
  if (isTRUE(provisional)) return("PROVISIONAL")
  "UNAVAILABLE"
}

v3_reliability_class <- function(n = NA_real_, coverage = NA_real_, se = NA_real_, observed = FALSE, fallback = FALSE) {
  n <- v3_as_numeric(n); coverage <- v3_as_numeric(coverage); se <- v3_as_numeric(se)
  dplyr::case_when(
    observed & !fallback & is.finite(n) & n >= 100 & (!is.finite(se) | se <= 0.05) ~ "A",
    !fallback & is.finite(n) & n >= 30 & (!is.finite(coverage) | coverage >= 0.60) ~ "B",
    TRUE ~ "C"
  )
}

v3_hash_file <- function(path) {
  if (!file.exists(path)) return(NA_character_)
  if (requireNamespace("openssl", quietly = TRUE)) return(as.character(openssl::sha256(file(path))))
  unname(tools::md5sum(path))
}

v3_build_id <- function(root = v3_project_root()) {
  cfg <- file.path(root, "config", "methodology_v3.yml")
  hash <- substr(v3_hash_file(cfg) %||% "nohash", 1, 10)
  paste0(format(Sys.time(), "%Y%m%dT%H%M%S"), "-v3-", hash)
}

v3_file_manifest <- function(paths, source_id = NA_character_) {
  paths <- unique(paths[file.exists(paths)])
  tibble::tibble(
    source_id = source_id,
    file = normalizePath(paths, winslash = "/", mustWork = FALSE),
    bytes = file.info(paths)$size,
    modified = as.character(file.info(paths)$mtime),
    sha256_or_md5 = vapply(paths, v3_hash_file, character(1))
  )
}

v3_find_first <- function(root, candidates) {
  p <- file.path(root, candidates)
  p <- p[file.exists(p)]
  if (length(p)) p[[1]] else NA_character_
}

v3_read_v2_atlas <- function(root = v3_project_root()) {
  candidates <- c(
    "data_processed/county_industry_occupation_atlas.parquet",
    "data_processed/county_industry_occupation_atlas.rds",
    "data_processed/county_industry_occupation_atlas.csv.gz",
    "data_processed/county_industry_occupation_atlas.csv"
  )
  path <- v3_find_first(root, candidates)
  if (is.na(path)) stop("Methodology v3 requires the completed Methodology v2 atlas output. None of the supported atlas files were found.", call. = FALSE)
  ext <- tolower(tools::file_ext(path))
  if (ext == "parquet") {
    if (!requireNamespace("arrow", quietly = TRUE)) stop("The v2 atlas is Parquet but arrow is unavailable. Rerun v2 with RDS/CSV fallback or install arrow.", call. = FALSE)
    x <- arrow::read_parquet(path, as_data_frame = TRUE)
  } else if (ext == "rds") {
    x <- readRDS(path)
  } else {
    x <- readr::read_csv(path, show_col_types = FALSE, progress = FALSE)
  }
  x <- v3_clean_names(as.data.frame(x))
  if ("county_fips" %in% names(x)) x$county_fips <- v3_normalize_fips5(x$county_fips)
  if ("naics2" %in% names(x)) x$naics2 <- v3_normalize_naics2(x$naics2)
  if ("soc_code" %in% names(x)) x$soc_code <- v3_normalize_soc(x$soc_code)
  attr(x, "source_path") <- path
  x
}

v3_read_v2_occupation_scores <- function(root = v3_project_root()) {
  path <- v3_find_first(root, c(
    "data_processed/occupation_ai_scores.csv",
    "data_processed/occupation_ai_scores.csv.gz",
    "data_processed/occupation_ai_scores.rds",
    "data_processed/occupation_ai_scores.parquet"
  ))
  if (is.na(path)) return(tibble::tibble())
  ext <- tolower(tools::file_ext(path))
  if (ext == "parquet") {
    if (!requireNamespace("arrow", quietly = TRUE)) return(tibble::tibble())
    x <- arrow::read_parquet(path, as_data_frame = TRUE)
  } else if (ext == "rds") x <- readRDS(path) else x <- readr::read_csv(path, show_col_types = FALSE)
  x <- v3_clean_names(as.data.frame(x))
  if ("soc_code" %in% names(x)) x$soc_code <- v3_normalize_soc(x$soc_code)
  x
}

v3_publication_note <- function() {
  paste(
    "Exposure is not adoption; adoption is not productivity; and productivity is not automatically pro-worker.",
    "Methodology v3 reports observed, benchmarked, scenario, provisional, and unavailable evidence separately."
  )
}

v3_write_build_metadata <- function(build_id, paths = v3_paths(), extra = list()) {
  cfg <- tryCatch(v3_load_config(paths$root), error = function(e) list())
  methodology_version <- as.character(cfg$methodology_version %||% "3.0.3")
  meta <- tibble::tibble(
    field = c(
      "build_id", "methodology_version", "built_at_utc", "r_version",
      "platform", "principle", names(extra)
    ),
    value = as.character(c(
      build_id, methodology_version, format(Sys.time(), tz = "UTC", usetz = TRUE),
      R.version.string, R.version$platform,
      "Exposure is not adoption; adoption is not productivity; and productivity is not automatically pro-worker.",
      unlist(extra, use.names = FALSE)
    ))
  )
  v3_write_csv(meta, file.path(paths$outputs, "build_metadata_v3.csv"))
  meta
}
