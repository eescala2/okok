# Iowa AI Workforce Atlas v3.1.3-clean-r4

## Runtime defect fixed

`resume_publication_from_stage6.R` previously sourced every R file, including the executable `R/run_all.R` and `R/run_all_v2.R`. That replayed the full analytical/report pipeline and reached the legacy PDF stage. The revised loader excludes both runner files and performs only editable-Excel creation and validation.

## Cairo/X11/XQuartz removed from maintained publication paths

- `R/08_pdf_reports.R`, `R/39_methodology_v3_publication_release.R`, and `R/40_methodology_v3_publication_completion_v309.R` now use base `grDevices::pdf()` with Helvetica for PNG compendia.
- `R/10_iowa_report_style.R` uses `ragg` and a plain `png()` fallback; it never selects `cairo-png`.
- Browser PDF processes require `processx` and have a hard timeout. There is no unbounded `system2()` browser fallback.
- `pagedown::chrome_print()` is disabled because its child-process lifetime is not controlled by this workflow.

## Other remediations

- Optional LWDA map is guarded with `file.exists()` in both report sources.
- Git provenance is skipped cleanly outside a Git repository.
- Deprecated `geom_errorbarh()` is replaced by `geom_errorbar(orientation = "y")`.
- Label layers use `na.rm = TRUE`; intentional repelled labels use `max.overlaps = Inf`.
- Stage 6 emits source-sheet, figure, save, and consolidation progress messages.
- Preflight removes Finder ZIP metadata and tests Stage-6 isolation plus absence of Cairo/X11 calls.
- The smoke test opens and writes a small base-PDF file using Helvetica.

No Methodology v2/v3 analytical formulas, scoring weights, classification thresholds, evidence rules, or public-source contracts were changed.

- Removed the last unbounded `system2()` browser-PDF fallback from the Methodology v3 renderer. All Chromium subprocesses now require `processx` and have a hard timeout.
