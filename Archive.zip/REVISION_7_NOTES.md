# Iowa AI Workforce Atlas v3.1.3-clean-r7

This revision adds an explicit, mapping-driven HTOPS benchmark contract and a visual publication pass that trims uniform outer PNG whitespace, applies compact readable typography, compacts HTML/PDF figure layout, audits every PNG, and creates a review gallery. It preserves the r6 openxlsx2 >= 1.26 DrawingML/media repair and does not change analytical scoring.

Changed/new maintained files: 18.
