# Iowa AI Workforce Atlas v3.1.3-clean-r9

## Browser PDF completion

- Accepts a PDF when its size is stable, `%PDF-` is present, `%%EOF` is present,
  and the project PDF validator accepts its page count/content.
- Terminates a Chromium process that remains alive after writing a validated PDF.
- Records whether completion was detected from the file and whether the browser
  was terminated after output.
- Writes revision-9 logs/status under `outputs/pdf_logs_v319/` and
  `outputs/pdf_print_status_v319.csv`.
- Preserves transactional staging and restores a previous valid PDF if promotion
  fails.
- Restores the list return contract (`valid`, `pages`, `bytes`, `attempt`,
  `tagged`) required by `atlas_v312_create_pdf_outputs()`.
- Recognizes legacy call arguments including `artifact`, `timeout_sec`,
  `heartbeat_sec`, `min_pages`, and `tagged`.
- Fixes the malformed visual-default block in the Stage-6 recovery script.

No analytical formula, score, threshold, evidence rule, or data-source contract
was changed.
