# Iowa AI Workforce Atlas 3.1.3-clean-r3

## Confirmed repairs

- Added the maintained `make_methodology_v3_editable_excel()` function to the
  Stage 6 dispatcher and installed backward-compatible aliases.
- Removed `wb$clone()$save()` calls that can lose embedded DrawingML media in
  `openxlsx2`; workbooks are saved directly.
- Corrected the Census BTOS base route to `/hfp/btos/api` and the Iowa state
  request identifier to FIPS `19`.
- BTOS periods are ordered by parsed `COLLECTION_END`, not numeric ID alone.
- BTOS state retrieval tries FIPS `19` first, then postal-code and all-state/query fallbacks with Iowa filtering.
- Added a valid BEA Regional fallback/control request:
  `SAINC1`, line `3`, `GeoFIPS=19000`, `Year=LAST5`.
- Preserved QWI unchanged because the live diagnostic produced 2,380 usable
  Sex-by-Age records.
- Added explicit live-source diagnostics, offline JSON parser fixtures, a
  Stage-6-only resume entry point, and XLSX relationship validation.

## Scope

No Methodology v2 or Methodology v3 scoring weights, classifications, partial
pooling, uncertainty calculations, pathway rules, or figure contracts were
changed.
