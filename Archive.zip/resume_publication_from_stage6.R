# Resume only the editable-Excel publication stage after analytics, figures,
# HTML, and PDFs have already completed. Run from the project root in a fresh
# R 4.4.0 session. This script never sources the executable run_all scripts.
#
# v3.1.3-clean-r7 adds validated phase checkpoints. Once a workbook phase has
# completed under r6, a later retry reuses it instead of rebuilding it.

.atlas_stage6_root <- normalizePath(getwd(), winslash = "/", mustWork = TRUE)
if (!file.exists(file.path(.atlas_stage6_root, "VERSION")) ||
    !dir.exists(file.path(.atlas_stage6_root, "R"))) {
  stop("Run resume_publication_from_stage6.R from the Atlas project root.", call. = FALSE)
}

source(file.path(.atlas_stage6_root, "R", "00_setup.R"))
activate_atlas_package_library()

.atlas_excluded_runners <- c("run_all.R", "run_all_v2.R")
.atlas_definition_files <- sort(list.files(
  file.path(.atlas_stage6_root, "R"),
  pattern = "[.]R$",
  full.names = TRUE
))
.atlas_definition_files <- .atlas_definition_files[
  !basename(.atlas_definition_files) %in% .atlas_excluded_runners
]

message("Stage 6-only resume: reusing existing analytics, figures, HTML, and PDFs.")
message("Executable runners excluded: R/run_all.R and R/run_all_v2.R.")
message("Loading maintained function definitions only (", length(.atlas_definition_files), " files).")

for (.atlas_file in .atlas_definition_files) {
  sys.source(.atlas_file, envir = .GlobalEnv, keep.source = FALSE)
}

if (exists("atlas_v317_set_visual_defaults", mode = "function", inherits = TRUE)) {
  atlas_v317_set_visual_defaults()
}

if (exists("atlas_v313_install_repairs", mode = "function", inherits = TRUE)) {
  atlas_v313_install_repairs()
}

# Stop before reconstructing 40 figures when the known openxlsx2 1.24/1.25
# raster-registration defect is still installed.
if (!requireNamespace("openxlsx2", quietly = TRUE)) {
  found <- "not installed"
  stop(
    "Stage 6 requires openxlsx2 >= 1.26.0; found ", found,
    ". Run source(\"install_dependencies.R\") in a fresh R session, restart R, run the smoke test, and then resume Stage 6.",
    call. = FALSE
  )
}
.atlas_openxlsx2_runtime_version <- tryCatch(
  package_version(as.character(getNamespaceVersion("openxlsx2"))),
  error = function(e) package_version("0.0.0")
)
if (.atlas_openxlsx2_runtime_version < package_version("1.26.0")) {
  found <- as.character(.atlas_openxlsx2_runtime_version)
  stop(
    "Stage 6 requires openxlsx2 >= 1.26.0; found ", found,
    ". Run source(\"install_dependencies.R\") in a fresh R session, restart R, run the smoke test, and then resume Stage 6.",
    call. = FALSE
  )
}
atlas_openxlsx2_capability_check(stop_on_error = TRUE)

# Load the XLSX validator as definitions only. It is used after each phase so a
# checkpoint is never written for a truncated or internally broken workbook.
.atlas_old_validator_option <- getOption("ia.atlas.xlsx_validator.define_only")
options("ia.atlas.xlsx_validator.define_only" = TRUE)
sys.source(
  file.path(.atlas_stage6_root, "validate_excel_packages.R"),
  envir = .GlobalEnv,
  keep.source = FALSE
)
options("ia.atlas.xlsx_validator.define_only" = .atlas_old_validator_option)

.atlas_stage6_outputs <- file.path(.atlas_stage6_root, "outputs")
dir.create(.atlas_stage6_outputs, recursive = TRUE, showWarnings = FALSE)
.atlas_stage6_checkpoint_dir <- file.path(
  .atlas_stage6_outputs,
  ".stage6_checkpoints_r6"
)
dir.create(.atlas_stage6_checkpoint_dir, recursive = TRUE, showWarnings = FALSE)
.atlas_stage6_version <- trimws(readLines(
  file.path(.atlas_stage6_root, "VERSION"),
  warn = FALSE,
  n = 1L
))

.atlas_stage6_md5 <- function(path) {
  if (!file.exists(path)) return(NA_character_)
  unname(tools::md5sum(path)[[1L]])
}

.atlas_stage6_checkpoint_path <- function(phase) {
  file.path(.atlas_stage6_checkpoint_dir, paste0(phase, ".rds"))
}

.atlas_stage6_checkpoint_valid <- function(
    phase,
    workbook,
    minimum_drawings,
    dependencies = character()) {

  marker_path <- .atlas_stage6_checkpoint_path(phase)
  if (!file.exists(marker_path) || !file.exists(workbook)) return(FALSE)
  marker <- tryCatch(readRDS(marker_path), error = function(e) NULL)
  if (is.null(marker) || !identical(marker$version, .atlas_stage6_version)) {
    return(FALSE)
  }
  if (!identical(marker$workbook_md5, .atlas_stage6_md5(workbook))) {
    return(FALSE)
  }
  if (length(dependencies)) {
    current_dependencies <- vapply(dependencies, .atlas_stage6_md5, character(1L))
    if (!identical(marker$dependency_md5, current_dependencies)) return(FALSE)
  }
  check <- atlas_validate_xlsx_package(workbook, minimum_drawings)
  isTRUE(check$passed[[1L]])
}

.atlas_stage6_write_checkpoint <- function(
    phase,
    workbook,
    minimum_drawings,
    dependencies = character()) {

  check <- atlas_validate_xlsx_package(workbook, minimum_drawings)
  if (!isTRUE(check$passed[[1L]])) {
    stop(
      "Stage 6 phase ", phase,
      " produced a workbook that failed package validation: ",
      check$detail[[1L]],
      call. = FALSE
    )
  }
  marker <- list(
    version = .atlas_stage6_version,
    phase = phase,
    workbook = normalizePath(workbook, winslash = "/", mustWork = TRUE),
    workbook_md5 = .atlas_stage6_md5(workbook),
    dependency_md5 = if (length(dependencies)) {
      vapply(dependencies, .atlas_stage6_md5, character(1L))
    } else {
      character()
    },
    drawing_count = check$drawing_count[[1L]],
    completed_at_utc = format(
      as.POSIXct(Sys.time(), tz = "UTC"),
      "%Y-%m-%d %H:%M:%S UTC"
    )
  )
  saveRDS(marker, .atlas_stage6_checkpoint_path(phase))
  invisible(check)
}

if (!exists("atlas_v312_call_supported", mode = "function", inherits = TRUE)) {
  stop("Stage 6 dispatcher is unavailable after loading maintained definitions.", call. = FALSE)
}

if (exists("atlas_override_excel_core_plots", mode = "function", inherits = TRUE)) {
  atlas_override_excel_core_plots()
}

.v2_workbook <- file.path(
  .atlas_stage6_outputs,
  "iowa_ai_workforce_atlas_editable_figures.xlsx"
)
.v3_workbook <- file.path(
  .atlas_stage6_outputs,
  "iowa_ai_workforce_atlas_methodology_v3_editable_figures.xlsx"
)
.master_workbook <- file.path(
  .atlas_stage6_outputs,
  "iowa_ai_workforce_atlas_all_editable_figures.xlsx"
)
.stage6_status <- character()

message("Stage 6 recovery 1/4: Methodology v2 editable workbook.")
if (.atlas_stage6_checkpoint_valid("v2", .v2_workbook, 40L)) {
  message("  Reusing validated r6 Methodology v2 workbook checkpoint.")
  .stage6_status[["v2"]] <- "reused_validated_checkpoint"
} else {
  atlas_v312_call_supported(
    c("make_editable_excel_figures"),
    list(
      install_missing = TRUE,
      build_if_missing = FALSE,
      refresh = FALSE,
      output_file = .v2_workbook,
      stop_on_error = TRUE
    ),
    required = TRUE,
    label = "Methodology v2 editable Excel"
  )
  .atlas_stage6_write_checkpoint("v2", .v2_workbook, 40L)
  .stage6_status[["v2"]] <- "built_and_validated"
}

message("Stage 6 recovery 2/4: Methodology v3 editable workbook.")
if (.atlas_stage6_checkpoint_valid("v3", .v3_workbook, 13L)) {
  message("  Reusing validated r6 Methodology v3 workbook checkpoint.")
  .stage6_status[["v3"]] <- "reused_validated_checkpoint"
} else {
  .paths_v3 <- if (exists("v3_paths", mode = "function", inherits = TRUE)) {
    v3_paths()
  } else {
    list(root = .atlas_stage6_root)
  }
  atlas_v312_call_supported(
    c(
      "make_methodology_v3_editable_excel",
      "make_methodology_v3_editable_excel_figures",
      "make_methodology_v3_editable_figures",
      "v3_make_editable_excel_figures",
      "make_editable_excel_figures_v3",
      "create_methodology_v3_editable_excel_workbook"
    ),
    list(
      paths = .paths_v3,
      install_missing = TRUE,
      build_if_missing = FALSE,
      refresh = FALSE
    ),
    required = TRUE,
    label = "Methodology v3 editable Excel"
  )
  .atlas_stage6_write_checkpoint("v3", .v3_workbook, 13L)
  .stage6_status[["v3"]] <- "built_and_validated"
}

message("Stage 6 recovery 3/4: optional article-ready editable sheets.")
# The recovery entry point intentionally has no article-only plot objects; they
# are optional and are created during a complete run. Preserve an explicit
# empty manifest instead of reopening and resaving the validated v2 workbook.
.article_manifest <- data.frame(
  plot = character(),
  sheet = character(),
  status = character(),
  stringsAsFactors = FALSE
)
readr::write_csv(
  .article_manifest,
  file.path(.atlas_stage6_outputs, "article_editable_figure_manifest_v312.csv")
)
.stage6_status[["article"]] <- "not_requested_in_stage6_recovery"

message("Stage 6 recovery 4/4: consolidated editable workbook.")
.master_dependencies <- c(v2 = .v2_workbook, v3 = .v3_workbook)
if (.atlas_stage6_checkpoint_valid(
  "master",
  .master_workbook,
  53L,
  dependencies = .master_dependencies
)) {
  message("  Reusing validated r6 consolidated workbook checkpoint.")
  .stage6_status[["master"]] <- "reused_validated_checkpoint"
} else {
  .consolidated <- atlas_v312_create_master_editable_workbook(
    v2_file = .v2_workbook,
    v3_file = .v3_workbook,
    output_file = .master_workbook,
    stop_on_failure = TRUE
  )
  if (!isTRUE(.consolidated)) {
    stop("Consolidated workbook builder did not report success.", call. = FALSE)
  }
  .atlas_stage6_write_checkpoint(
    "master",
    .master_workbook,
    53L,
    dependencies = .master_dependencies
  )
  .stage6_status[["master"]] <- "built_and_validated"
}

message("Final Stage 6 validation: checking all XLSX ZIP and DrawingML targets.")
.excel_validation <- atlas_run_xlsx_package_validation(
  workbooks = c(.v2_workbook, .v3_workbook, .master_workbook),
  minimum_drawings = c(40L, 13L, 53L),
  output_file = file.path(
    .atlas_stage6_outputs,
    "excel_package_validation_v313.csv"
  ),
  stop_on_failure = TRUE
)

.stage6_paths <- c(
  v2 = .v2_workbook,
  v3 = .v3_workbook,
  master = .master_workbook
)
.stage6_manifest <- data.frame(
  artifact = basename(.stage6_paths),
  phase = names(.stage6_paths),
  status = unname(.stage6_status[names(.stage6_paths)]),
  path = normalizePath(.stage6_paths, winslash = "/", mustWork = FALSE),
  exists = file.exists(.stage6_paths),
  bytes = ifelse(file.exists(.stage6_paths), file.info(.stage6_paths)$size, 0),
  md5 = vapply(.stage6_paths, .atlas_stage6_md5, character(1L)),
  openxlsx2_version = as.character(getNamespaceVersion("openxlsx2")),
  rvg_version = as.character(getNamespaceVersion("rvg")),
  completed_at_utc = format(
    as.POSIXct(Sys.time(), tz = "UTC"),
    "%Y-%m-%d %H:%M:%S UTC"
  ),
  stringsAsFactors = FALSE
)
readr::write_csv(
  .stage6_manifest,
  file.path(.atlas_stage6_outputs, "stage6_resume_manifest_v316.csv")
)

if (any(!.stage6_manifest$exists | .stage6_manifest$bytes <= 0)) {
  stop("One or more Stage 6 workbook outputs are missing or empty.", call. = FALSE)
}

message("Stage 6 workbook package validation passed.")
message("Stage 6-only publication resume completed without rerunning PDFs or analytics.")
message("Review outputs/stage6_resume_manifest_v316.csv and outputs/excel_package_validation_v313.csv.")
