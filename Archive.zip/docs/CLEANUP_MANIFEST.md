# Archive reduction

The superseded bundle contained 447 files (7,573,691 uncompressed bytes), including 190 `__MACOSX` files, 64 backup generations, 45 root `99_*` patch/installer/verifier scripts, 121 Markdown files, generated HTML, old manifests, logs, and duplicate root/R modules.

The clean distribution keeps one maintained copy of every v2/v3 analytical and output module, report templates, configuration/bibliographies, one entry point, one installer, one platform preflight, one smoke test, data diagnostics, header-only local-input schemas, and concise documentation. Stable internal names containing `v312` remain to avoid needless interface risk. The distribution version is `3.1.3-clean-r2`; the scoring methodology declaration remains unchanged.
