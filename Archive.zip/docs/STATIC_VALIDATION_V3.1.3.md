# Static validation — v3.1.3 clean, revision 2

- Checks run: **27**
- Blocking failures: **0**
- Nonblocking findings: **0**
- Maintained R files lexically checked: **49**
- Clean distribution files at validation time: **112**

## Validation boundary

The supplied Apple Silicon run confirms exact R 4.4 parsing and package checks for revision 1. Revision 2 changes only the generic dispatcher lookup, its smoke/preflight checks, version metadata, and documentation. This build environment does not contain R, macOS, or Windows, so the included target-machine preflight and no-download smoke test remain the authoritative runtime checks.

## Results

| Check | Passed | Blocking | Detail |
|---|:---:|:---:|---|
| All maintained R files pass lexical delimiter/string validation | Yes | Yes | 49 R files checked |
| Critical analytical, report, and verification files exist | Yes | Yes | 20 required files present |
| Literal R source/module references resolve inside the clean tree | Yes | Yes | 43 referenced modules resolved |
| v2 and v3 runner module chains are complete | Yes | Yes | v2 modules 00-08 and 10-15; v3 modules 20-34 referenced |
| One-click output module chain is complete | Yes | Yes | modules 41-44 and 46 sourced |
| Methodology v3 report renderer/caller argument contract is repaired | Yes | Yes | base=True; strict_wrapper=True; caller_omits_refresh=True |
| Generic one-click dispatcher filters unsupported arguments for strict functions | Yes | Yes | formal-argument filtering present |
| Generic one-click dispatcher uses an explicit source lookup environment | Yes | Yes | isolated-source contract present |
| Maintained entry scripts reactivate the R-4.4 Atlas package library | Yes | Yes | verifier, runner, live-source diagnostic, and smoke test bootstrap the dedicated library |
| Package installation defaults deterministically to Posit Package Manager | Yes | Yes | user override remains available through IA_ATLAS_CRAN_REPO |
| Package installation verifies the target library and loadable namespace | Yes | Yes | warning-only install returns cannot be treated as success |
| Nonblocking optional packages are skipped by default | Yes | No | Arrow, DuckDB, and fixest require IA_ATLAS_INSTALL_OPTIONAL=true |
| BTOS uses the official API before the JavaScript-page fallback | Yes | Yes | official endpoints=True; API_precedes_static_fallback=True |
| Public-source status separates unavailable/configuration/download/schema states | Yes | Yes | reason-aware status codes found |
| QWI early-career request omits incompatible firm-age/firm-size predicates | Yes | Yes | compact Sex-by-Age contract with ownercode found |
| Every optional/local CSV input referenced by v3 has an included schema template | Yes | Yes | 5 referenced local inputs covered |
| Input templates are header-only and cannot fabricate evidence | Yes | Yes | 16 header-only templates validated |
| All retained CSV/config/template files have consistent row widths | Yes | Yes | 40 CSV files validated |
| All retained YAML configuration files parse | Yes | Yes | 3 YAML files parsed |
| No macOS metadata or backup generations remain | Yes | No | 112 files clean |
| No literal Census/BEA API keys are present | Yes | Yes | no literal keys detected |
| No user-specific absolute home paths are embedded | Yes | Yes | all project paths are relative/discovered |
| Cross-platform branches cover Windows and macOS | Yes | Yes | OS branches and browser discovery present |
| Methodology v3 base PDF fallback does not require Cairo/XQuartz | Yes | Yes | all maintained publication paths use base grDevices::pdf() directly; no platform probes Cairo/X11 |
| Distribution version is 3.1.3-clean-r2 | Yes | Yes | 3.1.3-clean-r2 |
| Clean distribution materially reduces the superseded archive | Yes | No | original=447 files/7573691 bytes; clean=112 files/1132140 bytes |
| Font discovery prefers match_fonts with a warning-suppressed legacy fallback | Yes | No | current and legacy systemfonts APIs covered |
