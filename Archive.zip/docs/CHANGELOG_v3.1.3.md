# Implementation changelog — v3.1.3 clean

- Fixed the fatal Methodology v3 report-rerender argument leak.
- Replaced BTOS static-page discovery as the primary path with the official BTOS API.
- Corrected QWI to the valid all-ownership Sex-by-Age contract.
- Added reason-aware public-source and module availability outputs.
- Added all required header-only local-input schemas.
- Removed secrets, backups, patch generations, duplicate runners, generated artifacts, and macOS metadata.
- Added a maintained entry point, dependency installer, cross-platform preflight, contract smoke test, and source diagnostic.


## Clean-distribution revision 1

- Activated the dedicated R-4.4 Atlas package library in the verifier, maintained runner, live-source diagnostic, and smoke test after session restart.
- Made Posit Package Manager the deterministic default unless `IA_ATLAS_CRAN_REPO` is explicitly supplied.
- Verified namespace availability after each package installation instead of treating a warning-only `install.packages()` return as success.
- Added a CRAN source fallback with an explicit compiler-toolchain warning path.
- Removed a duplicate `install_missing` argument and made the generic function dispatcher discard duplicate names safely.

- Stopped installing Arrow, DuckDB, and other nonblocking optional packages by default; set `IA_ATLAS_INSTALL_OPTIONAL=true` to request them.

## Clean-distribution revision 2

- Fixed the strict smoke-test failure caused by implicit `exists()`/`get()` frame selection inside `vapply()`.
- Made the dispatcher resolve functions explicitly from its definition environment.
- Added a blocking runtime dispatcher check to `verify_install.R`.
- Extended the no-download smoke test to cover isolated source-environment function resolution.

