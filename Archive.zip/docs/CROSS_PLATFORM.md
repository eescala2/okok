# Cross-platform operating notes

## Positron and R 4.4.0
Open the project folder, select the R 4.4.0 interpreter, and restart the console before dependency installation. `verify_install.R` records R/OS/architecture, parses every maintained R source, checks packages, Quarto, write access, secrets, and the repaired interface.

## Apple Silicon MacBook Air M1
Use the ARM64 R 4.4.0 build. Every maintained figure-compendium path uses `grDevices::pdf()` and never probes Cairo/X11/XQuartz. Browser PDF generation searches standard Chrome/Edge locations.

## Windows 11 Dell Latitude 5550
Use 64-bit R 4.4.0. Install packages in a fresh session so a loaded `systemfonts` DLL cannot block its own update. Binary packages are preferred; Chrome or Edge is needed for browser PDF output.

## Validation boundary
The supplied Mac transcript proves that R 4.4.0 ARM reached completed v2/v3 analytics and initial v3 HTML rendering before the repaired late interface error. A genuine Windows execution must be run on the Dell; this distribution includes exact preflight and smoke tests for that purpose.


## Revision 4 publication-device policy

On both macOS ARM64 and Windows x64, report PDFs are printed by Chrome/Edge through `processx` with a hard timeout. Raster figure compendia use base PDF with Helvetica. `ragg` is the normal PNG device. Cairo, X11, and XQuartz are not required or probed.

The Stage-6 resume loader excludes `R/run_all.R` and `R/run_all_v2.R`; seeing `Step 1/10` after sourcing the resume file means an older script is still being used.
