# Methodology v3 data availability

| Source/module | Actual status | Clean behavior |
|---|---|---|
| Census BTOS | Public and current | Uses the official API first; distinguishes download failure from an unrecognized AI schema |
| Census QWI Sex by Age | Public; API key and released quarters required | Uses the all-ownership Sex-by-Age contract and reports configuration/request status |
| BEA Input-Output/Regional | Public; API key required | Reports API status; regional scenarios still require local project assumptions |
| HTOPS benchmark | Optional | Reports `optional_not_configured` unless a direct URL/local extract is supplied |
| Employer pulse, worker outcomes, apprenticeship, transition validation, industrial readiness, pilots/ARIA, project scenarios | Local evidence | Reports the exact missing file and does not fabricate rows |

Read `outputs/methodology_v3/public_data_status_v3.csv` with `outputs/methodology_v3/methodology_v3_module_status.csv`.
