# Iowa AI Workforce Atlas v3.1.3-clean-r9 validation report

## Observed revision-8 failure

The target Mac produced a staged 26,552-byte PDF and Chromium reported that the
bytes were written, but the browser parent process remained alive until both
60-second attempts timed out. Revision 8 incorrectly made browser exit a
condition of success. It also returned a character path, whereas the publication
manifest expects a validation list with page and byte metadata.

## Revision-9 remediation

- Detects `%PDF-` and a terminal `%%EOF` marker.
- Requires the complete file size to remain stable before live-process acceptance.
- Runs the existing page-count/content validator before accepting the file.
- Kills the browser process tree only after the PDF is complete and validated.
- Treats the allocator warning as nonfatal only when the output file passes all
  PDF checks.
- Returns `valid`, `pages`, `bytes`, `attempt`, and `tagged` to the report manifest.
- Uses transactional staging/promotion and retains prior valid publications.
- Caps each browser attempt at 240 seconds even when a legacy caller passes 900 or 1,200 seconds.
- Uses union-column status writing so earlier diagnostic CSV schemas cannot break
  a later run.

## Static and archive checks

The build process checked:

- revision-9 module and entry-point references;
- stable-file, EOF, process-kill, return-contract, and transactional-promotion
  source markers;
- balanced delimiters and closed string literals in changed R files;
- no literal Census or BEA keys;
- no user-specific absolute paths;
- no unsafe or duplicate ZIP paths;
- byte-for-byte archive extraction;
- SHA-256 manifest coverage.

## Runtime validation required

This Linux packaging environment cannot execute R 4.4.0 or macOS Chrome. The
definitive target test is:

```r
source("verify_install.R")
source("tests/smoke_test_v313.R")
Sys.setenv(IA_ATLAS_BROWSER_PDF_TIMEOUT_SECONDS = "120")
source("resume_publication_from_stage5.R")
```

The smoke test should now finish shortly after the staged PDF becomes complete,
even if Chrome emits the allocator warning and would otherwise remain alive.
