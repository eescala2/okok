# Iowa AI Workforce Atlas v3.1.3-clean-r6 validation report

## Observed failure

The revision-5 Stage 6 process passed the earlier alluvial repair and completed
construction of all 40 Methodology v2 DrawingML figures. During XLSX
serialization, `openxlsx2` warned that 13 `/xl/media/image*.png` files were
missing. The Atlas validator then confirmed 13 dangling drawing relationship
targets while all 40 drawing XML parts were present. Because package validation
failed, no valid revision-5 v2 checkpoint was written.

## Root cause

Revision 5 accepted `openxlsx2` 1.25. The upstream package issue reproduces
image loss in 1.25, the `openxlsx2` 1.26 changelog records restoration of image
handling broken in 1.24, and the corresponding patch explicitly registers
raster files produced by `rvg::dml_xlsx()`. This precisely matches the Atlas
package: vector DrawingML parts survived while companion raster media did not.

The warning's `wb$clone()$save()` call path also showed that the prior
`wb_save()` wrapper cloned the workbook before serialization. Revision 6 uses
the documented bound `wbWorkbook$save()` method instead.

## Corrective changes

- Raised the minimum loaded `openxlsx2` namespace version to 1.26.0.
- Added an early Stage 6 version gate, before reconstructing 40 figures.
- Compare the loaded namespace version rather than only the installed package
  files, preventing an old namespace from surviving an in-session upgrade.
- Replaced maintained `openxlsx2::wb_save()` calls with the bound
  `wbWorkbook$save()` method.
- Serialize to a same-directory temporary XLSX package.
- Validate ZIP readability, DrawingML counts, media counts, and every internal
  OOXML relationship before publishing the file.
- Preserve and restore any prior workbook if promotion or final validation
  fails.
- Added a raster-bearing `rvg` smoke workbook that must contain at least one
  `xl/media` part and zero missing relationship targets.
- Added a cross-workbook worksheet-clone smoke test for the consolidated
  workbook.
- Clone complete Methodology v3 worksheets into the consolidated workbook so
  data, drawings, media, and relationship parts travel together.
- Prevent article-sheet replacements from double-counting drawings in their
  required minimum; no-op article updates no longer rewrite a large workbook.
- Record loaded `openxlsx2` and `rvg` versions in the Stage 6 completion
  manifest.
- Use a new `.stage6_checkpoints_r6` namespace so broken revision-5 workbooks
  cannot be accepted as completed checkpoints.
- Preserve all earlier renderer, public-source, alluvial-stat, Cairo/X11, and
  restartable-checkpoint repairs.

## Static validation completed

- 52 R scripts passed lexical string and delimiter checks.
- 21 of 21 source-contract and structural checks passed.
- 40 CSV files have consistent row widths.
- 3 YAML files parse successfully.
- Every literal maintained R source/reference target resolves, with the
  generated one-click temporary runner correctly treated as a runtime artifact.
- No `.DS_Store`, `__MACOSX`, editor backup, Python cache, exposed API-key
  value, user-specific macOS home path, or user-specific Windows path remains.
- Maintained publication code contains no Cairo/X11 runtime calls.
- Maintained workbook code contains no `openxlsx2::wb_save()` call.
- The Stage 6 resume excludes both executable analytical runners.
- The smoke test exercises the exact raster-media registration and
  cross-workbook media-cloning contracts.

## Runtime validation boundary

R is not installed in the packaging container. Runtime confirmation is
therefore delegated to the expanded R 4.4 smoke test on macOS ARM64 and Windows
x64. The smoke test is intentionally placed before the long 40-figure rebuild
and now detects the exact raster-media regression that escaped revision 5.

## Archive packaging validation

The final package build is checked for complete internal SHA-256 manifest
coverage, matching manifest hashes, duplicate ZIP members, unsafe or absolute
ZIP paths, source/archive inventory differences, byte-for-byte extraction,
secret values, user-specific paths, and macOS/Python archive debris. The full
archive contains one rooted project directory; the overlay contains only
relative replacement paths plus its application instructions.
