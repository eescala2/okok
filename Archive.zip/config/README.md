# Versioned methodology configuration

Do not edit scoring thresholds or geography inside plotting/report functions. Change the relevant configuration file and rerun the workflow.

| File | Purpose |
|---|---|
| `methodology_v2.yml` | Build policy, score weights, partial-pooling strength, reliability, capacity, and pathway constraints |
| `score_schema.csv` | Required score types, units, ranges, and missing-value policy |
| `action_taxonomy.csv` | Action labels, order, colors, actionable status, and descriptions |
| `action_thresholds.csv` | Proactive, balanced, and cautious employment-weighted percentile thresholds |
| `score_weight_scenarios.csv` | Alternative composite-score stress tests |
| `county_lwda_crosswalk.csv` | Versioned Iowa county-to-original-LWDA assignment |
| `lwda_combinations.csv` | Versioned Mississippi Valley/South Central combination and report display names |
| `task_channel_dictionary.csv` | Transparent task-text patterns and weights |
| `sector_channel_modifiers.csv` | Explicit scenario adjustments for new-task and physical-AI channels |
| `source_registry.csv` | Source URLs, file patterns, vintages, required status, and analytical roles |
| `observed_input_schema.csv` | Required units and fields for adoption/outcome inputs |
| `onet_versions.csv` | Production O*NET version and retention policy |

Every configuration file is hashed into `outputs/methodology_v2/configuration_provenance.csv` and the build manifest.
