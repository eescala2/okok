# Local Methodology v3 inputs

These CSVs are **header-only schemas**, not observations. Copy the appropriate `_template.csv` file to the same name without `_template`, then populate it with authorized local evidence. The workflow deliberately reports a module as unavailable when required local evidence is absent; it does not generate example evidence.
